# GitHub publication notes

This source package was prepared from the supplied project archive.

- `config/config.local.php` is intentionally excluded. Copy `config/config.sample.php` to `config/config.local.php` and enter your own database credentials.
- Runtime database backups in `storage/backups/` are intentionally excluded.
- The SQL files under `database/` are schema/setup scripts; review them before importing into a live database.
- Change any database password or other credential that has previously been shared in an archive.
- Keep the repository private unless you have verified that all included source, assets, and sample data are suitable for sharing.
