<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Server-rendered SVG charts (no JavaScript): vertical bars with a data table, and horizontal comparison bars. */

/** "12.5" style number for chart labels (trailing zeros trimmed). */
function chart_number(float $value): string
{
    return rtrim(rtrim(number_format($value, 1, '.', ''), '0'), '.') ?: '0';
}

/**
 * Vertical bar chart as inline SVG (no JavaScript, prints well) plus a data table for screen readers.
 *
 * @param string[] $labels
 * @param float[]  $values
 */
function bar_chart(string $title, array $labels, array $values, string $unit = 'h'): string
{
    $count = count($values);
    if ($count === 0) {
        return '';
    }
    static $chartNo = 0;
    $cid   = ++$chartNo;
    $max   = max(1.0, (float) max($values));
    $step  = $max <= 10 ? 2.0 : ($max <= 50 ? 10.0 : ($max <= 200 ? 50.0 : 100.0));
    $top   = ceil($max / $step) * $step;
    $w = 640; $h = 280; $left = 44; $bottom = 34; $topPad = 22; $right = 10;
    $plotW = $w - $left - $right; $plotH = $h - $bottom - $topPad;
    $slot  = $plotW / $count;
    $barW  = min(46.0, $slot * 0.62);

    $svg = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-labelledby="chart-t' . $cid . '" preserveAspectRatio="xMidYMid meet">'
        . '<title id="chart-t' . $cid . '">' . e($title) . '</title>';
    for ($g = 0.0; $g <= $top + 0.001; $g += $step) {
        $y = $topPad + $plotH - ($g / $top * $plotH);
        $svg .= '<line class="chart-grid" x1="' . $left . '" x2="' . ($w - $right) . '" y1="' . round($y, 1) . '" y2="' . round($y, 1) . '"/>'
            . '<text class="chart-axis" x="' . ($left - 6) . '" y="' . round($y + 4, 1) . '" text-anchor="end">' . chart_number($g) . '</text>';
    }
    foreach ($values as $i => $value) {
        $barH = $top > 0 ? $value / $top * $plotH : 0;
        $x    = $left + $i * $slot + ($slot - $barW) / 2;
        $y    = $topPad + $plotH - $barH;
        $svg .= '<rect class="chart-bar" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($barW, 1) . '" height="' . round($barH, 1) . '" rx="3"/>';
        if ($value > 0) {
            $svg .= '<text class="chart-value" x="' . round($x + $barW / 2, 1) . '" y="' . round($y - 5, 1) . '" text-anchor="middle">' . chart_number((float) $value) . '</text>';
        }
        $svg .= '<text class="chart-axis" x="' . round($x + $barW / 2, 1) . '" y="' . ($h - 12) . '" text-anchor="middle">' . e($labels[$i] ?? '') . '</text>';
    }
    $svg .= '</svg>';

    $rows = '';
    foreach ($values as $i => $value) {
        $rows .= '<tr><th scope="row">' . e($labels[$i] ?? '') . '</th><td>' . chart_number((float) $value) . ' ' . e($unit) . '</td></tr>';
    }
    return '<figure class="chart-figure"><figcaption>' . e($title) . '</figcaption>' . $svg
        . '<details class="chart-data"><summary>View data as a table</summary><div class="table-wrap"><table><tbody>' . $rows . '</tbody></table></div></details></figure>';
}

/**
 * Horizontal bars for comparing groups (courses, duty days).
 *
 * @param array<int, array{label: string, value: float, note?: string}> $items
 */
function hbar_chart(string $title, array $items, string $unit = 'h'): string
{
    if (!$items) {
        return '';
    }
    $max  = max(1.0, (float) max(array_column($items, 'value')));
    $html = '<figure class="hbar-figure"><figcaption>' . e($title) . '</figcaption><ul class="hbar-list">';
    foreach ($items as $item) {
        $pct   = $item['value'] / $max * 100;
        $html .= '<li><span class="hbar-label">' . e($item['label']) . '</span>'
            . '<span class="hbar-track" aria-hidden="true"><span style="width:' . number_format($pct, 1, '.', '') . '%"></span></span>'
            . '<span class="hbar-value">' . chart_number((float) $item['value']) . ' ' . e($unit) . (isset($item['note']) ? ' <small>' . e($item['note']) . '</small>' : '') . '</span></li>';
    }
    return $html . '</ul></figure>';
}
