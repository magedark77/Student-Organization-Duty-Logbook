<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Form fields and list controls (filters, sorting, pagination). */

/** Render an attribute list: ['data-x' => 'y', 'disabled' => true]. */
function html_attrs(array $attrs): string
{
    $out = '';
    foreach ($attrs as $name => $value) {
        if ($value === false || $value === null) {
            continue;
        }
        $out .= ' ' . e($name) . ($value === true ? '' : '="' . e($value) . '"');
    }
    return $out;
}

/** Label text, with a visible (and screen-reader-friendly) marker when the field is required. */
function field_label_text(string $label, array $attrs): string
{
    // One wrapper element: <label> is a CSS grid, so bare text plus a span would otherwise sit on separate rows.
    return '<span class="label-text">' . e($label) . (!empty($attrs['required']) ? ' <span class="req" title="Required">*<span class="sr-only"> (required)</span></span>' : '') . '</span>';
}

/** Error message element shown under a field, plus the attributes that tie it to the control. */
function field_error_html(string $name): string
{
    $message = field_error($name);
    return $message !== '' ? '<span class="field-error" id="err-' . e($name) . '" role="alert">' . e($message) . '</span>' : '';
}

function field_error_attrs(string $name): array
{
    return field_error($name) !== '' ? ['aria-invalid' => 'true', 'aria-describedby' => 'err-' . $name] : [];
}

/** Labelled text-like input. $attrs may hold type, required, maxlength, placeholder, … */
function field_input(string $label, string $name, string $value = '', array $attrs = []): string
{
    return '<label>' . field_label_text($label, $attrs) . '<input name="' . e($name) . '" value="' . e($value) . '"'
        . html_attrs($attrs + field_error_attrs($name)) . '>' . field_error_html($name) . '</label>';
}

/** Labelled <select>. $placeholder adds an empty first option. */
function field_select(string $label, string $name, array $options, string $selected = '', array $attrs = [], ?string $placeholder = null): string
{
    $html = '<label>' . field_label_text($label, $attrs) . '<select name="' . e($name) . '"' . html_attrs($attrs + field_error_attrs($name)) . '>';
    if ($placeholder !== null) {
        $html .= '<option value="">' . e($placeholder) . '</option>';
    }
    $isList = array_is_list($options);
    foreach ($options as $value => $text) {
        $value  = $isList ? (string) $text : (string) $value; // a list uses the text as the value; a map is value => label
        $html  .= '<option value="' . e($value) . '"' . ($value === $selected ? ' selected' : '') . '>' . e((string) $text) . '</option>';
    }
    return $html . '</select>' . field_error_html($name) . '</label>';
}

/** Labelled <textarea>. */
function field_textarea(string $label, string $name, string $value = '', array $attrs = [], string $hint = ''): string
{
    return '<label>' . field_label_text($label, $attrs) . '<textarea name="' . e($name) . '"' . html_attrs($attrs + field_error_attrs($name)) . '>'
        . e($value) . '</textarea>' . ($hint !== '' ? '<span class="hint">' . e($hint) . '</span>' : '') . field_error_html($name) . '</label>';
}

/** Labelled password input. */
function field_password(string $label, string $name, array $attrs = [], string $hint = ''): string
{
    return '<label>' . field_label_text($label, $attrs) . '<input type="password" name="' . e($name) . '"' . html_attrs($attrs + field_error_attrs($name)) . '>'
        . ($hint !== '' ? '<span class="hint">' . e($hint) . '</span>' : '') . field_error_html($name) . '</label>';
}

/** Small POST form with a confirmation prompt (handled by app.js via data-confirm). */
function delete_form(string $action, int $id, string $confirm, array $hidden = [], string $label = 'Delete'): string
{
    $html = '<form method="post" action="' . e($action) . '" data-confirm="' . e($confirm) . '">'
        . csrf_field()
        . '<input type="hidden" name="action" value="delete">'
        . '<input type="hidden" name="id" value="' . $id . '">';
    foreach ($hidden as $name => $value) {
        $html .= '<input type="hidden" name="' . e($name) . '" value="' . e($value) . '">';
    }
    return $html . '<button class="btn danger btn-sm" type="submit">' . e($label) . '</button></form>';
}

/**
 * Small POST form with one button, for actions that are not deletions (deactivate, approve, cancel…).
 * $confirm adds a confirmation prompt; $hidden is extra hidden fields.
 */
function action_form(string $action, string $name, int $id, string $label, string $class = 'secondary', string $confirm = '', array $hidden = []): string
{
    $html = '<form method="post" action="' . e($action) . '"' . ($confirm !== '' ? ' data-confirm="' . e($confirm) . '"' : '') . '>'
        . csrf_field() . '<input type="hidden" name="action" value="' . e($name) . '"><input type="hidden" name="id" value="' . $id . '">';
    foreach ($hidden as $field => $value) {
        $html .= '<input type="hidden" name="' . e($field) . '" value="' . e($value) . '">';
    }
    return $html . '<button class="btn ' . e($class) . ' btn-sm" type="submit">' . e($label) . '</button></form>';
}

/**
 * Resolve ?sort=&dir= against a whitelist.
 * $allowed: ['key' => label]. Returns [key, 'asc'|'desc'].
 */
function sort_from_request(array $allowed, string $default, string $defaultDir = 'asc'): array
{
    $key = get_str('sort');
    $dir = strtolower(get_str('dir'));
    if (!isset($allowed[$key])) {
        return [$default, $defaultDir];
    }
    return [$key, $dir === 'desc' ? 'desc' : 'asc'];
}

/**
 * Sortable <th>: click to sort, click again to reverse. $query keeps the other filters.
 * With $sort = null it renders a plain header, so one template serves sortable and static tables.
 */
function sort_th(string $label, string $key, ?array $sort, string $baseUrl = '', array $query = []): string
{
    if ($sort === null) {
        return '<th scope="col">' . e($label) . '</th>';
    }
    [$cur, $dir] = $sort;
    $active = $cur === $key;
    $next   = $active && $dir === 'asc' ? 'desc' : 'asc';
    $href   = $baseUrl . '?' . http_build_query(array_merge($query, ['sort' => $key, 'dir' => $next]));
    $arrow  = $active ? ($dir === 'asc' ? ' ▲' : ' ▼') : '';
    return '<th scope="col"' . ($active ? ' aria-sort="' . ($dir === 'asc' ? 'ascending' : 'descending') . '"' : '') . '>'
        . '<a class="sort-link' . ($active ? ' active' : '') . '" href="' . e($href) . '">' . e($label) . $arrow . '</a></th>';
}

/** Drop empty values so URLs stay clean. */
function clean_query(array $q): array
{
    return array_filter($q, static fn($v) => $v !== '' && $v !== null);
}

/**
 * Clamp a requested page number and work out the SQL offset.
 *
 * @return array{page: int, pages: int, offset: int}
 */
function paginate(int $total, int $perPage, int $requestedPage): array
{
    $pages = max(1, (int) ceil($total / max(1, $perPage)));
    $page  = min(max(1, $requestedPage), $pages);
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage];
}

/**
 * Page links for a long list: Previous, 1 … 4 5 6 … 20, Next.
 * $query holds the filters/sort to keep; the page number is added as ?page=N.
 */
function pagination(int $page, int $pages, string $baseUrl, array $query = []): string
{
    if ($pages <= 1) {
        return '';
    }
    $href = static function (int $target) use ($baseUrl, $query): string {
        $params = $target > 1 ? $query + ['page' => $target] : $query;
        return $baseUrl . ($params ? '?' . http_build_query($params) : '');
    };

    $html = '<nav class="pagination no-print" aria-label="Pagination">';
    $html .= $page > 1
        ? '<a class="page-link" rel="prev" href="' . e($href($page - 1)) . '">&lsaquo; Previous</a>'
        : '<span class="page-link disabled" aria-disabled="true">&lsaquo; Previous</span>';

    $shown = array_unique(array_filter([1, $page - 1, $page, $page + 1, $pages], static fn(int $p): bool => $p >= 1 && $p <= $pages));
    sort($shown);
    $previous = 0;
    foreach ($shown as $number) {
        if ($number - $previous > 1) {
            $html .= '<span class="page-gap" aria-hidden="true">&hellip;</span>';
        }
        $html .= $number === $page
            ? '<span class="page-link active" aria-current="page">' . $number . '</span>'
            : '<a class="page-link" href="' . e($href($number)) . '" aria-label="Page ' . $number . '">' . $number . '</a>';
        $previous = $number;
    }

    $html .= $page < $pages
        ? '<a class="page-link" rel="next" href="' . e($href($page + 1)) . '">Next &rsaquo;</a>'
        : '<span class="page-link disabled" aria-disabled="true">Next &rsaquo;</span>';
    return $html . '</nav>';
}
