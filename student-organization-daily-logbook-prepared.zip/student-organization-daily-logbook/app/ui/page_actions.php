<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * POST handlers shared by more than one page, for use with handle_post().
 * Each returns action name => handler; a handler flashes its own success message and throws ValidationException to refuse.
 */

/** Deactivate / reactivate a student (login off or on, attendance kept). Used by the student list and the student page. */
function student_lifecycle_handlers(int $studentId): array
{
    $toggle = static function (bool $active) use ($studentId): callable {
        return static function () use ($studentId, $active): void {
            student_set_active($studentId, $active);
            flash('success', $active
                ? 'Student reactivated. Their login works again.'
                : 'Student deactivated. Their login is disabled and all attendance records are kept.');
        };
    };
    return ['deactivate' => $toggle(false), 'reactivate' => $toggle(true)];
}

/**
 * Create a one-time password-reset link for $userId and keep it in the session so the next page load shows it once.
 * $noLoginMessage is shown when the person has no login ($userId null); $who is "student" or "officer".
 */
function reset_link_handler(?int $userId, string $who, string $noLoginMessage): callable
{
    return static function () use ($userId, $who, $noLoginMessage): void {
        if ($userId === null) {
            throw new ValidationException($noLoginMessage);
        }
        $_SESSION['reset_link'] = password_reset_create($userId);
        flash('success', "Reset link created. Copy it now and send it to the {$who}; it is shown only once.");
    };
}

/** Take the reset link saved by reset_link_handler() out of the session (it is shown only once). */
function pull_reset_link(): ?array
{
    $link = $_SESSION['reset_link'] ?? null;
    unset($_SESSION['reset_link']);
    return $link;
}
