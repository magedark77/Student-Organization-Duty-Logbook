<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* List-page filtering: the filter bar, its controls, and the standard student filter group. */

/**
 * Toolbar <select> that submits its form on change (see data-autosubmit in app.js).
 *
 * $options is either a list (value = text) or [value => text].
 * $placeholder adds an empty first option such as "All courses".
 */
function toolbar_select(string $name, string $label, array $options, string $selected = '', ?string $placeholder = null): string
{
    $isList = array_is_list($options);
    $html   = '<select name="' . e($name) . '" aria-label="' . e($label) . '" data-autosubmit>';
    if ($placeholder !== null) {
        $html .= '<option value="">' . e($placeholder) . '</option>';
    }
    foreach ($options as $value => $text) {
        $value = $isList ? (string) $text : (string) $value;
        $html .= '<option' . ($isList ? '' : ' value="' . e($value) . '"') . ($value === $selected ? ' selected' : '') . '>' . e($text) . '</option>';
    }
    return $html . '</select>';
}

/**
 * The "Sort by" and "Direction" selects shared by every filter toolbar.
 *
 * $sortOptions: ['key' => 'Label']. $sort: [key, 'asc'|'desc'] from sort_from_request().
 * $directions:  ['asc' => 'Ascending', 'desc' => 'Descending'] (order and wording can be changed).
 */
function sort_controls(array $sortOptions, array $sort, array $directions = ['asc' => 'Ascending', 'desc' => 'Descending']): string
{
    return toolbar_select('sort', 'Sort by', array_map(static fn(string $label): string => 'Sort: ' . $label, $sortOptions), $sort[0])
        . toolbar_select('dir', 'Direction', $directions, $sort[1]);
}

/** Search box for a filter bar. */
function search_input(string $name, string $value, string $placeholder, string $label = ''): string
{
    return '<input type="search" name="' . e($name) . '" value="' . e($value) . '" placeholder="' . e($placeholder) . '" aria-label="' . e($label !== '' ? $label : $placeholder) . '">';
}

/**
 * The filter form shared by every list and report page: the given controls, then (optionally) Apply, a Reset link and extras.
 * Selects and date fields submit themselves (data-autosubmit); a search box submits on Enter, and also after a short
 * pause in typing when there is no Apply button. On phones the controls fold
 * behind a "Filters" button (open automatically when a filter is active); everywhere else, and without JavaScript, they are
 * always visible.
 *
 * Options:
 *   active  int                     how many filters are applied (shown on the Filters button)
 *   hidden  array<string, string>   values kept when the form is submitted (selected duty day, current sort, …); empty values are skipped
 *   extra   string[]                trusted HTML placed after the buttons (e.g. a Print button)
 *   apply   string|null             label of the Apply button; null leaves it out
 *   reset   string|null             URL of the "Reset filters" link; null leaves it out (default: the form's own URL)
 *
 * @param string[]             $controls trusted HTML from search_input(), toolbar_select(), sort_controls(), date fields …
 * @param array<string, mixed> $options
 */
function filter_bar(string $action, array $controls, array $options = []): string
{
    $active = (int) ($options['active'] ?? 0);
    $apply  = array_key_exists('apply', $options) ? $options['apply'] : 'Apply';
    $reset  = array_key_exists('reset', $options) ? $options['reset'] : $action;

    // Without an Apply button the search box submits itself shortly after typing stops (see data-live-search in app.js).
    $html = '<form class="filter-bar no-print" method="get" action="' . e($action) . '" role="search"' . ($apply === null ? ' data-live-search' : '') . '>';
    foreach (clean_query((array) ($options['hidden'] ?? [])) as $name => $value) {
        $html .= '<input type="hidden" name="' . e($name) . '" value="' . e($value) . '">';
    }
    $html .= '<details class="filter-details" open data-active="' . $active . '">'
        . '<summary class="filter-toggle">' . icon('search') . '<span>Filters</span>'
        . ($active > 0 ? '<span class="badge info">' . $active . ' active</span>' : '') . '</summary>'
        . '<div class="filter-fields">' . implode('', $controls);

    $actions = ($apply !== null ? '<button class="btn primary" type="submit">' . e($apply) . '</button>' : '')
        . ($reset !== null ? '<a class="btn secondary" href="' . e($reset) . '">Reset filters</a>' : '')
        . implode('', (array) ($options['extra'] ?? []));
    if ($actions !== '') {
        $html .= '<div class="filter-actions">' . $actions . '</div>';
    }
    return $html . '</div></details></form>';
}

/**
 * Hidden-field values that keep the current sort when a filter form is submitted (the sort controls themselves are
 * not shown on every page; the column headers change it). Returns [] for the default sort so URLs stay clean.
 *
 * @param array{0: string, 1: string} $sort    from sort_from_request()
 * @param array{0: string, 1: string} $default the page's default sort
 */
function sort_hidden(array $sort, array $default = ['name', 'asc']): array
{
    return $sort === $default ? [] : ['sort' => $sort[0], 'dir' => $sort[1]];
}

/**
 * The student filters most report pages share: duty day, course, status and (optionally) a name/number search.
 * $filters comes from student_filters_from_request(); $statusPlaceholder labels the "no status chosen" option.
 *
 * @return string[] controls for filter_bar()
 */
function student_filter_controls(array $filters, array $courses, string $statusPlaceholder = 'Any status', bool $withSearch = true, bool $withCourse = true): array
{
    $controls = [
        toolbar_select('year', 'Duty day', DUTY_DAYS, $filters['year'], 'All days'),
        toolbar_select('status', 'Status', STUDENT_STATUSES, $filters['status'], $statusPlaceholder),
    ];
    if ($withCourse) {
        array_splice($controls, 1, 0, [toolbar_select('course', 'Course', $courses, $filters['course'], 'All courses')]);
    }
    if ($withSearch) {
        $controls[] = search_input('q', $filters['q'], 'Search name or number', 'Search students');
    }
    return $controls;
}

/** A labelled number/date input that sits inline in a filter bar ("Year [2026]"). */
function inline_field(string $label, string $name, string $value, array $attrs = []): string
{
    return '<label class="inline-label">' . e($label) . ' <input name="' . e($name) . '" value="' . e($value) . '"' . html_attrs($attrs + ['aria-label' => $label]) . '></label>';
}
