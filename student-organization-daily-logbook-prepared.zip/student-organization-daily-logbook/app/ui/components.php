<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Display components: alerts, badges, progress bars, stat cards, tables, hero banner and modals. (Icons: icons.php) */

/** Empty-table placeholder row. */
function empty_row(int $columns, string $message): string
{
    return '<tr class="empty-row"><td colspan="' . $columns . '">' . e($message) . '</td></tr>';
}

/**
 * Open a scrollable, keyboard-focusable table region. Close it with table_end().
 * With $stack = true the rows turn into labelled cards on phones (cells need a data-label attribute).
 */
function table_start(string $label, bool $stack = false): void
{
    echo '<div class="table-wrap' . ($stack ? ' table-stack' : '') . '" role="region" aria-label="' . e($label) . '" tabindex="0"><table>';
}

function table_end(): void
{
    echo '</table></div>';
}

/**
 * Heading row of a card: optional icon + title on the left, $aside on the right.
 * $aside is trusted markup: usually section_link(), a badge or status_indicator(). $id lets a card's aria-labelledby point at the title.
 */
function section_head(string $title, string $icon = '', string $aside = '', string $id = ''): string
{
    return '<div class="section-head"><h2' . ($id !== '' ? ' id="' . e($id) . '"' : '') . '>' . ($icon !== '' ? icon($icon) . ' ' : '') . e($title) . '</h2>' . $aside . '</div>';
}

/** "View All →" style link for the right side of a section_head(). */
function section_link(string $label, string $href): string
{
    return '<a class="link-more" href="' . e($href) . '">' . e($label) . ' ' . icon('arrow') . '</a>';
}

/** Dashboard banner. $text is plain text; $actionsHtml is trusted markup (buttons/links). */
function hero(string $text, string $actionsHtml = ''): void
{
    echo '<section class="card dashboard-hero"><div class="hero-copy">'
        . '<span class="hero-eyebrow">' . e(APP_SHORT_NAME) . '</span>'
        . '<h2>Different Minds.<em>One Community.</em></h2>'
        . '<p>' . e($text) . '</p>'
        . ($actionsHtml !== '' ? '<div class="actions hero-actions">' . $actionsHtml . '</div>' : '')
        . '</div><div class="hero-art" aria-hidden="true">'
        . '</div></section>';
}

function alert(string $type, string $message): void
{
    $type = in_array($type, ['success', 'danger', 'warning', 'info'], true) ? $type : 'info';
    $role = $type === 'danger' ? 'alert' : 'status';
    echo '<div class="alert ' . $type . '" role="' . $role . '">' . e($message) . '</div>';
}

/** Badge for an audit-log action (CREATE / UPDATE / DELETE). */
function action_badge(string $action): string
{
    $variant = match ($action) {
        'CREATE' => 'success',
        'DELETE' => 'danger',
        'UPDATE' => 'info',
        'LOGIN_FAILED' => 'warning',
        'BACKUP', 'RESTORE' => 'info',
        default  => 'neutral',
    };
    return '<span class="badge ' . $variant . '">' . e($action) . '</span>';
}

function status_badge(string $status): string
{
    $variant = match ($status) {
        'Active'    => 'success',
        'Inactive'  => 'warning',
        'Graduated' => 'info',
        default     => 'neutral',
    };
    return '<span class="badge ' . $variant . '">' . e($status) . '</span>';
}

function progress_bar(float $percent, string $label = 'Progress'): string
{
    $p = max(0.0, min(100.0, $percent));
    return '<div class="progress" role="progressbar" aria-label="' . e($label) . '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) round($p) . '">'
        . '<span style="width:' . number_format($p, 1, '.', '') . '%"></span></div>';
}

/** Coloured hours text: tone 'done' (green) or 'left' (orange; green when nothing is left). */
function hours_span(string $text, string $tone): string
{
    return '<span class="hours hours-' . e($tone) . '">' . e($text) . '</span>';
}

/** Unread-count pill. Always rendered (hidden at 0) so app.js can show it when new notifications arrive. */
function notification_badge(int $count): string
{
    return '<span class="notif-badge" data-notif-badge' . ($count > 0 ? '' : ' hidden') . '>' . ($count > 99 ? '99+' : $count) . '</span>';
}

/** Metric card used on dashboards and student profiles. */
function stat_card(string $label, string $value, string $sub = '', string $icon = '', string $tone = ''): void
{
    echo '<div class="card stat-card' . ($tone !== '' ? ' tone-' . e($tone) : '') . '">';
    if ($icon !== '') {
        echo '<span class="stat-icon">' . icon($icon) . '</span>';
    }
    echo '<div class="stat-body"><div class="stat-label">' . e($label) . '</div>'
        . '<div class="stat-value">' . e($value) . '</div>';
    if ($sub !== '') {
        echo '<div class="stat-sub">' . e($sub) . '</div>';
    }
    echo '</div></div>';
}

/**
 * Open a modal dialog. Close it with modal_end(). The server decides whether
 * it starts open; app.js handles closing (Escape, backdrop, close button).
 * $clearParams: query-string keys to remove from the URL when it closes.
 */
function modal_start(string $id, string $title, bool $open = false, array $clearParams = []): void
{
    echo '<div class="modal' . ($open ? ' is-open' : '') . '" id="' . e($id) . '" role="dialog" aria-modal="true"'
        . ' aria-labelledby="' . e($id) . '-title" aria-hidden="' . ($open ? 'false' : 'true') . '"'
        . ($clearParams ? ' data-clear-params="' . e(implode(',', $clearParams)) . '"' : '') . '>';
    echo '<div class="modal-box"><div class="modal-head"><h2 id="' . e($id) . '-title">' . e($title) . '</h2>'
        . '<button type="button" class="icon-btn" data-modal-close aria-label="Close dialog">&times;</button></div>';
}

function modal_end(): void
{
    echo '</div></div>';
}

/** Brand mark: three people under one arch (decorative). Colour comes from CSS (.brand-logo). */
function brand_logo(int $size = 40): string
{
    return '<svg class="brand-logo" width="' . (int) round($size * 1.5) . '" height="' . $size . '" viewBox="0 0 96 64" fill="none" aria-hidden="true" focusable="false"'
        . ' stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round">'
        . '<circle cx="48" cy="12" r="6.5"/><path d="M35 52V36a13 13 0 0 1 26 0v16"/>'
        . '<circle cx="21" cy="25" r="5.5"/><path d="M8 52V44a12 12 0 0 1 8-11.3"/>'
        . '<circle cx="75" cy="25" r="5.5"/><path d="M88 52V44a12 12 0 0 0-8-11.3"/></svg>';
}

/** One or two capital letters for the avatar: "rico.santos" -> "RS", "admin" -> "AD". */
function user_initials(string $name): string
{
    $parts = preg_split('/[\s._-]+/', trim($name), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    if (count($parts) >= 2) {
        return mb_strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1));
    }
    return mb_strtoupper(mb_substr($name, 0, 2));
}

/**
 * Secondary or destructive row actions folded behind a "More" button, so a table row shows its main actions and
 * a safe default. It opens in place (not as a floating popover, which a scrolling table would clip).
 *
 * @param string[] $items trusted HTML: action_form(), delete_form(), links
 */
function action_menu(array $items, string $accessibleName = 'More actions', string $label = 'More'): string
{
    return '<details class="action-menu"><summary class="btn secondary btn-sm" aria-label="' . e($accessibleName) . '">' . e($label) . icon('chevron') . '</summary>'
        . '<div class="action-menu-items" role="group" aria-label="' . e($accessibleName) . '">' . implode('', $items) . '</div></details>';
}

/* ---- Navigation and status pieces ---------------------------------------------- */

/**
 * Breadcrumb trail. $trail: list of [label, href|null]; the last entry is the current page.
 * The first crumb should be the user's dashboard.
 */
function breadcrumbs(array $trail): string
{
    if (count($trail) < 2) {
        return '';
    }
    $html = '<nav class="breadcrumbs no-print" aria-label="Breadcrumb"><ol>';
    $last = count($trail) - 1;
    foreach ($trail as $i => [$label, $href]) {
        $html .= '<li>' . ($i === $last || $href === null
            ? '<span aria-current="page">' . e($label) . '</span>'
            : '<a href="' . e($href) . '">' . e($label) . '</a>') . '</li>';
    }
    return $html . '</ol></nav>';
}

/** Friendly "nothing here" block with an optional call to action ($actionHtml is trusted markup). */
function empty_state(string $title, string $text = '', string $actionHtml = '', string $icon = 'file'): string
{
    return '<div class="empty-state">' . icon($icon) . '<strong>' . e($title) . '</strong>'
        . ($text !== '' ? '<p>' . e($text) . '</p>' : '') . $actionHtml . '</div>';
}

/**
 * Status indicator that never relies on colour alone: every kind has its own icon and text.
 * Kinds: complete, incomplete, pending, urgent, info.
 */
function status_indicator(string $kind, ?string $text = null): string
{
    [$icon, $label, $tone] = match ($kind) {
        'complete'   => ['check', 'Completed', 'success'],
        'incomplete' => ['alert', 'Incomplete', 'warning'],
        'pending'    => ['clock', 'Pending', 'info'],
        'urgent'     => ['alert', 'Urgent', 'danger'],
        default      => ['activity', 'Info', 'neutral'],
    };
    return '<span class="status status-' . e($tone) . '">' . icon($icon) . '<span>' . e($text ?? $label) . '</span></span>';
}

/** Tab strip linking the report pages. $active is a key of the list below. */
function report_tabs(string $active): string
{
    $tabs = [
        'monthly'     => ['Monthly report', 'reports/monthly.php'],
        'outstanding' => ['Hours not completed', 'reports/outstanding.php'],
        'analytics'   => ['Charts & summaries', 'reports/analytics.php'],
    ];
    $html = '<nav class="subnav no-print" aria-label="Report type">';
    foreach ($tabs as $key => [$label, $path]) {
        $html .= '<a href="' . e(url($path)) . '"' . ($key === $active ? ' class="active" aria-current="page"' : '') . '>' . e($label) . '</a>';
    }
    return $html . '</nav>';
}
