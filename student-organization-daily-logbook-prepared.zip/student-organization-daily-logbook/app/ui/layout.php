<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/**
 * Relative prefix from the current script back to the project root
 * ('' at the root, '../' inside admin/, and so on). Works in any subfolder.
 */
function app_root_prefix(): string
{
    static $prefix = null;
    if ($prefix !== null) {
        return $prefix;
    }

    $root   = str_replace('\\', '/', (string) realpath(APP_ROOT));
    $script = str_replace('\\', '/', (string) realpath(dirname($_SERVER['SCRIPT_FILENAME'] ?? APP_ROOT)));

    if ($root === '' || !str_starts_with($script, $root)) {
        return $prefix = '';
    }
    $relative = trim(substr($script, strlen($root)), '/');
    return $prefix = $relative === '' ? '' : str_repeat('../', substr_count($relative, '/') + 1);
}

/**
 * URL of a project page, relative to the current page.
 * $query is appended as a clean query string (empty values are dropped):
 *     url('admin/attendance.php', ['date' => $date, 'edit' => 5])
 */
function url(string $path = '', array $query = []): string
{
    $result = app_root_prefix() . ltrim($path, '/');
    $query  = array_filter($query, static fn($v): bool => $v !== '' && $v !== null);
    if ($query) {
        $result .= (str_contains($result, '?') ? '&' : '?') . http_build_query($query);
    }
    return $result === '' ? './' : $result;
}

/** "1 record" / "3 records"; pass $plural for irregular words ("entry", "entries"). */
function plural(int $count, string $singular, ?string $plural = null): string
{
    return number_format($count) . ' ' . ($count === 1 ? $singular : ($plural ?? $singular . 's'));
}

/** URL of a static asset with a cache-busting version. */
function asset(string $path): string
{
    $file    = APP_ROOT . '/assets/' . $path;
    $version = is_file($file) ? (int) filemtime($file) : 0;
    return app_root_prefix() . 'assets/' . $path . '?v=' . $version;
}

/** Render app/views/<name>.php with $__vars available as local variables. */
function view(string $__template, array $__vars = []): void
{
    extract($__vars, EXTR_SKIP);
    require APP_ROOT . '/app/views/' . $__template . '.php';
}

/**
 * Sidebar navigation: key => [label, path, icon]. Items are chosen by role here, and every page repeats the same
 * check on the server (require_admin(), require_announcer(), …), so hiding a link is never the only protection.
 */
function nav_items(string $role): array
{
    $items = match (true) {
        $role === ROLE_ADMIN => [
            'dashboard'   => ['Dashboard', 'admin/dashboard.php', 'home'],
            'students'    => ['Students', 'admin/students.php', 'users'],
            'attendance'  => ['Attendance', 'admin/attendance.php', 'clipboard'],
            'qrscan'      => ['Scan QR Attendance', 'admin/qr-scanner.php', 'qr'],
            'qrmonitor'   => ['QR Monitor', 'admin/qr-attendance.php', 'activity'],
            'qrcodes'     => ['Student QR Codes', 'admin/qr-codes.php', 'qr'],
            'corrections' => ['Corrections', 'admin/corrections.php', 'check'],
            'reports'     => ['Reports', 'reports/monthly.php', 'chart'],
            'announce'    => ['Announcements', 'admin/announcements.php', 'megaphone'],
            'officers'    => ['Officer Accounts', 'admin/officers.php', 'officers'],
            'audit'       => ['Audit Logs', 'admin/audit-logs.php', 'file'],
            'backups'     => ['Backup & Recovery', 'admin/backups.php', 'shield'],
            'recovery'    => ['Account Recovery', 'admin/recovery.php', 'key'],
        ],
        in_array($role, STAFF_ROLES, true) => [
            'attendance' => ['Attendance & Duty Hours', 'admin/attendance.php', 'clipboard'],
            'record'     => ['Record Attendance', 'admin/record-attendance.php', 'plus'],
            'qrscan'     => ['Scan QR Attendance', 'admin/qr-scanner.php', 'qr'],
            'inbox'      => ['Announcement Inbox', 'my-announcements.php', 'megaphone'],
        ],
        default => [
            'dashboard'   => ['My Dashboard', 'student/dashboard.php', 'home'],
            'myqr'        => ['My QR Code', 'student/my-qr.php', 'qr'],
            'corrections' => ['My Corrections', 'student/corrections.php', 'check'],
            'inbox'       => ['Announcements', 'my-announcements.php', 'megaphone'],
        ],
    };

    if (in_array($role, ANNOUNCER_ROLES, true)) {
        $items['announce'] = ['Manage Announcements', 'admin/announcements.php', 'plus'];
    }

    return $items + [
        'notifications' => ['Notifications', 'notifications.php', 'bell'],
        'password' => ['Change Password', 'change-password.php', 'key'],
        'logout'   => ['Logout', 'logout.php', 'logout'],
    ];
}

/** Counts shown as pills on menu items: key => number (only keys the current role has). */
function nav_badges(?array $user): array
{
    if (!$user) {
        return [];
    }
    $badges = ['notifications' => notifications_unread_count((int) $user['id'])];
    if ($user['role'] === ROLE_ADMIN) {
        $badges['corrections'] = corrections_pending_count();
    } else {
        $badges['inbox'] = announcements_unread_summary((int) $user['id'])['unread'];
    }
    return $badges;
}

/** Small count pill for a menu item (hidden at 0). Unlike notification_badge() it is not refreshed by the poller. */
function nav_badge(int $count): string
{
    return $count > 0 ? '<span class="notif-badge nav-count"><span class="sr-only">' . $count . ' pending</span><span aria-hidden="true">' . ($count > 99 ? '99+' : $count) . '</span></span>' : '';
}

/** First breadcrumb of every page: the signed-in user's home page. */
function home_crumb(): array
{
    return [match (true) { is_admin() => 'Dashboard', is_restricted_staff() => 'Attendance', default => 'My Dashboard' }, home_url()];
}

/**
 * Open the HTML document. With ['bare' => true] only the <head> and <body>
 * are printed (login screen); otherwise the sidebar shell is rendered too.
 */
function render_header(string $title, string $active = '', array $options = []): void
{
    view('partials/header', [
        'title'     => $title,
        'active'    => $active,
        'bare'      => (bool) ($options['bare'] ?? false),
        'bodyClass' => (string) ($options['bodyClass'] ?? ''),
        'scripts'   => (array) ($options['scripts'] ?? []),  // extra files under assets/, e.g. 'js/qr-scanner.js'
        'styles'    => (array) ($options['styles'] ?? []),
    ]);
}

function render_footer(bool $bare = false): void
{
    view('partials/footer', ['bare' => $bare]);
}

/**
 * Page title bar followed by the security notice and flash message.
 *
 * $actions: list of ['label' => ..., 'href' => ..., 'class' => 'primary|secondary',
 * 'attrs' => [...]]. Entries without 'href' render as buttons.
 * $crumbs: breadcrumb trail, see breadcrumbs() (the dashboard crumb is added in front automatically).
 */
function page_head(string $title, string $subtitle = '', array $actions = [], array $crumbs = []): void
{
    view('partials/page-head', [
        'title'    => $title,
        'subtitle' => $subtitle,
        'actions'  => $actions,
        'crumbs'   => $crumbs,
    ]);
}
