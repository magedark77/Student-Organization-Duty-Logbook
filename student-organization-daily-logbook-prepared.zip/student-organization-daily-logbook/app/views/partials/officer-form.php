<?php
/**
 * Add / edit officer form (rendered inside a modal).
 * Required: $formAction. Optional: $edit (officer row), $roles (role => label, defaults to officer_role_options()).
 */
defined('APP_BOOT') || exit;

$edit  ??= null;
$roles ??= officer_role_options();
$field = static fn(string $key, string $default = '') => (string) old($key, $edit[$key] ?? $default);
$role  = $field('role');
?>
<form method="post" action="<?= e($formAction) ?>" class="form-stack"
      data-confirm-change-select="role"
      data-confirm-change-message="Change this officer's role? This changes what they are allowed to do.">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
    <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
    <p class="hint required-note"><span class="req" aria-hidden="true">*</span> marks required fields.</p>

    <div class="form-grid">
        <?= field_input('Username', 'username', $field('username'), ['required' => true, 'maxlength' => 100, 'autocomplete' => 'off']) ?>
        <?= field_select('Role', 'role', $roles, $role, ['required' => true, 'data-original' => $edit ? (string) $edit['role'] : ''], $role === '' || !isset($roles[$role]) ? '— Choose a role —' : null) ?>
        <?= field_password('Password', 'password', ['minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password', 'required' => !$edit,
            'placeholder' => $edit ? 'Leave blank to keep current' : 'At least ' . MIN_PASSWORD_LENGTH . ' characters']) ?>
    </div>
    <p class="hint">Officers can view and record attendance only during duty hours (<?= e(duty_hours_label()) ?>). To let an officer choose their own password, save the account and then use <strong>Create reset link</strong>.</p>

    <div class="form-actions">
        <button type="button" class="btn secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn primary">Save officer</button>
    </div>
</form>
