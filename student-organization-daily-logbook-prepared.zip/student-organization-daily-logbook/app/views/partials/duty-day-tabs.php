<?php
/**
 * "All Students" + Monday–Saturday tabs with student counts.
 *
 * Required: $active (selected duty day or ''), $counts (students_duty_day_counts()),
 *           $baseUrl, $query (filters to keep in every tab link, without the day)
 */
defined('APP_BOOT') || exit;

$tabs = ['' => ['All Students', 'All', $counts['all']]];
foreach (DUTY_DAYS as $day) {
    $tabs[$day] = [$day, substr($day, 0, 3), $counts['by_day'][$day]];
}
?>
<nav class="year-tabs" aria-label="Filter students by duty day">
    <?php foreach ($tabs as $day => [$label, $short, $count]):
        $href = $baseUrl . ($day === '' ? ($query ? '?' . http_build_query($query) : '') : '?' . http_build_query(['year' => $day] + $query)); ?>
        <a class="year-tab<?= $active === (string) $day ? ' active' : '' ?>"<?= $active === (string) $day ? ' aria-current="page"' : '' ?> href="<?= e($href) ?>">
            <span class="tab-icon" aria-hidden="true"><?= e($short) ?></span>
            <span><b><?= e($label) ?></b></span>
            <em><?= (int) $count ?></em>
        </a>
    <?php endforeach; ?>
</nav>
