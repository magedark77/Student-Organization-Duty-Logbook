<?php
/**
 * Create / edit attendance form, used on the record page and in the edit dialog.
 *
 * Required: $date, $context ('page' | 'modal')
 * Create mode: $students (active students). Edit mode: $edit (attendance_find() row).
 * Optional: $cancelHref (page context)
 */
defined('APP_BOOT') || exit;

$edit       ??= null;
$students   ??= [];
$cancelHref ??= url('admin/attendance.php');

// Previously submitted (invalid) values win over stored ones.
$timeValue = static fn(string $field, string $column) =>
    old($field, ($edit[$column] ?? null) !== null ? substr((string) $edit[$column], 0, 5) : '');
$remarks = old('remarks', $edit['remarks'] ?? '');
$isAdmin = is_admin();
// Admin-only: the reason box shows when editing, or when the server found an existing record for this student and date.
$needsReason = $edit !== null || field_error('confirm_overwrite') !== '' || (string) old('confirm_overwrite') === '1';
$timeField = static fn(string $label, string $name, string $column): string =>
    field_input($label, $name, (string) $timeValue($name, $column), ['type' => 'time', 'data-now' => true]);
?>
<form method="post" action="<?= e(url('admin/attendance.php')) ?>" class="form-stack attendance-form" data-attendance-form
      <?= $edit ? '' : 'data-check-url="' . e(url('admin/attendance-check.php')) . '"' ?>>
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <?php if ($edit): ?><input type="hidden" name="edit_id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
    <p class="hint required-note"><span class="req" aria-hidden="true">*</span> marks required fields. Time In and Time Out must be entered together.</p>

    <fieldset class="form-section">
        <legend>Student information</legend>
        <div class="form-grid">
            <?php if ($edit): ?>
                <input type="hidden" name="student_id" value="<?= (int) $edit['student_id'] ?>">
                <label>Student
                    <input type="text" value="<?= e(student_label($edit)) ?>" readonly data-student-label>
                </label>
                <label>Attendance date
                    <input type="date" name="attendance_date" value="<?= e($edit['attendance_date']) ?>" readonly>
                </label>
            <?php else:
                $selected = (string) old('student_id', (string) ($preselect ?? '')); ?>
                <label><?= field_label_text('Student', ['required' => true]) ?>
                    <select name="student_id" required data-student-select<?= field_error('student_id') !== '' ? ' aria-invalid="true" aria-describedby="err-student_id"' : '' ?>>
                        <option value="">Select a student</option>
                        <?php $group = null;
                        foreach ($students as $student):
                            if ($student['year_level'] !== $group):
                                if ($group !== null): ?></optgroup><?php endif;
                                $group = $student['year_level']; ?>
                                <optgroup label="<?= e($group) ?>">
                            <?php endif; ?>
                            <option value="<?= (int) $student['id'] ?>"<?= $selected === (string) $student['id'] ? ' selected' : '' ?>>
                                <?= e(student_label($student)) ?>
                            </option>
                        <?php endforeach;
                        if ($group !== null): ?></optgroup><?php endif; ?>
                    </select>
                    <?= field_error_html('student_id') ?>
                </label>
                <?= field_input('Attendance date', 'attendance_date', (string) old('attendance_date', $date), ['type' => 'date', 'required' => true, 'max' => date('Y-m-d'), 'data-date-input' => true]) ?>
            <?php endif; ?>
        </div>
        <div class="duplicate-warning" data-duplicate-warning role="status" aria-live="polite" hidden></div>
    </fieldset>

    <fieldset class="form-section">
        <legend>Morning</legend>
        <div class="form-grid">
            <?= $timeField('Time in', 'morning_in', 'morning_time_in') ?>
            <?= $timeField('Time out', 'morning_out', 'morning_time_out') ?>
        </div>
    </fieldset>

    <fieldset class="form-section">
        <legend>Afternoon</legend>
        <div class="form-grid">
            <?= $timeField('Time in', 'afternoon_in', 'afternoon_time_in') ?>
            <?= $timeField('Time out', 'afternoon_out', 'afternoon_time_out') ?>
        </div>
    </fieldset>

    <?php if ($isAdmin): ?>
        <label><span>Remarks <span class="text-faint">(optional)</span></span>
            <textarea name="remarks" maxlength="255" placeholder="Add notes or remarks"><?= e($remarks) ?></textarea>
        </label>
        <?php if (!$edit): ?>
            <div data-overwrite-block<?= $needsReason ? '' : ' hidden' ?>>
                <label class="check urgent-confirm"><input type="checkbox" name="confirm_overwrite" value="1"<?= (string) old('confirm_overwrite') === '1' ? ' checked' : '' ?>>
                    <span>A record already exists for this student and date. <strong>Replace it</strong> with the times above.</span></label>
                <?= field_error_html('confirm_overwrite') ?>
            </div>
        <?php endif; ?>
        <div data-reason-block<?= $needsReason ? '' : ' hidden' ?>>
            <?= field_textarea('Reason for change', 'reason', (string) old('reason'), ['maxlength' => 500, 'rows' => 2, 'placeholder' => 'e.g. Student forgot to log out; confirmed with the officer on duty'],
                'Required when changing an existing record. It is saved with your name and the time in the change history.') ?>
        </div>
    <?php endif; ?>

    <div class="form-actions">
        <?php if ($context === 'modal'): ?>
            <button type="button" class="btn secondary" data-modal-close>Cancel</button>
        <?php else: ?>
            <a class="btn secondary" href="<?= e($cancelHref) ?>">Cancel</a>
        <?php endif; ?>
        <button type="submit" class="btn primary">Save attendance</button>
    </div>
</form>
