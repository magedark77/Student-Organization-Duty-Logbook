<?php
/**
 * Add / edit student form (rendered inside a modal).
 * Required: $formAction. Optional: $edit (student row with username).
 */
defined('APP_BOOT') || exit;

$edit ??= null;
$field = static fn(string $key, string $default = '') => (string) old($key, $edit[$key] ?? $default);

$position = $field('position');
$positionOptions = POSITIONS;
if ($position !== '' && !in_array($position, $positionOptions, true)) {
    $positionOptions[] = $position; // keep a legacy free-text position selectable
}
$status = $field('status', STUDENT_STATUSES[0]);
?>
<form method="post" action="<?= e($formAction) ?>" class="form-stack">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
    <p class="hint required-note"><span class="req" aria-hidden="true">*</span> marks required fields.</p>

    <div class="form-grid">
        <?= field_input('Student number', 'student_number', $field('student_number'), ['required' => true, 'maxlength' => 50, 'placeholder' => 'e.g. 2026-0001']) ?>
        <?= field_input('Course', 'course', $field('course', 'BSCS'), ['required' => true, 'maxlength' => 150, 'placeholder' => 'e.g. BSCS']) ?>
        <?= field_input('First name', 'first_name', $field('first_name'), ['required' => true, 'maxlength' => 100]) ?>
        <?= field_input('Middle name', 'middle_name', $field('middle_name'), ['maxlength' => 100]) ?>
        <?= field_input('Last name', 'last_name', $field('last_name'), ['required' => true, 'maxlength' => 100]) ?>
        <?= field_select('Position', 'position', $positionOptions, $position, [], '— None —') ?>
        <?= field_select('Status', 'status', STUDENT_STATUSES, $status) ?>
    </div>

    <fieldset class="form-section">
        <legend>Student login</legend>
        <div class="form-grid">
            <?= field_input('Username', 'username', $field('username'), ['maxlength' => 100, 'autocomplete' => 'off', 'required' => !$edit, 'placeholder' => 'Usually the student number']) ?>
            <?= field_password('Password', 'password', ['minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password', 'required' => !$edit,
                'placeholder' => $edit ? 'Leave blank to keep current' : 'At least ' . MIN_PASSWORD_LENGTH . ' characters']) ?>
        </div>
        <p class="hint">Only administrators can create student logins. To let a student choose their own password, create the login and then use <strong>Create reset link</strong> on the student’s page.</p>
    </fieldset>

    <div class="form-actions">
        <button type="button" class="btn secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn primary">Save student</button>
    </div>
</form>
