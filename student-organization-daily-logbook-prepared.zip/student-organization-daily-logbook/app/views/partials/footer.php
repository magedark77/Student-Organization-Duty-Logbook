<?php defined('APP_BOOT') || exit; ?>
<?php if (!$bare): ?>
        <footer class="app-footer no-print"><b><?= e(APP_SHORT_NAME) ?></b><span>Build</span><span>Learn</span><span>Innovate</span></footer>
    </main>
</div>
<?php endif; ?>
</body>
</html>
