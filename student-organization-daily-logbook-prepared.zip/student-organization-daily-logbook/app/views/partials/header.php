<?php
defined('APP_BOOT') || exit;
$currentUser = user();
$navBadges = ($currentUser && empty($bare)) ? nav_badges($currentUser) : [];
$unreadNotifications = (int) ($navBadges['notifications'] ?? 0); // same number as the menu badge: one query, not two
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#071f48">
    <meta name="color-scheme" content="light">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230b5fe0'/%3E%3Ctext x='32' y='42' font-family='Arial' font-size='28' font-weight='800' text-anchor='middle' fill='white'%3ESO%3C/text%3E%3C/svg%3E">
    <title><?= e($title) ?> | <?= e(APP_SHORT_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&amp;family=Manrope:wght@600;700;800&amp;family=Caveat:wght@600&amp;display=swap">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
    <?php foreach ($styles ?? [] as $extraStyle): ?>
    <link rel="stylesheet" href="<?= e(asset($extraStyle)) ?>">
    <?php endforeach; ?>
    <script src="<?= e(asset('js/app.js')) ?>" defer></script>
    <?php foreach ($scripts ?? [] as $extraScript): ?>
    <script src="<?= e(asset($extraScript)) ?>" defer></script>
    <?php endforeach; ?>
</head>
<body class="<?= e(trim($bodyClass)) ?>">
<?php if (!$bare): ?>
<a class="skip-link" href="#main">Skip to content</a>
<div class="layout">
    <aside class="sidebar">
        <a class="brand" href="<?= e(home_url()) ?>">
            <?= brand_logo(62) ?>
            <span class="brand-name"><?= e(strtoupper(APP_SHORT_NAME)) ?></span>
            <span class="brand-tag">Connect <i>•</i> Lead <i>•</i> Make an Impact</span>
        </a>
        <button type="button" class="menu-toggle no-print" data-menu-toggle aria-expanded="false" aria-controls="site-nav" hidden><?= icon('menu') ?><span>Menu</span></button>
        <nav class="nav" id="site-nav" aria-label="Main navigation">
            <?php foreach (nav_items($currentUser['role'] ?? 'student') as $key => [$label, $path, $navIcon]): ?>
                <a href="<?= e(url($path)) ?>"<?= $key === $active ? ' class="active" aria-current="page"' : '' ?>><?= icon($navIcon) ?><span><?= e($label) ?></span><?= $key === 'notifications' ? notification_badge($unreadNotifications) : nav_badge((int) ($navBadges[$key] ?? 0)) ?></a>
            <?php endforeach; ?>
        </nav>
        <p class="sidebar-quote"><b>Stronger<br>Together.</b>Student organizations<br>build a better campus.</p>
    </aside>
    <main class="main" id="main">
        <?php if ($currentUser): ?>
        <header class="appbar no-print">
            <?php if (($currentUser['role'] ?? '') === ROLE_ADMIN): ?>
                <form class="appbar-search" method="get" action="<?= e(url('admin/students.php')) ?>" role="search">
                    <?= icon('search') ?>
                    <input type="search" name="q" placeholder="Search students, records, or reports…" aria-label="Search students">
                </form>
            <?php else: ?>
                <span class="appbar-spacer"></span>
            <?php endif; ?>
            <a class="appbar-bell" href="<?= e(url('notifications.php')) ?>" data-notif-poll="<?= e(url('notifications-count.php')) ?>"
               aria-label="Notifications<?= $unreadNotifications > 0 ? ' (' . $unreadNotifications . ' unread)' : '' ?>">
                <?= icon('bell') ?><?= notification_badge($unreadNotifications) ?>
            </a>
            <details class="appbar-user" data-user-menu>
                <summary aria-label="Account menu for <?= e($currentUser['username']) ?>">
                    <span class="avatar" aria-hidden="true"><?= e(user_initials((string) $currentUser['username'])) ?></span>
                    <span class="appbar-user-text">
                        <strong><?= e($currentUser['username']) ?></strong>
                        <small><?= e(role_label($currentUser['role'])) ?></small>
                    </span>
                    <?= icon('chevron') ?>
                </summary>
                <div class="user-menu">
                    <a href="<?= e(url('change-password.php')) ?>"><?= icon('key') ?>Change Password</a>
                    <a href="<?= e(url('logout.php')) ?>"><?= icon('logout') ?>Logout</a>
                </div>
            </details>
        </header>
        <?php endif; ?>
<?php endif; ?>
