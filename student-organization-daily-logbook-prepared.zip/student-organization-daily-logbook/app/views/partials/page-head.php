<?php
defined('APP_BOOT') || exit;
$flash = get_flash();
$crumbs ??= [];
?>
<?= $crumbs ? breadcrumbs(array_merge([home_crumb()], $crumbs)) : '' ?>
<div class="topbar">
    <div class="topbar-title">
        <h1><?= e($title) ?></h1>
        <?php if ($subtitle !== ''): ?><p class="text-muted"><?= e($subtitle) ?></p><?php endif; ?>
    </div>
    <?php if ($actions): ?>
        <div class="actions no-print">
            <?php foreach ($actions as $action):
                $class = 'btn ' . ($action['class'] ?? 'secondary'); ?>
                <?php if (isset($action['href'])): ?>
                    <a class="<?= e($class) ?>" href="<?= e($action['href']) ?>"<?= html_attrs($action['attrs'] ?? []) ?>><?= e($action['label']) ?></a>
                <?php else: ?>
                    <button type="button" class="<?= e($class) ?>"<?= html_attrs($action['attrs'] ?? []) ?>><?= e($action['label']) ?></button>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php if (default_password_in_use()): ?>
    <div class="alert warning" role="alert">
        <strong>Security notice:</strong> you are still using the default administrator password.
        <a href="<?= e(url('change-password.php')) ?>">Change it now</a>.
    </div>
<?php endif; ?>

<?php if ($flash): alert($flash[0], $flash[1]); endif; ?>
