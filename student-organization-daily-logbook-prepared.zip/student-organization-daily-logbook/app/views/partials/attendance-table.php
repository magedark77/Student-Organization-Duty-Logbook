<?php
/**
 * Attendance table shared by the dashboard, attendance list and student pages.
 *
 * Required: $rows
 * Optional: $showStudent, $showDate, $actions, $date, $label, $emptyMessage, $emptyHtml, $correctionLink
 * Rows with a missing time-in or time-out are flagged with an "Incomplete" indicator and the reason.
 */
defined('APP_BOOT') || exit;

$showStudent    ??= false;
$showDate       ??= false;
$actions        ??= false;
$date           ??= '';
$sort           ??= null;
$sortBase       ??= '';
$sortQuery      ??= [];
$label          ??= 'Attendance records';
$emptyMessage   ??= 'No attendance records found.';
$emptyHtml      ??= '';
$correctionLink ??= false;
?>
<?php if (!$rows && $emptyHtml !== ''): ?>
    <?= $emptyHtml ?>
<?php else: ?>
<?php table_start($label, true); ?>
    <thead>
        <tr>
            <?php if ($showStudent): ?><?= sort_th('Student', 'name', $sort, $sortBase, $sortQuery) ?><?php endif; ?>
            <?php if ($showDate): ?><th scope="col">Date</th><?php endif; ?>
            <?= sort_th('Morning', 'morning', $sort, $sortBase, $sortQuery) ?>
            <?= sort_th('Afternoon', 'afternoon', $sort, $sortBase, $sortQuery) ?>
            <?= sort_th('Total', 'total', $sort, $sortBase, $sortQuery) ?>
            <th scope="col">Remarks</th>
            <?php if ($actions || $correctionLink): ?><th scope="col" class="no-print">Actions</th><?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php if (!$rows): ?>
            <?= empty_row(4 + (int) $showStudent + (int) $showDate + (int) ($actions || $correctionLink), $emptyMessage) ?>
        <?php endif; ?>
        <?php foreach ($rows as $row):
            $minutes    = attendance_minutes($row);
            $incomplete = attendance_incomplete_reasons($row); ?>
            <tr<?= $incomplete ? ' class="row-incomplete"' : '' ?>>
                <?php if ($showStudent): ?>
                    <td data-label="Student">
                        <strong><?= e($row['student_number']) ?></strong>
                        <span class="cell-sub"><?= e($row['first_name'] . ' ' . $row['last_name']) ?></span>
                    </td>
                <?php endif; ?>
                <?php if ($showDate): ?><td data-label="Date"><?= e(format_date($row['attendance_date'])) ?></td><?php endif; ?>
                <td data-label="Morning"><?= e(format_time_range($row['morning_time_in'], $row['morning_time_out'])) ?></td>
                <td data-label="Afternoon"><?= e(format_time_range($row['afternoon_time_in'], $row['afternoon_time_out'])) ?></td>
                <td data-label="Total"><strong><?= e(format_duration($minutes['total'])) ?></strong>
                    <?php if ($incomplete): ?><span class="cell-sub"><?= status_indicator('incomplete', implode('; ', $incomplete)) ?></span><?php endif; ?></td>
                <td data-label="Remarks" class="cell-wrap"><?= ($row['remarks'] ?? '') !== '' ? e($row['remarks']) : '<span class="text-faint">—</span>' ?></td>
                <?php if ($actions): ?>
                    <td data-label="Actions" class="no-print">
                        <div class="actions">
                            <a class="btn secondary btn-sm"
                               href="<?= e(url('admin/attendance.php', ['date' => $row['attendance_date'], 'edit' => $row['id']])) ?>">Edit</a>
                            <?= delete_form(url('admin/attendance.php'), (int) $row['id'],
                                'Delete the attendance record of ' . $row['first_name'] . ' ' . $row['last_name'] . ' on ' . format_date($row['attendance_date']) . '? The deletion is kept in the change history.',
                                ['attendance_date' => $row['attendance_date']]) ?>
                        </div>
                    </td>
                <?php elseif ($correctionLink): ?>
                    <td data-label="Actions" class="no-print"><a class="btn secondary btn-sm" href="<?= e(url('student/corrections.php', ['date' => $row['attendance_date']])) ?>">Request correction</a></td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
<?php table_end(); ?>
<?php endif; ?>
