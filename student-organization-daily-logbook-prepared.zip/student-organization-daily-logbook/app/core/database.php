<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

function db_setting(string $key): string
{
    $value = app_config('db_' . $key);
    if ($value === null || $value === '') {
        $value = getenv('DB_' . strtoupper($key)) ?: '';
    }
    return (string) $value;
}

/** Shared PDO connection. */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if (($configError = app_config_error()) !== null) {
        throw new ConfigurationException($configError);
    }

    $host = db_setting('host');
    $name = db_setting('name');
    $user = db_setting('user');
    if ($host === '' || $name === '' || $user === '') {
        throw new ConfigurationException(
            'Database settings were not found. Copy config/config.sample.php to config/config.local.php and enter your MySQL details.'
        );
    }

    $pdo = new PDO(
        'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4',
        $user,
        db_setting('pass'),
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            // Keep MySQL's TIMESTAMP columns in the same time zone PHP uses for display.
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '" . date('P') . "'",
        ]
    );

    ensure_schema($pdo);
    return $pdo;
}

/**
 * Prepare and execute a statement, binding $params as values.
 * Use this instead of db()->query() so every SQL statement is a prepared statement.
 */
function db_run(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/** First row of a query, or null. */
function db_one(string $sql, array $params = []): ?array
{
    return db_run($sql, $params)->fetch() ?: null;
}

/** First column of the first row (COUNT(*), SUM(...), ...). */
function db_value(string $sql, array $params = []): mixed
{
    return db_run($sql, $params)->fetchColumn();
}

/** All rows of a query. */
function db_all(string $sql, array $params = []): array
{
    return db_run($sql, $params)->fetchAll();
}

/** "?,?,?" for an IN (...) list of $count values. */
function sql_placeholders(int $count): string
{
    return implode(',', array_fill(0, max(1, $count), '?'));
}

/** True when $e is a UNIQUE / PRIMARY KEY violation (SQLSTATE 23000), so callers can show a friendly message. */
function db_is_duplicate_key(Throwable $e): bool
{
    return $e instanceof PDOException && (string) $e->getCode() === '23000';
}

/** Run $callback inside a transaction; roll back and rethrow on failure. */
function db_transaction(callable $callback): mixed
{
    $pdo = db();
    if ($pdo->inTransaction()) {
        return $callback($pdo); // already inside a larger transaction: the outer one commits or rolls back everything
    }
    $pdo->beginTransaction();
    try {
        $result = $callback($pdo);
        $pdo->commit();
        return $result;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}
