<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/**
 * Verify credentials and start a session.
 * Only non-sensitive fields are stored in the session (never the password hash).
 *
 * @return string|null null on success, otherwise a message that is safe to show
 */
function login_user(string $username, string $password): ?string
{
    if (login_is_throttled($username)) {
        return 'Too many failed sign-in attempts. Please wait ' . LOGIN_LOCKOUT_MINUTES . ' minutes and try again.';
    }

    $row = db_one('SELECT * FROM users WHERE username = ? LIMIT 1', [$username]);

    // Always run one hash check so timing doesn't reveal whether the username exists.
    $matches = password_verify($password, $row ? $row['password'] : DEFAULT_ADMIN_HASH);
    if (!$row || !$matches) {
        login_record_failure($username);
        login_audit('LOGIN_FAILED', $row ? (int) $row['id'] : null, 'Failed sign-in for username "' . mb_substr($username, 0, 60) . '"');
        return 'Invalid username or password.';
    }
    login_clear_failures($username);
    // Only reached with a correct password, so these messages do not reveal which usernames exist.
    if ((int) ($row['is_active'] ?? 1) !== 1) {
        return 'This account has been deactivated. Please contact the administrator.';
    }
    // Old (Director, Manager I-VIII...) or blank roles match no landing page and would bounce between pages forever.
    if (!in_array($row['role'], [ROLE_ADMIN, ROLE_STUDENT, ...STAFF_ROLES], true)) {
        return 'This officer account has an old role. Please ask the administrator to assign a new role (Officer Accounts > Edit).';
    }
    if (in_array($row['role'], STAFF_ROLES, true) && !within_duty_hours()) {
        return 'This account can sign in only during duty hours (' . duty_hours_label() . ').';
    }

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'         => (int) $row['id'],
        'username'   => $row['username'],
        'role'       => $row['role'],
        'student_id' => $row['student_id'] !== null ? (int) $row['student_id'] : null,
    ];
    $_SESSION['user']['pw'] = session_password_stamp((string) $row['password']);
    $_SESSION['default_password'] = $row['role'] === ROLE_ADMIN && hash_equals(DEFAULT_ADMIN_PASSWORD, $password);
    login_audit('LOGIN', (int) $row['id'], 'Signed in (' . role_label((string) $row['role']) . ')');
    return null;
}

/** Sign-in events for the audit trail. Never stores the password; a logging problem must never block or reveal anything at sign-in. */
function login_audit(string $action, ?int $userId, string $description): void
{
    try {
        audit($action, 'users', $userId, $description . ' from ' . login_client_ip());
    } catch (Throwable $e) {
        error_log('[studentbody] could not audit sign-in: ' . $e->getMessage());
    }
}

/* ---- Sign-in throttling -------------------------------------------------- */

/** The client address as the web server reports it (forwarded headers are client-controlled, so they are not trusted). */
function login_client_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

/** True when this username, or this address, has failed too often within the lockout window. */
function login_is_throttled(string $username): bool
{
    try {
        $since = date('Y-m-d H:i:s', time() - LOGIN_LOCKOUT_MINUTES * 60);
        $byUser = (int) db_value('SELECT COUNT(*) FROM login_attempts WHERE username = ? AND attempted_at >= ?', [mb_substr($username, 0, 100), $since]);
        if ($byUser >= LOGIN_MAX_FAILURES_PER_USER) {
            return true;
        }
        return (int) db_value('SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempted_at >= ?', [login_client_ip(), $since]) >= LOGIN_MAX_FAILURES_PER_IP;
    } catch (Throwable $e) {
        error_log('[studentbody] login throttle check failed: ' . $e->getMessage());
        return false; // never lock everyone out because the bookkeeping failed
    }
}

function login_record_failure(string $username): void
{
    try {
        db_run('INSERT INTO login_attempts (username, ip_address, attempted_at) VALUES (?, ?, ?)', [mb_substr($username, 0, 100), login_client_ip(), date('Y-m-d H:i:s')]);
        // Housekeeping: old rows are useless, so keep the table small.
        db_run('DELETE FROM login_attempts WHERE attempted_at < ?', [date('Y-m-d H:i:s', time() - 86400)]);
    } catch (Throwable $e) {
        error_log('[studentbody] could not record failed sign-in: ' . $e->getMessage());
    }
}

function login_clear_failures(string $username): void
{
    try {
        db_run('DELETE FROM login_attempts WHERE username = ?', [mb_substr($username, 0, 100)]);
    } catch (Throwable $e) {
        error_log('[studentbody] could not clear failed sign-ins: ' . $e->getMessage());
    }
}

/** Fingerprint of a stored password hash, kept in the session to notice when the password was changed elsewhere. */
function session_password_stamp(string $passwordHash): string
{
    return hash('sha256', $passwordHash);
}

/** Roles that may swap among themselves without signing out: every staff role counts as one group. */
function role_group(string $role): string
{
    return in_array($role, STAFF_ROLES, true) ? 'staff' : $role;
}

/**
 * A session ends as soon as an administrator deletes the account, moves it to a different kind of role
 * (administrator, student or officer) or resets the password. Otherwise it keeps the username and officer
 * role in step with the database.
 */
function session_is_current(): bool
{
    $user = user();
    $row  = db_one('SELECT username, role, password, is_active FROM users WHERE id = ?', [(int) ($user['id'] ?? 0)]);
    if ($row === null || (int) ($row['is_active'] ?? 1) !== 1 || role_group((string) $row['role']) !== role_group((string) ($user['role'] ?? ''))) {
        return false;
    }
    $stamp = session_password_stamp((string) $row['password']);
    if (isset($user['pw']) && !hash_equals((string) $user['pw'], $stamp)) {
        return false;
    }
    $_SESSION['user']['pw']       = $stamp; // also covers sessions started before this check existed
    $_SESSION['user']['username'] = $row['username'];
    $_SESSION['user']['role']     = $row['role'];
    return true;
}

/**
 * Change a user's password after checking the current one.
 *
 * @throws ValidationException with a message that is safe to show
 */
function change_password(int $userId, string $current, string $new, string $confirm): void
{
    $row = db_one('SELECT password FROM users WHERE id = ?', [$userId]);

    if (!$row || !password_verify($current, $row['password'])) {
        throw new ValidationException('Current password is incorrect.');
    }
    if (strlen($new) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('New password must be at least ' . MIN_PASSWORD_LENGTH . ' characters.');
    }
    if ($new !== $confirm) {
        throw new ValidationException('New passwords do not match.');
    }
    if ($current === $new) {
        throw new ValidationException('New password must be different from the current password.');
    }
    db_run('UPDATE users SET password = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $userId]);
}

function user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_admin(): bool
{
    return (user()['role'] ?? '') === ROLE_ADMIN;
}

/** "assistant_director" -> "Assistant Director". */
function role_label(string $role): string
{
    return ROLE_LABELS[$role] ?? ucwords(str_replace('_', ' ', $role));
}

/** Schedule defaults to 08:00–17:00 in Philippine time; override in config if needed. */
function within_duty_hours(): bool
{
    $tz    = new DateTimeZone((string) app_config('duty_timezone', 'Asia/Manila'));
    $clock = (new DateTimeImmutable('now', $tz))->format('H:i');
    return $clock >= (string) app_config('duty_start', '08:00') && $clock <= (string) app_config('duty_end', '17:00');
}

/** "08:00–17:00" in 12-hour form, for messages. */
function duty_hours_label(): string
{
    return format_clock((string) app_config('duty_start', '08:00')) . ' – ' . format_clock((string) app_config('duty_end', '17:00'));
}

/** President, Internal/External Vice President or Secretary: may view and create attendance during duty hours only. */
function is_restricted_staff(): bool
{
    return in_array(user()['role'] ?? '', STAFF_ROLES, true);
}

/** Administrators, the President and the Internal Vice President may send announcements. */
function can_announce(): bool
{
    return is_admin() || in_array(user()['role'] ?? '', ANNOUNCER_ROLES, true);
}

function require_announcer(): void
{
    require_login();
    if (!can_announce()) {
        render_error_page(403, 'Access denied', 'You do not have permission to view this page.');
    }
}

/** Only administrators may edit or delete attendance, review corrections and manage students, officers and reports. */
function can_modify_attendance(): bool
{
    return is_admin();
}

function require_attendance_access(): void
{
    require_login();
    if (!is_admin() && !is_restricted_staff()) {
        render_error_page(403, 'Access denied', 'You do not have permission to view this page.');
    }
}

/** True while the signed-in administrator still uses the documented default password. */
function default_password_in_use(): bool
{
    return !empty($_SESSION['default_password']);
}

function require_login(): void
{
    if (!user()) {
        redirect(url('index.php'));
    }
    // Keep signed-in pages out of the browser cache (back button after logout).
    header('Cache-Control: no-store');
    if (!session_is_current()) {
        session_end();
        render_error_page(403, 'Signed out', 'This account was changed, deactivated or removed by an administrator. Please sign in again.');
    }
    if (is_restricted_staff() && !within_duty_hours()) {
        session_end();
        render_error_page(403, 'Outside duty hours', 'These staff accounts may access the logbook only during configured duty hours.');
    }
}

function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        render_error_page(403, 'Access denied', 'You do not have permission to view this page.');
    }
}

/** Student pages: administrators and staff are sent to their own landing page instead. */
function require_student(): void
{
    require_login();
    if (($_SESSION['user']['role'] ?? '') !== ROLE_STUDENT) {
        redirect(home_url());
    }
}

/** Landing page for the signed-in user's role. */
function home_url(): string
{
    if (!user()) {
        return url('index.php');
    }
    return url(match (true) {
        is_admin()            => 'admin/dashboard.php',
        is_restricted_staff() => 'admin/attendance.php',
        default               => 'student/dashboard.php',
    });
}
