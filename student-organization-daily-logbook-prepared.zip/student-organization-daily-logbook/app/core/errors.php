<?php
defined('APP_BOOT') || exit;

/** A problem the user can fix. The message is safe to display. */
class ValidationException extends RuntimeException
{
    /** $field: name of the form field the message belongs to ('' = the form as a whole). */
    public function __construct(string $message, public readonly string $field = '')
    {
        parent::__construct($message);
    }
}

/** The app is not set up correctly. The message is safe to display. */
class ConfigurationException extends RuntimeException {}

/**
 * Where the error page's back link goes: the previous page when it is on this site,
 * otherwise the start page. (A javascript: link would be blocked by our Content-Security-Policy.)
 */
function error_back_url(): string
{
    $referer     = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    $refererHost = parse_url($referer, PHP_URL_HOST);
    $ownHost     = parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
    if (is_string($refererHost) && is_string($ownHost) && strcasecmp($refererHost, $ownHost) === 0) {
        return $referer;
    }
    return function_exists('url') ? url('index.php') : './';
}

/** Render a minimal standalone error page and stop. */
function render_error_page(int $status, string $title, string $message): never
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
    }
    $t = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $m = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $back = htmlspecialchars(error_back_url(), ENT_QUOTES, 'UTF-8');
    echo <<<HTML
<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>{$t}</title>
<style>
body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f4f7fc;color:#1b2a47;font:16px/1.5 system-ui,-apple-system,"Segoe UI",Arial,sans-serif}
main{max-width:480px;background:#fff;border:1px solid #e3e9f3;border-radius:16px;padding:32px;box-shadow:0 10px 30px rgba(10,30,70,.12)}
h1{margin:0 0 8px;font-size:22px}p{margin:0 0 20px;color:#5b6a85}
a{color:#0b5fe0;font-weight:600}
</style></head>
<body><main><h1>{$t}</h1><p>{$m}</p><a href="{$back}">&larr; Go back</a></main></body></html>
HTML;
    exit;
}

set_exception_handler(static function (Throwable $e): void {
    error_log('[studentbody] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

    if ($e instanceof ConfigurationException) {
        render_error_page(500, 'Setup required', $e->getMessage());
    }
    $debug = function_exists('app_config') && app_config('debug', false);
    render_error_page(
        500,
        'Something went wrong',
        $debug ? $e->getMessage() : 'An unexpected error occurred. Please try again in a moment.'
    );
});
