<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/**
 * Minimal PDF writer for printable tables (no external library needed, so it also runs on free hosting).
 * Uses the built-in Helvetica fonts, A4 pages and WinAnsi text, which covers Latin and accented letters.
 */
final class SimplePdf
{
    /** Helvetica glyph widths (1/1000 em) for ASCII 32–126. */
    private const WIDTHS = [
        278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
        556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
    ];

    /** @var string[] content stream of each page */
    private array $pages = [];
    public readonly float $width;
    public readonly float $height;

    public function __construct(bool $landscape = false)
    {
        $this->width  = $landscape ? 841.89 : 595.28;
        $this->height = $landscape ? 595.28 : 841.89;
        $this->addPage();
    }

    public function addPage(): void
    {
        $this->pages[] = '';
    }

    public function pageCount(): int
    {
        return count($this->pages);
    }

    /** UTF-8 -> WinAnsi (CP1252); characters it cannot show become "?". */
    public static function encode(string $text): string
    {
        $text = str_replace(["\u{2013}", "\u{2014}", "\u{2026}", "\u{2022}", "\u{2018}", "\u{2019}", "\u{201C}", "\u{201D}"], ['-', '-', '...', '*', "'", "'", '"', '"'], $text);
        $text = preg_replace('/[\x00-\x1F\x7F]/', ' ', $text) ?? '';
        $out  = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        return $out === false ? mb_convert_encoding($text, 'ASCII', 'UTF-8') : $out;
    }

    /** Text width in points. */
    public function textWidth(string $text, float $size, bool $bold = false): float
    {
        $units = 0;
        foreach (str_split(self::encode($text)) as $ch) {
            $code   = ord($ch);
            $units += ($code >= 32 && $code <= 126) ? self::WIDTHS[$code - 32] : 556;
        }
        return $units / 1000 * $size * ($bold ? 1.06 : 1.0);
    }

    /** Shorten $text with "..." so it fits $maxWidth points. */
    public function fit(string $text, float $maxWidth, float $size, bool $bold = false): string
    {
        $text = trim(preg_replace('/\s+/', ' ', $text) ?? '');
        if ($this->textWidth($text, $size, $bold) <= $maxWidth) {
            return $text;
        }
        while ($text !== '' && $this->textWidth($text . '...', $size, $bold) > $maxWidth) {
            $text = mb_substr($text, 0, -1);
        }
        return rtrim($text) . '...';
    }

    /** Draw text; $y is measured from the top of the page (baseline). $align: l, r or c within [$x, $x + $w]. */
    public function text(float $x, float $y, string $text, float $size = 9, bool $bold = false, string $align = 'l', float $w = 0, string $gray = '0'): void
    {
        $tw = $this->textWidth($text, $size, $bold);
        if ($align === 'r') {
            $x += $w - $tw;
        } elseif ($align === 'c') {
            $x += ($w - $tw) / 2;
        }
        $escaped = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], self::encode($text));
        $this->add(sprintf("BT /%s %.2F Tf %s g %.2F %.2F Td (%s) Tj ET\n", $bold ? 'F2' : 'F1', $size, $gray, $x, $this->height - $y, $escaped));
    }

    public function line(float $x1, float $y1, float $x2, float $y2, string $gray = '0.8', float $weight = 0.5): void
    {
        $this->add(sprintf("%s G %.2F w %.2F %.2F m %.2F %.2F l S\n", $gray, $weight, $x1, $this->height - $y1, $x2, $this->height - $y2));
    }

    /** Filled rectangle with its top-left corner at ($x, $y). */
    public function rect(float $x, float $y, float $w, float $h, string $gray): void
    {
        $this->add(sprintf("%s g %.2F %.2F %.2F %.2F re f\n", $gray, $x, $this->height - $y - $h, $w, $h));
    }

    /** Page footer: generation note on the left, "Page n of m" on the right. */
    public function footerOn(int $pageIndex, string $note, int $number, int $total, float $margin, float $usable): void
    {
        $saved = $this->pages;
        $this->pages = [$pageIndex => $this->pages[$pageIndex]];
        $y = $this->height - 26;
        $this->line($margin, $y - 12, $margin + $usable, $y - 12, '0.8');
        $this->text($margin, $y, $this->fit($note, $usable - 90, 7.5), 7.5, false, 'l', 0, '0.4');
        $this->text($margin, $y, "Page $number of $total", 7.5, false, 'r', $usable, '0.4');
        $saved[$pageIndex] = $this->pages[$pageIndex];
        $this->pages = $saved;
    }

    private function add(string $operators): void
    {
        $this->pages[array_key_last($this->pages)] .= $operators;
    }

    /** The finished document. */
    public function output(string $title = ''): string
    {
        $objects = [];
        $n       = count($this->pages);
        // 1 catalog, 2 page tree, 3-4 fonts, 5 info, then (page, content) pairs.
        $kids = [];
        for ($i = 0; $i < $n; $i++) {
            $kids[] = (6 + $i * 2) . ' 0 R';
        }
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $n . ' >>';
        $objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $escapedTitle = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], self::encode($title));
        $objects[5] = '<< /Title (' . $escapedTitle . ') /Producer (Student Office Daily Logbook) /CreationDate (D:' . date('YmdHis') . ') >>';
        foreach ($this->pages as $i => $stream) {
            $pageNo = 6 + $i * 2;
            $objects[$pageNo]     = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', $this->width, $this->height, $pageNo + 1);
            $objects[$pageNo + 1] = '<< /Length ' . strlen($stream) . " >>\nstream\n" . $stream . 'endstream';
        }

        $pdf     = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objects as $num => $body) {
            $offsets[$num] = strlen($pdf);
            $pdf .= $num . " 0 obj\n" . $body . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
        foreach ($offsets as $offset) {
            $pdf .= sprintf("%010d 00000 n \n", $offset);
        }
        return $pdf . "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R /Info 5 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";
    }
}

/**
 * A printable table report.
 *
 * @param string   $title    report title
 * @param string[] $meta     lines under the title (period, filters, who generated it …)
 * @param array    $columns  list of ['label' => string, 'weight' => number, 'align' => 'l'|'r'|'c']
 * @param array    $rows     list of string[] (one string per column)
 * @param string[]|null $totals optional last row, shown in bold
 * @return string PDF bytes
 */
function pdf_table_report(string $title, array $meta, array $columns, array $rows, ?array $totals = null, string $footer = ''): string
{
    $landscape = count($columns) > 5;
    $pdf       = new SimplePdf($landscape);
    $margin    = 36.0;
    $usable    = $pdf->width - 2 * $margin;
    $weights   = array_sum(array_column($columns, 'weight'));
    $widths    = array_map(static fn(array $c): float => $usable * $c['weight'] / $weights, $columns);
    $rowH      = 17.0;
    $bottom    = $pdf->height - 44;

    $drawHeader = static function (SimplePdf $pdf, float $y) use ($columns, $widths, $margin, $usable): float {
        $pdf->rect($margin, $y, $usable, 19, '0.90');
        $x = $margin;
        foreach ($columns as $i => $col) {
            $pdf->text($x + 5, $y + 13, $pdf->fit(strtoupper($col['label']), $widths[$i] - 10, 7.5, true), 7.5, true, $col['align'] ?? 'l', $widths[$i] - 10, '0.25');
            $x += $widths[$i];
        }
        return $y + 19;
    };

    $drawRow = static function (SimplePdf $pdf, float $y, array $cells, bool $bold, bool $zebra) use ($columns, $widths, $margin, $usable, $rowH): float {
        if ($zebra) {
            $pdf->rect($margin, $y, $usable, $rowH, '0.97');
        }
        $x = $margin;
        foreach ($columns as $i => $col) {
            $cell = (string) ($cells[$i] ?? '');
            $pdf->text($x + 5, $y + 12, $pdf->fit($cell, $widths[$i] - 10, 8.5, $bold), 8.5, $bold, $col['align'] ?? 'l', $widths[$i] - 10);
            $x += $widths[$i];
        }
        $pdf->line($margin, $y + $rowH, $margin + $usable, $y + $rowH, '0.88');
        return $y + $rowH;
    };

    // Title block
    $y = 48.0;
    $pdf->text($margin, $y, APP_NAME, 8, false, 'l', 0, '0.4');
    $y += 20;
    $pdf->text($margin, $y, $title, 17, true);
    $y += 8;
    foreach ($meta as $line) {
        $y += 13;
        $pdf->text($margin, $y, $pdf->fit($line, $usable, 9), 9, false, 'l', 0, '0.25');
    }
    $y += 12;
    $pdf->line($margin, $y, $margin + $usable, $y, '0.55', 1.0);
    $y += 10;
    $y = $drawHeader($pdf, $y);

    if (!$rows) {
        $pdf->text($margin, $y + 26, 'No records match the selected filters.', 10, false, 'c', $usable, '0.4');
    }
    foreach ($rows as $index => $cells) {
        if ($y + $rowH > $bottom) {
            $pdf->addPage();
            $y = $drawHeader($pdf, 48.0);
        }
        $y = $drawRow($pdf, $y, $cells, false, $index % 2 === 1);
    }
    if ($totals !== null && $rows) {
        if ($y + $rowH > $bottom) {
            $pdf->addPage();
            $y = $drawHeader($pdf, 48.0);
        }
        $pdf->rect($margin, $y, $usable, $rowH, '0.90');
        $drawRow($pdf, $y, $totals, true, false);
    }

    // Footer on every page (page numbers need the final count, so draw them last).
    $pages = $pdf->pageCount();
    for ($p = 0; $p < $pages; $p++) {
        $pdf->footerOn($p, $footer, $p + 1, $pages, $margin, $usable);
    }
    return $pdf->output($title);
}
