<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'httponly' => true,
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax',
    ]);
    session_start();
}

/** Empty the session and expire its cookie (logout, or a forced sign-out). */
function session_end(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
}

/* ---- Flash messages ------------------------------------------------------ */

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = [$type, $message];
}

/** The pending flash message as [type, text], shown once. */
function get_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

/* ---- Remembering form input after a failed save ---------------------------- */

/** Store submitted values (never passwords) so the next page load can refill the form. */
function remember_input(array $data): void
{
    unset($data['csrf'], $data['password'], $data['current_password'], $data['new_password'], $data['confirm_password']);
    $_SESSION['old'] = $data;
}

/** Input saved by remember_input() on the previous request. Consumed on first read. */
function old_input(): array
{
    static $input = null;
    if ($input === null) {
        $input = $_SESSION['old'] ?? [];
        unset($_SESSION['old']);
    }
    return $input;
}

function old(string $key, mixed $default = ''): mixed
{
    return old_input()[$key] ?? $default;
}

// Consume immediately so stale input never leaks into a later page.
old_input();

/* ---- Validation messages shown next to the field they belong to --------------- */

/** Field errors saved by run_action() on the previous request. Consumed on first read. */
function field_errors(): array
{
    static $errors = null;
    if ($errors === null) {
        $errors = $_SESSION['field_errors'] ?? [];
        unset($_SESSION['field_errors']);
    }
    return $errors;
}

function field_error(string $name): string
{
    return (string) (field_errors()[$name] ?? '');
}

field_errors();
