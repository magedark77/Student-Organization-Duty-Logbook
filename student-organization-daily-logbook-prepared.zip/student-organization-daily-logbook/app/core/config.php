<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

const APP_NAME           = 'Student Office Daily Logbook';
const APP_SHORT_NAME     = 'Student Organizations';
const APP_TIMEZONE       = 'Asia/Manila';
const REQUIRED_HOURS     = 100;
const MIN_PASSWORD_LENGTH = 8;

// Sign-in throttling: after this many failed attempts for one username (or from one address) within the window, sign-in pauses.
const LOGIN_MAX_FAILURES_PER_USER = 6;
const LOGIN_MAX_FAILURES_PER_IP   = 20;
const LOGIN_LOCKOUT_MINUTES       = 10;

// Duty days. Stored in the students.year_level column (the name is kept for backwards compatibility).
const DUTY_DAYS        = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
// Positions available on every duty day, from Director down to Members.
const POSITIONS        = ['Director', 'Assistant Director', 'Secretary', 'Treasurer', 'Auditor', 'Public Relations Officer', 'Members'];
const STUDENT_STATUSES = ['Active', 'Inactive', 'Graduated'];

// Roles (users.role). Staff roles can view and create attendance, only during duty hours.
const ROLE_ADMIN   = 'admin';
const ROLE_STUDENT = 'student';
const STAFF_ROLES  = ['president', 'internal_vp', 'external_vp', 'secretary'];
// Roles from earlier versions (Director, Assistant Director, Managers I – VIII). They are no longer offered; Director and
// Assistant Director accounts are converted to President / Internal Vice President automatically, and the Manager
// accounts stay listed under Officer Accounts, flagged, until an administrator gives them one of the roles above.
const LEGACY_ROLES = ['director', 'assistant_director', 'manager_1', 'manager_2', 'manager_3', 'manager_4', 'manager_5', 'manager_6', 'manager_7', 'manager_8'];
// Staff roles that may also send announcements (administrators always can).
const ANNOUNCER_ROLES = ['president', 'internal_vp'];
const ROLE_LABELS  = [
    'admin'              => 'Administrator',
    'student'            => 'Student',
    'president'          => 'President',
    'internal_vp'        => 'Internal Vice President',
    'external_vp'        => 'External Vice President',
    'secretary'          => 'Secretary',
    // Legacy labels, so old audit-log entries and not-yet-reassigned accounts still read well.
    'director'           => 'Director',
    'assistant_director' => 'Assistant Director',
    'manager_1'          => 'Manager I',
    'manager_2'          => 'Manager II',
    'manager_3'          => 'Manager III',
    'manager_4'          => 'Manager IV',
    'manager_5'          => 'Manager V',
    'manager_6'          => 'Manager VI',
    'manager_7'          => 'Manager VII',
    'manager_8'          => 'Manager VIII',
];

// Notifications: rows shown per page, and how long they are kept.
const NOTIFICATION_PAGE_SIZE      = 15;
const NOTIFICATION_RETENTION_DAYS = 180;
// type => [label, badge colour]
const NOTIFICATION_TYPES = [
    'attendance'   => ['Attendance',   'neutral'],
    'milestone'    => ['Milestone',    'success'],
    'security'     => ['Security',     'warning'],
    'announcement' => ['Announcement', 'info'],
    'activity'     => ['Activity',     'neutral'],
];

/**
 * Default administrator, created only when the users table has no admin.
 * The login page and every admin page warn until this password is changed.
 */
const DEFAULT_ADMIN_USERNAME = 'admin';
const DEFAULT_ADMIN_PASSWORD = 'Admin@12345';
const DEFAULT_ADMIN_HASH     = '$2y$12$s3KJVfNDR.bb4F1j4A/eKOWPXk6LZYMzCPji/.oXdjkhp.EL5PF1.';

date_default_timezone_set(APP_TIMEZONE);

/**
 * Read a setting from config/config.local.php (never committed to version
 * control). Returns $default when the file or key is missing.
 */
function app_config(string $key, mixed $default = null): mixed
{
    return load_app_config($problem)[$key] ?? $default;
}

/** Why config/config.local.php could not be used, or null when it is fine (or absent). */
function app_config_error(): ?string
{
    load_app_config($problem);
    return $problem;
}

/** Load the config file once. $problem receives a displayable message when the file is broken. */
function load_app_config(?string &$problem = null): array
{
    static $config = null, $error = null;
    if ($config === null) {
        $config = [];
        $file   = APP_ROOT . '/config/config.local.php';
        if (is_file($file)) {
            try {
                $loaded = require $file;
                $config = is_array($loaded) ? $loaded : [];
                if (!is_array($loaded)) {
                    $problem = 'config/config.local.php must start with <?php and contain "return [ ... ];".';
                }
            } catch (Throwable $e) {
                // A typo in this file must never crash the error handler itself.
                error_log('[studentbody] config.local.php is invalid: ' . $e->getMessage());
                $problem = 'config/config.local.php has a syntax error (' . $e->getMessage()
                    . '). Compare it with config/config.sample.php: check quotes, commas and the final "];".';
            }
        }
        $error = $problem ?? null;
    }
    $problem = $error;
    return $config;
}
