<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* ---- Reading input ----------------------------------------------------- */

/** A string from $_POST (arrays and missing keys become ''). */
function post_str(string $key, bool $trim = true): string
{
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) {
        return '';
    }
    return $trim ? trim($value) : $value;
}

/** A string from $_GET (arrays and missing keys become ''). */
function get_str(string $key): string
{
    $value = $_GET[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

/** A $_GET value restricted to $allowed; anything else becomes $default. */
function get_choice(string $key, array $allowed, string $default = ''): string
{
    $value = get_str($key);
    return in_array($value, $allowed, true) ? $value : $default;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/* ---- Running a state-changing action ------------------------------------ */

const ACTION_OK      = 'ok';
const ACTION_INVALID = 'invalid'; // the user can fix it; a message was flashed
const ACTION_FAILED  = 'failed';  // unexpected error; logged, generic message flashed

/**
 * Run $action and turn any failure into a flash message, so every POST handler
 * reports errors the same way. Returns one of the ACTION_* constants.
 */
function run_action(string $label, callable $action): string
{
    try {
        $action();
        return ACTION_OK;
    } catch (ValidationException $e) {
        flash('danger', $e->getMessage());
        if ($e->field !== '') {
            $_SESSION['field_errors'] = [$e->field => $e->getMessage()];
        }
        return ACTION_INVALID;
    } catch (Throwable $e) {
        error_log('[studentbody] ' . $label . ' failed: ' . $e->getMessage());
        flash('danger', 'Something went wrong while saving. Please try again.');
        return ACTION_FAILED;
    }
}

/**
 * Handle a state-changing POST in one call: check the CSRF token, run the handler registered for the posted "action",
 * and report failures the same way everywhere. The caller then redirects.
 *
 * A handler flashes its own success message and throws ValidationException to refuse; any other error is logged and
 * shown as a generic message (see run_action()). An unregistered action is refused with "Unknown action."
 *
 * @param array<string, callable(): void> $handlers action name => handler
 * @param callable(string): void|null $authorize optional permission check, given the posted action
 * @return array{action: string, outcome: string} the posted action and one of the ACTION_* constants
 */
function handle_post(array $handlers, string $label = 'request', ?callable $authorize = null): array
{
    check_csrf();
    $action = post_str('action');
    if ($authorize !== null) {
        $authorize($action); // may stop the request with render_error_page(403, …) for actions this user may not perform
    }
    $outcome = run_action($label . ' ' . $action, static function () use ($handlers, $action): void {
        if (!isset($handlers[$action])) {
            throw new ValidationException('Unknown action.');
        }
        $handlers[$action]();
    });
    return ['action' => $action, 'outcome' => $outcome];
}
