<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/**
 * Indexes added after the first release: [table, index name, comma-separated columns].
 * The audit-log ones keep its filters fast as the table grows. idx_attendance_hours covers every column the
 * hour totals read, so the dashboard and reports aggregate straight from the index instead of the table
 * (measured on 150,000 records: dashboard 314 -> 202 ms, monthly report 220 -> 145 ms, charts 397 -> 292 ms).
 */
const SCHEMA_INDEXES = [
    ['audit_logs', 'idx_audit_action', 'action'],
    ['audit_logs', 'idx_audit_table',  'table_name'],
    ['attendance', 'idx_attendance_hours', 'student_id, attendance_date, morning_time_in, morning_time_out, afternoon_time_in, afternoon_time_out'],
];

/** Same definition as in database/logbook.sql; created automatically on installs that predate notifications. */
const NOTIFICATIONS_TABLE_SQL = <<<'SQL'
CREATE TABLE IF NOT EXISTS notifications (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT UNSIGNED NOT NULL,
    type       VARCHAR(30)  NOT NULL,
    title      VARCHAR(150) NOT NULL,
    message    VARCHAR(500) NULL,
    link       VARCHAR(255) NULL,
    ref        VARCHAR(100) NULL,
    is_read    TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notifications_user (user_id, is_read, created_at),
    INDEX idx_notifications_ref (user_id, ref),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;

/**
 * One-time upgrades for older installations. Runs at most once per session
 * instead of on every request.
 */
function ensure_schema(PDO $pdo): void
{
    if (!empty($_SESSION['schema_ready'])) {
        return;
    }

    $migrated = false;
    $seeded   = false;

    try {
        migrate_section_to_position($pdo);
        $migrated = true;
    } catch (Throwable $e) {
        error_log('[studentbody] position migration skipped: ' . $e->getMessage());
    }

    try {
        seed_default_admin($pdo);
        $seeded = true;
    } catch (Throwable $e) {
        // Tables are probably not imported yet; import database/logbook.sql.
        error_log('[studentbody] admin bootstrap skipped: ' . $e->getMessage());
    }

    try {
        ensure_user_roles($pdo);
    } catch (Throwable $e) {
        error_log('[studentbody] role upgrade failed: ' . $e->getMessage());
        $migrated = false; // try again on the next request instead of caching a half-upgraded schema
    }

    if ($seeded) {
        try {
            ensure_indexes($pdo);
        } catch (Throwable $e) {
            // Optional speed-up only: the app works without these indexes.
            error_log('[studentbody] index upgrade skipped: ' . $e->getMessage());
        }
    }

    if ($seeded) {
        try {
            $pdo->exec(NOTIFICATIONS_TABLE_SQL);
            $pdo->exec(ADMIN_RECOVERY_TABLE_SQL);
            // Housekeeping: old notifications are not worth keeping forever.
            $pdo->exec('DELETE FROM notifications WHERE created_at < NOW() - INTERVAL ' . NOTIFICATION_RETENTION_DAYS . ' DAY');
        } catch (Throwable $e) {
            // Notifications are optional: the rest of the app keeps working without them.
            error_log('[studentbody] notifications setup skipped: ' . $e->getMessage());
        }
    }

    if ($seeded) {
        try {
            ensure_improvements($pdo);
        } catch (Throwable $e) {
            error_log('[studentbody] improvements upgrade failed: ' . $e->getMessage());
            $migrated = false; // retry on the next request
        }
    }

    if ($seeded) {
        try {
            qr_ensure_tables($pdo);
        } catch (Throwable $e) {
            // QR attendance is an add-on: the rest of the app keeps working, and its pages retry via qr_ensure_ready().
            error_log('[studentbody] QR tables setup skipped: ' . $e->getMessage());
        }
    }

    if ($migrated && $seeded) {
        $_SESSION['schema_ready'] = true;
    }
}

/**
 * Older databases have a users.role ENUM without the officer roles (Director, Manager I – VIII, ...).
 * Creating such an account then fails (or stores a blank role), so widen the ENUM to match the app.
 */
function ensure_user_roles(PDO $pdo): void
{
    $type = (string) $pdo->query(
        "SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role'"
    )->fetchColumn();
    if ($type === '') {
        return; // table not imported yet
    }
    $roles = array_keys(ROLE_LABELS);
    if (str_contains($type, "'bus_manager'")) {
        // The Bus Manager role was replaced by Secretary: widen, convert existing accounts, then drop the old value.
        $list = implode(',', array_map(static fn(string $r): string => "'" . $r . "'", [...$roles, 'bus_manager']));
        $pdo->exec("ALTER TABLE users MODIFY role ENUM({$list}) NOT NULL");
        $pdo->exec("UPDATE users SET role = 'secretary' WHERE role = 'bus_manager'");
        $type = str_replace("'bus_manager'", '', $type);
    }
    foreach ($roles as $role) {
        if (!str_contains($type, "'" . $role . "'")) {
            // Roles come from the constant above, never from user input.
            $list = implode(',', array_map(static fn(string $r): string => "'" . $r . "'", $roles));
            $pdo->exec("ALTER TABLE users MODIFY role ENUM({$list}) NOT NULL");
            break;
        }
    }
    // Director / Assistant Director became President / Internal Vice President.
    $pdo->exec("UPDATE users SET role = 'president' WHERE role = 'director'");
    $pdo->exec("UPDATE users SET role = 'internal_vp' WHERE role = 'assistant_director'");
}

/** Older installs named the students.position column "section". */
function migrate_section_to_position(PDO $pdo): void
{
    $has = static function (string $column) use ($pdo): bool {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND COLUMN_NAME = ?"
        );
        $stmt->execute([$column]);
        return (int) $stmt->fetchColumn() > 0;
    };

    if (!$has('position') && $has('section')) {
        $pdo->exec('ALTER TABLE students CHANGE COLUMN section position VARCHAR(50) NULL');
    }
}

/** Create the default administrator only when no admin exists. */
function seed_default_admin(PDO $pdo): void
{
    $check = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = ?');
    $check->execute([ROLE_ADMIN]);
    if ((int) $check->fetchColumn() > 0) {
        return;
    }
    $stmt = $pdo->prepare('INSERT INTO users (username, password, role, student_id) VALUES (?, ?, ?, NULL)');
    $stmt->execute([DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_HASH, ROLE_ADMIN]);
}

/** Add any missing index from SCHEMA_INDEXES. */
function ensure_indexes(PDO $pdo): void
{
    $exists = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?'
    );
    foreach (SCHEMA_INDEXES as [$table, $index, $columns]) {
        $exists->execute([$table, $index]);
        if ((int) $exists->fetchColumn() === 0) {
            // Identifiers come from the constant above, never from user input.
            $list = '`' . implode('`, `', array_map('trim', explode(',', $columns))) . '`';
            $pdo->exec("ALTER TABLE `{$table}` ADD INDEX `{$index}` ({$list})");
        }
    }
}

/**
 * Create the tables added after the first release (IMPROVEMENT_TABLES_SQL) and users.is_active.
 * Every statement is idempotent and none deletes data. "ADD COLUMN IF NOT EXISTS" only exists in MariaDB,
 * so the column is added after a portable INFORMATION_SCHEMA check.
 */
function ensure_improvements(PDO $pdo): void
{
    $names = sql_placeholders(count(IMPROVEMENT_TABLES_SQL));
    // Fast path (every session after the first upgrade): one query confirms the column and every table exist.
    $stmt = $pdo->prepare(
        "SELECT (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$names}))
              + (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'is_active')"
    );
    $stmt->execute(array_keys(IMPROVEMENT_TABLES_SQL));
    if ((int) $stmt->fetchColumn() === count(IMPROVEMENT_TABLES_SQL) + 1) {
        return;
    }

    $has = $pdo->query(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'is_active'"
    );
    if ((int) $has->fetchColumn() === 0) {
        $pdo->exec('ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1');
    }
    foreach (IMPROVEMENT_TABLES_SQL as $sql) {
        $pdo->exec($sql);
    }
}
