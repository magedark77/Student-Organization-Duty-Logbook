<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* ---- Response headers -------------------------------------------------- */

if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    // No inline scripts or event-handler attributes anywhere (pages use data-* hooks handled by assets/js/app.js), so scripts stay 'self' only.
    // style-src keeps 'unsafe-inline' for the width style on progress bars.
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        . "font-src https://fonts.gstatic.com; img-src 'self' data:; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
}

/* ---- Output escaping --------------------------------------------------- */

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/* ---- CSRF ---------------------------------------------------------------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_is_valid(): bool
{
    $sent = $_POST['csrf'] ?? '';
    return is_string($sent) && hash_equals((string) ($_SESSION['csrf'] ?? ''), $sent);
}

function check_csrf(): void
{
    if (!csrf_is_valid()) {
        render_error_page(419, 'Session expired', 'Your security token is invalid or has expired. Please go back, refresh the page and try again.');
    }
}
