<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

const AUDIT_PAGE_SIZE   = 50;
const AUDIT_SYSTEM_USER = '__system'; // filter value for entries with no signed-in user
const AUDIT_SORTS       = ['date' => 'Date', 'user' => 'User', 'action' => 'Action', 'table' => 'Table'];

/** Record who changed what. Values are stored as JSON. */
function audit(string $action, string $table, ?int $recordId, string $description, mixed $old = null, mixed $new = null): void
{
    db_run(
        'INSERT INTO audit_logs (user_id, action, table_name, record_id, description, old_values, new_values)
         VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            user()['id'] ?? null,
            $action,
            $table,
            $recordId,
            mb_strlen($description) > 500 ? mb_substr($description, 0, 497) . '…' : $description, // the column holds 500 characters
            $old !== null ? json_encode($old) : null,
            $new !== null ? json_encode($new) : null,
        ]
    );
}

/** Filters from the query string: user, action, table, q (description text), from, to (dates). */
function audit_filters_from_request(): array
{
    $date = static fn(string $key): string => is_valid_date(get_str($key)) ? get_str($key) : '';
    return [
        'user'   => get_str('user'),
        'action' => get_str('action'),
        'table'  => get_str('table'),
        'q'      => get_str('q'),
        'from'   => $date('from'),
        'to'     => $date('to'),
    ];
}

/**
 * One page of audit entries.
 *
 * @param array $filters see audit_filters_from_request()
 * @param array $sort    [key from AUDIT_SORTS, 'asc'|'desc']
 * @return array{rows: array<int, array>, total: int, page: int, pages: int}
 */
function audit_search(array $filters, array $sort, int $page): array
{
    $where  = [];
    $params = [];
    if ($filters['user'] === AUDIT_SYSTEM_USER) {
        $where[] = 'a.user_id IS NULL';
    } elseif ($filters['user'] !== '') {
        $where[]  = 'u.username = ?';
        $params[] = $filters['user'];
    }
    if ($filters['action'] !== '') {
        $where[]  = 'a.action = ?';
        $params[] = $filters['action'];
    }
    if ($filters['table'] !== '') {
        $where[]  = 'a.table_name = ?';
        $params[] = $filters['table'];
    }
    if ($filters['q'] !== '') {
        $where[]  = 'a.description LIKE ?';
        $params[] = '%' . addcslashes($filters['q'], '%_\\') . '%';
    }
    if ($filters['from'] !== '') {
        $where[]  = 'a.created_at >= ?';
        $params[] = $filters['from'] . ' 00:00:00';
    }
    if ($filters['to'] !== '') {
        $where[]  = 'a.created_at <= ?';
        $params[] = $filters['to'] . ' 23:59:59';
    }
    $from = ' FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id' . ($where ? ' WHERE ' . implode(' AND ', $where) : '');

    $total = (int) db_value('SELECT COUNT(*)' . $from, $params);
    $pager = paginate($total, AUDIT_PAGE_SIZE, $page);

    $dir      = $sort[1] === 'asc' ? 'ASC' : 'DESC';
    $orderCol = match ($sort[0]) {
        'user'   => 'u.username',
        'action' => 'a.action',
        'table'  => 'a.table_name',
        default  => 'a.created_at',
    };
    // LIMIT and OFFSET cannot be bound as strings with native prepared statements; both are integers computed here.
    $rows = db_run(
        'SELECT a.id, a.created_at, a.action, a.table_name, a.description, a.old_values, a.new_values, u.username'
        . $from . " ORDER BY {$orderCol} {$dir}, a.id {$dir} LIMIT " . AUDIT_PAGE_SIZE . ' OFFSET ' . $pager['offset'],
        $params
    )->fetchAll();

    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/** The newest entries, for the dashboard feed (no count query, no filters). */
function audit_recent(int $limit = 4): array
{
    $limit = max(1, $limit);
    return db_all(
        "SELECT a.created_at, a.description, u.username
         FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
         ORDER BY a.created_at DESC, a.id DESC LIMIT {$limit}"
    );
}

/** Values for the filter dropdowns: ['users' => [...], 'actions' => [...], 'tables' => [...]]. */
function audit_filter_options(): array
{
    return [
        'users'   => db_run('SELECT username FROM users WHERE id IN (SELECT DISTINCT user_id FROM audit_logs WHERE user_id IS NOT NULL) ORDER BY username')
            ->fetchAll(PDO::FETCH_COLUMN),
        'actions' => db_run('SELECT DISTINCT action FROM audit_logs ORDER BY action')->fetchAll(PDO::FETCH_COLUMN),
        'tables'  => db_run('SELECT DISTINCT table_name FROM audit_logs ORDER BY table_name')->fetchAll(PDO::FETCH_COLUMN),
    ];
}

/** Old and new values of an entry as pretty JSON, or null when nothing was recorded. */
function audit_changes_json(array $log): ?string
{
    if ($log['old_values'] === null && $log['new_values'] === null) {
        return null;
    }
    $decode = static fn(?string $json): mixed => $json !== null ? json_decode($json, true) : null;
    return json_encode(
        ['old' => $decode($log['old_values']), 'new' => $decode($log['new_values'])],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
}
