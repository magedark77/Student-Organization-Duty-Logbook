<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * QR-code attendance.
 *
 * A student's QR code holds ONLY an opaque random token ("SOLQR1:" + 32 hex characters). It contains no name, student
 * number or database detail; the server looks the token up in qr_codes and decides everything else (which student,
 * Time In or Time Out, late or not) using its own clock. Scans are written to the existing `attendance` table through
 * attendance_persist(), so the audit log, change history, hour totals and reports keep working unchanged.
 *
 * Tables added by this feature (see schema_tables.php): qr_codes, qr_scans, qr_settings.
 */

/** Text that starts every QR code of this app; the version digit allows a future format change. */
const QR_PREFIX = 'SOLQR1:';

/** The four attendance columns in the order they happen during a day. */
const QR_SLOTS = [
    'morning_time_in'    => ['Morning', 'Time In'],
    'morning_time_out'   => ['Morning', 'Time Out'],
    'afternoon_time_in'  => ['Afternoon', 'Time In'],
    'afternoon_time_out' => ['Afternoon', 'Time Out'],
];

/** Defaults for every setting; the admin changes them on the QR Settings page. Times are 24-hour HH:MM. */
const QR_SETTING_DEFAULTS = [
    'enabled'         => '1',     // 1 = scanning allowed
    'allow_manual'    => '1',     // 1 = scanner page offers "type the student number" when the camera is unavailable
    'morning_start'   => '08:00', // morning Time In after this (+ grace) is late
    'morning_end'     => '12:00', // morning Time Out before this (- grace) is an early departure
    'afternoon_start' => '13:00',
    'afternoon_end'   => '17:00',
    'session_cutoff'  => '12:00', // the FIRST scan of a day before this is a morning Time In, at/after it an afternoon Time In
    'late_grace'      => '15',    // minutes allowed after the start time before "late"
    'early_grace'     => '0',     // minutes allowed before the end time before "early"
    'min_gap'         => '60',    // seconds between two scans of the same student (never below 60, see qr_effective_gap())
];

/** Rejected scans of unknown codes allowed per user in 5 minutes before the scanner is paused (guessing protection). */
const QR_MAX_INVALID_PER_5_MIN = 25;

/** A scan that was refused. `reason` is machine-readable, the message is safe to show on the scanner screen. */
class QrScanException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly string $reason,
        public readonly int $httpStatus = 422,
        public readonly ?array $student = null,
        public readonly array $extra = []
    ) {
        parent::__construct($message);
    }
}

/* ---- Pure helpers (no database; covered by tests/qr.php) ------------------------------------------------------ */

/** Human label of a slot column: "Morning Time In". */
function qr_slot_label(string $slot): string
{
    return isset(QR_SLOTS[$slot]) ? QR_SLOTS[$slot][0] . ' ' . QR_SLOTS[$slot][1] : $slot;
}

/** 'Time In' or 'Time Out' for a slot column. */
function qr_slot_action(string $slot): string
{
    return QR_SLOTS[$slot][1] ?? '';
}

/** A fresh unguessable token: 128 random bits as 32 hex characters. */
function qr_token_new(): string
{
    return bin2hex(random_bytes(16));
}

/** The exact text stored in a student's QR code. */
function qr_payload(string $token): string
{
    return QR_PREFIX . $token;
}

/**
 * Pull the token out of scanned text. Returns null for anything that is not one of our codes
 * (so random QR codes, URLs and oversized input are rejected before touching the database).
 */
function qr_extract_token(string $scanned): ?string
{
    $scanned = trim($scanned);
    if (strlen($scanned) !== strlen(QR_PREFIX) + 32 || !str_starts_with($scanned, QR_PREFIX)) {
        return null;
    }
    $token = strtolower(substr($scanned, strlen(QR_PREFIX)));
    return preg_match('/^[a-f0-9]{32}$/', $token) === 1 ? $token : null;
}

/** Scans of the same student are never accepted closer than 60 s: a Time Out must land in a later minute than its Time In. */
function qr_effective_gap(array $settings): int
{
    return max(60, (int) ($settings['min_gap'] ?? 60));
}

/** Seconds since midnight of 'HH:MM' or 'HH:MM:SS', or null. */
function qr_seconds(?string $time): ?int
{
    if ($time === null || !preg_match('/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/', $time, $m)) {
        return null;
    }
    return (int) $m[1] * 3600 + (int) $m[2] * 60 + (int) ($m[3] ?? 0);
}

/**
 * Which column the next scan fills: the slot after the last one filled, so a day always runs
 * Morning In → Morning Out → Afternoon In → Afternoon Out. A day with no times starts with a morning Time In before
 * the cut-off time, or an afternoon Time In from then on. Returns null when the day is complete.
 *
 * @param array<string, mixed>|null $row attendance row (or null) with the four time columns
 */
function qr_next_slot(?array $row, string $time, array $settings): ?string
{
    $order = array_keys(QR_SLOTS);
    $last  = -1;
    foreach ($order as $i => $column) {
        if (!empty($row[$column])) {
            $last = $i;
        }
    }
    if ($last === -1) {
        $now    = qr_seconds($time) ?? 0;
        $cutoff = qr_seconds((string) $settings['session_cutoff']) ?? 43200;
        return $now < $cutoff ? 'morning_time_in' : 'afternoon_time_in';
    }
    return $order[$last + 1] ?? null;
}

/**
 * Order rules for a day that may still be open (a Time In without its Time Out is normal while the scanner is in use,
 * unlike on the manual form where in/out come as a pair). Same rules otherwise: a Time Out must fall in a later minute
 * than its Time In, and the afternoon cannot begin before the morning Time Out.
 *
 * @throws ValidationException
 */
function qr_validate_times(array $v): void
{
    $m = static fn(string $c): ?int => time_to_minutes($v[$c] ?? null);
    foreach ([['morning_time_in', 'morning_time_out', 'Morning'], ['afternoon_time_in', 'afternoon_time_out', 'Afternoon']] as [$in, $out, $label]) {
        if ($m($out) !== null && $m($in) === null) {
            throw new ValidationException($label . ': Time Out cannot be recorded before a Time In.');
        }
        if ($m($out) !== null && $m($out) <= $m($in)) {
            throw new ValidationException($label . ': Time Out must be later than Time In.');
        }
    }
    if ($m('morning_time_out') !== null && $m('afternoon_time_in') !== null && $m('afternoon_time_in') < $m('morning_time_out')) {
        throw new ValidationException('Afternoon Time In cannot be earlier than the morning Time Out.');
    }
    if ($m('morning_time_in') !== null && $m('afternoon_time_in') !== null && $m('morning_time_out') === null) {
        return; // forgotten morning Time Out: allowed, the administrator can correct it
    }
}

/** Seconds since the latest time already stored in $row, or null when the row has no times. */
function qr_seconds_since_last(?array $row, string $time): ?int
{
    $latest = null;
    foreach (array_keys(QR_SLOTS) as $column) {
        $s = qr_seconds($row[$column] ?? null);
        if ($s !== null && ($latest === null || $s > $latest)) {
            $latest = $s;
        }
    }
    $now = qr_seconds($time);
    return ($latest === null || $now === null) ? null : $now - $latest;
}

/**
 * Late / early classification of one scan (whole minutes, like the rest of the app).
 *
 * @return array{status: string, minutes: int} status: on_time | late | early
 */
function qr_scan_status(string $slot, string $time, array $settings): array
{
    $m = intdiv(qr_seconds($time) ?? 0, 60);
    $t = static fn(string $key): int => intdiv(qr_seconds((string) $settings[$key]) ?? 0, 60);
    switch ($slot) {
        case 'morning_time_in':
        case 'afternoon_time_in':
            $start = $t($slot === 'morning_time_in' ? 'morning_start' : 'afternoon_start');
            return $m > $start + (int) $settings['late_grace']
                ? ['status' => 'late', 'minutes' => $m - $start]
                : ['status' => 'on_time', 'minutes' => 0];
        default:
            $end = $t($slot === 'morning_time_out' ? 'morning_end' : 'afternoon_end');
            return $m < $end - (int) $settings['early_grace']
                ? ['status' => 'early', 'minutes' => $end - $m]
                : ['status' => 'on_time', 'minutes' => 0];
    }
}

/**
 * Flags for an attendance row, from its times and the current rules. Works for QR and manually entered records alike.
 *
 * @return array{late: bool, late_minutes: int, early: bool, early_minutes: int, open: bool, has_times: bool}
 */
function qr_row_flags(?array $row, array $settings): array
{
    $flags = ['late' => false, 'late_minutes' => 0, 'early' => false, 'early_minutes' => 0, 'open' => false, 'has_times' => false];
    if ($row === null) {
        return $flags;
    }
    foreach (['morning_time_in', 'afternoon_time_in'] as $slot) {
        if (!empty($row[$slot])) {
            $r = qr_scan_status($slot, (string) $row[$slot], $settings);
            if ($r['status'] === 'late') {
                $flags['late'] = true;
                $flags['late_minutes'] = max($flags['late_minutes'], $r['minutes']);
            }
        }
    }
    foreach (['morning_time_out', 'afternoon_time_out'] as $slot) {
        if (!empty($row[$slot])) {
            $r = qr_scan_status($slot, (string) $row[$slot], $settings);
            if ($r['status'] === 'early') {
                $flags['early'] = true;
                $flags['early_minutes'] = max($flags['early_minutes'], $r['minutes']);
            }
        }
    }
    $flags['open'] = (!empty($row['morning_time_in']) && empty($row['morning_time_out']))
        || (!empty($row['afternoon_time_in']) && empty($row['afternoon_time_out']));
    foreach (array_keys(QR_SLOTS) as $column) {
        $flags['has_times'] = $flags['has_times'] || !empty($row[$column]);
    }
    return $flags;
}

/**
 * Validate the settings form. Returns the cleaned values (all strings), or throws ValidationException.
 *
 * @throws ValidationException
 */
function qr_validate_settings(array $input): array
{
    $out = [
        'enabled'      => !empty($input['enabled']) ? '1' : '0',
        'allow_manual' => !empty($input['allow_manual']) ? '1' : '0',
    ];
    foreach (['morning_start', 'morning_end', 'afternoon_start', 'afternoon_end', 'session_cutoff'] as $key) {
        $value = trim((string) ($input[$key] ?? ''));
        if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $value)) {
            throw new ValidationException('Please enter every time as HH:MM (24-hour), for example 08:00 or 13:30.', $key);
        }
        $out[$key] = $value;
    }
    foreach (['late_grace' => [0, 120], 'early_grace' => [0, 120], 'min_gap' => [60, 3600]] as $key => [$min, $max]) {
        $value = trim((string) ($input[$key] ?? ''));
        if (!ctype_digit($value) || (int) $value < $min || (int) $value > $max) {
            throw new ValidationException("Please enter a whole number from {$min} to {$max}.", $key);
        }
        $out[$key] = (string) (int) $value;
    }
    if ($out['morning_start'] >= $out['morning_end']) {
        throw new ValidationException('The morning must end after it starts.', 'morning_end');
    }
    if ($out['afternoon_start'] >= $out['afternoon_end']) {
        throw new ValidationException('The afternoon must end after it starts.', 'afternoon_end');
    }
    if ($out['morning_end'] > $out['afternoon_start']) {
        throw new ValidationException('The afternoon cannot start before the morning ends.', 'afternoon_start');
    }
    if ($out['session_cutoff'] <= $out['morning_start'] || $out['session_cutoff'] > $out['afternoon_end']) {
        throw new ValidationException('The morning/afternoon cut-off must be after the morning start and not after the afternoon end.', 'session_cutoff');
    }
    return $out;
}

/* ---- Settings ------------------------------------------------------------------------------------------------- */

/**
 * Current settings (defaults + saved values). Cached per request; pass $refresh after saving.
 * If the table cannot be read the defaults are used, so a scan never fails because of a settings problem.
 */
function qr_settings(bool $refresh = false): array
{
    static $cache = null;
    if ($cache !== null && !$refresh) {
        return $cache;
    }
    $settings = QR_SETTING_DEFAULTS;
    try {
        foreach (db_all('SELECT setting_key, setting_value FROM qr_settings') as $row) {
            if (isset($settings[$row['setting_key']])) {
                $settings[$row['setting_key']] = (string) $row['setting_value'];
            }
        }
        // A hand-edited or corrupted value falls back to its default instead of breaking scans.
        try {
            qr_validate_settings($settings);
        } catch (ValidationException) {
            $settings = QR_SETTING_DEFAULTS;
        }
    } catch (Throwable $e) {
        error_log('[studentbody] qr settings unavailable, using defaults: ' . $e->getMessage());
    }
    return $cache = $settings;
}

function qr_enabled(): bool
{
    return qr_settings()['enabled'] === '1';
}

/** Save validated settings (administrator only; the page checks). One audit entry records old and new values. */
function qr_settings_save(array $input): void
{
    $new = qr_validate_settings($input);
    $old = qr_settings(true);
    db_transaction(static function (PDO $pdo) use ($new): void {
        $userId = user()['id'] ?? null;
        foreach ($new as $key => $value) {
            $exists = db_value('SELECT COUNT(*) FROM qr_settings WHERE setting_key = ?', [$key]);
            if ((int) $exists > 0) {
                $pdo->prepare('UPDATE qr_settings SET setting_value = ?, updated_by = ? WHERE setting_key = ?')->execute([$value, $userId, $key]);
            } else {
                $pdo->prepare('INSERT INTO qr_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?)')->execute([$key, $value, $userId]);
            }
        }
    });
    audit('UPDATE', 'qr_settings', null, 'Changed QR attendance settings', $old, $new);
    qr_settings(true);
}

/* ---- QR codes ------------------------------------------------------------------------------------------------- */

/** ' FOR UPDATE' on MySQL/MariaDB (locks the student row so two scans of one student cannot interleave). */
function qr_lock_clause(): string
{
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql' ? ' FOR UPDATE' : '';
}

/** The student's token, creating it first if the student has none. */
function qr_code_ensure(int $studentId): string
{
    $row = db_one('SELECT token FROM qr_codes WHERE student_id = ?', [$studentId]);
    if ($row !== null) {
        return (string) $row['token'];
    }
    $token = qr_token_new();
    try {
        db_run('INSERT INTO qr_codes (student_id, token) VALUES (?, ?)', [$studentId, $token]);
    } catch (PDOException $e) {
        if (!db_is_duplicate_key($e)) {
            throw $e;
        }
        // Another request created it a moment ago: use that one.
        return (string) db_value('SELECT token FROM qr_codes WHERE student_id = ?', [$studentId]);
    }
    return $token;
}

/** Give every student without a code a new one. Returns how many were created. */
function qr_codes_generate_missing(): int
{
    $ids = db_all('SELECT s.id FROM students s LEFT JOIN qr_codes c ON c.student_id = s.id WHERE c.id IS NULL');
    foreach ($ids as $row) {
        qr_code_ensure((int) $row['id']);
    }
    return count($ids);
}

/** Replace a student's code. The old printed/saved code stops working immediately. */
function qr_code_regenerate(int $studentId): void
{
    $student = student_find($studentId);
    if ($student === null) {
        throw new ValidationException('That student no longer exists.');
    }
    $token = qr_token_new();
    db_transaction(static function (PDO $pdo) use ($studentId, $token, $student): void {
        $exists = (int) db_value('SELECT COUNT(*) FROM qr_codes WHERE student_id = ?', [$studentId]);
        if ($exists > 0) {
            $pdo->prepare('UPDATE qr_codes SET token = ?, is_active = 1, regenerated_at = ?, regenerated_by = ? WHERE student_id = ?')
                ->execute([$token, date('Y-m-d H:i:s'), user()['id'] ?? null, $studentId]);
        } else {
            $pdo->prepare('INSERT INTO qr_codes (student_id, token) VALUES (?, ?)')->execute([$studentId, $token]);
        }
        // The token itself is never written to the audit log.
        audit('UPDATE', 'qr_codes', $studentId, 'Regenerated QR code for ' . student_label($student));
    });
}

/** Switch a student's code off or on without changing it (lost card: disable first, regenerate later). */
function qr_code_set_active(int $studentId, bool $active): void
{
    qr_code_ensure($studentId);
    db_run('UPDATE qr_codes SET is_active = ? WHERE student_id = ?', [$active ? 1 : 0, $studentId]);
    $student = student_find($studentId);
    audit('UPDATE', 'qr_codes', $studentId, ($active ? 'Enabled' : 'Disabled') . ' QR code for ' . ($student !== null ? student_label($student) : '#' . $studentId));
}

/** Student + code state for the QR Codes page: filters as in student_filters_from_request(). */
function qr_codes_search(array $filters, int $page, int $perPage = 24, bool $all = false): array
{
    $params = [];
    $where  = student_filter_sql('s', $filters, $params);
    $sql    = 'FROM students s LEFT JOIN qr_codes c ON c.student_id = s.id' . ($where !== '' ? ' WHERE ' . $where : '');
    $total  = (int) db_value('SELECT COUNT(*) ' . $sql, $params);
    $pager  = $all ? ['page' => 1, 'pages' => 1, 'offset' => 0] : paginate($total, $perPage, $page);
    $limit  = $all ? 500 : $perPage; // ints, safe to inline
    $rows   = db_all(
        'SELECT s.id, s.student_number, s.first_name, s.middle_name, s.last_name, s.course, s.year_level, s.position, s.status,
                c.token, c.is_active, c.regenerated_at ' . $sql
        . ' ORDER BY s.last_name, s.first_name, s.id LIMIT ' . $limit . ' OFFSET ' . $pager['offset'],
        $params
    );
    return ['rows' => $rows, 'total' => $total] + $pager;
}

/** Students by id with their code (creating missing ones), for the print sheet. */
function qr_codes_for_ids(array $ids): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $i): bool => $i > 0)));
    $ids = array_slice($ids, 0, 500);
    if (!$ids) {
        return [];
    }
    foreach ($ids as $id) {
        qr_code_ensure($id);
    }
    return db_all(
        'SELECT s.id, s.student_number, s.first_name, s.middle_name, s.last_name, s.course, s.year_level, s.position, s.status, c.token, c.is_active
         FROM students s JOIN qr_codes c ON c.student_id = s.id WHERE s.id IN (' . sql_placeholders(count($ids)) . ')
         ORDER BY s.last_name, s.first_name, s.id',
        $ids
    );
}

/** Public URL path of a student's photo when a file named after the student number exists in assets/photos/, else null. */
function student_photo_url(array $student): ?string
{
    $name = preg_replace('/[^A-Za-z0-9._-]/', '_', (string) ($student['student_number'] ?? ''));
    if ($name === '' || $name === null) {
        return null;
    }
    foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
        if (is_file(APP_ROOT . '/assets/photos/' . $name . '.' . $ext)) {
            return asset('photos/' . $name . '.' . $ext);
        }
    }
    return null;
}

/* ---- Recording a scan ----------------------------------------------------------------------------------------- */

/** Client IP for the scan log. Only REMOTE_ADDR is trusted (headers such as X-Forwarded-For can be forged). */
function qr_client_ip(): ?string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : null;
}

/** Add a row to the scan log (also for refused scans, so unusual activity can be seen). */
function qr_log_scan(array $v): void
{
    db_run(
        'INSERT INTO qr_scans (request_id, student_id, attendance_id, attendance_date, slot, scanned_time, result, status, minutes_off, method, message, scanned_by, ip, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $v['request_id'] ?? null, $v['student_id'] ?? null, $v['attendance_id'] ?? null, $v['date'], $v['slot'] ?? null, $v['time'],
            $v['result'], $v['status'] ?? null, $v['minutes'] ?? null, $v['method'] ?? 'camera',
            mb_substr((string) ($v['message'] ?? ''), 0, 255), user()['id'] ?? null, qr_client_ip(),
            $v['date'] . ' ' . $v['time'], // PHP clock, the same one the throttle compares against
        ]
    );
}

/** The data the scanner screen shows about a student. */
function qr_student_card(array $student): array
{
    return [
        'id'       => (int) $student['id'],
        'name'     => student_display_name($student),
        'number'   => (string) $student['student_number'],
        'course'   => (string) ($student['course'] ?? ''),
        'position' => (string) ($student['position'] ?? ''),
        'duty_day' => (string) ($student['year_level'] ?? ''),
        'initials' => user_initials(trim($student['first_name'] . ' ' . $student['last_name'])),
        'photo'    => student_photo_url($student),
    ];
}

/**
 * Handle one scan and record attendance.
 *
 * @param string $scanned   text read from the QR code, or (method "manual") a student number
 * @param string $requestId 32 hex characters made by the scanner for this one scan; a retry with the same id returns the
 *                          first result instead of recording twice
 * @param string $method    'camera' or 'manual'
 * @param DateTimeImmutable|null $now injectable clock for tests; production always uses the server clock
 * @return array result for the scanner screen (see keys below)
 * @throws QrScanException when the scan is refused
 */
function qr_process_scan(string $scanned, string $requestId, string $method = 'camera', ?DateTimeImmutable $now = null): array
{
    $now    = $now ?? new DateTimeImmutable('now');
    $date   = $now->format('Y-m-d');
    $time   = $now->format('H:i:s');
    $method = $method === 'manual' ? 'manual' : 'camera';
    $requestId = preg_match('/^[a-f0-9]{32}$/', $requestId) === 1 ? $requestId : null;
    $log = ['date' => $date, 'time' => $time, 'method' => $method, 'request_id' => $requestId];

    $settings = qr_settings();
    if ($settings['enabled'] !== '1') {
        throw new QrScanException('QR attendance is switched off. Ask an administrator to enable it.', 'disabled', 503);
    }

    // A retry of a scan that already succeeded (network drop, double tap): give the same answer, record nothing new.
    if ($requestId !== null) {
        $prior = db_one('SELECT * FROM qr_scans WHERE request_id = ?', [$requestId]);
        if ($prior !== null) {
            return qr_replay($prior);
        }
    }

    // Too many unknown codes from one user in a few minutes looks like guessing.
    $uid = user()['id'] ?? 0;
    $recent = (int) db_value(
        "SELECT COUNT(*) FROM qr_scans WHERE scanned_by = ? AND result = 'invalid' AND created_at >= ?",
        [$uid, $now->modify('-5 minutes')->format('Y-m-d H:i:s')]
    );
    if ($recent >= QR_MAX_INVALID_PER_5_MIN) {
        throw new QrScanException('Too many unrecognised codes. Please wait a few minutes and try again.', 'throttled', 429);
    }

    // Find the student.
    $student = null;
    if ($method === 'manual') {
        if ($settings['allow_manual'] !== '1') {
            throw new QrScanException('Manual entry is turned off in the QR settings.', 'manual_disabled', 403);
        }
        $typed = trim($scanned);
        if ($typed === '' || mb_strlen($typed) > 60) {
            throw new QrScanException('Enter a student number.', 'invalid', 422);
        }
        // A pasted QR text also works in the manual box.
        $token = qr_extract_token($typed);
        $student = $token !== null
            ? db_one('SELECT s.* FROM qr_codes c JOIN students s ON s.id = c.student_id WHERE c.token = ? AND c.is_active = 1', [$token])
            : db_one('SELECT * FROM students WHERE student_number = ? LIMIT 1', [$typed]);
        if ($student !== null && $token === null) {
            $active = db_value('SELECT is_active FROM qr_codes WHERE student_id = ?', [$student['id']]);
            if ($active !== false && $active !== null && (int) $active === 0) {
                $student = null; // a disabled (lost) code also blocks manual entry for that student
            }
        }
    } else {
        $token = qr_extract_token($scanned);
        if ($token !== null) {
            $found = db_one('SELECT s.*, c.is_active FROM qr_codes c JOIN students s ON s.id = c.student_id WHERE c.token = ?', [$token]);
            if ($found !== null && (int) $found['is_active'] === 1) {
                $student = $found;
            } elseif ($found !== null) {
                qr_log_scan($log + ['student_id' => (int) $found['id'], 'result' => 'invalid', 'message' => 'Disabled QR code']);
                throw new QrScanException('This QR code has been disabled. Please contact the administrator.', 'disabled_code', 422, qr_student_card($found));
            }
        }
    }
    if ($student === null) {
        qr_log_scan($log + ['result' => 'invalid', 'message' => 'Unrecognised ' . ($method === 'manual' ? 'student number' : 'QR code')]);
        throw new QrScanException(
            $method === 'manual' ? 'No student found with that number.' : 'Invalid or unregistered QR code.',
            'invalid'
        );
    }
    $card = qr_student_card($student);

    // The rest happens under a lock on the student's row: two scans of one student are handled one after the other.
    try {
        $outcome = db_transaction(static function (PDO $pdo) use ($student, $date, $time, $settings, $log, $card): array {
            db_value('SELECT id FROM students WHERE id = ?' . qr_lock_clause(), [$student['id']]);
            $fresh = student_find((int) $student['id']);
            if ($fresh === null || $fresh['status'] !== 'Active') {
                $msg = 'This student is not Active, so attendance cannot be recorded.';
                qr_log_scan($log + ['student_id' => (int) $student['id'], 'result' => 'inactive', 'message' => $msg]);
                return ['error' => ['inactive', $msg, 422]];
            }
            $row = attendance_find_for((int) $student['id'], $date);

            // Duplicate / repeated scan guard.
            $since = qr_seconds_since_last($row, $time);
            $gap   = qr_effective_gap($settings);
            if ($since !== null && $since >= 0 && $since < $gap) {
                $wait = $gap - $since;
                $msg  = 'Already scanned ' . $since . ' second' . ($since === 1 ? '' : 's') . ' ago. Please wait ' . $wait . ' second' . ($wait === 1 ? '' : 's') . '.';
                qr_log_scan($log + ['student_id' => (int) $student['id'], 'attendance_id' => $row['id'] ?? null, 'result' => 'duplicate', 'message' => $msg]);
                return ['error' => ['duplicate', $msg, 409, ['retry_after' => $wait]]];
            }

            $slot = qr_next_slot($row, $time, $settings);
            if ($slot === null) {
                $msg = 'Attendance for today is already complete (Time Out recorded).';
                qr_log_scan($log + ['student_id' => (int) $student['id'], 'attendance_id' => $row['id'] ?? null, 'result' => 'complete', 'message' => $msg]);
                return ['error' => ['complete', $msg, 409]];
            }

            // Build the full set of times and run them through the same rules as the manual form.
            $values = [
                'morning_time_in'    => $row['morning_time_in'] ?? null,
                'morning_time_out'   => $row['morning_time_out'] ?? null,
                'afternoon_time_in'  => $row['afternoon_time_in'] ?? null,
                'afternoon_time_out' => $row['afternoon_time_out'] ?? null,
            ];
            $values[$slot] = $time;
            qr_validate_times($values);
            $values['remarks'] = $row['remarks'] ?? null; // never overwrite an administrator's remark

            $result = qr_scan_status($slot, $time, $settings);
            attendance_persist($row, (int) $student['id'], $date, $values, 'QR scan: ' . qr_slot_label($slot), 'update');
            $saved = attendance_find_for((int) $student['id'], $date);
            $msg   = qr_slot_label($slot) . ' recorded successfully.';
            qr_log_scan($log + [
                'student_id' => (int) $student['id'], 'attendance_id' => (int) $saved['id'], 'slot' => $slot,
                'result' => 'ok', 'status' => $result['status'], 'minutes' => $result['minutes'], 'message' => $msg,
            ]);
            return ['ok' => ['slot' => $slot, 'row' => $saved, 'created' => $row === null, 'status' => $result]];
        });
    } catch (DuplicateAttendanceException) {
        // Two scans of this student crossed on a database without row locks: the other one was recorded first.
        throw new QrScanException('This student was scanned a moment ago. Please wait a few seconds.', 'duplicate', 409, $card, ['retry_after' => qr_effective_gap($settings)]);
    } catch (ValidationException $e) {
        // The times would break an attendance rule (for example the server clock moved backwards).
        throw new QrScanException($e->getMessage() . ' Nothing was recorded; ask an administrator to check today\'s record.', 'invalid_time', 422, $card);
    } catch (PDOException $e) {
        // The same request id arrived twice at once: the other one won, return its result.
        if (db_is_duplicate_key($e) && $log['request_id'] !== null) {
            $prior = db_one('SELECT * FROM qr_scans WHERE request_id = ?', [$log['request_id']]);
            if ($prior !== null) {
                return qr_replay($prior);
            }
        }
        throw $e;
    }

    if (isset($outcome['error'])) {
        [$reason, $msg, $http] = $outcome['error'];
        throw new QrScanException($msg, $reason, $http, $card, $outcome['error'][3] ?? []);
    }

    ['slot' => $slot, 'row' => $saved, 'created' => $created, 'status' => $status] = $outcome['ok'];
    // Time Out finishes a session: tell the student their hours (and the yearly milestone). Time In needs no message.
    if (str_ends_with($slot, '_out')) {
        notify_attendance_saved($student, $date, $created, false);
    }
    return qr_result_payload($card, $slot, $saved, $status['status'], $status['minutes'], $time, $date, false);
}

/** Rebuild the answer of a scan that was already recorded (retry with the same request id). */
function qr_replay(array $scan): array
{
    if ($scan['result'] !== 'ok') {
        $student = $scan['student_id'] !== null ? student_find((int) $scan['student_id']) : null;
        $http = match ($scan['result']) { 'duplicate', 'complete' => 409, 'disabled' => 503, default => 422 };
        throw new QrScanException((string) $scan['message'], (string) $scan['result'], $http, $student !== null ? qr_student_card($student) : null);
    }
    $student = student_find((int) $scan['student_id']);
    $row     = attendance_find_for((int) $scan['student_id'], (string) $scan['attendance_date']);
    return qr_result_payload(
        $student !== null ? qr_student_card($student) : ['id' => 0, 'name' => 'Student', 'number' => '', 'course' => '', 'position' => '', 'duty_day' => '', 'initials' => '?', 'photo' => null],
        (string) $scan['slot'], $row ?? [], (string) $scan['status'], (int) $scan['minutes_off'], (string) $scan['scanned_time'], (string) $scan['attendance_date'], true
    );
}

/** JSON-ready answer for a recorded scan. */
function qr_result_payload(array $card, string $slot, array $row, string $status, int $minutes, string $time, string $date, bool $replayed): array
{
    $action  = qr_slot_action($slot);
    $session = QR_SLOTS[$slot][0] ?? '';
    $notes   = [];
    if ($status === 'late') {
        $notes[] = 'Late by ' . format_duration($minutes) . '.';
    } elseif ($status === 'early') {
        $notes[] = 'Early departure: ' . format_duration($minutes) . ' before the scheduled end.';
    }
    $minutesToday = attendance_minutes($row)['total'];
    if ($action === 'Time Out' && $minutesToday > 0) {
        $notes[] = 'Hours logged today: ' . format_duration($minutesToday) . '.';
    }
    if ($slot === 'morning_time_out' && intdiv(qr_seconds($time) ?? 0, 60) >= intdiv(qr_seconds((string) qr_settings()['afternoon_start']) ?? 0, 60)) {
        $notes[] = 'This morning Time Out is after the afternoon start. If the student was arriving for the afternoon, ask an administrator to correct the record.';
    }
    return [
        'ok'        => true,
        'replayed'  => $replayed,
        'message'   => $action . ' Recorded Successfully',
        'detail'    => $session . ' ' . $action . ' at ' . format_clock($time) . ' on ' . format_date($date),
        'action'    => $action,
        'slot'      => $slot,
        'session'   => $session,
        'status'    => $status,
        'time'      => format_clock($time),
        'time_full' => $time,
        'date'      => $date,
        'notes'     => $notes,
        'student'   => $card,
        'today'     => [
            'morning'   => format_time_range($row['morning_time_in'] ?? null, $row['morning_time_out'] ?? null),
            'afternoon' => format_time_range($row['afternoon_time_in'] ?? null, $row['afternoon_time_out'] ?? null),
        ],
    ];
}

/* ---- Monitor (today / any date) -------------------------------------------------------------------------------- */

const QR_STATUS_FILTERS = [
    'present'  => 'Present (has a record)',
    'late'     => 'Late',
    'early'    => 'Early departure',
    'open'     => 'Still timed in',
    'complete' => 'Timed out',
    'absent'   => 'Absent',
];

/** Filters for the monitor page from the query string. */
function qr_monitor_filters_from_request(): array
{
    $date = get_str('date');
    return [
        'date'   => is_valid_date($date) ? $date : date('Y-m-d'),
        'q'      => get_str('q'),
        'course' => get_str('course'),
        'year'   => get_choice('day', DUTY_DAYS),
        'status' => get_choice('status', array_keys(QR_STATUS_FILTERS)),
        'all'    => get_str('all') === '1',
    ];
}

/**
 * Everyone expected on $filters['date'] (active students whose duty day is that weekday) plus anyone with a record that day,
 * each with their flags and one of: absent | late | open | present | none.
 *
 * @return array{rows: array<int, array>, stats: array<string,int>}
 */
function qr_monitor(array $filters): array
{
    $date     = $filters['date'];
    $weekday  = date('l', strtotime($date));
    $settings = qr_settings();
    $params   = [$date];
    $sql = 'SELECT s.id AS sid, s.student_number, s.first_name, s.middle_name, s.last_name, s.course, s.year_level, s.position, s.status AS student_status,
                   a.id AS attendance_id, a.morning_time_in, a.morning_time_out, a.afternoon_time_in, a.afternoon_time_out, a.remarks
            FROM students s LEFT JOIN attendance a ON a.student_id = s.id AND a.attendance_date = ?
            WHERE (a.id IS NOT NULL OR s.status = ?';
    $params[] = 'Active';
    if (!$filters['all']) {
        $sql .= ' AND s.year_level = ?';
        $params[] = $weekday;
    }
    $sql .= ')';
    if ($filters['q'] !== '') {
        $sql .= ' AND (' . student_search_clause('s') . ')';
        $params = array_merge($params, student_search_params($filters['q']));
    }
    if ($filters['course'] !== '') {
        $sql .= ' AND s.course = ?';
        $params[] = $filters['course'];
    }
    if ($filters['year'] !== '') {
        $sql .= ' AND s.year_level = ?';
        $params[] = $filters['year'];
    }
    $sql .= ' ORDER BY s.last_name, s.first_name, s.id';

    $stats = ['expected' => 0, 'present' => 0, 'late' => 0, 'open' => 0, 'early' => 0, 'absent' => 0];
    $rows  = [];
    foreach (db_all($sql, $params) as $r) {
        $hasRow   = $r['attendance_id'] !== null;
        $expected = $r['student_status'] === 'Active' && ($filters['all'] || $r['year_level'] === $weekday);
        $flags    = qr_row_flags($hasRow ? $r : null, $settings);
        $state    = !$hasRow ? ($expected ? 'absent' : 'none') : ($flags['late'] ? 'late' : ($flags['open'] ? 'open' : 'present'));
        $r['flags'] = $flags;
        $r['state'] = $state;
        $r['minutes'] = $hasRow ? attendance_minutes($r)['total'] : 0;

        $stats['expected'] += $expected ? 1 : 0;
        $stats['present']  += $hasRow ? 1 : 0;
        $stats['late']     += $flags['late'] ? 1 : 0;
        $stats['open']     += $flags['open'] ? 1 : 0;
        $stats['early']    += $flags['early'] ? 1 : 0;
        $stats['absent']   += $state === 'absent' ? 1 : 0;

        $keep = match ($filters['status']) {
            'present'  => $hasRow,
            'late'     => $flags['late'],
            'early'    => $flags['early'],
            'open'     => $flags['open'],
            'complete' => $hasRow && $flags['has_times'] && !$flags['open'],
            'absent'   => $state === 'absent',
            default    => true,
        };
        if ($keep) {
            $rows[] = $r;
        }
    }
    return ['rows' => $rows, 'stats' => $stats];
}

/** Recent scans (newest first) for the live feed, including refused ones. */
function qr_recent_scans(string $date, int $limit = 15): array
{
    $limit = max(1, min(100, $limit));
    return db_all(
        'SELECT q.id, q.scanned_time, q.slot, q.result, q.status, q.method, q.message, s.student_number, s.first_name, s.last_name
         FROM qr_scans q LEFT JOIN students s ON s.id = q.student_id
         WHERE q.attendance_date = ? ORDER BY q.id DESC LIMIT ' . $limit,
        [$date]
    );
}

/** Label + badge variant of a monitor row's state. */
function qr_state_badge(array $row): string
{
    [$label, $variant] = match ($row['state']) {
        'absent' => ['Absent', 'danger'],
        'late'   => ['Late', 'warning'],
        'open'   => ['Timed in', 'info'],
        'present' => ['Present', 'success'],
        default  => ['No record', 'neutral'],
    };
    $html = '<span class="badge ' . $variant . '">' . e($label) . '</span>';
    if ($row['state'] === 'late') {
        $html .= ' <small class="text-muted">' . e(format_duration($row['flags']['late_minutes'])) . '</small>';
        if ($row['flags']['open']) {
            $html .= ' <span class="badge info">Timed in</span>';
        }
    }
    if ($row['flags']['early']) {
        $html .= ' <span class="badge neutral">Early out ' . e(format_duration($row['flags']['early_minutes'])) . '</span>';
    }
    return $html;
}

/** Rows of the monitor as a CSV table: [header[], rows[][]]. */
function qr_monitor_csv(array $monitor, string $date): array
{
    $header = ['Date', 'Student No.', 'Name', 'Course', 'Duty Day', 'Morning In', 'Morning Out', 'Afternoon In', 'Afternoon Out', 'Hours', 'Status', 'Late (min)', 'Early out (min)', 'Remarks'];
    $rows = [];
    foreach ($monitor['rows'] as $r) {
        $t = static fn(?string $v): string => $v !== null && $v !== '' ? substr($v, 0, 8) : '';
        $rows[] = [
            $date, $r['student_number'], $r['last_name'] . ', ' . $r['first_name'], $r['course'], $r['year_level'],
            $t($r['morning_time_in']), $t($r['morning_time_out']), $t($r['afternoon_time_in']), $t($r['afternoon_time_out']),
            number_format($r['minutes'] / 60, 2, '.', ''),
            match ($r['state']) { 'absent' => 'Absent', 'late' => 'Late', 'open' => 'Timed in', 'present' => 'Present', default => 'No record' },
            $r['flags']['late'] ? $r['flags']['late_minutes'] : '', $r['flags']['early'] ? $r['flags']['early_minutes'] : '',
            (string) ($r['remarks'] ?? ''),
        ];
    }
    return [$header, $rows];
}

/** True when the request arrived over HTTPS (also behind the proxies some hosts put in front of PHP). */
function request_is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
        || str_contains((string) ($_SERVER['HTTP_CF_VISITOR'] ?? ''), '"scheme":"https"');
}

/* ---- Schema ---------------------------------------------------------------------------------------------------- */

/** Create the QR tables when missing (idempotent, never deletes). One cheap query confirms they exist. */
function qr_ensure_tables(PDO $pdo): void
{
    $names = sql_placeholders(count(QR_TABLES_SQL));
    $stmt  = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$names})");
    $stmt->execute(array_keys(QR_TABLES_SQL));
    if ((int) $stmt->fetchColumn() === count(QR_TABLES_SQL)) {
        return;
    }
    foreach (QR_TABLES_SQL as $sql) {
        $pdo->exec($sql);
    }
}

/**
 * Call at the top of every QR page. Sessions that were already signed in when this feature was installed skip the
 * once-per-session upgrade in ensure_schema(), so the QR pages make sure the tables exist themselves.
 */
function qr_ensure_ready(): void
{
    if (!empty($_SESSION['qr_schema_ready'])) {
        return;
    }
    qr_ensure_tables(db());
    $_SESSION['qr_schema_ready'] = true;
}
