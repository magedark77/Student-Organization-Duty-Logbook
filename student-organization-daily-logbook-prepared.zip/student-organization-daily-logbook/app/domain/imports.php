<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * Bulk student import from CSV, in two steps: upload -> preview (nothing is saved) -> confirm.
 * Passwords are never read from the file. Optionally a login is created for each student with an
 * unusable random password plus a one-time password-reset link, so no password is ever shared in plain text.
 */

const IMPORT_MAX_ROWS  = 500;
const IMPORT_MAX_BYTES = 1048576;
const IMPORT_REQUIRED  = ['student_number', 'first_name', 'last_name', 'course', 'duty_day'];
const IMPORT_OPTIONAL  = ['middle_name', 'position', 'status'];
const IMPORT_LINK_TTL_MINUTES = 7 * 24 * 60;

/** Example file offered for download. */
function student_import_template(): string
{
    $lines = [
        ['student_number', 'first_name', 'middle_name', 'last_name', 'course', 'duty_day', 'position', 'status'],
        ['2026-0001', 'Juan', 'Santos', 'Dela Cruz', 'BSCS', 'Monday', 'Secretary', 'Active'],
        ['2026-0002', 'Maria', '', 'Reyes', 'BSIT', 'Tuesday', 'Members', 'Active'],
    ];
    $out = fopen('php://temp', 'w+');
    foreach ($lines as $line) {
        fputcsv($out, $line);
    }
    rewind($out);
    return "\xEF\xBB\xBF" . stream_get_contents($out);
}

/** "Student Number " -> "student_number"; a few friendly aliases are accepted. */
function import_header_key(string $header): string
{
    $key = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', trim($header)) ?? '', '_'));
    return ['year_level' => 'duty_day', 'day' => 'duty_day', 'student_no' => 'student_number', 'student_id' => 'student_number', 'firstname' => 'first_name', 'lastname' => 'last_name', 'middlename' => 'middle_name'][$key] ?? $key;
}

/**
 * Read an uploaded CSV into its column keys and non-blank records. Handles a BOM, Excel's Windows-1252 files and
 * semicolon-separated files; nothing is validated here except that the file is usable as a whole.
 *
 * @return array{columns: string[], records: array<int, array{line: int, cells: array}>}
 * @throws ValidationException when the file as a whole cannot be used
 */
function import_read_csv(string $path): array
{
    if (!is_file($path) || filesize($path) === 0) {
        throw new ValidationException('The file is empty. Download the template to see the expected columns.', 'csv');
    }
    if (filesize($path) > IMPORT_MAX_BYTES) {
        throw new ValidationException('The file is larger than ' . (IMPORT_MAX_BYTES / 1048576) . ' MB. Split it into smaller files.', 'csv');
    }
    $raw = (string) file_get_contents($path);
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
    if (!mb_check_encoding($raw, 'UTF-8')) {
        $raw = (string) mb_convert_encoding($raw, 'UTF-8', 'Windows-1252'); // Excel "CSV" files are often not UTF-8
    }
    $firstLine = strtok($raw, "\n") ?: '';
    $delimiter = substr_count($firstLine, ';') > substr_count($firstLine, ',') ? ';' : ',';

    $handle = fopen('php://temp', 'w+');
    fwrite($handle, $raw);
    rewind($handle);
    $header = fgetcsv($handle, 0, $delimiter, '"', '');
    if (!$header || count($header) < 2) {
        throw new ValidationException('The first row must contain the column names. Download the template to see them.', 'csv');
    }
    $columns = array_map('import_header_key', $header);
    $missing = array_diff(IMPORT_REQUIRED, $columns);
    if ($missing) {
        throw new ValidationException('Missing required column(s): ' . implode(', ', $missing) . '.', 'csv');
    }

    $records = [];
    $line    = 1;
    while (($cells = fgetcsv($handle, 0, $delimiter, '"', '')) !== false) {
        $line++;
        if ($cells === [null] || implode('', array_map('trim', array_map('strval', $cells))) === '') {
            continue; // blank line
        }
        if (count($records) >= IMPORT_MAX_ROWS) {
            throw new ValidationException('The file has more than ' . IMPORT_MAX_ROWS . ' students. Split it into smaller files.', 'csv');
        }
        $records[] = ['line' => $line, 'cells' => $cells];
    }
    fclose($handle);
    if (!$records) {
        throw new ValidationException('The file has a header but no students.', 'csv');
    }
    return ['columns' => $columns, 'records' => $records];
}

/**
 * Turn one CSV record into a preview row, validating it with the same rules as the student form.
 *
 * @param string[] $columns column keys from import_read_csv()
 * @return array{line: int, data: array, status: string, message: string} status is "ok" or "error"
 */
function import_validate_row(array $columns, array $cells, int $line): array
{
    $known = [...IMPORT_REQUIRED, ...IMPORT_OPTIONAL];
    $data  = [];
    foreach ($columns as $i => $key) {
        if (in_array($key, $known, true)) {
            $data[$key] = trim((string) ($cells[$i] ?? ''));
        }
    }
    $data += array_fill_keys($known, '');
    if ($data['status'] === '') {
        $data['status'] = STUDENT_STATUSES[0];
    }
    $data['status']   = ucfirst(strtolower($data['status']));
    $data['duty_day'] = ucfirst(strtolower($data['duty_day']));

    try {
        $clean = student_validate(['year_level' => $data['duty_day']] + $data, null);
    } catch (ValidationException $e) {
        return ['line' => $line, 'data' => $data, 'status' => 'error', 'message' => $e->getMessage()];
    }
    $data = [
        'student_number' => $clean['student_number'], 'first_name' => $clean['first_name'], 'middle_name' => (string) $clean['middle_name'],
        'last_name' => $clean['last_name'], 'course' => $clean['course'], 'duty_day' => $clean['year_level'],
        'position' => (string) $clean['position'], 'status' => $clean['status'],
    ];
    return ['line' => $line, 'data' => $data, 'status' => 'ok', 'message' => ''];
}

/** Mark valid rows that repeat a student number already seen earlier in the same file. */
function import_flag_file_duplicates(array $rows): array
{
    $seen = [];
    foreach ($rows as &$row) {
        if ($row['status'] !== 'ok') {
            continue;
        }
        $key = strtolower($row['data']['student_number']);
        if (isset($seen[$key])) {
            $row['status']  = 'duplicate';
            $row['message'] = 'Same student number as line ' . $seen[$key] . ' of this file.';
        } else {
            $seen[$key] = $row['line'];
        }
    }
    return $rows;
}

/** Mark valid rows whose student number already belongs to a saved student. */
function import_flag_existing_duplicates(array $rows): array
{
    $numbers = [];
    foreach ($rows as $row) {
        if ($row['status'] === 'ok') {
            $numbers[] = $row['data']['student_number'];
        }
    }
    $existing = [];
    foreach (array_chunk($numbers, 200) as $chunk) {
        foreach (db_all('SELECT student_number FROM students WHERE student_number IN (' . sql_placeholders(count($chunk)) . ')', $chunk) as $found) {
            $existing[strtolower((string) $found['student_number'])] = true;
        }
    }
    foreach ($rows as &$row) {
        if ($row['status'] === 'ok' && isset($existing[strtolower($row['data']['student_number'])])) {
            $row['status']  = 'duplicate';
            $row['message'] = 'A student with this number already exists.';
        }
    }
    return $rows;
}

/**
 * Read and validate an uploaded CSV without saving anything.
 *
 * @return array{rows: array<int, array{line: int, data: array, status: string, message: string}>, ok: int, errors: int, duplicates: int}
 * @throws ValidationException when the file as a whole cannot be used
 */
function student_import_parse(string $path): array
{
    $csv  = import_read_csv($path);
    $rows = array_map(static fn(array $r): array => import_validate_row($csv['columns'], $r['cells'], $r['line']), $csv['records']);
    $rows = import_flag_existing_duplicates(import_flag_file_duplicates($rows));

    $count = static fn(string $status): int => count(array_filter($rows, static fn(array $r): bool => $r['status'] === $status));
    return ['rows' => $rows, 'ok' => $count('ok'), 'errors' => $count('error'), 'duplicates' => $count('duplicate')];
}

/**
 * Save the valid rows of a previewed import. Duplicates are re-checked inside the transaction, so a student
 * added since the preview is skipped rather than overwritten. Everything is saved or nothing is.
 *
 * @param array $rows rows from student_import_parse()
 * @return array{created: int, skipped: int, logins: int, links: array<int, array{student_number: string, name: string, username: string, url: string}>}
 */
function student_import_commit(array $rows, bool $createLogins): array
{
    $result = ['created' => 0, 'skipped' => 0, 'logins' => 0, 'links' => []];
    db_transaction(static function (PDO $pdo) use ($rows, $createLogins, &$result): void {
        // Prepared once and reused for every row (the statements do not change between rows).
        $insertStudent = $pdo->prepare(
            'INSERT INTO students (student_number, first_name, middle_name, last_name, course, year_level, position, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insertUser  = $pdo->prepare("INSERT INTO users (username, password, role, student_id) VALUES (?, ?, 'student', ?)");
        $insertReset = $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at, created_by) VALUES (?, ?, ?, ?)');
        $createdBy   = user()['id'] ?? null;

        foreach ($rows as $row) {
            if ($row['status'] !== 'ok') {
                $result['skipped']++;
                continue;
            }
            $d = $row['data'];
            if (db_value('SELECT COUNT(*) FROM students WHERE student_number = ?', [$d['student_number']]) > 0) {
                $result['skipped']++;
                continue;
            }
            $insertStudent->execute([$d['student_number'], $d['first_name'], $d['middle_name'] ?: null, $d['last_name'], $d['course'], $d['duty_day'], $d['position'] ?: null, $d['status']]);
            $studentId = (int) $pdo->lastInsertId();
            audit('CREATE', 'students', $studentId, 'Imported student from CSV (line ' . $row['line'] . ')', null, $d);
            $result['created']++;

            if ($createLogins) {
                $username = $d['student_number'];
                if (db_value('SELECT COUNT(*) FROM users WHERE username = ?', [$username]) > 0) {
                    continue; // username taken: the student is kept, an administrator can create a login later
                }
                $insertUser->execute([$username, password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT), $studentId]); // unusable until the link is used
                $userId = (int) $pdo->lastInsertId();
                $token  = bin2hex(random_bytes(32));
                $insertReset->execute([$userId, hash('sha256', $token), date('Y-m-d H:i:s', time() + IMPORT_LINK_TTL_MINUTES * 60), $createdBy]);
                $result['logins']++;
                $result['links'][] = [
                    'student_number' => $d['student_number'],
                    'name'           => $d['last_name'] . ', ' . $d['first_name'],
                    'username'       => $username,
                    'url'            => absolute_url('reset-password.php?token=' . $token),
                ];
            }
        }
        audit('CREATE', 'students', null, 'Student CSV import: ' . plural($result['created'], 'student') . ' created, ' . plural($result['skipped'], 'row') . ' skipped, ' . plural($result['logins'], 'login') . ' created');
    });
    return $result;
}
