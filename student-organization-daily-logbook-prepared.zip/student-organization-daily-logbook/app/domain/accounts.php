<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Account lifecycle shared by students and officers: deactivation and password-reset links. */

const PASSWORD_RESET_TTL_MINUTES = 60;

/** "Active" / "Deactivated" badge (text as well as colour). */
function account_status_badge(?array $account): string
{
    if ($account === null) {
        return '<span class="badge neutral">No login</span>';
    }
    return (int) ($account['is_active'] ?? 1) === 1
        ? '<span class="badge success">' . icon('check') . 'Active</span>'
        : '<span class="badge danger">' . icon('x') . 'Deactivated</span>';
}

/**
 * Switch a login on or off without touching any record it created. Administrator accounts are never changed here,
 * and nobody can deactivate their own account.
 *
 * @throws ValidationException with a message that is safe to show
 */
function account_set_active(int $userId, bool $active): array
{
    $account = db_one('SELECT id, username, role, student_id, is_active FROM users WHERE id = ?', [$userId]);
    if ($account === null) {
        throw new ValidationException('That account no longer exists.');
    }
    if ($account['role'] === ROLE_ADMIN) {
        throw new ValidationException('Administrator accounts cannot be deactivated here.');
    }
    if ($userId === (int) (user()['id'] ?? 0)) {
        throw new ValidationException('You cannot deactivate your own account.');
    }
    if ((int) $account['is_active'] === (int) $active) {
        throw new ValidationException('That account is already ' . ($active ? 'active' : 'deactivated') . '.');
    }
    db_transaction(static function () use ($userId, $active, $account): void {
        db_run('UPDATE users SET is_active = ? WHERE id = ?', [(int) $active, $userId]);
        if (!$active) {
            db_run('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$userId]); // outstanding links die with the account
        }
        audit('UPDATE', 'users', $userId, ($active ? 'Reactivated' : 'Deactivated') . ' account ' . $account['username'] . ' (' . role_label((string) $account['role']) . ')',
            ['is_active' => (int) $account['is_active']], ['is_active' => (int) $active]);
    });
    return $account;
}

/* ---- Password-reset links ---------------------------------------------------- */

/** Absolute address of a project page, for links that are shared outside the browser (e.g. a reset link). */
function absolute_url(string $path): string
{
    $https  = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $host   = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
    if (!preg_match('/^[A-Za-z0-9.\-]+(:\d{1,5})?$/', $host)) {
        $host = 'localhost';
    }
    $dir    = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    $levels = substr_count(app_root_prefix(), '../');
    for ($i = 0; $i < $levels; $i++) {
        $dir = rtrim(dirname($dir), '/');
    }
    return ($https ? 'https' : 'http') . '://' . $host . ($dir === '.' ? '' : $dir) . '/' . ltrim($path, '/');
}

/**
 * Create a one-time reset link for a student or officer login (never an administrator). Earlier unused links for the
 * same login stop working. Only the SHA-256 hash of the token is stored, so the link can be shown just once.
 *
 * @return array{token: string, url: string, expires_at: string, username: string}
 * @throws ValidationException with a message that is safe to show
 */
function password_reset_create(int $userId, int $ttlMinutes = PASSWORD_RESET_TTL_MINUTES): array
{
    if (!is_admin()) {
        throw new ValidationException('Only administrators can create password-reset links.');
    }
    $account = db_one('SELECT id, username, role, is_active FROM users WHERE id = ?', [$userId]);
    if ($account === null || $account['role'] === ROLE_ADMIN) {
        throw new ValidationException('A reset link can be created for student and officer accounts only.');
    }
    if ((int) $account['is_active'] !== 1) {
        throw new ValidationException('Reactivate the account before creating a reset link.');
    }
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + $ttlMinutes * 60);
    db_transaction(static function () use ($userId, $token, $expires, $account): void {
        db_run('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$userId]);
        db_run('INSERT INTO password_resets (user_id, token_hash, expires_at, created_by) VALUES (?, ?, ?, ?)', [$userId, hash('sha256', $token), $expires, user()['id'] ?? null]);
        audit('CREATE', 'password_resets', $userId, 'Created a password-reset link for ' . $account['username'] . ' (the link itself is never logged)');
    });
    return ['token' => $token, 'url' => absolute_url('reset-password.php?token=' . $token), 'expires_at' => $expires, 'username' => (string) $account['username']];
}

/** The account a valid, unused, unexpired token belongs to, or null. */
function password_reset_lookup(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }
    return db_one(
        'SELECT p.id, p.user_id, u.username FROM password_resets p JOIN users u ON u.id = p.user_id
         WHERE p.token_hash = ? AND p.used_at IS NULL AND p.expires_at > NOW() AND u.is_active = 1',
        [hash('sha256', $token)]
    );
}

/**
 * Set a new password with a reset link. The link is consumed in the same transaction, so it works once.
 *
 * @throws ValidationException with a message that is safe to show
 */
function password_reset_apply(string $token, string $new, string $confirm): string
{
    if (strlen($new) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('The new password must be at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'new_password');
    }
    if ($new !== $confirm) {
        throw new ValidationException('The two passwords do not match.', 'confirm_password');
    }
    $username = db_transaction(static function (PDO $pdo) use ($token, $new): string {
        $stmt = $pdo->prepare(
            'SELECT p.id, p.user_id, u.username FROM password_resets p JOIN users u ON u.id = p.user_id
             WHERE p.token_hash = ? AND p.used_at IS NULL AND p.expires_at > NOW() AND u.is_active = 1 FOR UPDATE'
        );
        $stmt->execute([hash('sha256', $token)]);
        $row = $stmt->fetch();
        if (!$row) {
            throw new ValidationException('This reset link is invalid, expired or has already been used. Ask an administrator for a new one.');
        }
        $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $row['user_id']]);
        $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);
        $pdo->prepare('INSERT INTO audit_logs (user_id, action, table_name, record_id, description) VALUES (?, ?, ?, ?, ?)')
            ->execute([$row['user_id'], 'UPDATE', 'users', $row['user_id'], 'Password set using a reset link by ' . $row['username']]);
        notify_password_changed((int) $row['user_id']);
        return (string) $row['username'];
    });
    return $username;
}
