<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/** 'HH:MM' or 'HH:MM:SS' -> minutes since midnight, or null if empty/invalid. */
function time_to_minutes(?string $time): ?int
{
    if ($time === null || !preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $m)) {
        return null;
    }
    return (int) $m[1] * 60 + (int) $m[2];
}

/** Whole minutes between two clock times (0 when either is missing or out < in). */
function duration_minutes(?string $in, ?string $out): int
{
    $start = time_to_minutes($in);
    $end   = time_to_minutes($out);
    return ($start === null || $end === null) ? 0 : max(0, $end - $start);
}

/** Minutes worked in one attendance row: morning, afternoon and total. */
function attendance_minutes(array $row): array
{
    $morning   = duration_minutes($row['morning_time_in'] ?? null, $row['morning_time_out'] ?? null);
    $afternoon = duration_minutes($row['afternoon_time_in'] ?? null, $row['afternoon_time_out'] ?? null);
    return ['morning' => $morning, 'afternoon' => $afternoon, 'total' => $morning + $afternoon];
}

/** 125 -> "2h 5m". Accepts ints, floats and numeric strings from the database. */
function format_duration(mixed $minutes): string
{
    $m = max(0, (int) round((float) $minutes));
    return intdiv($m, 60) . 'h ' . ($m % 60) . 'm';
}

function required_minutes(): int
{
    return REQUIRED_HOURS * 60;
}

function remaining_minutes(int $completed): int
{
    return max(0, required_minutes() - $completed);
}

function progress_percent(int $completed): float
{
    return min(100.0, $completed / required_minutes() * 100);
}

/** '13:05:00' -> '1:05 PM'. */
function format_clock(?string $time): string
{
    $minutes = time_to_minutes($time);
    if ($minutes === null) {
        return '';
    }
    $hour = intdiv($minutes, 60);
    return sprintf('%d:%02d %s', $hour % 12 === 0 ? 12 : $hour % 12, $minutes % 60, $hour >= 12 ? 'PM' : 'AM');
}

/** '8:00 AM – 12:00 PM', or an em dash when nothing was recorded. */
function format_time_range(?string $in, ?string $out): string
{
    if (time_to_minutes($in) === null && time_to_minutes($out) === null) {
        return '—';
    }
    return (format_clock($in) ?: '…') . ' – ' . (format_clock($out) ?: '…');
}

/** '2026-10-05' -> 'Mon, Oct 5, 2026'. */
function format_date(string $date): string
{
    $timestamp = strtotime($date);
    return $timestamp === false ? $date : date('D, M j, Y', $timestamp);
}

/** '2026-10-05 14:30:00' -> 'Oct 5, 2026, 2:30 PM'. */
function format_datetime(string $datetime): string
{
    $timestamp = strtotime($datetime);
    return $timestamp === false ? $datetime : date('M j, Y, g:i A', $timestamp);
}

function is_valid_date(string $date): bool
{
    $parsed = DateTime::createFromFormat('Y-m-d', $date);
    return $parsed !== false && $parsed->format('Y-m-d') === $date;
}
