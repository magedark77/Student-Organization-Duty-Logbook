<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * Announcements. Each announcement is one row in `announcements`; every recipient gets one row in
 * `announcement_recipients` (the read receipt) plus an ordinary notification that points to it.
 * A notification's own is_read flag is NOT a read receipt: receipts live only in announcement_recipients.read_at.
 */

const ANNOUNCEMENT_TITLE_MAX   = 150;
const ANNOUNCEMENT_MESSAGE_MAX = 2000;
const ANNOUNCEMENT_PAGE_SIZE   = 20;
/** key => [label, badge tone] */
const ANNOUNCEMENT_PRIORITIES  = ['normal' => ['Normal', 'neutral'], 'important' => ['Important', 'warning'], 'urgent' => ['Urgent', 'danger']];
const ANNOUNCEMENT_SORTS       = ['date' => 'Published', 'priority' => 'Priority', 'title' => 'Title', 'reads' => 'Read count', 'expires' => 'Expires'];
const ANNOUNCEMENT_STATUSES    = ['active' => 'Active', 'expired' => 'Expired', 'cancelled' => 'Cancelled'];

/** audience key => label. Keys: students, officers, everyone, day:<duty day>. */
function announcement_audiences(): array
{
    $audiences = [
        'everyone' => 'Everyone (active students and officers)',
        'students' => 'All active students',
        'officers' => 'All officers',
    ];
    foreach (DUTY_DAYS as $day) {
        $audiences['day:' . $day] = 'Active students on ' . $day . ' duty';
    }
    return $audiences;
}

/** Groups an announcement can be sent to now. Older announcements keep their original audience (see announcement_audiences()). */
function announcement_send_audiences(): array
{
    return ['students' => announcement_audiences()['students']];
}

function announcement_audience_label(string $audience): string
{
    return announcement_audiences()[$audience] ?? $audience;
}

/** [FROM … WHERE … clause selecting u.id for the audience, bound parameters]. */
function announcement_recipient_query(string $audience): array
{
    $staff  = sql_placeholders(count(STAFF_ROLES));
    $active = "u.role = 'student' AND s.status = 'Active'";
    $params = [];
    if ($audience === 'officers') {
        $from   = "FROM users u WHERE u.is_active = 1 AND u.role IN ({$staff})";
        $params = STAFF_ROLES;
    } elseif ($audience === 'everyone') {
        $from   = "FROM users u LEFT JOIN students s ON s.id = u.student_id WHERE u.is_active = 1 AND (u.role IN ({$staff}) OR ({$active}))";
        $params = STAFF_ROLES;
    } else {
        $from = "FROM users u JOIN students s ON s.id = u.student_id WHERE u.is_active = 1 AND {$active}";
        if (str_starts_with($audience, 'day:')) {
            $from    .= ' AND s.year_level = ?';
            $params[] = substr($audience, 4);
        }
    }
    return [$from, $params];
}

/** How many people each audience reaches right now, all in one query: [audience key => count]. */
function announcement_audience_sizes(): array
{
    $staff    = sql_placeholders(count(STAFF_ROLES));
    $isActive = "u.role = 'student' AND s.status = 'Active'";
    $perDay   = implode(', ', array_map(static fn(int $i): string => "COALESCE(SUM({$isActive} AND s.year_level = ?), 0) AS day_{$i}", array_keys(DUTY_DAYS)));
    $row = db_one(
        "SELECT COALESCE(SUM(u.role IN ({$staff})), 0) AS officers, COALESCE(SUM({$isActive}), 0) AS students, {$perDay}
         FROM users u LEFT JOIN students s ON s.id = u.student_id WHERE u.is_active = 1",
        [...STAFF_ROLES, ...DUTY_DAYS]
    );
    $sizes = ['officers' => (int) $row['officers'], 'students' => (int) $row['students'], 'everyone' => (int) $row['officers'] + (int) $row['students']];
    foreach (DUTY_DAYS as $i => $day) {
        $sizes['day:' . $day] = (int) $row['day_' . $i];
    }
    return $sizes;
}

/** Validate shared fields of a new or edited announcement. Returns [title, message, priority, expiresAt|null]. */
function announcement_validate(string $title, string $message, string $priority, string $expiresOn, ?string $unchangedDate = null): array
{
    $title   = trim($title);
    $message = trim($message);
    if ($title === '' || mb_strlen($title) > ANNOUNCEMENT_TITLE_MAX) {
        throw new ValidationException('Enter a title of up to ' . ANNOUNCEMENT_TITLE_MAX . ' characters.', 'title');
    }
    if ($message === '' || mb_strlen($message) > ANNOUNCEMENT_MESSAGE_MAX) {
        throw new ValidationException('Enter a message of up to ' . number_format(ANNOUNCEMENT_MESSAGE_MAX) . ' characters.', 'message');
    }
    if (!isset(ANNOUNCEMENT_PRIORITIES[$priority])) {
        throw new ValidationException('Choose a priority: Normal, Important or Urgent.', 'priority');
    }
    $expiresAt = null;
    if ($expiresOn !== '') {
        if (!is_valid_date($expiresOn)) {
            throw new ValidationException('Enter a valid expiration date.', 'expires_on');
        }
        if ($expiresOn < date('Y-m-d') && $expiresOn !== $unchangedDate) {
            throw new ValidationException('The expiration date cannot be in the past.', 'expires_on');
        }
        $expiresAt = $expiresOn . ' 23:59:59'; // the announcement stays visible through its last day
    }
    return [$title, $message, $priority, $expiresAt];
}

/**
 * Publish an announcement to a group.
 *
 * @param array $options priority (normal|important|urgent), expires_on (YYYY-MM-DD or ''), pinned (bool, administrators only),
 *                       confirm_urgent (bool, required for urgent announcements)
 * @return array{id: int, recipients: int}
 * @throws ValidationException with a message that is safe to show
 */
function announcement_send(string $audience, string $title, string $message, array $options = []): array
{
    $audiences = announcement_audiences(); // full label list, used for the audit entry
    if (!isset(announcement_send_audiences()[$audience])) {
        throw new ValidationException('Choose who should receive the announcement.', 'audience');
    }
    [$title, $message, $priority, $expiresAt] = announcement_validate($title, $message, (string) ($options['priority'] ?? 'normal'), (string) ($options['expires_on'] ?? ''));
    if ($priority === 'urgent' && empty($options['confirm_urgent'])) {
        throw new ValidationException('Tick the box to confirm that this urgent announcement should be sent now.', 'confirm_urgent');
    }
    $pinned = !empty($options['pinned']) && is_admin() ? 1 : 0;
    $author = user()['id'] ?? null;

    [$from, $params] = announcement_recipient_query($audience);
    $notifTitle = ($priority === 'urgent' ? '[Urgent] ' : ($priority === 'important' ? '[Important] ' : '')) . $title;
    $preview    = mb_strlen($message) > 300 ? mb_substr($message, 0, 297) . '…' : $message;

    return db_transaction(static function (PDO $pdo) use ($from, $params, $audience, $audiences, $title, $message, $priority, $expiresAt, $pinned, $author, $notifTitle, $preview): array {
        $pdo->prepare(
            'INSERT INTO announcements (title, message, audience, priority, is_pinned, expires_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)'
        )->execute([$title, $message, $audience, $priority, $pinned, $expiresAt, $author]);
        $id = (int) $pdo->lastInsertId();

        $stmt = $pdo->prepare("INSERT INTO announcement_recipients (announcement_id, user_id) SELECT {$id}, u.id {$from}");
        $stmt->execute($params);
        $count = $stmt->rowCount();
        if ($count === 0) {
            throw new ValidationException('Nobody is in that group yet, so no one was notified.', 'audience');
        }

        $pdo->prepare(
            "INSERT INTO notifications (user_id, type, title, message, link, ref)
             SELECT r.user_id, 'announcement', ?, ?, ?, ? FROM announcement_recipients r WHERE r.announcement_id = ?"
        )->execute([mb_substr($notifTitle, 0, 150), $preview, 'my-announcements.php?id=' . $id, 'announcement:' . $id, $id]);

        audit('CREATE', 'announcements', $id, 'Published ' . $priority . ' announcement to ' . $audiences[$audience] . ' (' . plural($count, 'recipient') . '): ' . $title);
        return ['id' => $id, 'recipients' => $count];
    });
}

/* ---- Looking announcements up ---------------------------------------------- */

/** Status shown to people: cancelled, expired or active. */
function announcement_status(array $row, ?int $now = null): string
{
    if (($row['status'] ?? 'active') === 'cancelled') {
        return 'cancelled';
    }
    $expires = $row['expires_at'] ?? null;
    return ($expires !== null && strtotime((string) $expires) < ($now ?? time())) ? 'expired' : 'active';
}

function announcement_status_badge(array $row): string
{
    $status = announcement_status($row);
    $tone   = ['active' => 'success', 'expired' => 'neutral', 'cancelled' => 'danger'][$status];
    return '<span class="badge ' . $tone . '">' . e(ANNOUNCEMENT_STATUSES[$status]) . '</span>';
}

function announcement_priority_badge(string $priority): string
{
    [$label, $tone] = ANNOUNCEMENT_PRIORITIES[$priority] ?? ANNOUNCEMENT_PRIORITIES['normal'];
    return '<span class="badge ' . $tone . '">' . ($priority === 'urgent' ? icon('alert') : '') . e($label) . '</span>';
}

function announcement_find(int $id): ?array
{
    return db_one(
        "SELECT a.*, u.username AS author,
                (SELECT COUNT(*) FROM announcement_recipients r WHERE r.announcement_id = a.id) AS recipient_count,
                (SELECT COUNT(*) FROM announcement_recipients r WHERE r.announcement_id = a.id AND r.read_at IS NOT NULL) AS read_count
         FROM announcements a LEFT JOIN users u ON u.id = a.created_by WHERE a.id = ?",
        [$id]
    );
}

/** Administrators manage every announcement; the Director and Assistant Director manage only their own. */
function announcement_can_manage(array $row): bool
{
    if (is_admin()) {
        return true;
    }
    return can_announce() && $row['created_by'] !== null && (int) $row['created_by'] === (int) (user()['id'] ?? 0);
}

function announcement_filters_from_request(): array
{
    return [
        'q'        => get_str('q'),
        'status'   => get_choice('status', array_keys(ANNOUNCEMENT_STATUSES)),
        'priority' => get_choice('priority', array_keys(ANNOUNCEMENT_PRIORITIES)),
        'audience' => get_choice('audience', array_keys(announcement_audiences())),
    ];
}

/**
 * One page of the announcement history. Administrators see everything; announcers only their own.
 *
 * @return array{rows: array, total: int, page: int, pages: int}
 */
function announcements_search(array $filters, array $sort, int $page): array
{
    $where  = [];
    $params = [];
    if (!is_admin()) {
        $where[]  = 'a.created_by = ?';
        $params[] = (int) (user()['id'] ?? 0);
    }
    if ($filters['q'] !== '') {
        $where[]  = '(a.title LIKE ? OR a.message LIKE ?)';
        $like     = '%' . addcslashes($filters['q'], '%_\\') . '%';
        array_push($params, $like, $like);
    }
    if ($filters['priority'] !== '') {
        $where[]  = 'a.priority = ?';
        $params[] = $filters['priority'];
    }
    if ($filters['audience'] !== '') {
        $where[]  = 'a.audience = ?';
        $params[] = $filters['audience'];
    }
    $where[] = match ($filters['status']) {
        'active'    => "a.status = 'active' AND (a.expires_at IS NULL OR a.expires_at > NOW())",
        'expired'   => "a.status = 'active' AND a.expires_at IS NOT NULL AND a.expires_at <= NOW()",
        'cancelled' => "a.status = 'cancelled'",
        default     => '1 = 1',
    };
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $total = (int) db_value("SELECT COUNT(*) FROM announcements a {$whereSql}", $params);
    $pager = paginate($total, ANNOUNCEMENT_PAGE_SIZE, $page);
    $dir   = $sort[1] === 'asc' ? 'ASC' : 'DESC';
    $order = match ($sort[0]) {
        'priority' => "FIELD(a.priority, 'urgent', 'important', 'normal') " . ($dir === 'ASC' ? 'DESC' : 'ASC') . ', a.published_at DESC',
        'title'    => "a.title {$dir}",
        'reads'    => "read_count {$dir}, a.published_at DESC",
        'expires'  => "a.expires_at IS NULL, a.expires_at {$dir}",
        default    => "a.published_at {$dir}, a.id {$dir}",
    };
    $rows = db_all(
        "SELECT a.*, u.username AS author,
                (SELECT COUNT(*) FROM announcement_recipients r WHERE r.announcement_id = a.id) AS recipient_count,
                (SELECT COUNT(*) FROM announcement_recipients r WHERE r.announcement_id = a.id AND r.read_at IS NOT NULL) AS read_count
         FROM announcements a LEFT JOIN users u ON u.id = a.created_by {$whereSql}
         ORDER BY {$order} LIMIT " . ANNOUNCEMENT_PAGE_SIZE . ' OFFSET ' . $pager['offset'],
        $params
    );
    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/**
 * The newest announcements that are still active (not cancelled or expired), for dashboard panels.
 * One small query: no paging, no totals, no read counts.
 */
function announcements_latest_active(int $limit = 3): array
{
    return db_all(
        "SELECT id, title, message, priority, published_at FROM announcements
         WHERE status = 'active' AND (expires_at IS NULL OR expires_at > NOW())
         ORDER BY published_at DESC, id DESC LIMIT " . max(1, $limit)
    );
}

/** Who received an announcement and who has read it. */
function announcement_receipts(int $id): array
{
    return db_all(
        "SELECT r.user_id, r.read_at, u.username, u.role, s.first_name, s.last_name, s.student_number
         FROM announcement_recipients r
         JOIN users u ON u.id = r.user_id
         LEFT JOIN students s ON s.id = u.student_id
         WHERE r.announcement_id = ?
         ORDER BY r.read_at IS NOT NULL, u.username",
        [$id]
    );
}

/* ---- Changing announcements --------------------------------------------------- */

/** Edit wording, priority and expiry (the audience cannot change after publishing). Administrators may also pin. */
function announcement_update(int $id, string $title, string $message, string $priority, string $expiresOn, bool $pinned): void
{
    $old = announcement_find($id);
    if ($old === null) {
        throw new ValidationException('That announcement no longer exists.');
    }
    if (!announcement_can_manage($old)) {
        throw new ValidationException('You do not have permission to edit this announcement.');
    }
    if ($old['status'] === 'cancelled') {
        throw new ValidationException('A cancelled announcement cannot be edited.');
    }
    [$title, $message, $priority, $expiresAt] = announcement_validate($title, $message, $priority, $expiresOn, $old['expires_at'] !== null ? substr((string) $old['expires_at'], 0, 10) : null);
    // An unchanged expiry date may already be in the past (editing an expired notice): it is kept as is.
    $pin = is_admin() ? (int) $pinned : (int) $old['is_pinned'];

    db_transaction(static function (PDO $pdo) use ($id, $old, $title, $message, $priority, $expiresAt, $pin): void {
        $pdo->prepare('UPDATE announcements SET title = ?, message = ?, priority = ?, expires_at = ?, is_pinned = ?, edited_at = NOW(), edited_by = ? WHERE id = ?')
            ->execute([$title, $message, $priority, $expiresAt, $pin, user()['id'] ?? null, $id]);
        $prefix = $priority === 'urgent' ? '[Urgent] ' : ($priority === 'important' ? '[Important] ' : '');
        $pdo->prepare("UPDATE notifications SET title = ?, message = ? WHERE ref = ? AND type = 'announcement'")
            ->execute([mb_substr($prefix . $title, 0, 150), mb_strlen($message) > 300 ? mb_substr($message, 0, 297) . '…' : $message, 'announcement:' . $id]);
        audit('UPDATE', 'announcements', $id, 'Edited announcement: ' . $title,
            ['title' => $old['title'], 'message' => $old['message'], 'priority' => $old['priority'], 'expires_at' => $old['expires_at'], 'is_pinned' => (int) $old['is_pinned']],
            ['title' => $title, 'message' => $message, 'priority' => $priority, 'expires_at' => $expiresAt, 'is_pinned' => $pin]);
    });
}

/** Withdraw an announcement: recipients no longer see it, and its notifications are removed. History and receipts are kept. */
function announcement_cancel(int $id): void
{
    $row = announcement_find($id);
    if ($row === null) {
        throw new ValidationException('That announcement no longer exists.');
    }
    if (!announcement_can_manage($row)) {
        throw new ValidationException('You do not have permission to cancel this announcement.');
    }
    if ($row['status'] === 'cancelled') {
        throw new ValidationException('That announcement is already cancelled.');
    }
    db_transaction(static function (PDO $pdo) use ($id, $row): void {
        $pdo->prepare("UPDATE announcements SET status = 'cancelled', is_pinned = 0, cancelled_at = NOW(), cancelled_by = ? WHERE id = ?")
            ->execute([user()['id'] ?? null, $id]);
        $pdo->prepare("DELETE FROM notifications WHERE ref = ? AND type = 'announcement'")->execute(['announcement:' . $id]);
        audit('UPDATE', 'announcements', $id, 'Cancelled announcement: ' . $row['title']);
    });
}

/** Pin or unpin (administrators only). */
function announcement_set_pinned(int $id, bool $pinned): void
{
    if (!is_admin()) {
        throw new ValidationException('Only administrators can pin announcements.');
    }
    $row = announcement_find($id);
    if ($row === null || $row['status'] === 'cancelled') {
        throw new ValidationException('That announcement is not available.');
    }
    db_run('UPDATE announcements SET is_pinned = ? WHERE id = ?', [(int) $pinned, $id]);
    audit('UPDATE', 'announcements', $id, ($pinned ? 'Pinned' : 'Unpinned') . ' announcement: ' . $row['title']);
}

/* ---- The recipient's side ------------------------------------------------------ */

/** Condition for announcements a recipient may still see: not cancelled and not expired. */
const ANNOUNCEMENT_CURRENT_SQL = "a.status = 'active' AND (a.expires_at IS NULL OR a.expires_at > NOW())";

/**
 * A page of announcements addressed to $userId. $tab: 'current' (default) or 'archive' (expired).
 * Pinned first, then urgent, then newest.
 */
function announcements_for_user(int $userId, string $tab, string $term, int $page): array
{
    $cond   = $tab === 'archive' ? "a.status = 'active' AND a.expires_at IS NOT NULL AND a.expires_at <= NOW()" : ANNOUNCEMENT_CURRENT_SQL;
    $params = [$userId];
    $extra  = '';
    if ($term !== '') {
        $extra   = ' AND (a.title LIKE ? OR a.message LIKE ?)';
        $like    = '%' . addcslashes($term, '%_\\') . '%';
        $params[] = $like;
        $params[] = $like;
    }
    $from  = "FROM announcement_recipients r JOIN announcements a ON a.id = r.announcement_id WHERE r.user_id = ? AND {$cond}{$extra}";
    $total = (int) db_value('SELECT COUNT(*) ' . $from, $params);
    $pager = paginate($total, ANNOUNCEMENT_PAGE_SIZE, $page);
    $rows  = db_all(
        "SELECT a.id, a.title, a.message, a.priority, a.is_pinned, a.published_at, a.expires_at, a.status, r.read_at {$from}
         ORDER BY a.is_pinned DESC, FIELD(a.priority, 'urgent', 'important', 'normal'), a.published_at DESC, a.id DESC
         LIMIT " . ANNOUNCEMENT_PAGE_SIZE . ' OFFSET ' . $pager['offset'],
        $params
    );
    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/** One announcement, only if $userId is one of its recipients (never for someone else's). Cancelled ones are hidden. */
function announcement_find_for_user(int $id, int $userId): ?array
{
    return db_one(
        "SELECT a.id, a.title, a.message, a.priority, a.is_pinned, a.published_at, a.expires_at, a.status, r.read_at, u.username AS author
         FROM announcement_recipients r
         JOIN announcements a ON a.id = r.announcement_id
         LEFT JOIN users u ON u.id = a.created_by
         WHERE a.id = ? AND r.user_id = ? AND a.status = 'active'",
        [$id, $userId]
    );
}

/**
 * Record that $userId has read an announcement (first read only). The user id always comes from the session,
 * and the update only touches that user's own receipt, so nobody can mark another person's announcement as read.
 * The matching notification is marked read too, so the bell count stays in step.
 */
function announcement_mark_read(int $id, int $userId): void
{
    db_run('UPDATE announcement_recipients SET read_at = NOW() WHERE announcement_id = ? AND user_id = ? AND read_at IS NULL', [$id, $userId]);
    db_run("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND ref = ? AND type = 'announcement'", [$userId, 'announcement:' . $id]);
}

/** Unread, current announcements for a user (and how many are urgent). */
function announcements_unread_summary(int $userId): array
{
    try {
        $row = db_one(
            "SELECT COUNT(*) AS unread, COALESCE(SUM(a.priority = 'urgent'), 0) AS urgent
             FROM announcement_recipients r JOIN announcements a ON a.id = r.announcement_id
             WHERE r.user_id = ? AND r.read_at IS NULL AND " . ANNOUNCEMENT_CURRENT_SQL,
            [$userId]
        );
        return ['unread' => (int) $row['unread'], 'urgent' => (int) $row['urgent']];
    } catch (Throwable $e) {
        error_log('[studentbody] announcement summary failed: ' . $e->getMessage());
        return ['unread' => 0, 'urgent' => 0];
    }
}

/** The history page's data for the current request. */
function announcement_search_page(array $filters, array $sort): array
{
    return announcements_search($filters, $sort, (int) get_str('page'));
}
