<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/** Officer roles an administrator can create accounts for: role => label, in display order. */
function officer_role_options(): array
{
    return array_intersect_key(ROLE_LABELS, array_flip(STAFF_ROLES));
}

/**
 * Every officer login, ordered by role (President, Internal VP, External VP, Secretary; old roles last), then by username.
 * Accounts saved with a blank role (created while the database could not store the officer role) are listed too,
 * so they can be edited and given the right role instead of being invisible.
 */
function officer_accounts(): array
{
    $all          = [...STAFF_ROLES, ...LEGACY_ROLES];
    $placeholders = sql_placeholders(count($all));
    return db_all(
        "SELECT id, username, role, created_at, is_active FROM users
         WHERE role IN ({$placeholders}) OR role = '' ORDER BY FIELD(role, {$placeholders}), username",
        [...$all, ...$all]
    );
}

/** Shared username and role checks for creating and editing an officer. */
function officer_validate(string $username, string $role): void
{
    if (!preg_match('/^[A-Za-z0-9_.-]{3,100}$/', $username)) {
        throw new ValidationException('Username must be 3–100 characters and use only letters, numbers, dots, underscores, or hyphens.', 'username');
    }
    if (!in_array($role, STAFF_ROLES, true)) {
        throw new ValidationException('Choose a valid officer role.', 'role');
    }
}

/** One officer login by id. Administrators and students are never returned, so they can never be edited or deleted here. */
function officer_find(int $id): ?array
{
    $all          = [...STAFF_ROLES, ...LEGACY_ROLES];
    $placeholders = sql_placeholders(count($all));
    return db_one("SELECT id, username, role, created_at, is_active FROM users WHERE id = ? AND (role IN ({$placeholders}) OR role = '')", [$id, ...$all]);
}

/**
 * Create an officer login.
 *
 * @return int The new user id.
 * @throws ValidationException with a message that is safe to show
 */
function officer_create(string $username, string $password, string $role): int
{
    officer_validate($username, $role);
    if (strlen($password) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('Password must be at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'password');
    }

    try {
        return (int) db_transaction(static function (PDO $pdo) use ($username, $password, $role): int {
            db_run(
                'INSERT INTO users (username, password, role, student_id) VALUES (?, ?, ?, NULL)',
                [$username, password_hash($password, PASSWORD_DEFAULT), $role]
            );
            $id = (int) $pdo->lastInsertId();
            audit('CREATE', 'users', $id, 'Created officer account (' . role_label($role) . '): ' . $username);
            return $id;
        });
    } catch (PDOException $e) {
        throw db_is_duplicate_key($e) ? new ValidationException('That username is already in use. Choose another username.', 'username') : $e;
    }
}

/**
 * Change an officer's username and role, and optionally set a new password.
 *
 * @param string $password New password, or '' to keep the current one.
 * @throws ValidationException with a message that is safe to show
 */
function officer_update(int $id, string $username, string $role, string $password): void
{
    $officer = officer_find($id);
    if ($officer === null) {
        throw new ValidationException('That officer account no longer exists.');
    }
    officer_validate($username, $role);
    if ($password !== '' && strlen($password) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('Password must be at least ' . MIN_PASSWORD_LENGTH . ' characters, or leave it blank to keep the current one.', 'password');
    }

    try {
        db_transaction(static function () use ($id, $officer, $username, $role, $password): void {
            if ($password !== '') {
                db_run('UPDATE users SET username = ?, role = ?, password = ? WHERE id = ?', [$username, $role, password_hash($password, PASSWORD_DEFAULT), $id]);
            } else {
                db_run('UPDATE users SET username = ?, role = ? WHERE id = ?', [$username, $role, $id]);
            }

            $changes = [];
            if ($username !== $officer['username']) {
                $changes[] = 'username ' . $officer['username'] . ' → ' . $username;
            }
            if ($role !== $officer['role']) {
                $changes[] = 'role ' . role_label($officer['role']) . ' → ' . role_label($role);
            }
            if ($password !== '') {
                $changes[] = 'password reset'; // the password itself is never logged
            }
            audit(
                'UPDATE', 'users', $id,
                'Updated officer account ' . $officer['username'] . ($changes ? ': ' . implode(', ', $changes) : ' (no changes)'),
                ['username' => $officer['username'], 'role' => $officer['role']],
                ['username' => $username, 'role' => $role]
            );
        });
    } catch (PDOException $e) {
        throw db_is_duplicate_key($e) ? new ValidationException('That username is already in use. Choose another username.', 'username') : $e;
    }

    if ($password !== '') {
        notify_safely(static function () use ($id): void {
            notify_user($id, 'security', 'Password reset by administrator', 'An administrator set a new password for your account. If you did not expect this, contact the administrator.');
        });
    }
}

/**
 * Delete an officer login. Attendance they recorded is kept (it just no longer names who recorded it),
 * and their notifications are removed with the account.
 *
 * @throws ValidationException when the account does not exist
 */
function officer_delete(int $id): void
{
    db_transaction(static function () use ($id): void {
        $officer = officer_find($id);
        if ($officer === null) {
            throw new ValidationException('That officer account no longer exists.');
        }
        db_run('DELETE FROM users WHERE id = ?', [$id]);
        audit('DELETE', 'users', $id, 'Deleted officer account (' . role_label($officer['role']) . '): ' . $officer['username'], $officer);
    });
}
