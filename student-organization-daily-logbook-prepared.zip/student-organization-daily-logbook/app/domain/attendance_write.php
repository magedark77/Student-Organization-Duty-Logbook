<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Validation and writes for attendance: save, delete, and the who/when/why change history. */

/** Raised when a record already exists for that student and date and the caller may not (or did not agree to) replace it. */
class DuplicateAttendanceException extends ValidationException
{
    public function __construct(string $message, public readonly array $existing)
    {
        parent::__construct($message, 'student_id');
    }
}

/** Earliest date accepted for attendance (guards against typos such as year 0026). */
const ATTENDANCE_EARLIEST_DATE = '2000-01-01';

/** Attendance may be recorded for today or earlier, never for a future day. */
function attendance_validate_date(string $date): void
{
    if (!is_valid_date($date) || $date < ATTENDANCE_EARLIEST_DATE) {
        throw new ValidationException('Please enter a valid attendance date.', 'attendance_date');
    }
    if ($date > date('Y-m-d')) {
        throw new ValidationException('Attendance cannot be recorded for a future date.', 'attendance_date');
    }
}

/**
 * Check the four times of a day. Existing rules are kept (in/out come in pairs, out is after in); a new rule stops the
 * afternoon session from starting before the morning one ended, which would count the same minutes twice.
 *
 * @return array{morning_in: ?string, morning_out: ?string, afternoon_in: ?string, afternoon_out: ?string}
 */
function attendance_validate_times(array $input): array
{
    $times = [];
    foreach (['morning_in', 'morning_out', 'afternoon_in', 'afternoon_out'] as $field) {
        $value = trim((string) ($input[$field] ?? ''));
        if ($value !== '' && time_to_minutes($value) === null) {
            throw new ValidationException('Please enter valid times.', $field);
        }
        $times[$field] = $value !== '' ? $value : null;
    }
    foreach ([['morning_in', 'morning_out', 'Morning'], ['afternoon_in', 'afternoon_out', 'Afternoon']] as [$in, $out, $label]) {
        if (($times[$in] === null) !== ($times[$out] === null)) {
            throw new ValidationException($label . ': Time In and Time Out must be paired.', $times[$in] === null ? $in : $out);
        }
        if ($times[$in] !== null && duration_minutes($times[$in], $times[$out]) <= 0) {
            throw new ValidationException($label . ': Time Out must be later than Time In.', $out);
        }
    }
    if ($times['morning_out'] !== null && $times['afternoon_in'] !== null
        && time_to_minutes($times['afternoon_in']) < time_to_minutes($times['morning_out'])) {
        throw new ValidationException('Afternoon Time In cannot be earlier than the morning Time Out.', 'afternoon_in');
    }
    return $times;
}

/** Why a change was made: required for edits and corrections. */
function attendance_validate_reason(string $reason, bool $required): string
{
    $reason = trim($reason);
    if ($required && mb_strlen($reason) < 3) {
        throw new ValidationException('Please enter the reason for this change (at least 3 characters).', 'reason');
    }
    if (mb_strlen($reason) > 500) {
        throw new ValidationException('The reason must be 500 characters or fewer.', 'reason');
    }
    return $reason;
}

/** Add a row to the attendance change history (who, when, why, old and new values). */
function attendance_log_change(?int $attendanceId, ?int $studentId, string $date, string $type, string $reason, ?array $old, ?array $new): void
{
    db_run(
        'INSERT INTO attendance_changes (attendance_id, student_id, attendance_date, change_type, reason, old_values, new_values, changed_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $attendanceId, $studentId, $date, $type, $reason !== '' ? $reason : null,
            $old !== null ? json_encode($old) : null, $new !== null ? json_encode($new) : null, user()['id'] ?? null,
        ]
    );
}

/** The times (and remarks) of a stored row, for the change history. */
function attendance_snapshot(?array $row): ?array
{
    if ($row === null) {
        return null;
    }
    $out = [];
    foreach (['morning_time_in', 'morning_time_out', 'afternoon_time_in', 'afternoon_time_out', 'remarks'] as $column) {
        $out[$column] = $row[$column] ?? null;
    }
    return $out;
}

/** Change history of one student's attendance on one date (or of a record id), newest first. */
function attendance_changes_for(int $studentId, string $date): array
{
    return db_all(
        'SELECT c.*, u.username FROM attendance_changes c LEFT JOIN users u ON u.id = c.changed_by
         WHERE c.student_id = ? AND c.attendance_date = ? ORDER BY c.changed_at DESC, c.id DESC',
        [$studentId, $date]
    );
}

/**
 * Create or update the record for (student, date).
 *
 * @param array  $input       student_id, attendance_date, morning_in, morning_out, afternoon_in, afternoon_out, remarks
 * @param string $reason      why the record is being changed (required when an existing record is replaced)
 * @param bool   $allowUpdate false for roles that may only create (officers): an existing record is refused
 * @param string $changeType  'update' normally, 'correction' when approving a correction request
 * @return bool true when a new record was created, false when updated.
 * @throws DuplicateAttendanceException when a record already exists and $allowUpdate is false
 */
function attendance_save(array $input, string $reason = '', bool $allowUpdate = true, string $changeType = 'update'): bool
{
    [$studentId, $date, $values] = attendance_validated_input($input);

    $student = student_find($studentId);
    if ($student === null) {
        throw new ValidationException('The selected student could not be found. Please refresh the page and try again.', 'student_id');
    }
    $existing = attendance_find_for($studentId, $date);
    if ($existing === null && $student['status'] !== 'Active') {
        throw new ValidationException('Attendance can only be recorded for Active students.', 'student_id');
    }
    if ($existing !== null && !$allowUpdate) {
        throw new DuplicateAttendanceException(
            'A record for ' . student_display_name($student) . ' on ' . format_date($date) . ' already exists. '
            . 'Only an administrator can change it.',
            $existing
        );
    }
    $reason = attendance_validate_reason($reason, $existing !== null);

    attendance_persist($existing, $studentId, $date, $values, $reason, $changeType);
    notify_attendance_saved($student, $date, $existing === null);

    return $existing === null;
}

/**
 * Validate the fields of an attendance form (student, date, the four times, remarks) without touching the database.
 *
 * @return array{0: int, 1: string, 2: array} student id, date, and the column values to store
 * @throws ValidationException
 */
function attendance_validated_input(array $input): array
{
    $studentId = (int) ($input['student_id'] ?? 0);
    $date      = (string) ($input['attendance_date'] ?? '');
    if ($studentId <= 0) {
        throw new ValidationException('Please select a student and a valid attendance date.', 'student_id');
    }
    attendance_validate_date($date);
    $times = attendance_validate_times($input);

    $remarks = trim((string) ($input['remarks'] ?? ''));
    if (mb_strlen($remarks) > 255) {
        throw new ValidationException('Remarks must be 255 characters or fewer.', 'remarks');
    }

    return [$studentId, $date, [
        'morning_time_in'    => $times['morning_in'],
        'morning_time_out'   => $times['morning_out'],
        'afternoon_time_in'  => $times['afternoon_in'],
        'afternoon_time_out' => $times['afternoon_out'],
        'remarks'            => $remarks !== '' ? $remarks : null,
    ]];
}

/**
 * Insert or update the attendance row, with its audit entry and change-history row, in one transaction.
 * $existing is the stored row for this student and date, or null to insert.
 *
 * @throws DuplicateAttendanceException when someone else inserted the same student and date a moment ago
 */
function attendance_persist(?array $existing, int $studentId, string $date, array $values, string $reason, string $changeType): void
{
    $recordedBy = user()['id'] ?? null;
    try {
        db_transaction(static function (PDO $pdo) use ($existing, $studentId, $date, $values, $recordedBy, $reason, $changeType): void {
            if ($existing !== null) {
                $pdo->prepare(
                    'UPDATE attendance SET morning_time_in = ?, morning_time_out = ?, afternoon_time_in = ?,
                     afternoon_time_out = ?, remarks = ?, recorded_by = ? WHERE id = ?'
                )->execute([...array_values($values), $recordedBy, $existing['id']]);
                audit('UPDATE', 'attendance', (int) $existing['id'], 'Updated attendance' . ($reason !== '' ? ' (' . $reason . ')' : ''), $existing, $values);
                attendance_log_change((int) $existing['id'], $studentId, $date, $changeType, $reason, attendance_snapshot($existing), $values);
                return;
            }

            $pdo->prepare(
                'INSERT INTO attendance (student_id, attendance_date, morning_time_in, morning_time_out,
                 afternoon_time_in, afternoon_time_out, remarks, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            )->execute([$studentId, $date, ...array_values($values), $recordedBy]);
            $newId = (int) $pdo->lastInsertId();
            audit('CREATE', 'attendance', $newId, 'Created attendance', null, $values);
            attendance_log_change($newId, $studentId, $date, $changeType === 'correction' ? 'correction' : 'create', $reason, null, $values);
        });
    } catch (PDOException $e) {
        // Someone else recorded the same student and date a moment ago (unique key student + date).
        if (db_is_duplicate_key($e)) {
            throw new DuplicateAttendanceException('A record for that student and date was just created by someone else. Please review it first.', attendance_find_for($studentId, $date) ?? []);
        }
        throw $e;
    }
}

function attendance_delete(int $id, string $reason = ''): void
{
    $reason = attendance_validate_reason($reason, false);
    $old = db_transaction(static function (PDO $pdo) use ($id, $reason): array {
        $old = db_one('SELECT * FROM attendance WHERE id = ?', [$id]);
        if ($old === null) {
            throw new ValidationException('That attendance record no longer exists.');
        }
        $pdo->prepare('DELETE FROM attendance WHERE id = ?')->execute([$id]);
        audit('DELETE', 'attendance', $id, 'Deleted attendance', $old);
        attendance_log_change($id, (int) $old['student_id'], (string) $old['attendance_date'], 'delete', $reason !== '' ? $reason : 'Deleted by an administrator', attendance_snapshot($old), null);
        return $old;
    });
    notify_attendance_deleted($old);
}
