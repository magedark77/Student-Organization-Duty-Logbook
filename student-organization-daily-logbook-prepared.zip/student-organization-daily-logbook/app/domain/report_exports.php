<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Report output: filter/identification text, CSV and PDF downloads, and the one definition of each export. */

/** Short text of the filters in force, for report headers ("Duty day: Monday; Course: BSCS"). */
function report_filter_summary(array $filters): string
{
    $parts = [];
    if (($filters['year'] ?? '') !== '') {
        $parts[] = 'Duty day: ' . $filters['year'];
    }
    if (($filters['course'] ?? '') !== '') {
        $parts[] = 'Course: ' . $filters['course'];
    }
    if (($filters['status'] ?? '') !== '') {
        $parts[] = 'Status: ' . $filters['status'];
    }
    if (($filters['q'] ?? '') !== '') {
        $parts[] = 'Search: “' . $filters['q'] . '”';
    }
    return $parts ? implode('; ', $parts) : 'No filters (all students)';
}

/** "Generated on Oct 17, 2026, 3:04 PM by admin (Administrator)". */
function report_generated_line(): string
{
    $u = user();
    return 'Generated on ' . format_datetime(date('Y-m-d H:i:s')) . ' by ' . ($u['username'] ?? 'unknown') . ' (' . role_label((string) ($u['role'] ?? '')) . ')';
}

/** Send a CSV download (Excel-friendly, formula-safe). */
function send_csv(string $filename, array $header, array $rows): never
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) . '"');
    header('Cache-Control: no-store');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $header);
    foreach ($rows as $row) {
        fputcsv($out, array_map(static fn($v) => is_string($v) ? csv_safe($v) : $v, $row));
    }
    fclose($out);
    exit;
}

/** Send a PDF built by pdf_table_report(). */
function send_pdf(string $filename, string $title, array $meta, array $columns, array $rows, ?array $totals = null): never
{
    $pdf = pdf_table_report($title, $meta, $columns, $rows, $totals, report_generated_line());
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) . '"');
    header('Content-Length: ' . strlen($pdf));
    header('Cache-Control: no-store');
    echo $pdf;
    exit;
}


/** Report definitions: key => [title, filename stem]. */
const EXPORTABLE_REPORTS = ['monthly' => 'Monthly Duty-Hour Report', 'outstanding' => 'Students Who Have Not Completed Required Hours'];

/**
 * Build the export for a report from the current request: one definition feeds both the CSV and the PDF, and uses the
 * same filter parsing as the on-screen page, so a download always matches what the filtered screen shows.
 *
 * @return array{title: string, file: string, meta: string[], header: string[], rows: array, pdf: array, totals: ?array}
 *         pdf: column definitions for pdf_table_report(); optional pdfRows when the PDF shows fewer columns than the CSV
 */
function report_export_build(string $report): array
{
    $builders = ['monthly' => 'report_export_monthly', 'outstanding' => 'report_export_outstanding'];
    $filters  = student_filters_from_request();
    return $builders[$report]($filters, ['Filters: ' . report_filter_summary($filters)]);
}

/** Export definition of the monthly duty-hour report. @param string[] $meta */
function report_export_monthly(array $filters, array $meta): array
{
    $report = 'monthly';
    $month  = report_month_from_request();
    $data   = monthly_report($month, $filters, sort_from_request(REPORT_SORTS, 'name'));
    $header = ['Student Number', 'Name', 'Course', 'Duty Day', 'Status', 'Days Present', 'Hours This Month', 'Hours Year to Date', 'Remaining Hours (of ' . REQUIRED_HOURS . ' per year)', 'Year Progress'];
    $rows   = [];
    foreach ($data['rows'] as $r) {
        $rows[] = [$r['student_number'], $r['last_name'] . ', ' . $r['first_name'], $r['course'], $r['year_level'], $r['status'], (int) $r['days'],
            format_duration($r['minutes']), format_duration($r['year_minutes']), format_duration($r['remaining']), number_format($r['percent'], 1) . '%'];
    }
    array_unshift($meta, 'Period: ' . format_date($data['start']) . ' to ' . format_date($data['end']) . ' (year-to-date from ' . format_date($data['year_start']) . ')', 'Required: ' . REQUIRED_HOURS . ' hours per year');
    $meta[] = plural(count($rows), 'student') . ' in this report';
    $totals = ['Total', '', '', '', '', (int) $data['totals']['days'], format_duration($data['totals']['minutes']), format_duration($data['totals']['year_minutes']), '', ''];
    $pdf = [['label' => 'Student No.', 'weight' => 10], ['label' => 'Name', 'weight' => 20], ['label' => 'Course', 'weight' => 9], ['label' => 'Duty day', 'weight' => 9],
            ['label' => 'Status', 'weight' => 8], ['label' => 'Days', 'weight' => 5, 'align' => 'r'], ['label' => 'This month', 'weight' => 9, 'align' => 'r'],
            ['label' => 'Year to date', 'weight' => 10, 'align' => 'r'], ['label' => 'Remaining', 'weight' => 10, 'align' => 'r'], ['label' => 'Progress', 'weight' => 8, 'align' => 'r']];
    return ['title' => EXPORTABLE_REPORTS[$report], 'file' => 'logbook-' . $month, 'meta' => $meta, 'header' => $header, 'rows' => $rows, 'pdf' => $pdf, 'totals' => $totals];
}

/** Export definition of the "hours not completed" report. @param string[] $meta */
function report_export_outstanding(array $filters, array $meta): array
{
    $report = 'outstanding';
    $year   = report_year_from_request();
    $sort   = sort_from_request(OUTSTANDING_SORTS, 'remaining', 'desc');
    $list   = students_outstanding($year, $filters, $sort);
    $header = ['Student Number', 'Name', 'Course', 'Duty Day', 'Status', 'Days Present', 'Hours Completed', 'Hours Remaining', 'Progress'];
    $rows   = [];
    foreach ($list as $r) {
        $rows[] = [$r['student_number'], $r['last_name'] . ', ' . $r['first_name'], $r['course'], $r['year_level'], $r['status'], $r['days'],
            format_duration($r['minutes']), format_duration($r['remaining']), number_format($r['percent'], 1) . '%'];
    }
    array_unshift($meta, 'Year: ' . $year . ' (1 January to 31 December)', 'Required: ' . REQUIRED_HOURS . ' hours per year');
    if (($filters['status'] ?? '') === '') {
        $meta[count($meta) - 1] = 'Filters: ' . report_filter_summary($filters + ['status' => STUDENT_STATUSES[0]]) . ' (Active students by default)';
    }
    $meta[] = plural(count($rows), 'student') . ' below the requirement';
    $pdf = [['label' => 'Student No.', 'weight' => 11], ['label' => 'Name', 'weight' => 24], ['label' => 'Course', 'weight' => 10], ['label' => 'Duty day', 'weight' => 10],
            ['label' => 'Days', 'weight' => 6, 'align' => 'r'], ['label' => 'Completed', 'weight' => 11, 'align' => 'r'], ['label' => 'Remaining', 'weight' => 11, 'align' => 'r'], ['label' => 'Progress', 'weight' => 9, 'align' => 'r']];
    $pdfRows = array_map(static fn(array $r): array => [$r[0], $r[1], $r[2], $r[3], $r[5], $r[6], $r[7], $r[8]], $rows);
    return ['title' => EXPORTABLE_REPORTS[$report], 'file' => 'outstanding-hours-' . $year, 'meta' => $meta, 'header' => $header, 'rows' => $rows, 'pdf' => $pdf, 'pdfRows' => $pdfRows, 'totals' => null];
}

/** Stream the export of a report in the requested format and stop. */
function report_export_send(string $report, string $format): never
{
    $x = report_export_build($report);
    audit('EXPORT', 'reports', null, 'Exported ' . $x['title'] . ' as ' . strtoupper($format) . ' (' . count($x['rows']) . ' rows)');
    if ($format === 'pdf') {
        send_pdf($x['file'] . '.pdf', $x['title'], $x['meta'], $x['pdf'], $x['pdfRows'] ?? $x['rows'], $x['totals']);
    }
    send_csv($x['file'] . '.csv', $x['header'], $x['rows']);
}
