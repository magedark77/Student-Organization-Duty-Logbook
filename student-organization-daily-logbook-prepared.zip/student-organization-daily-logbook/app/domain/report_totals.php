<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * Report data: per-student totals, students below the yearly requirement, and chart/summary figures.
 *
 * Every report that needs "hours per student for a period" goes through students_with_totals(), which adds up the
 * attendance rows of the period FIRST (one pass over the date range) and joins the students afterwards. That is
 * markedly faster on large tables than joining first and grouping afterwards, and it keeps one definition of the SQL.
 */

const OUTSTANDING_SORTS = ['name' => 'Name', 'number' => 'Student No.', 'course' => 'Course', 'day' => 'Duty day', 'done' => 'Hours done', 'remaining' => 'Remaining'];

/** SQL condition: the row counts as a day present (a time-in exists in either session). */
const SQL_DAY_PRESENT = '(a.morning_time_in IS NOT NULL OR a.afternoon_time_in IS NOT NULL)';

/**
 * Sort rows by a computed value, ascending or descending (stable, so ties keep their incoming order).
 *
 * @param callable(array): (int|float|string) $value
 */
function sort_rows(array $rows, callable $value, string $dir): array
{
    usort($rows, static function (array $a, array $b) use ($value, $dir): int {
        $c = $value($a) <=> $value($b);
        return $dir === 'desc' ? -$c : $c;
    });
    return $rows;
}

/**
 * Every student matching $filters with the days present and minutes worked between $from and $to (zero when none).
 * With $subRange = [from, to] each row also has sub_days and sub_minutes for that narrower range (e.g. the month
 * inside a year-to-date period), computed in the same pass.
 *
 * @return array<int, array> student columns plus days, minutes (and sub_days, sub_minutes); values are DB strings
 */
function students_with_totals(string $from, string $to, array $filters = [], ?array $subRange = null, string $order = 's.id'): array
{
    $minutes = sql_attendance_minutes('a');
    $inner   = "SUM(CASE WHEN " . SQL_DAY_PRESENT . " THEN 1 ELSE 0 END) AS days, SUM({$minutes}) AS minutes";
    $params  = [];
    $outer   = 'COALESCE(t.days, 0) AS days, COALESCE(t.minutes, 0) AS minutes';
    if ($subRange !== null) {
        $inner  .= ", SUM(CASE WHEN a.attendance_date BETWEEN ? AND ? AND " . SQL_DAY_PRESENT . " THEN 1 ELSE 0 END) AS sub_days"
                 . ", SUM(CASE WHEN a.attendance_date BETWEEN ? AND ? THEN {$minutes} ELSE 0 END) AS sub_minutes";
        $outer  .= ', COALESCE(t.sub_days, 0) AS sub_days, COALESCE(t.sub_minutes, 0) AS sub_minutes';
        array_push($params, $subRange[0], $subRange[1], $subRange[0], $subRange[1]);
    }
    array_push($params, $from, $to);
    $where = student_filter_sql('s', $filters, $params);

    return db_all(
        "SELECT s.id, s.student_number, s.first_name, s.last_name, s.course, s.year_level, s.status, {$outer}
         FROM students s
         LEFT JOIN (SELECT a.student_id, {$inner} FROM attendance a WHERE a.attendance_date BETWEEN ? AND ? GROUP BY a.student_id) t
                ON t.student_id = s.id"
        . ($where !== '' ? " WHERE {$where}" : '') . " ORDER BY {$order}",
        $params
    );
}

/**
 * Students below the yearly requirement for $year (default filter: Active students only).
 *
 * @return array<int, array> rows with minutes (done), remaining, percent, days
 */
function students_outstanding(string $year, array $filters = [], array $sort = ['remaining', 'desc'], ?int $limit = null): array
{
    if (($filters['status'] ?? '') === '') {
        $filters['status'] = STUDENT_STATUSES[0];
    }
    $rows = [];
    foreach (students_with_totals($year . '-01-01', $year . '-12-31', $filters) as $row) {
        if ((int) $row['minutes'] >= required_minutes()) {
            continue;
        }
        $row['minutes']   = (int) $row['minutes'];
        $row['days']      = (int) $row['days'];
        $row['remaining'] = remaining_minutes($row['minutes']);
        $row['percent']   = progress_percent($row['minutes']);
        $rows[] = $row;
    }

    [$key, $dir] = $sort;
    $dayRank = array_flip(DUTY_DAYS);
    $rows = sort_rows($rows, static fn(array $r) => match ($key) {
        'number'    => strtolower($r['student_number']),
        'course'    => strtolower($r['course']),
        'day'       => $dayRank[$r['year_level']] ?? 99,
        'done'      => $r['minutes'],
        'remaining' => $r['remaining'],
        default     => strtolower($r['last_name'] . ' ' . $r['first_name']),
    }, $dir);
    return $limit !== null ? array_slice($rows, 0, $limit) : $rows;
}

/**
 * How many active students are below / at the requirement for a year (for the dashboard).
 * Pass the list from students_outstanding($year) to avoid computing it twice.
 */
function students_requirement_counts(string $year, ?array $outstanding = null): array
{
    $outstanding ??= students_outstanding($year);
    $active = students_count_active();
    return ['active' => $active, 'done' => $active - count($outstanding), 'outstanding' => count($outstanding)];
}

/** "Urgent" in the last 60 days of the year, otherwise "Pending" (used for outstanding-hours indicators). */
function outstanding_urgency(string $year, ?int $today = null): string
{
    $today ??= time();
    $daysLeft = (int) floor((strtotime($year . '-12-31 23:59:59') - $today) / 86400);
    return $daysLeft <= 60 ? 'urgent' : 'pending';
}

/** FROM/WHERE pieces for attendance joined to students only when student filters need it (the join is lossless otherwise). */
function attendance_scope_sql(array $filters, array &$params): array
{
    $where = student_filter_sql('s', $filters, $params);
    return [$where !== '' ? 'attendance a JOIN students s ON s.id = a.student_id' : 'attendance a', $where !== '' ? ' AND ' . $where : ''];
}

/** Minutes logged in each month of $year (index 1–12) for students matching $filters. */
function analytics_monthly_minutes(string $year, array $filters = []): array
{
    $params = [$year . '-01-01', $year . '-12-31'];
    [$from, $extra] = attendance_scope_sql($filters, $params);
    $rows = db_all(
        'SELECT MONTH(a.attendance_date) AS m, SUM(' . sql_attendance_minutes('a') . ') AS minutes
         FROM ' . $from . ' WHERE a.attendance_date BETWEEN ? AND ?' . $extra . ' GROUP BY MONTH(a.attendance_date)',
        $params
    );
    $months = array_fill(1, 12, 0);
    foreach ($rows as $row) {
        $months[(int) $row['m']] = (int) $row['minutes'];
    }
    return $months;
}

/** Minutes logged per calendar year, for the yearly chart. */
function analytics_yearly_minutes(array $filters = []): array
{
    $params = [];
    [$from, $extra] = attendance_scope_sql($filters, $params);
    $rows = db_all(
        'SELECT YEAR(a.attendance_date) AS y, SUM(' . sql_attendance_minutes('a') . ') AS minutes
         FROM ' . $from . ' WHERE 1 = 1' . $extra . ' GROUP BY YEAR(a.attendance_date) ORDER BY y',
        $params
    );
    $out = [];
    foreach ($rows as $row) {
        $out[(string) $row['y']] = (int) $row['minutes'];
    }
    return $out;
}

/**
 * Totals grouped by 'course' or 'year_level' (duty day) for one year: students, attendance days, hours, average per student.
 * Pass $totals (from students_with_totals() for the same year and filters) to group several ways from one query.
 *
 * @return array<int, array{label: string, students: int, days: int, minutes: int, average: float}>
 */
function analytics_group(string $year, string $group, array $filters = [], ?array $totals = null): array
{
    $totals ??= students_with_totals($year . '-01-01', $year . '-12-31', $filters);
    $column = $group === 'course' ? 'course' : 'year_level';

    $groups = [];
    foreach ($totals as $row) {
        $g = &$groups[(string) $row[$column]];
        $g ??= ['label' => (string) $row[$column], 'students' => 0, 'days' => 0, 'minutes' => 0];
        $g['students']++;
        $g['days']    += (int) $row['days'];
        $g['minutes'] += (int) $row['minutes'];
        unset($g);
    }
    uksort($groups, 'strcasecmp'); // same order as the database's case-insensitive GROUP BY, so ties stay stable
    $rows = array_values($groups);
    foreach ($rows as &$row) {
        $row['average'] = $row['students'] > 0 ? (float) ($row['minutes'] / $row['students']) : 0.0;
    }
    unset($row);

    if ($group === 'course') {
        return sort_rows($rows, static fn(array $r): int => $r['minutes'], 'desc');
    }
    $rank = array_flip(DUTY_DAYS);
    return sort_rows($rows, static fn(array $r): int => $rank[$r['label']] ?? 99, 'asc');
}
