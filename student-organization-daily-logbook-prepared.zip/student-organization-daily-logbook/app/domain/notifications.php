<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* ---- Creating notifications ---------------------------------------------- */

/**
 * Notify one user.
 *
 * @param string $link Project-relative page ("student/dashboard.php", "admin/attendance.php?date=2026-01-05") or ''.
 * @param string $ref  Optional de-duplication key: the same user never gets the same $ref twice.
 * @return bool false when skipped (invalid input or $ref already notified)
 */
function notify_user(int $userId, string $type, string $title, string $message = '', string $link = '', string $ref = ''): bool
{
    $title = trim($title);
    if ($userId <= 0 || !isset(NOTIFICATION_TYPES[$type]) || $title === '') {
        return false;
    }
    if ($ref !== '' && (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND ref = ?', [$userId, $ref]) > 0) {
        return false;
    }

    $message = trim($message);
    db_run(
        'INSERT INTO notifications (user_id, type, title, message, link, ref) VALUES (?, ?, ?, ?, ?, ?)',
        [
            $userId,
            $type,
            mb_substr($title, 0, 150),
            $message !== '' ? mb_substr($message, 0, 500) : null,
            $link !== '' ? mb_substr($link, 0, 255) : null,
            $ref !== '' ? mb_substr($ref, 0, 100) : null,
        ]
    );
    return true;
}

/** Notify every administrator, except $exceptUserId (usually the person who caused the event). */
function notify_admins(string $type, string $title, string $message = '', string $link = '', string $ref = '', ?int $exceptUserId = null): int
{
    $sent = 0;
    foreach (db_all('SELECT id FROM users WHERE role = ?', [ROLE_ADMIN]) as $row) {
        if ((int) $row['id'] !== $exceptUserId && notify_user((int) $row['id'], $type, $title, $message, $link, $ref)) {
            $sent++;
        }
    }
    return $sent;
}

/** Notify the login linked to a student record (students without a login are skipped). */
function notify_student_account(int $studentId, string $type, string $title, string $message = '', string $link = '', string $ref = ''): int
{
    $sent = 0;
    foreach (db_all("SELECT id FROM users WHERE student_id = ? AND role = 'student'", [$studentId]) as $row) {
        if (notify_user((int) $row['id'], $type, $title, $message, $link, $ref)) {
            $sent++;
        }
    }
    return $sent;
}

/**
 * Run a notification action so that a failure can never break the action that triggered it
 * (a saved attendance record must stay saved even if the notifications table is unavailable).
 */
function notify_safely(callable $send): void
{
    try {
        $send();
    } catch (Throwable $e) {
        error_log('[studentbody] notification failed: ' . $e->getMessage());
    }
}

/* ---- Events ----------------------------------------------------------------- */

/**
 * An attendance record was created or updated. Call after the change is committed.
 * $notifyAdmins = false is used by the QR scanner, so an officer running the scanner does not flood the administrators.
 */
function notify_attendance_saved(array $student, string $date, bool $created, bool $notifyAdmins = true): void
{
    notify_safely(static function () use ($student, $date, $created, $notifyAdmins): void {
        $studentId = (int) $student['id'];
        $verb      = $created ? 'recorded' : 'updated';
        $name      = student_display_name($student);
        $actor     = user();
        $actorId   = isset($actor['id']) ? (int) $actor['id'] : null;

        $record  = attendance_find_for($studentId, $date);
        $minutes = $record !== null ? attendance_minutes($record)['total'] : 0;
        notify_student_account(
            $studentId,
            'attendance',
            $created ? 'Attendance recorded' : 'Attendance updated',
            'Your attendance for ' . format_date($date) . ' was ' . $verb . ': '
                . ($minutes > 0 ? format_duration($minutes) . ' logged.' : 'no hours logged.'),
            'student/dashboard.php'
        );

        if ($notifyAdmins && is_restricted_staff()) {
            notify_admins(
                'activity',
                'Attendance ' . $verb . ' by ' . role_label((string) $actor['role']),
                $actor['username'] . ' ' . $verb . ' attendance for ' . $name . ' on ' . format_date($date) . '.',
                'admin/attendance.php?date=' . $date,
                '',
                $actorId
            );
        }

        // Yearly requirement reached (once per student per year).
        $year     = substr($date, 0, 4);
        if (attendance_year_minutes($studentId, $year) >= required_minutes()) {
            notify_student_account(
                $studentId,
                'milestone',
                'Required hours completed',
                'You have completed your ' . REQUIRED_HOURS . ' required duty hours for ' . $year . '. Great work!',
                'student/dashboard.php',
                'hours_complete:' . $year
            );
            notify_admins(
                'milestone',
                $name . ' completed the required hours',
                $name . ' has reached ' . REQUIRED_HOURS . ' duty hours for ' . $year . '.',
                'admin/student-view.php?id=' . $studentId,
                'hours_complete:' . $year . ':' . $studentId,
                $actorId
            );
        }
    });
}

/** An attendance record was deleted ($old is the row as it was). */
function notify_attendance_deleted(array $old): void
{
    notify_safely(static function () use ($old): void {
        notify_student_account(
            (int) $old['student_id'],
            'attendance',
            'Attendance removed',
            'Your attendance record for ' . format_date((string) $old['attendance_date'])
                . ' was removed by an administrator. Please ask the administrator if you think this is a mistake.',
            'student/dashboard.php'
        );
    });
}

function notify_password_changed(int $userId): void
{
    notify_safely(static function () use ($userId): void {
        notify_user(
            $userId,
            'security',
            'Password changed',
            'Your password was changed on ' . format_datetime(date('Y-m-d H:i:s')) . '. If this was not you, contact the administrator right away.'
        );
    });
}

/* ---- Reading and managing a user's notifications --------------------------- */

function notifications_unread_count(?int $userId = null): int
{
    static $cache = [];
    $userId ??= (int) (user()['id'] ?? 0);
    if ($userId <= 0) {
        return 0;
    }
    try {
        // Asked for by the page header and again by the page body: one query per request is enough.
        return $cache[$userId] ??= (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$userId]);
    } catch (Throwable $e) {
        error_log('[studentbody] notification count failed: ' . $e->getMessage());
        return 0;
    }
}

/**
 * One page of a user's notifications, newest first.
 *
 * @return array{rows: array<int, array>, total: int, page: int, pages: int}
 */
function notifications_for_user(int $userId, bool $unreadOnly, int $page): array
{
    $where = 'user_id = ?' . ($unreadOnly ? ' AND is_read = 0' : '');
    $total = (int) db_value("SELECT COUNT(*) FROM notifications WHERE {$where}", [$userId]);
    $pager = paginate($total, NOTIFICATION_PAGE_SIZE, $page);

    // LIMIT and OFFSET are integers computed here (they cannot be bound with native prepares).
    $rows = db_all(
        "SELECT id, type, title, message, link, is_read, created_at FROM notifications WHERE {$where}
         ORDER BY created_at DESC, id DESC LIMIT " . NOTIFICATION_PAGE_SIZE . ' OFFSET ' . $pager['offset'],
        [$userId]
    );
    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/** A notification, only if it belongs to $userId. */
function notification_find(int $id, int $userId): ?array
{
    return db_one('SELECT * FROM notifications WHERE id = ? AND user_id = ?', [$id, $userId]);
}

function notification_mark_read(int $id, int $userId): void
{
    db_run('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [$id, $userId]);
}

/** @return int How many were marked. */
function notifications_mark_all_read(int $userId): int
{
    return db_run('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$userId])->rowCount();
}

function notification_delete(int $id, int $userId): void
{
    db_run('DELETE FROM notifications WHERE id = ? AND user_id = ?', [$id, $userId]);
}

/** @return int How many were deleted. */
function notifications_clear_read(int $userId): int
{
    return db_run('DELETE FROM notifications WHERE user_id = ? AND is_read = 1', [$userId])->rowCount();
}

/* ---- Display helpers --------------------------------------------------------- */

/** Page URL for a stored link, or null when it is empty or not a plain project page. */
function notification_href(array $notification): ?string
{
    $link = (string) ($notification['link'] ?? '');
    if ($link === '' || !preg_match('/^[A-Za-z0-9_\-\/]+\.php(\?[A-Za-z0-9_=&%.\-]*)?$/', $link)) {
        return null;
    }
    return url($link);
}

/** "Just now", "5 min ago", "3 h ago", "2 d ago", then a date. $now is for tests. */
function notification_age(string $datetime, ?int $now = null): string
{
    $then = strtotime($datetime);
    if ($then === false) {
        return '';
    }
    $seconds = ($now ?? time()) - $then;
    return match (true) {
        $seconds < 60         => 'Just now',
        $seconds < 3600       => intdiv($seconds, 60) . ' min ago',
        $seconds < 86400      => intdiv($seconds, 3600) . ' h ago',
        $seconds < 7 * 86400  => intdiv($seconds, 86400) . ' d ago',
        default               => format_date(date('Y-m-d', $then)),
    };
}
