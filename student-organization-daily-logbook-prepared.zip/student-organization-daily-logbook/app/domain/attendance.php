<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/**
 * SQL expression for the minutes worked in an attendance row. It mirrors
 * attendance_minutes() (whole minutes, never negative) so database totals
 * and PHP totals always agree.
 */
function sql_attendance_minutes(string $alias = 'a'): string
{
    $p = $alias !== '' ? $alias . '.' : '';
    $span = static fn(string $in, string $out): string =>
        "COALESCE(GREATEST(0, (TIME_TO_SEC({$p}{$out}) DIV 60) - (TIME_TO_SEC({$p}{$in}) DIV 60)), 0)";

    return $span('morning_time_in', 'morning_time_out') . ' + ' . $span('afternoon_time_in', 'afternoon_time_out');
}

const ATTENDANCE_SORTS = ['name' => 'Student', 'morning' => 'Morning', 'afternoon' => 'Afternoon', 'total' => 'Total'];

/** Attendance rows for one day, optionally filtered by a student search term and duty day. */
function attendance_for_date(string $date, string $term = '', string $day = '', array $sort = ['name', 'asc']): array
{
    $sql = 'SELECT a.*, s.student_number, s.first_name, s.last_name
            FROM attendance a JOIN students s ON s.id = a.student_id
            WHERE a.attendance_date = ?';
    $params = [$date];

    if ($term !== '') {
        $sql .= ' AND (' . student_search_clause('s') . ')';
        $params = array_merge($params, student_search_params($term));
    }
    if (in_array($day, DUTY_DAYS, true)) {
        $sql .= ' AND s.year_level = ?';
        $params[] = $day;
    }
    $dir = $sort[1] === 'desc' ? 'DESC' : 'ASC';
    $sql .= match ($sort[0]) {
        'morning'   => " ORDER BY a.morning_time_in IS NULL, a.morning_time_in {$dir}, s.last_name",
        'afternoon' => " ORDER BY a.afternoon_time_in IS NULL, a.afternoon_time_in {$dir}, s.last_name",
        'total'     => ' ORDER BY (' . sql_attendance_minutes('a') . ") {$dir}, s.last_name",
        default     => " ORDER BY s.last_name {$dir}, s.first_name {$dir}",
    };

    return db_all($sql, $params);
}

/** Most recently updated rows for a day (dashboard feed). */
function attendance_recent_for_date(string $date, int $limit = 50): array
{
    $limit = max(1, $limit); // an int, so safe to inline (LIMIT cannot be bound with native prepares)
    return db_all(
        "SELECT a.*, s.student_number, s.first_name, s.last_name
         FROM attendance a JOIN students s ON s.id = a.student_id
         WHERE a.attendance_date = ?
         ORDER BY a.updated_at DESC LIMIT {$limit}",
        [$date]
    );
}

function attendance_for_student(int $studentId): array
{
    return db_all('SELECT * FROM attendance WHERE student_id = ? ORDER BY attendance_date DESC', [$studentId]);
}

/** One record with its student's details (for the edit dialog). */
function attendance_find(int $id): ?array
{
    return db_one(
        'SELECT a.*, s.student_number, s.first_name, s.last_name, s.year_level
         FROM attendance a JOIN students s ON s.id = a.student_id WHERE a.id = ?',
        [$id]
    );
}

function attendance_find_for(int $studentId, string $date): ?array
{
    return db_one('SELECT * FROM attendance WHERE student_id = ? AND attendance_date = ? LIMIT 1', [$studentId, $date]);
}

/** Read the attendance form from $_POST. Officers (restricted staff) cannot add remarks. */
function attendance_input_from_post(): array
{
    return [
        'student_id'      => post_str('student_id'),
        'attendance_date' => post_str('attendance_date'),
        'morning_in'      => post_str('morning_in'),
        'morning_out'     => post_str('morning_out'),
        'afternoon_in'    => post_str('afternoon_in'),
        'afternoon_out'   => post_str('afternoon_out'),
        'remarks'         => is_restricted_staff() ? '' : post_str('remarks'),
    ];
}
