<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Attendance correction requests: a student asks, an administrator approves or rejects. Approval is the only way a student's request changes attendance. */

const CORRECTION_WINDOW_DAYS = 60;
const CORRECTION_PAGE_SIZE   = 20;
const CORRECTION_STATUSES    = ['pending' => ['Pending', 'info'], 'approved' => ['Approved', 'success'], 'rejected' => ['Rejected', 'danger'], 'cancelled' => ['Cancelled', 'neutral']];

function correction_status_badge(string $status): string
{
    [$label, $tone] = CORRECTION_STATUSES[$status] ?? [ucfirst($status), 'neutral'];
    $icon = match ($status) { 'approved' => 'check', 'pending' => 'clock', 'rejected' => 'x', default => '' };
    return '<span class="badge ' . $tone . '">' . ($icon !== '' ? icon($icon) : '') . e($label) . '</span>';
}

function correction_find(int $id): ?array
{
    return db_one(
        'SELECT c.*, s.student_number, s.first_name, s.last_name, s.course, s.year_level, r.username AS reviewer
         FROM attendance_corrections c
         JOIN students s ON s.id = c.student_id
         LEFT JOIN users r ON r.id = c.reviewed_by
         WHERE c.id = ?',
        [$id]
    );
}

/** A student's own requests, newest first. */
function corrections_for_student(int $studentId): array
{
    return db_all('SELECT c.*, r.username AS reviewer FROM attendance_corrections c LEFT JOIN users r ON r.id = c.reviewed_by WHERE c.student_id = ? ORDER BY c.created_at DESC, c.id DESC', [$studentId]);
}

/** Pending correction requests of one student. */
function student_pending_corrections_count(int $studentId): int
{
    return (int) db_value("SELECT COUNT(*) FROM attendance_corrections WHERE student_id = ? AND status = 'pending'", [$studentId]);
}

/** Pending correction requests across all students (admin menu badge). */
function corrections_pending_count(): int
{
    try {
        return (int) db_value("SELECT COUNT(*) FROM attendance_corrections WHERE status = 'pending'");
    } catch (Throwable $e) {
        error_log('[studentbody] correction count failed: ' . $e->getMessage());
        return 0;
    }
}

/** One page of requests for administrators. $status '' = all. */
function corrections_search(string $status, string $term, int $page): array
{
    $where  = [];
    $params = [];
    if (isset(CORRECTION_STATUSES[$status])) {
        $where[]  = 'c.status = ?';
        $params[] = $status;
    }
    if ($term !== '') {
        $where[] = '(' . student_search_clause('s') . ')';
        $params  = array_merge($params, student_search_params($term));
    }
    $from  = 'FROM attendance_corrections c JOIN students s ON s.id = c.student_id';
    $where = $where ? ' WHERE ' . implode(' AND ', $where) : '';
    $total = (int) db_value('SELECT COUNT(*) ' . $from . $where, $params);
    $pager = paginate($total, CORRECTION_PAGE_SIZE, $page);
    $rows  = db_all(
        // The reviewer's name is only needed for the rows on this page, so it is joined here and not in the count.
        'SELECT c.*, s.student_number, s.first_name, s.last_name, r.username AS reviewer ' . $from
        . ' LEFT JOIN users r ON r.id = c.reviewed_by' . $where
        . " ORDER BY c.status = 'pending' DESC, c.created_at DESC, c.id DESC LIMIT " . CORRECTION_PAGE_SIZE . ' OFFSET ' . $pager['offset'],
        $params
    );
    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/**
 * A student asks for a day's attendance to be corrected (or recorded, if it is missing).
 *
 * @throws ValidationException with a message that is safe to show
 */
function correction_create(int $studentId, array $input): int
{
    $student = student_find($studentId);
    if ($student === null || $student['status'] !== 'Active') {
        throw new ValidationException('Only Active students can request corrections.');
    }
    $date = (string) ($input['attendance_date'] ?? '');
    attendance_validate_date($date);
    if ($date < date('Y-m-d', strtotime('-' . CORRECTION_WINDOW_DAYS . ' days'))) {
        throw new ValidationException('Corrections can be requested for the last ' . CORRECTION_WINDOW_DAYS . ' days only. Please contact the administrator.', 'attendance_date');
    }
    $times  = attendance_validate_times($input);
    $reason = trim((string) ($input['reason'] ?? ''));
    if (mb_strlen($reason) < 5 || mb_strlen($reason) > 500) {
        throw new ValidationException('Explain what needs correcting (5 to 500 characters).', 'reason');
    }
    if (db_value("SELECT COUNT(*) FROM attendance_corrections WHERE student_id = ? AND attendance_date = ? AND status = 'pending'", [$studentId, $date]) > 0) {
        throw new ValidationException('You already have a pending request for ' . format_date($date) . '. Wait for the administrator or cancel it first.', 'attendance_date');
    }
    $current = attendance_find_for($studentId, $date);
    if ($current !== null
        && substr((string) ($current['morning_time_in'] ?? ''), 0, 5) === (string) $times['morning_in']
        && substr((string) ($current['morning_time_out'] ?? ''), 0, 5) === (string) $times['morning_out']
        && substr((string) ($current['afternoon_time_in'] ?? ''), 0, 5) === (string) $times['afternoon_in']
        && substr((string) ($current['afternoon_time_out'] ?? ''), 0, 5) === (string) $times['afternoon_out']) {
        throw new ValidationException('The times you entered are the same as the current record. Change at least one time.', 'morning_in');
    }

    $id = (int) db_transaction(static function (PDO $pdo) use ($studentId, $date, $times, $reason): int {
        $pdo->prepare(
            'INSERT INTO attendance_corrections (student_id, attendance_date, morning_time_in, morning_time_out, afternoon_time_in, afternoon_time_out, reason, requested_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$studentId, $date, $times['morning_in'], $times['morning_out'], $times['afternoon_in'], $times['afternoon_out'], $reason, user()['id'] ?? null]);
        $id = (int) $pdo->lastInsertId();
        audit('CREATE', 'attendance_corrections', $id, 'Requested attendance correction for ' . $date . ': ' . $reason);
        return $id;
    });
    notify_safely(static function () use ($student, $date, $id): void {
        notify_admins('activity', 'Attendance correction requested', student_display_name($student) . ' asked for a correction for ' . format_date($date) . '.', 'admin/corrections.php?status=pending', 'correction:' . $id);
    });
    return $id;
}

/** A student withdraws their own pending request. */
function correction_cancel(int $id, int $studentId): void
{
    $row = correction_find($id);
    if ($row === null || (int) $row['student_id'] !== $studentId) {
        throw new ValidationException('That request could not be found.');
    }
    if ($row['status'] !== 'pending') {
        throw new ValidationException('Only pending requests can be cancelled.');
    }
    db_transaction(static function () use ($id, $row): void {
        db_run("UPDATE attendance_corrections SET status = 'cancelled' WHERE id = ? AND status = 'pending'", [$id]);
        audit('UPDATE', 'attendance_corrections', $id, 'Cancelled correction request for ' . $row['attendance_date']);
    });
}

/**
 * An administrator decides on a request. Approving applies the requested times to the attendance record
 * (recorded in the change history with the student's reason) in the same transaction as the decision.
 *
 * @throws ValidationException with a message that is safe to show
 */
function correction_review(int $id, bool $approve, string $note): void
{
    if (!is_admin()) {
        throw new ValidationException('Only administrators can review correction requests.');
    }
    $note = trim($note);
    if (mb_strlen($note) > 500) {
        throw new ValidationException('The note must be 500 characters or fewer.', 'note');
    }
    if (!$approve && mb_strlen($note) < 3) {
        throw new ValidationException('Please tell the student why the request was rejected.', 'note');
    }

    $row = db_transaction(static function (PDO $pdo) use ($id, $approve, $note): array {
        $stmt = $pdo->prepare('SELECT * FROM attendance_corrections WHERE id = ? FOR UPDATE');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) {
            throw new ValidationException('That request no longer exists.');
        }
        if ($row['status'] !== 'pending') {
            throw new ValidationException('That request has already been ' . $row['status'] . '.');
        }
        if ($approve) {
            attendance_save([
                'student_id'      => $row['student_id'],
                'attendance_date' => $row['attendance_date'],
                'morning_in'      => substr((string) $row['morning_time_in'], 0, 5),
                'morning_out'     => substr((string) $row['morning_time_out'], 0, 5),
                'afternoon_in'    => substr((string) $row['afternoon_time_in'], 0, 5),
                'afternoon_out'   => substr((string) $row['afternoon_time_out'], 0, 5),
                'remarks'         => (string) (attendance_find_for((int) $row['student_id'], (string) $row['attendance_date'])['remarks'] ?? ''),
            ], 'Approved correction request #' . $id . ': ' . $row['reason'], true, 'correction');
        }
        $pdo->prepare('UPDATE attendance_corrections SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_note = ? WHERE id = ?')
            ->execute([$approve ? 'approved' : 'rejected', user()['id'] ?? null, $note !== '' ? $note : null, $id]);
        audit('UPDATE', 'attendance_corrections', $id, ($approve ? 'Approved' : 'Rejected') . ' correction request for ' . $row['attendance_date'] . ($note !== '' ? ': ' . $note : ''));
        return $row;
    });

    notify_safely(static function () use ($row, $approve, $note): void {
        notify_student_account(
            (int) $row['student_id'],
            'attendance',
            $approve ? 'Correction approved' : 'Correction rejected',
            'Your correction request for ' . format_date((string) $row['attendance_date']) . ' was ' . ($approve ? 'approved and your attendance was updated.' : 'rejected.') . ($note !== '' ? ' Note: ' . $note : ''),
            'student/corrections.php'
        );
    });
}
