<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * Database backup and recovery.
 *
 * Pure PHP/PDO: no mysqldump, exec(), shell access or extra extensions, so it runs on shared hosting such as InfinityFree.
 *
 * File format ("SOLBACKUP1"): plain SQL, ONE statement per line, so it can also be imported with phpMyAdmin.
 *   -- comment lines start with "--"
 *   SET / DROP TABLE IF EXISTS / CREATE TABLE / INSERT INTO statements only
 *   last line: "-- END OF BACKUP tables=N rows=M"  (a file without it is treated as truncated)
 * The db_backups history table is NOT part of a dump, so history and restore events survive a restore.
 *
 * A restore cannot be wrapped in a transaction (MySQL commits implicitly on DROP/CREATE TABLE). That is why a
 * pre-restore backup is mandatory: if a restore fails half-way, restore the pre-restore file.
 */

const BACKUP_MAGIC        = '-- Format: SOLBACKUP1';
const BACKUP_END_MARKER   = '-- END OF BACKUP';
const BACKUP_EXCLUDED     = ['db_backups'];
const BACKUP_BATCH_ROWS   = 200;
const BACKUP_BATCH_BYTES  = 400000;   // keep each INSERT well below a typical max_allowed_packet
const BACKUP_KINDS        = ['manual' => 'Manual', 'scheduled' => 'Scheduled', 'pre_restore' => 'Before restore', 'restore' => 'Restore'];
const BACKUP_FILE_PATTERN = '/^logbook_[0-9]{8}_[0-9]{6}_[a-f0-9]{8}\.sql$/';

/* ---- Where files live --------------------------------------------------- */

/** Backup folder: config 'backup_dir', else a sibling of the web folder when writable, else storage/backups (protected by .htaccess). */
function backup_dir(): string
{
    $configured = (string) app_config('backup_dir', '');
    if ($configured !== '') {
        return rtrim($configured, '/\\');
    }
    $outside = dirname(APP_ROOT) . '/logbook_backups';
    if (is_dir($outside) ? is_writable($outside) : @is_writable(dirname(APP_ROOT))) {
        return $outside;
    }
    return APP_ROOT . '/storage/backups';
}

/** True when the backup folder can be reached through the web server's document tree. */
function backup_dir_is_public(): bool
{
    $dir  = realpath(backup_dir());
    $root = realpath(APP_ROOT);
    return $dir !== false && $root !== false && str_starts_with($dir . DIRECTORY_SEPARATOR, $root . DIRECTORY_SEPARATOR);
}

/** Create the folder if needed and drop deny-all guards inside it. Throws ValidationException when it is not writable. */
function backup_prepare_dir(): string
{
    $dir = backup_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
        throw new ValidationException('The backup folder could not be created. Set "backup_dir" in config/config.local.php to a writable folder.');
    }
    if (!is_writable($dir)) {
        throw new ValidationException('The backup folder is not writable. Check its permissions or set "backup_dir" in config/config.local.php.');
    }
    $htaccess = $dir . '/.htaccess';
    if (!is_file($htaccess)) {
        @file_put_contents($htaccess, "Require all denied\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
    }
    if (!is_file($dir . '/index.html')) {
        @file_put_contents($dir . '/index.html', '');
    }
    return $dir;
}

function backup_valid_file_name(string $name): bool
{
    return preg_match(BACKUP_FILE_PATTERN, $name) === 1;
}

/** Full path for a stored backup row, or null if the name is not one this module could have created. */
function backup_path(string $fileName): ?string
{
    return backup_valid_file_name($fileName) ? backup_dir() . '/' . $fileName : null;
}

/* ---- Creating a backup -------------------------------------------------- */

function backup_sql_value(PDO $pdo, mixed $value): string
{
    if ($value === null) {
        return 'NULL';
    }
    $value = (string) $value;
    if ($value !== '' && !mb_check_encoding($value, 'UTF-8')) {
        return '0x' . bin2hex($value); // binary data
    }
    // PDO::quote escapes quotes, backslashes, NUL, CR and LF, so one INSERT stays on one line.
    return str_replace(["\r", "\n"], ['\r', '\n'], $pdo->quote($value));
}

/** Names of base tables included in a dump. */
function backup_tables(PDO $pdo): array
{
    $tables = [];
    foreach ($pdo->query('SHOW FULL TABLES WHERE Table_type = \'BASE TABLE\'')->fetchAll(PDO::FETCH_NUM) as $row) {
        if (!in_array($row[0], BACKUP_EXCLUDED, true)) {
            $tables[] = (string) $row[0];
        }
    }
    sort($tables);
    return $tables;
}

/**
 * Write a full dump of $pdo's database to $path.
 *
 * @return array{tables: int, rows: int}
 */
function backup_write_dump(PDO $pdo, string $path, string $databaseLabel): array
{
    $handle = @fopen($path, 'wb');
    if ($handle === false) {
        throw new RuntimeException('Cannot open backup file for writing.');
    }

    $previousMode = (string) $pdo->query('SELECT @@SESSION.sql_mode')->fetchColumn();
    $buffered     = $pdo->getAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY);
    $totalRows    = 0;
    $tables       = backup_tables($pdo);

    try {
        // quote() output must match the mode the restore will run in (see the SET below).
        $pdo->exec("SET SESSION sql_mode = 'NO_AUTO_VALUE_ON_ZERO'");
        $write = static function (string $text) use ($handle): void {
            if (fwrite($handle, $text) === false) {
                throw new RuntimeException('Writing the backup file failed (disk full?).');
            }
        };

        $write("-- Student Office Daily Logbook backup\n" . BACKUP_MAGIC . "\n-- Created: " . date('Y-m-d H:i:s') . "\n-- Database: {$databaseLabel}\n");
        $write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");

        foreach ($tables as $table) {
            $quoted = '`' . str_replace('`', '``', $table) . '`';
            $create = $pdo->query('SHOW CREATE TABLE ' . $quoted)->fetch(PDO::FETCH_NUM);
            $ddl    = preg_replace('/\s*\R\s*/', ' ', (string) ($create[1] ?? ''));
            if ($ddl === '' || $ddl === null) {
                throw new RuntimeException("Could not read the structure of table {$table}.");
            }
            $write("-- TABLE {$quoted}\nDROP TABLE IF EXISTS {$quoted};\n{$ddl};\n");

            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false); // stream rows instead of loading a whole table
            $stmt = $pdo->query('SELECT * FROM ' . $quoted);
            $batch = [];
            $bytes = 0;
            $flush = static function () use (&$batch, &$bytes, $write, $quoted): void {
                if ($batch) {
                    $write('INSERT INTO ' . $quoted . ' VALUES ' . implode(',', $batch) . ";\n");
                    $batch = [];
                    $bytes = 0;
                }
            };
            while (($row = $stmt->fetch(PDO::FETCH_NUM)) !== false) {
                $tuple   = '(' . implode(',', array_map(static fn($v): string => backup_sql_value($pdo, $v), $row)) . ')';
                $batch[] = $tuple;
                $bytes  += strlen($tuple);
                $totalRows++;
                if (count($batch) >= BACKUP_BATCH_ROWS || $bytes >= BACKUP_BATCH_BYTES) {
                    $flush();
                }
            }
            $stmt->closeCursor();
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, $buffered);
            $flush();
        }

        $write("SET FOREIGN_KEY_CHECKS=1;\n" . BACKUP_END_MARKER . ' tables=' . count($tables) . ' rows=' . $totalRows . "\n");
    } finally {
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, $buffered);
        $pdo->exec('SET SESSION sql_mode = ' . $pdo->quote($previousMode));
        fclose($handle);
    }

    return ['tables' => count($tables), 'rows' => $totalRows];
}

function backup_raise_limits(): void
{
    if (function_exists('set_time_limit')) {
        @set_time_limit(300); // shared hosts may ignore this; see docs/BACKUP_RECOVERY.md
    }
    @ini_set('memory_limit', '256M');
}

/**
 * Create a backup file and its history row.
 *
 * @param string $kind one of BACKUP_KINDS ('manual', 'scheduled', 'pre_restore')
 * @return array the db_backups row
 */
function backup_create(string $kind = 'manual', ?int $userId = null): array
{
    backup_raise_limits();
    $dir  = backup_prepare_dir();
    $name = 'logbook_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.sql';
    $path = $dir . '/' . $name;

    try {
        $pdo   = db();
        $stats = backup_write_dump($pdo, $path, db_setting('name'));
        $check = backup_verify_file($path);
        if (!$check['ok']) {
            throw new RuntimeException('Integrity check failed: ' . $check['message']);
        }
        $size = (int) filesize($path);
        $hash = (string) hash_file('sha256', $path);
        db_run(
            'INSERT INTO db_backups (kind, file_name, size_bytes, sha256, table_count, row_count, status, message, created_by)
             VALUES (?, ?, ?, ?, ?, ?, \'ok\', NULL, ?)',
            [$kind, $name, $size, $hash, $stats['tables'], $stats['rows'], $userId]
        );
        $id = (int) db()->lastInsertId();
        if ($kind !== 'pre_restore') {
            backup_prune((int) app_config('backup_keep', 10));
        }
        return db_one('SELECT * FROM db_backups WHERE id = ?', [$id]) ?? [];
    } catch (Throwable $e) {
        if (is_file($path)) {
            @unlink($path); // never keep a half-written backup that could be mistaken for a good one
        }
        error_log('[studentbody] backup failed: ' . $e->getMessage());
        try {
            db_run(
                'INSERT INTO db_backups (kind, file_name, status, message, created_by) VALUES (?, NULL, \'failed\', ?, ?)',
                [$kind, mb_substr($e->getMessage(), 0, 250), $userId]
            );
        } catch (Throwable) {
            // history is best-effort
        }
        throw new ValidationException('The backup could not be created. Details were written to the server error log.');
    }
}

/** Keep the newest $keep manual/scheduled backups; pre-restore safety copies are never pruned automatically. */
function backup_prune(int $keep): void
{
    if ($keep < 1) {
        return;
    }
    $old = db_all(
        "SELECT id, file_name FROM db_backups
         WHERE status = 'ok' AND kind IN ('manual','scheduled') AND file_name IS NOT NULL
         ORDER BY created_at DESC, id DESC LIMIT 1000 OFFSET " . (int) $keep
    );
    foreach ($old as $row) {
        backup_delete((int) $row['id']);
    }
}

/* ---- Verification ------------------------------------------------------- */

/**
 * Check a backup file without touching the database: readable, correct header, complete footer, only allowed statements.
 *
 * @return array{ok: bool, message: string, tables: int, rows: int}
 */
function backup_verify_file(string $path): array
{
    $fail = static fn(string $m): array => ['ok' => false, 'message' => $m, 'tables' => 0, 'rows' => 0];
    if (!is_file($path) || !is_readable($path)) {
        return $fail('The backup file is missing or unreadable.');
    }
    $handle = fopen($path, 'rb');
    if ($handle === false) {
        return $fail('The backup file could not be opened.');
    }
    $magic = false;
    $end   = null;
    $creates = 0;
    $lineNo  = 0;
    while (($line = fgets($handle)) !== false) {
        $lineNo++;
        $line = rtrim($line, "\r\n");
        if ($line === '') {
            continue;
        }
        if (str_starts_with($line, '--')) {
            $magic = $magic || $line === BACKUP_MAGIC;
            if (str_starts_with($line, BACKUP_END_MARKER)) {
                $end = $line;
            }
            continue;
        }
        if ($end !== null) {
            fclose($handle);
            return $fail('Unexpected content after the end marker.');
        }
        if (!backup_statement_allowed($line)) {
            fclose($handle);
            return $fail("Line {$lineNo} contains a statement that a backup file may not contain.");
        }
        if (str_starts_with($line, 'CREATE TABLE ')) {
            $creates++;
        }
    }
    fclose($handle);

    if (!$magic) {
        return $fail('This is not a backup made by this application (header missing).');
    }
    if ($end === null || !preg_match('/tables=(\d+) rows=(\d+)/', $end, $m)) {
        return $fail('The file is incomplete (end marker missing); the backup was probably interrupted.');
    }
    if ((int) $m[1] !== $creates) {
        return $fail("The file declares {$m[1]} tables but contains {$creates}.");
    }
    if ($creates === 0) {
        return $fail('The file contains no tables.');
    }
    return ['ok' => true, 'message' => 'Structure and end marker are valid.', 'tables' => (int) $m[1], 'rows' => (int) $m[2]];
}

/** The only statement types a restore will execute. */
function backup_statement_allowed(string $line): bool
{
    return (bool) preg_match('/^(SET (NAMES|FOREIGN_KEY_CHECKS|SQL_MODE)\b|DROP TABLE IF EXISTS `|CREATE TABLE `|INSERT INTO `)/', $line);
}

/** Verify the file AND its SHA-256 against the value recorded when it was created. */
function backup_verify_record(array $row): array
{
    $path = backup_path((string) ($row['file_name'] ?? ''));
    if ($path === null || !is_file($path)) {
        return ['ok' => false, 'message' => 'The backup file no longer exists on the server.', 'tables' => 0, 'rows' => 0];
    }
    if (!hash_equals((string) $row['sha256'], (string) hash_file('sha256', $path))) {
        return ['ok' => false, 'message' => 'The file has been changed since it was created (checksum mismatch). Do not restore it.', 'tables' => 0, 'rows' => 0];
    }
    return backup_verify_file($path);
}

/* ---- Restoring ---------------------------------------------------------- */

/**
 * Execute a verified backup file against $pdo. DESTRUCTIVE: replaces every table in the file.
 * $pdo may be a test database; callers decide which database that is.
 *
 * @return int number of statements executed
 */
function backup_execute_file(PDO $pdo, string $path): int
{
    $check = backup_verify_file($path);
    if (!$check['ok']) {
        throw new RuntimeException($check['message']);
    }
    backup_raise_limits();
    $handle = fopen($path, 'rb');
    if ($handle === false) {
        throw new RuntimeException('The backup file could not be opened.');
    }
    $count = 0;
    try {
        while (($line = fgets($handle)) !== false) {
            $line = rtrim($line, "\r\n");
            if ($line === '' || str_starts_with($line, '--')) {
                continue;
            }
            $pdo->exec($line);
            $count++;
        }
    } finally {
        fclose($handle);
        try {
            $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        } catch (Throwable) {
        }
    }
    return $count;
}

/**
 * Restore the PRODUCTION database from a recorded backup. Steps: verify (checksum + structure) -> pre-restore backup
 * (abort if it fails) -> execute -> history + audit entry. The caller must already have checked the password and confirmation.
 *
 * @return array{statements: int, safety_backup: array}
 */
function backup_restore_record(int $backupId, ?int $userId): array
{
    $row = db_one("SELECT * FROM db_backups WHERE id = ? AND status = 'ok' AND file_name IS NOT NULL", [$backupId]);
    if (!$row) {
        throw new ValidationException('That backup was not found.');
    }
    $check = backup_verify_record($row);
    if (!$check['ok']) {
        throw new ValidationException('Restore cancelled: ' . $check['message']);
    }

    $safety = backup_create('pre_restore', $userId); // throws (and aborts the restore) if it cannot be made
    $path   = (string) backup_path((string) $row['file_name']);

    try {
        $statements = backup_execute_file(db(), $path);
    } catch (Throwable $e) {
        error_log('[studentbody] restore failed: ' . $e->getMessage());
        db_run(
            "INSERT INTO db_backups (kind, file_name, status, message, created_by) VALUES ('restore', ?, 'failed', ?, ?)",
            [$row['file_name'], mb_substr('Restore failed part-way. Restore the safety backup ' . $safety['file_name'], 0, 250), $userId]
        );
        throw new ValidationException(
            'The restore failed part-way, so the database may be incomplete. Restore the safety backup "' . $safety['file_name']
            . '" (made just before) from this page, or import it with phpMyAdmin.'
        );
    }

    db_run(
        "INSERT INTO db_backups (kind, file_name, status, message, created_by) VALUES ('restore', ?, 'ok', ?, ?)",
        [$row['file_name'], 'Restored ' . $statements . ' statements. Safety backup: ' . $safety['file_name'], $userId]
    );
    try {
        audit('RESTORE', 'db_backups', (int) $row['id'], 'Database restored from backup ' . $row['file_name'] . '; safety backup ' . $safety['file_name']);
    } catch (Throwable) {
        // The restored users table may not contain this administrator; the db_backups history above is the record.
        try {
            db_run("INSERT INTO audit_logs (user_id, action, table_name, record_id, description) VALUES (NULL, 'RESTORE', 'db_backups', ?, ?)",
                [(int) $row['id'], 'Database restored from backup ' . $row['file_name']]);
        } catch (Throwable) {
        }
    }
    return ['statements' => $statements, 'safety_backup' => $safety];
}

/* ---- History, deletion, automation -------------------------------------- */

function backup_history(int $limit = 50): array
{
    return db_all('SELECT b.*, u.username FROM db_backups b LEFT JOIN users u ON u.id = b.created_by ORDER BY b.created_at DESC, b.id DESC LIMIT ' . (int) $limit);
}

function backup_delete(int $id): void
{
    $row = db_one('SELECT * FROM db_backups WHERE id = ?', [$id]);
    if (!$row) {
        throw new ValidationException('That backup was not found.');
    }
    $path = backup_path((string) ($row['file_name'] ?? ''));
    if ($path !== null && is_file($path) && !@unlink($path)) {
        throw new ValidationException('The file could not be deleted from the server.');
    }
    db_run('DELETE FROM db_backups WHERE id = ?', [$id]);
}

function backup_last_ok(): ?array
{
    return db_one("SELECT * FROM db_backups WHERE status = 'ok' AND kind IN ('manual','scheduled') ORDER BY created_at DESC, id DESC LIMIT 1");
}

function backup_format_size(int $bytes): string
{
    return $bytes >= 1048576 ? number_format($bytes / 1048576, 2) . ' MB' : number_format(max(1, (int) ceil($bytes / 1024))) . ' KB';
}

/**
 * Opportunistic schedule for hosts without cron: when an administrator opens the dashboard and the newest backup is older than
 * config 'backup_auto_days' (0 = off), make one. It only runs when someone visits, so it is not a guarantee.
 */
function backup_auto_if_due(?int $userId): void
{
    $days = (int) app_config('backup_auto_days', 0);
    if ($days < 1) {
        return;
    }
    $last = backup_last_ok();
    if ($last && strtotime((string) $last['created_at']) > time() - $days * 86400) {
        return;
    }
    // A failed attempt must not be retried on every page view: back off for an hour after the last failure.
    $failed = db_value("SELECT COUNT(*) FROM db_backups WHERE status = 'failed' AND kind = 'scheduled' AND created_at > NOW() - INTERVAL 1 HOUR");
    if ((int) $failed > 0) {
        return;
    }
    try {
        $row = backup_create('scheduled', $userId);
        audit('BACKUP', 'db_backups', (int) $row['id'], 'Scheduled backup created: ' . $row['file_name']);
    } catch (Throwable $e) {
        error_log('[studentbody] scheduled backup skipped: ' . $e->getMessage());
    }
}
