<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

const STUDENT_FIELD_LIMITS = [
    'student_number' => 50,
    'first_name'     => 100,
    'middle_name'    => 100,
    'last_name'      => 100,
    'course'         => 150,
    'year_level'     => 50,
    'position'       => 50,
];

/** Sort options for the student directory (shared by the page and students_search()). */
const STUDENT_SORTS = ['name' => 'Name', 'number' => 'Student No.', 'course' => 'Course', 'day' => 'Day', 'status' => 'Status'];

function student_find(int $id): ?array
{
    return db_one('SELECT * FROM students WHERE id = ?', [$id]);
}

/** Student plus the username of their login account (if any). */
function student_find_with_username(int $id): ?array
{
    return db_one(
        "SELECT s.*, u.username FROM students s
         LEFT JOIN users u ON u.student_id = s.id AND u.role = 'student'
         WHERE s.id = ? LIMIT 1",
        [$id]
    );
}

function student_account(int $studentId): ?array
{
    return db_one("SELECT id, username FROM users WHERE student_id = ? AND role = 'student' LIMIT 1", [$studentId]);
}

/** ORDER BY expression that sorts duty days Monday to Saturday. The values are constants, not user input. */
function sql_duty_day_order(string $column = 'year_level'): string
{
    return 'FIELD(' . $column . ", '" . implode("', '", DUTY_DAYS) . "')";
}

/** "2024-001 - Cruz, Juan": how a student is named in tables, dropdowns and reports. */
function student_label(array $student): string
{
    return $student['student_number'] . ' - ' . $student['last_name'] . ', ' . $student['first_name'];
}

/** "2024-001 • BSCS • Monday • Director": the line under a student's name. */
function student_subtitle(array $student): string
{
    return implode(' • ', array_filter(
        [$student['student_number'], $student['course'], $student['year_level'] ?? '', $student['position'] ?? ''],
        static fn($v): bool => (string) $v !== ''
    ));
}

/** SQL fragment + parameters for a name / student-number search. */
function student_search_clause(string $alias): string
{
    return "{$alias}.student_number LIKE ? OR {$alias}.first_name LIKE ? OR {$alias}.last_name LIKE ?"
        . " OR CONCAT_WS(' ', {$alias}.first_name, {$alias}.middle_name, {$alias}.last_name) LIKE ?"
        . " OR CONCAT_WS(' ', {$alias}.first_name, {$alias}.last_name) LIKE ?";
}

function student_search_params(string $term): array
{
    return array_fill(0, 5, '%' . addcslashes($term, '%_\\') . '%');
}

/** Filters from the query string: year (duty day), course, status, q (search text). */
function student_filters_from_request(): array
{
    return [
        'year'   => get_choice('year', DUTY_DAYS),
        'course' => get_str('course'),
        'status' => get_choice('status', STUDENT_STATUSES),
        'q'      => get_str('q'),
    ];
}

/** Distinct course names, for filter dropdowns. */
function students_courses(): array
{
    return db_run('SELECT DISTINCT course FROM students WHERE course <> ? ORDER BY course', [''])->fetchAll(PDO::FETCH_COLUMN);
}

/** Shared WHERE builder for student filters: day, term, course, status. */
function student_filter_sql(string $alias, array $f, array &$params): string
{
    $where = [];
    if (in_array($f['year'] ?? '', DUTY_DAYS, true)) {
        $where[] = "{$alias}.year_level = ?";
        $params[] = $f['year'];
    }
    if (($f['course'] ?? '') !== '') {
        $where[] = "{$alias}.course = ?";
        $params[] = $f['course'];
    }
    if (in_array($f['status'] ?? '', STUDENT_STATUSES, true)) {
        $where[] = "{$alias}.status = ?";
        $params[] = $f['status'];
    }
    if (($f['q'] ?? '') !== '') {
        $where[] = '(' . student_search_clause($alias) . ')';
        $params = array_merge($params, student_search_params($f['q']));
    }
    return $where ? implode(' AND ', $where) : '';
}

/** [WHERE clause, ORDER BY clause, params] of the student directory for $filters and $sort. */
function students_query_parts(array $filters, array $sort): array
{
    $params = [];
    $where  = student_filter_sql('students', $filters, $params);
    $cols = [
        'number' => 'student_number', 'name' => 'last_name', 'course' => 'course', 'status' => 'status',
        'day'    => sql_duty_day_order(),
    ];
    $col = $cols[$sort[0]] ?? 'last_name';
    $dir = $sort[1] === 'desc' ? 'DESC' : 'ASC';
    $order = $col . ' ' . $dir . ($sort[0] === 'name' ? ', first_name ' . $dir : ', last_name, first_name');
    return [$where !== '' ? ' WHERE ' . $where : '', $order, $params];
}

/** Students matching $filters (see student_filters_from_request()), ordered by $sort. */
function students_search(array $filters = [], array $sort = ['name', 'asc']): array
{
    [$where, $order, $params] = students_query_parts($filters, $sort);
    return db_all('SELECT * FROM students' . $where . ' ORDER BY ' . $order, $params);
}

/** ['all' => total, 'by_day' => ['Monday' => n, ...]]. Students on a legacy duty day only count toward 'all'. */
function students_duty_day_counts(): array
{
    $byDay = array_fill_keys(DUTY_DAYS, 0);
    $all   = 0;
    foreach (db_all('SELECT year_level, COUNT(*) AS total FROM students GROUP BY year_level') as $row) {
        $all += (int) $row['total'];
        if (isset($byDay[$row['year_level']])) {
            $byDay[$row['year_level']] = (int) $row['total'];
        }
    }
    return ['all' => $all, 'by_day' => $byDay];
}

function students_count_active(): int
{
    return (int) db_value('SELECT COUNT(*) FROM students WHERE status = ?', [STUDENT_STATUSES[0]]);
}

/** Active students, grouped-friendly order, for attendance forms. */
function students_active(): array
{
    return db_run(
        'SELECT id, student_number, first_name, last_name, year_level
         FROM students WHERE status = ? ORDER BY ' . sql_duty_day_order() . ', last_name, first_name',
        [STUDENT_STATUSES[0]]
    )->fetchAll();
}

/** Read the student form from $_POST. Passwords are not trimmed. */
function student_input_from_post(): array
{
    $input = [];
    foreach (['student_number', 'first_name', 'middle_name', 'last_name', 'course', 'position', 'status', 'username'] as $field) {
        $input[$field] = post_str($field);
    }
    $input['password'] = post_str('password', false);
    return $input;
}

/** Validate and normalise the student columns. Optional fields become NULL. */
function student_validate(array $input, ?array $existing): array
{
    $data = [];
    foreach (array_keys(STUDENT_FIELD_LIMITS) as $field) {
        $data[$field] = trim((string) ($input[$field] ?? ''));
    }
    $data['status'] = (string) ($input['status'] ?? 'Active');
    // The add/edit form no longer asks for a duty day: keep what is stored (blank for new students).
    // The CSV import still supplies one.
    if (!array_key_exists('year_level', $input)) {
        $data['year_level'] = (string) ($existing['year_level'] ?? '');
    }

    $required = [
        'student_number' => 'Student number',
        'first_name'     => 'First name',
        'last_name'      => 'Last name',
        'course'         => 'Course',
    ];
    foreach ($required as $field => $label) {
        if ($data[$field] === '') {
            throw new ValidationException($label . ' is required.', $field);
        }
    }
    foreach (STUDENT_FIELD_LIMITS as $field => $max) {
        if (mb_strlen($data[$field]) > $max) {
            throw new ValidationException(ucfirst(str_replace('_', ' ', $field)) . ' must be ' . $max . ' characters or fewer.', $field);
        }
    }
    if (!in_array($data['status'], STUDENT_STATUSES, true)) {
        throw new ValidationException('Please choose a valid status.', 'status');
    }
    // Existing records may keep a legacy duty day; new values must come from the list.
    if ($data['year_level'] !== '' && !in_array($data['year_level'], DUTY_DAYS, true) && $data['year_level'] !== ($existing['year_level'] ?? null)) {
        throw new ValidationException('Please choose a valid duty day.', 'year_level');
    }

    if ($data['position'] !== '' && !in_array($data['position'], POSITIONS, true) && $data['position'] !== ($existing['position'] ?? null)) {
        throw new ValidationException('Please choose a valid position.', 'position');
    }

    foreach (['middle_name', 'position'] as $optional) {
        if ($data[$optional] === '') {
            $data[$optional] = null;
        }
    }

    // Fixed column order: matches the INSERT/UPDATE statements below.
    return array_merge(array_fill_keys(
        ['student_number', 'first_name', 'middle_name', 'last_name', 'course', 'year_level', 'position', 'status'],
        null
    ), $data);
}

/**
 * Create ($id = 0) or update a student together with their login account.
 * Everything happens in one transaction so a failure never leaves half a record.
 *
 * @return int The student id.
 */
function student_save(array $input, int $id = 0): int
{
    $existing = $id > 0 ? student_find($id) : null;
    if ($id > 0 && $existing === null) {
        throw new ValidationException('That student no longer exists.');
    }

    $data     = student_validate($input, $existing);
    $username = trim((string) ($input['username'] ?? ''));
    $password = (string) ($input['password'] ?? '');
    $account  = $existing ? student_account($id) : null;

    if (mb_strlen($username) > 100) {
        throw new ValidationException('Username must be 100 characters or fewer.', 'username');
    }
    if ($password !== '' && strlen($password) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('Password must be at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'password');
    }
    if ($existing === null && $username === '') {
        throw new ValidationException('Enter a username for the student login.', 'username');
    }
    if ($existing === null && $password === '') {
        throw new ValidationException('Enter a password of at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'password');
    }
    student_assert_unique($data['student_number'], $username, $id, $account);

    try {
        return (int) db_transaction(static function (PDO $pdo) use ($id, $existing, $data, $username, $password, $account): int {
            if ($existing !== null) {
                $stmt = $pdo->prepare(
                    'UPDATE students SET student_number = ?, first_name = ?, middle_name = ?, last_name = ?,
                     course = ?, year_level = ?, position = ?, status = ? WHERE id = ?'
                );
                $stmt->execute([...array_values($data), $id]);
                student_sync_account($pdo, $id, $account, $username, $password);
                audit('UPDATE', 'students', $id, 'Updated student', $existing, $data);
                return $id;
            }

            $stmt = $pdo->prepare(
                'INSERT INTO students (student_number, first_name, middle_name, last_name, course, year_level, position, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute(array_values($data));
            $newId = (int) $pdo->lastInsertId();
            student_sync_account($pdo, $newId, null, $username, $password);
            audit('CREATE', 'students', $newId, 'Created student', null, $data);
            return $newId;
        });
    } catch (PDOException $e) {
        throw db_is_duplicate_key($e) ? new ValidationException('That student number or username is already in use.', 'student_number') : $e;
    }
}

/**
 * Refuse a student number or username that already belongs to someone else, naming the field so the form can point at it.
 * (The database also enforces both; this gives a precise message before anything is written.)
 */
function student_assert_unique(string $studentNumber, string $username, int $id, ?array $account): void
{
    $other = db_one('SELECT id, first_name, last_name FROM students WHERE student_number = ? AND id <> ?', [$studentNumber, $id]);
    if ($other !== null) {
        throw new ValidationException('Student number ' . $studentNumber . ' is already used by ' . $other['first_name'] . ' ' . $other['last_name'] . '.', 'student_number');
    }
    if ($username !== '' && db_value('SELECT COUNT(*) FROM users WHERE username = ? AND id <> ?', [$username, (int) ($account['id'] ?? 0)]) > 0) {
        throw new ValidationException('The username “' . $username . '” is already taken. Choose another one.', 'username');
    }
}

/** Create or update the student's login account. */
function student_sync_account(PDO $pdo, int $studentId, ?array $account, string $username, string $password): void
{
    if ($account !== null) {
        // Only touch what was filled in: a blank username or password keeps the stored one.
        $set    = [];
        $values = [];
        if ($username !== '' && ($password !== '' || $username !== $account['username'])) {
            $set[]    = 'username = ?';
            $values[] = $username;
        }
        if ($password !== '') {
            $set[]    = 'password = ?';
            $values[] = password_hash($password, PASSWORD_DEFAULT);
        }
        if ($set) {
            $pdo->prepare('UPDATE users SET ' . implode(', ', $set) . ' WHERE id = ?')->execute([...$values, $account['id']]);
        }
        return;
    }

    if ($username === '' && $password === '') {
        return; // Existing student without a login: nothing to do.
    }
    if ($username === '') {
        throw new ValidationException('Enter a username when creating a student login.', 'username');
    }
    if (strlen($password) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('A new student login needs a password of at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'password');
    }
    $pdo->prepare("INSERT INTO users (username, password, role, student_id) VALUES (?, ?, 'student', ?)")
        ->execute([$username, password_hash($password, PASSWORD_DEFAULT), $studentId]);
}

/** Delete a student, their login and (by cascade) their attendance. */
function student_delete(int $id): void
{
    db_transaction(static function (PDO $pdo) use ($id): void {
        $student = student_find($id);
        if ($student === null) {
            throw new ValidationException('That student no longer exists.');
        }
        $pdo->prepare("DELETE FROM users WHERE student_id = ? AND role = 'student'")->execute([$id]);
        $pdo->prepare('DELETE FROM students WHERE id = ?')->execute([$id]);
        audit('DELETE', 'students', $id, 'Deleted student', $student);
    });
}

/** "Dela Cruz, Juan P." */
function student_display_name(array $student): string
{
    return trim($student['last_name'] . ', ' . $student['first_name'] . ' ' . ($student['middle_name'] ?? ''));
}

/** Attendance records a student has (they are removed if the student is deleted). */
function student_attendance_count(int $id): int
{
    return (int) db_value('SELECT COUNT(*) FROM attendance WHERE student_id = ?', [$id]);
}

/**
 * Deactivate: status becomes Inactive and the login stops working, but the student and every attendance record stay.
 * Reactivate reverses it. This is the safe alternative to student_delete().
 */
function student_set_active(int $id, bool $active): void
{
    $student = student_find($id);
    if ($student === null) {
        throw new ValidationException('That student no longer exists.');
    }
    $account = student_account($id);
    db_transaction(static function (PDO $pdo) use ($id, $active, $student, $account): void {
        $status = $active ? 'Active' : 'Inactive';
        if ($student['status'] === $status && ($account === null || (int) db_value('SELECT is_active FROM users WHERE id = ?', [$account['id']]) === (int) $active)) {
            throw new ValidationException('That student is already ' . strtolower($status) . '.');
        }
        $pdo->prepare('UPDATE students SET status = ? WHERE id = ?')->execute([$status, $id]);
        if ($account !== null) {
            $pdo->prepare('UPDATE users SET is_active = ? WHERE id = ?')->execute([(int) $active, $account['id']]);
            if (!$active) {
                $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL')->execute([$account['id']]);
            }
        }
        audit('UPDATE', 'students', $id, ($active ? 'Reactivated' : 'Deactivated') . ' student ' . student_display_name($student) . ' (attendance records kept)',
            ['status' => $student['status']], ['status' => $status]);
    });
}

/** One page of the student directory (only that page's rows are fetched). */
function students_page(array $filters, array $sort, int $page, int $perPage = 25): array
{
    [$where, $order, $params] = students_query_parts($filters, $sort);
    $total = (int) db_value('SELECT COUNT(*) FROM students' . $where, $params);
    $pager = paginate($total, $perPage, $page);
    $rows  = db_all('SELECT * FROM students' . $where . ' ORDER BY ' . $order . ' LIMIT ' . $perPage . ' OFFSET ' . $pager['offset'], $params);
    return ['rows' => $rows, 'total' => $total, 'page' => $pager['page'], 'pages' => $pager['pages']];
}

/** Student with their login account's status (is_active), for profile pages. */
function student_profile(int $id): ?array
{
    return db_one(
        "SELECT s.*, u.id AS user_id, u.username, u.is_active AS login_active, u.created_at AS login_created
         FROM students s LEFT JOIN users u ON u.student_id = s.id AND u.role = 'student' WHERE s.id = ? LIMIT 1",
        [$id]
    );
}

/** Attendance record counts for a set of students: [student id => count]. */
function student_attendance_counts(array $ids): array
{
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (!$ids) {
        return [];
    }
    $out = array_fill_keys($ids, 0);
    foreach (db_all('SELECT student_id, COUNT(*) AS total FROM attendance WHERE student_id IN (' . sql_placeholders(count($ids)) . ') GROUP BY student_id', $ids) as $row) {
        $out[(int) $row['student_id']] = (int) $row['total'];
    }
    return $out;
}

/** Login state for a set of students: [student id => is_active (0|1)]. Students without a login are left out. */
function student_login_states(array $ids): array
{
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (!$ids) {
        return [];
    }
    $out = [];
    foreach (db_all("SELECT student_id, is_active FROM users WHERE role = 'student' AND student_id IN (" . sql_placeholders(count($ids)) . ')', $ids) as $row) {
        $out[(int) $row['student_id']] = (int) $row['is_active'];
    }
    return $out;
}
