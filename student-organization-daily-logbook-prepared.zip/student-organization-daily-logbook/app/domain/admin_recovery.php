<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/*
 * Administrator account recovery. Administrators have no one above them to issue a reset link, so a signed-in
 * administrator generates a set of single-use recovery codes and keeps them somewhere safe. If the password is
 * ever lost, "Forgot admin password?" on the sign-in page accepts the username, one unused code and a new password.
 * Only SHA-256 hashes of the codes are stored (codes carry 60 random bits), so a code can be shown just once.
 */

const RECOVERY_CODE_COUNT = 8;
const RECOVERY_ALPHABET   = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I

/** Same definition as in database/logbook.sql; created automatically on installs that predate recovery codes. */
const ADMIN_RECOVERY_TABLE_SQL = <<<'SQL'
CREATE TABLE IF NOT EXISTS admin_recovery_codes (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT UNSIGNED NOT NULL,
    code_hash  CHAR(64) NOT NULL,
    used_at    DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_recovery_lookup (code_hash),
    INDEX idx_recovery_user (user_id, used_at),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;

/** "abcd-efgh jklm" / lowercase / stray spaces -> "ABCD-EFGH-JKLM" so typed codes compare reliably. */
function recovery_code_normalise(string $code): string
{
    $plain = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code) ?? '');
    return strlen($plain) === 12 ? implode('-', str_split($plain, 4)) : '';
}

function recovery_code_hash(string $normalised): string
{
    return hash('sha256', $normalised);
}

/** Number of unused recovery codes an administrator still has. */
function recovery_codes_remaining(int $userId): int
{
    return (int) db_value('SELECT COUNT(*) FROM admin_recovery_codes WHERE user_id = ? AND used_at IS NULL', [$userId]);
}

/**
 * Replace all of the signed-in administrator's recovery codes with a fresh set. The current password is required,
 * so a left-open browser cannot mint codes. The plain codes are returned once and never stored.
 *
 * @return string[] the new codes, formatted XXXX-XXXX-XXXX
 * @throws ValidationException with a message that is safe to show
 */
function recovery_codes_generate(string $currentPassword): array
{
    $admin = user();
    if (!$admin || ($admin['role'] ?? '') !== ROLE_ADMIN) {
        throw new ValidationException('Only administrators can create recovery codes.');
    }
    $row = db_one('SELECT password FROM users WHERE id = ?', [(int) $admin['id']]);
    if (!$row || !password_verify($currentPassword, $row['password'])) {
        throw new ValidationException('Your password is incorrect.', 'current_password');
    }

    $codes = [];
    for ($i = 0; $i < RECOVERY_CODE_COUNT; $i++) {
        $plain = '';
        for ($j = 0; $j < 12; $j++) {
            $plain .= RECOVERY_ALPHABET[random_int(0, strlen(RECOVERY_ALPHABET) - 1)];
        }
        $codes[] = implode('-', str_split($plain, 4));
    }
    db_transaction(static function () use ($admin, $codes): void {
        db_run('DELETE FROM admin_recovery_codes WHERE user_id = ?', [(int) $admin['id']]);
        foreach ($codes as $code) {
            db_run('INSERT INTO admin_recovery_codes (user_id, code_hash) VALUES (?, ?)', [(int) $admin['id'], recovery_code_hash($code)]);
        }
        audit('CREATE', 'admin_recovery_codes', (int) $admin['id'], 'Generated a new set of administrator recovery codes (the codes themselves are never logged)');
    });
    return $codes;
}

/**
 * Set a new administrator password using a username and an unused recovery code. The code is consumed in the same
 * transaction. Every failure gives the same message so nothing reveals which usernames or codes exist.
 *
 * @throws ValidationException with a message that is safe to show
 */
function admin_recover_account(string $username, string $code, string $new, string $confirm): void
{
    $fail = static function (): never {
        usleep(random_int(400000, 700000)); // slows down guessing
        throw new ValidationException('The username or recovery code is not valid, or the code was already used.');
    };
    $normalised = recovery_code_normalise($code);
    if ($username === '' || $normalised === '') {
        $fail();
    }
    if (strlen($new) < MIN_PASSWORD_LENGTH) {
        throw new ValidationException('New password must be at least ' . MIN_PASSWORD_LENGTH . ' characters.', 'new_password');
    }
    if ($new !== $confirm) {
        throw new ValidationException('New passwords do not match.', 'confirm_password');
    }

    $ok = db_transaction(static function (PDO $pdo) use ($username, $normalised, $new): bool {
        $stmt = $pdo->prepare(
            "SELECT c.id, u.id AS user_id FROM admin_recovery_codes c JOIN users u ON u.id = c.user_id
             WHERE u.username = ? AND u.role = 'admin' AND u.is_active = 1 AND c.code_hash = ? AND c.used_at IS NULL FOR UPDATE"
        );
        $stmt->execute([$username, recovery_code_hash($normalised)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return false;
        }
        $pdo->prepare('UPDATE admin_recovery_codes SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);
        $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $row['user_id']]);
        $pdo->prepare('INSERT INTO audit_logs (user_id, action, table_name, record_id, description) VALUES (?, ?, ?, ?, ?)')
            ->execute([$row['user_id'], 'UPDATE', 'users', $row['user_id'], 'Administrator password reset with a recovery code']);
        return true;
    });
    if (!$ok) {
        $fail();
    }
}
