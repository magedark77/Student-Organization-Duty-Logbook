<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/* Attendance statistics: totals, yearly progress, and detection of incomplete records. */

/** Day count and morning / afternoon / total minutes for a set of rows. */
function attendance_summarize(array $rows): array
{
    $summary = ['days' => attendance_days_present($rows), 'morning' => 0, 'afternoon' => 0, 'total' => 0];
    foreach ($rows as $row) {
        $minutes = attendance_minutes($row);
        $summary['morning']   += $minutes['morning'];
        $summary['afternoon'] += $minutes['afternoon'];
        $summary['total']     += $minutes['total'];
    }
    return $summary;
}

/**
 * Progress toward the yearly requirement (REQUIRED_HOURS per calendar year).
 *
 * @param array       $rows attendance rows of one student (any years)
 * @param string|null $year four-digit year to count, default: the current year
 * @return array{minutes: int, remaining: int, percent: float}
 */
function attendance_year_progress(array $rows, ?string $year = null): array
{
    $year ??= date('Y');
    $inYear = array_filter($rows, static fn(array $row): bool => substr((string) $row['attendance_date'], 0, 4) === $year);
    $minutes = attendance_summarize($inYear)['total'];
    return [
        'minutes'   => $minutes,
        'remaining' => remaining_minutes($minutes),
        'percent'   => progress_percent($minutes),
    ];
}

/** Minutes one student logged in a calendar year, summed in the database (no need to load every row). */
function attendance_year_minutes(int $studentId, string $year): int
{
    return (int) db_value(
        'SELECT COALESCE(SUM(' . sql_attendance_minutes('a') . '), 0) FROM attendance a
         WHERE a.student_id = ? AND a.attendance_date BETWEEN ? AND ?',
        [$studentId, $year . '-01-01', $year . '-12-31']
    );
}

/** Students present (timed in) on a date, of which active ones, and students with an open (timed-in, not out) session. */
function attendance_day_stats(string $date): array
{
    $row = db_one(
        'SELECT
            COALESCE(SUM(a.morning_time_in IS NOT NULL OR a.afternoon_time_in IS NOT NULL), 0) AS present,
            COALESCE(SUM((a.morning_time_in IS NOT NULL OR a.afternoon_time_in IS NOT NULL) AND s.status = ?), 0) AS present_active,
            COALESCE(SUM((a.morning_time_in IS NOT NULL AND a.morning_time_out IS NULL)
                      OR (a.afternoon_time_in IS NOT NULL AND a.afternoon_time_out IS NULL)), 0) AS open_sessions
         FROM attendance a JOIN students s ON s.id = a.student_id WHERE a.attendance_date = ?',
        [STUDENT_STATUSES[0], $date]
    );
    return ['present' => (int) $row['present'], 'present_active' => (int) $row['present_active'], 'open' => (int) $row['open_sessions']];
}

/** Every minute ever logged, summed in the database. */
function attendance_total_minutes(): int
{
    return (int) db_value('SELECT COALESCE(SUM(' . sql_attendance_minutes('a') . '), 0) FROM attendance a');
}

/**
 * SQL condition (no placeholders) true for a record with a missing time-in or time-out in either session,
 * or with no times at all.
 */
function sql_attendance_incomplete(string $alias = 'a'): string
{
    $p = $alias !== '' ? $alias . '.' : '';
    return "(({$p}morning_time_in IS NULL) <> ({$p}morning_time_out IS NULL)"
        . " OR ({$p}afternoon_time_in IS NULL) <> ({$p}afternoon_time_out IS NULL)"
        . " OR ({$p}morning_time_in IS NULL AND {$p}morning_time_out IS NULL AND {$p}afternoon_time_in IS NULL AND {$p}afternoon_time_out IS NULL))";
}

/** Human-readable problems of one record: empty list when it is complete. */
function attendance_incomplete_reasons(array $row): array
{
    $reasons = [];
    foreach ([['morning', 'Morning'], ['afternoon', 'Afternoon']] as [$key, $label]) {
        $in  = ($row[$key . '_time_in'] ?? null) !== null;
        $out = ($row[$key . '_time_out'] ?? null) !== null;
        if ($in && !$out) {
            $reasons[] = $label . ' time-out missing';
        } elseif (!$in && $out) {
            $reasons[] = $label . ' time-in missing';
        }
    }
    if (($row['morning_time_in'] ?? null) === null && ($row['morning_time_out'] ?? null) === null
        && ($row['afternoon_time_in'] ?? null) === null && ($row['afternoon_time_out'] ?? null) === null) {
        $reasons[] = 'No times recorded';
    }
    return $reasons;
}

/** Number of incomplete records, optionally limited to one student. */
function attendance_incomplete_count(?int $studentId = null, ?string $from = null, ?string $to = null): int
{
    $sql    = 'SELECT COUNT(*) FROM attendance a WHERE ' . sql_attendance_incomplete('a');
    $params = [];
    if ($studentId !== null) {
        $sql .= ' AND a.student_id = ?';
        $params[] = $studentId;
    }
    if ($from !== null) {
        $sql .= ' AND a.attendance_date >= ?';
        $params[] = $from;
    }
    if ($to !== null) {
        $sql .= ' AND a.attendance_date <= ?';
        $params[] = $to;
    }
    return (int) db_value($sql, $params);
}

/** Incomplete records between two dates, and how many of them fall on $onDate: one query for both numbers. */
function attendance_incomplete_counts(string $from, string $to, string $onDate): array
{
    $row = db_one(
        'SELECT COUNT(*) AS total, COALESCE(SUM(a.attendance_date = ?), 0) AS on_date
         FROM attendance a WHERE a.attendance_date BETWEEN ? AND ? AND ' . sql_attendance_incomplete('a'),
        [$onDate, $from, $to]
    );
    return ['total' => (int) $row['total'], 'on_date' => (int) $row['on_date']];
}

/** Rows of a student's attendance that fall in $year. */
function attendance_rows_in_year(array $rows, string $year): array
{
    return array_values(array_filter($rows, static fn(array $r): bool => substr((string) $r['attendance_date'], 0, 4) === $year));
}

/** Days with at least one time-in (a record with no times is not a day present). */
function attendance_days_present(array $rows): int
{
    return count(array_filter($rows, static fn(array $r): bool => ($r['morning_time_in'] ?? null) !== null || ($r['afternoon_time_in'] ?? null) !== null));
}

/** Minutes per month (1–12) for the rows given (use attendance_rows_in_year() first). */
function attendance_month_minutes(array $rows): array
{
    $months = array_fill(1, 12, 0);
    foreach ($rows as $row) {
        $months[(int) substr((string) $row['attendance_date'], 5, 2)] += attendance_minutes($row)['total'];
    }
    return $months;
}

/** Short month names for charts. */
function month_labels(): array
{
    return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
}

/** Whole days left in the calendar year (0 on 31 December). */
function days_left_in_year(?int $now = null): int
{
    $now ??= time();
    return max(0, (int) floor((strtotime(date('Y', $now) . '-12-31 23:59:59') - $now) / 86400));
}
