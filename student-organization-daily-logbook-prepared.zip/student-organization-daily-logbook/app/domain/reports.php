<?php
declare(strict_types=1);
defined('APP_BOOT') || exit;

/** 'YYYY-MM' from ?month=, falling back to the current month. */
function report_month_from_request(): string
{
    $month = get_str('month');
    return preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month) ? $month : date('Y-m');
}

const REPORT_SORTS = [
    'name' => 'Name', 'number' => 'Student No.', 'course' => 'Course', 'days' => 'Days',
    'total' => 'This Month', 'year' => 'Year to Date', 'remaining' => 'Remaining', 'progress' => 'Progress',
];

/**
 * Per-student totals for a month.
 *
 * @return array{start: string, end: string, rows: array<int, array>, totals: array}
 */
function monthly_report(string $month, array $filters = [], array $sort = ['name', 'asc']): array
{
    $start = $month . '-01';
    $end   = date('Y-m-t', (int) strtotime($start));
    // The required hours are per calendar year, so progress is measured from
    // 1 January up to the end of the selected month.
    $yearStart = substr($month, 0, 4) . '-01-01';

    $rows   = [];
    $totals = ['days' => 0, 'minutes' => 0, 'year_minutes' => 0];
    foreach (students_with_totals($yearStart, $end, $filters, [$start, $end], 's.last_name, s.first_name, s.id') as $row) {
        $minutes = (int) $row['sub_minutes'];   // this month
        $year    = (int) $row['minutes'];       // year to date
        $rows[]  = [
            'id' => $row['id'], 'student_number' => $row['student_number'], 'first_name' => $row['first_name'], 'last_name' => $row['last_name'],
            'course' => $row['course'], 'year_level' => $row['year_level'], 'status' => $row['status'],
            'days' => $row['sub_days'], 'total_minutes' => $row['sub_minutes'], 'year_minutes' => $year,
            'minutes' => $minutes, 'remaining' => remaining_minutes($year), 'percent' => progress_percent($year),
        ];
        $totals['days']         += (int) $row['sub_days'];
        $totals['minutes']      += $minutes;
        $totals['year_minutes'] += $year;
    }

    [$key, $dir] = $sort;
    $rows = sort_rows($rows, static fn(array $r) => match ($key) {
        'number'    => strtolower($r['student_number']),
        'course'    => strtolower($r['course']),
        'days'      => $r['days'],
        'total'     => $r['minutes'],
        'year'      => $r['year_minutes'],
        'remaining' => $r['remaining'],
        'progress'  => $r['percent'],
        default     => strtolower($r['last_name'] . ' ' . $r['first_name']),
    }, $dir);

    return ['start' => $start, 'end' => $end, 'year_start' => $yearStart, 'rows' => $rows, 'totals' => $totals];
}

/** Neutralise spreadsheet formulas (=, +, -, @) in user-entered CSV cells. */
function csv_safe(string $value): string
{
    return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
}


/** Four-digit year from ?year_of= (the reporting year), defaulting to the current year. */
function report_year_from_request(): string
{
    $year = get_str('report_year');
    return preg_match('/^(19|20)\d{2}$/', $year) ? $year : date('Y');
}

/* ---- Report metadata and export plumbing ------------------------------------ */

/* ---- Export tables: the ONE place that defines what each report exports ----------------
 * CSV and PDF both come from these, built from the same filter parsing as the on-screen pages,
 * so a download always matches what the filtered screen shows. */
