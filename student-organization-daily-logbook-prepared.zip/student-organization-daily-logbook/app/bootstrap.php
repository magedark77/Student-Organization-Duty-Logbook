<?php
/**
 * Application bootstrap. Every page starts with:
 *     require __DIR__ . '/../app/bootstrap.php';
 */

define('APP_BOOT', true);
define('APP_ROOT', dirname(__DIR__));

/*
 * Load order matters only within a group: core (infrastructure) first, then ui (rendering helpers), then domain (rules and data).
 * Everything is plain functions; there is no autoloader, so a new file just needs adding to its list.
 */
$modules = [
    'core'   => ['errors', 'config', 'request', 'session', 'security', 'database', 'schema_tables', 'schema', 'auth', 'pdf'],
    'ui'     => ['layout', 'forms', 'filters', 'icons', 'components', 'charts', 'page_actions'],
    'domain' => [
        'duration', 'students', 'attendance', 'attendance_write', 'attendance_stats', 'reports', 'report_totals', 'report_exports',
        'audit', 'officers', 'notifications', 'announcements', 'corrections', 'accounts', 'admin_recovery', 'imports', 'qr_attendance', 'backups',
    ],
];
foreach ($modules as $group => $files) {
    foreach ($files as $file) {
        require __DIR__ . "/{$group}/{$file}.php";
    }
}
unset($modules, $group, $files, $file);
