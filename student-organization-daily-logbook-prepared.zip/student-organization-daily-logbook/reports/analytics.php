<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$year    = report_year_from_request();
$filters = student_filters_from_request();
$base    = url('reports/analytics.php');
$courses = students_courses();
$query   = clean_query(['report_year' => $year === date('Y') ? '' : $year] + $filters);

$months   = analytics_monthly_minutes($year, $filters);
$yearly   = analytics_yearly_minutes($filters);
$totals   = students_with_totals($year . '-01-01', $year . '-12-31', $filters); // one pass feeds both groupings
$byCourse = analytics_group($year, 'course', $filters, $totals);
$byDay    = analytics_group($year, 'year_level', $filters, $totals);
$total    = array_sum($months);
$hours    = static fn(int $minutes): float => round($minutes / 60, 1);

render_header('Charts & Summaries', 'reports');
page_head('Charts & summaries', 'Duty hours for ' . $year . ' by month, course and duty day.', [
    ['label' => 'Print', 'class' => 'primary', 'attrs' => ['data-print' => true]],
], [['Reports', url('reports/monthly.php')], ['Charts & summaries', null]]);
echo report_tabs('analytics');
?>
<p class="print-only report-id"><?= e(APP_NAME) ?> — Charts &amp; Summaries, <?= e($year) ?>. <?= e(report_generated_line()) ?>. Filters: <?= e(report_filter_summary($filters)) ?></p>
<section class="card">
    <?= filter_bar($base, array_merge(
        [inline_field('Year', 'report_year', $year, ['type' => 'number', 'min' => 2000, 'max' => 2100])],
        student_filter_controls($filters, $courses, 'Any status', false, false)
    ), [
        'active' => count(clean_query($filters)),
        'hidden' => array_intersect_key($filters, ['course' => 1]),
        'apply'  => null,
        'reset'  => null,
    ]) ?>
    <p class="report-meta"><strong>Total logged in <?= e($year) ?>:</strong> <?= e(format_duration($total)) ?> <span class="dot" aria-hidden="true">•</span> <?= e(report_filter_summary($filters)) ?></p>
</section>

<?php if ($total === 0 && !$yearly): ?>
    <section class="card"><?= empty_state('No attendance data yet', 'Charts appear once attendance has been recorded' . (clean_query($filters) ? ' for these filters.' : '.'), '', 'chart') ?></section>
<?php else: ?>
    <section class="card">
        <h2>Hours per month, <?= e($year) ?></h2>
        <?= bar_chart('Duty hours logged per month in ' . $year, month_labels(), array_map($hours, array_values($months))) ?>
    </section>
    <section class="card">
        <h2>Hours per year</h2>
        <?= bar_chart('Duty hours logged per year', array_keys($yearly), array_map($hours, array_values($yearly))) ?>
    </section>
    <div class="grid cols-2">
        <section class="card">
            <h2>By course, <?= e($year) ?></h2>
            <?= $byCourse ? hbar_chart('Total hours by course', array_map(static fn(array $g): array => ['label' => $g['label'], 'value' => $g['minutes'] / 60, 'note' => plural($g['students'], 'student') . ', avg ' . chart_number($g['average'] / 60) . 'h'], $byCourse)) : empty_state('No courses to compare') ?>
        </section>
        <section class="card">
            <h2>By duty day, <?= e($year) ?></h2>
            <?= $byDay ? hbar_chart('Total hours by duty day', array_map(static fn(array $g): array => ['label' => $g['label'], 'value' => $g['minutes'] / 60, 'note' => plural($g['students'], 'student') . ', avg ' . chart_number($g['average'] / 60) . 'h'], $byDay)) : empty_state('No duty days to compare') ?>
        </section>
    </div>
    <section class="card">
        <h2>Summary table, <?= e($year) ?></h2>
        <?php table_start('Summary by course and duty day', true); ?>
            <thead><tr><th scope="col">Group</th><th scope="col">Students</th><th scope="col">Days present</th><th scope="col">Total hours</th><th scope="col">Average per student</th></tr></thead>
            <tbody>
                <?php foreach (['Course' => $byCourse, 'Duty day' => $byDay] as $kind => $groups): foreach ($groups as $g): ?>
                    <tr><td data-label="Group"><span class="cell-sub"><?= e($kind) ?></span><strong><?= e($g['label']) ?></strong></td>
                        <td data-label="Students"><?= $g['students'] ?></td><td data-label="Days present"><?= $g['days'] ?></td>
                        <td data-label="Total hours"><?= e(format_duration($g['minutes'])) ?></td><td data-label="Average per student"><?= e(format_duration((int) round($g['average']))) ?></td></tr>
                <?php endforeach; endforeach; ?>
            </tbody>
        <?php table_end(); ?>
    </section>
<?php endif; ?>
<?php render_footer();
