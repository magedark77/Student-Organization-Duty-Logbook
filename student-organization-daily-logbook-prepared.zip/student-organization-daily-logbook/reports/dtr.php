<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$month = report_month_from_request();
$start = $month . '-01';
$end = date('Y-m-t', (int) strtotime($start));
$studentId = max(0, (int) get_str('student_id'));
$students = db_all("SELECT id, student_number, first_name, middle_name, last_name, course, year_level FROM students ORDER BY last_name, first_name");
$student = $studentId ? student_find($studentId) : null;
$records = [];
if ($student) {
    $records = db_all(
        'SELECT * FROM attendance WHERE student_id = ? AND attendance_date BETWEEN ? AND ? ORDER BY attendance_date',
        [$studentId, $start, $end]
    );
}
$byDate = [];
foreach ($records as $record) $byDate[$record['attendance_date']] = $record;
$daysInMonth = (int) date('t', (int) strtotime($start));
$totalMinutes = 0;
foreach ($records as $record) $totalMinutes += attendance_minutes($record)['total'];

render_header('Daily Time Record', 'reports');
page_head('Daily Time Record', date('F Y', (int) strtotime($start)), [
    ['label' => 'Print DTR', 'class' => 'primary', 'attrs' => ['data-print' => true]],
], [['Reports', url('reports/monthly.php')], ['Daily Time Record', null]]);
?>
<section class="card no-print" style="margin-bottom:18px">
    <form method="get" action="<?= e(url('reports/dtr.php')) ?>" class="filter-form" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
        <label style="display:block;min-width:220px;flex:1">Student
            <select name="student_id" required style="display:block;width:100%;margin-top:6px">
                <option value="">Select a student…</option>
                <?php foreach ($students as $s): ?>
                    <option value="<?= (int) $s['id'] ?>" <?= $studentId === (int) $s['id'] ? 'selected' : '' ?>>
                        <?= e(trim(($s['student_number'] ?? '') . ' — ' . $s['last_name'] . ', ' . $s['first_name'] . ' ' . ($s['middle_name'] ?? ''))) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Month
            <input type="month" name="month" value="<?= e($month) ?>" required style="display:block;margin-top:6px">
        </label>
        <button class="btn primary" type="submit">Generate DTR</button>
    </form>
    <p class="muted" style="margin:12px 0 0">Choose a student and month, then print or save as PDF from your browser’s print dialog.</p>
</section>

<?php if (!$student): ?>
    <section class="card no-print"><p>Select a student and month to generate the official-style Daily Time Record.</p></section>
<?php else: ?>
<div class="dtr-sheet">
    <div class="dtr-brand">CIVIL SERVICE FORM NO. 48</div>
    <h1>DAILY TIME RECORD</h1>
    <div class="dtr-name"><?= e(trim(($student['first_name'] ?? '') . ' ' . ($student['middle_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></div>
    <div class="dtr-label">(Name)</div>
    <?php $position = trim((string) ($student['position'] ?? '')); ?>
    <div class="dtr-position"><?= $position !== '' ? e($position) : '&nbsp;' ?></div>
    <div class="dtr-label">(Position)</div>
    <div class="dtr-month">For the month of <strong><?= e(date('F Y', (int) strtotime($start))) ?></strong></div>
    <div class="dtr-official">
        <span>Official hours for arrival<br>and departure</span>
        <span>(Regular days&nbsp; __________________<br>(Saturdays&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __________________</span>
    </div>
    <table class="dtr-table">
        <thead>
            <tr>
                <th rowspan="2" class="day-col">Day</th>
                <th colspan="2">A.M.</th>
                <th colspan="2">P.M.</th>
                <th colspan="2">UNDERTIME</th>
            </tr>
            <tr>
                <th>Arrival</th><th>Departure</th><th>Arrival</th><th>Departure</th><th>Hours</th><th>Minutes</th>
            </tr>
        </thead>
        <tbody>
        <?php for ($day = 1; $day <= $daysInMonth; $day++):
            $date = sprintf('%s-%02d', $month, $day);
            $r = $byDate[$date] ?? [];
            $minutes = isset($byDate[$date]) ? attendance_minutes($r)['total'] : 0;
        ?>
            <tr>
                <td class="day-col"><?= $day ?></td>
                <td><?= e(format_clock($r['morning_time_in'] ?? null)) ?></td>
                <td><?= e(format_clock($r['morning_time_out'] ?? null)) ?></td>
                <td><?= e(format_clock($r['afternoon_time_in'] ?? null)) ?></td>
                <td><?= e(format_clock($r['afternoon_time_out'] ?? null)) ?></td>
                <td></td><td></td>
            </tr>
        <?php endfor; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="5" class="total-label">T O T A L</th><th colspan="2"><?= e(format_duration($totalMinutes)) ?></th></tr>
        </tfoot>
    </table>
    <p class="dtr-verified">Verified as to the prescribed office hours.</p>
    <p class="dtr-certify">I CERTIFY on my honor that the above is a true and correct report of the hours of work performed, record of which was made daily at the time of arrival at and departure from office.</p>
    <div class="dtr-signatures">
        <div class="dtr-sign-block dtr-officer-block">
            <div class="dtr-sign-space"></div>
            <div class="dtr-sign-line dtr-name-above"><?= e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></div>
            <div class="dtr-officer-title">Officers/Club Members</div>
            <small class="dtr-officer-caption">(Signature over printed name)</small>
        </div>
        <div class="dtr-sign-block dtr-adviser-block">
            <div class="dtr-sign-space"></div>
            <div class="dtr-sign-line dtr-name-above">Jessica R. Anave</div>
            <div class="dtr-officer-title">Adviser</div>
            <small class="dtr-officer-caption">(Signature over printed name)</small>
        </div>
    </div>
    <p class="dtr-note">Student No.: <?= e($student['student_number'] ?? '') ?> &nbsp; | &nbsp; Course: <?= e($student['course'] ?? '') ?> &nbsp; | &nbsp; Year/Day: <?= e($student['year_level'] ?? '') ?></p>
    <p class="dtr-note">Generated by <?= e(APP_NAME) ?> on <?= e(date('F j, Y g:i A')) ?>. This is a system-generated DTR; verify official hours and signatures before submission.</p>
</div>
<?php endif; ?>

<style>
.dtr-sheet{background:#fff;color:#171717;max-width:900px;margin:0 auto;padding:28px 34px;border:1px solid #d8d8d8;font-family:Georgia,"Times New Roman",serif;box-shadow:0 4px 18px #0000000d}
.dtr-brand{font-size:13px;font-weight:bold;letter-spacing:.5px;color:#444}
.dtr-sheet h1{text-align:center;font-size:24px;letter-spacing:1.5px;margin:8px 0 18px}
.dtr-name{text-align:left;border-bottom:1px solid #333;padding:7px 0 3px;font-size:16px;font-weight:bold;text-transform:uppercase}
.dtr-label{text-align:left;font-size:12px;margin-top:2px}
.dtr-month{margin-top:15px;border-bottom:1px solid #555;padding-bottom:5px;font-size:14px}
.dtr-official{display:flex;justify-content:space-between;gap:15px;margin:8px 0;font-size:12px;line-height:1.45}
.dtr-table{border-collapse:collapse;width:100%;table-layout:fixed;font-size:12px}
.dtr-table th,.dtr-table td{border:1px solid #555;text-align:center;padding:5px 3px;height:22px}
.dtr-table thead th{font-weight:bold;background:#f1f1f1}
.dtr-table .day-col{width:7%}
.dtr-table tfoot th{height:32px;font-size:13px}
.dtr-table .total-label{text-align:center;letter-spacing:3px}
.dtr-certify{font-size:12px;line-height:1.5;margin:20px 0 28px;text-align:justify}
.dtr-signatures{display:grid;grid-template-columns:1fr 1fr;gap:25px;font-size:12px;line-height:1.5}
.dtr-signatures small{font-size:11px}
.dtr-position{text-align:left;border-bottom:0;padding:9px 0 3px;font-size:14px;font-weight:bold;text-transform:uppercase;letter-spacing:.5px}
.dtr-verified{text-align:left;font-size:12px;font-style:italic;margin:10px 0 0}
.dtr-sign-block{text-align:center}
.dtr-signatures{align-items:start}
.dtr-sign-line.dtr-name-above{border-top:0;border-bottom:1px solid #222;padding:0 0 2px}
.dtr-officer-title{font-weight:bold;font-size:12px;letter-spacing:.3px}
.dtr-officer-caption{font-style:italic;display:block;margin-top:1px}
.dtr-officer-title{margin-top:3px}
.dtr-sign-space{min-height:42px;display:flex;align-items:flex-end;justify-content:center;font-size:11px;font-style:italic;padding-bottom:6px}
.dtr-sign-line{border-top:1px solid #222;margin:0 auto;width:85%;padding-top:4px;font-weight:bold;text-transform:uppercase;font-size:12px;letter-spacing:.3px}
.dtr-sign-block small{display:block;margin-top:2px}
.dtr-note{font:10px Arial,sans-serif;color:#555;margin:18px 0 0}
@media print{
    @page{size:A4 portrait;margin:0}
    html,body{height:auto!important;margin:0!important;padding:0!important;background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .layout{display:block!important}
    .main{padding:0!important;margin:0!important;max-width:none!important}
    .no-print,header,nav,.sidebar,.topbar,.appbar,.page-actions,.page-head,.breadcrumbs,footer{display:none!important}
    .dtr-brand,.dtr-official,.dtr-certify,.dtr-note{display:none!important}

    .dtr-sheet{box-sizing:border-box;width:210mm;height:296mm;max-width:none;margin:0;padding:11mm 14mm 9mm;border:0;box-shadow:none;overflow:hidden;page-break-after:avoid;break-after:avoid;break-inside:avoid;display:flex;flex-direction:column}
    .dtr-sheet h1{font-size:16pt;letter-spacing:2.5px;margin:0 0 4mm;padding-bottom:0;border-bottom:0}
    .dtr-name{padding:1mm 0 .5mm;font-size:12pt;letter-spacing:.6px}
    .dtr-position{padding:1.5mm 0 .5mm;font-size:10pt;font-weight:600;letter-spacing:.5px;color:#222}
    .dtr-label{font-size:7.5pt;font-style:italic;color:#444;margin-top:.5mm}
    .dtr-month{margin:3.5mm 0 3mm;padding-bottom:1.5mm;font-size:10pt}

    .dtr-table{font-size:8pt;margin:0}
    .dtr-table th,.dtr-table td{padding:0 2px;height:5.5mm;line-height:1;border:.6pt solid #222}
    .dtr-table thead th{height:5mm;background:#ececec!important;font-size:7.5pt;letter-spacing:.8px;text-transform:uppercase}
    .dtr-table tfoot th{height:7.5mm;font-size:9pt;background:#f6f6f6!important}
    .dtr-table .total-label{letter-spacing:5px}

    .dtr-verified{font-size:8.5pt;margin:2.5mm 0 0}
    .dtr-signatures{margin-top:auto;padding-top:8mm;gap:20mm;font-size:8.5pt}
    .dtr-sign-space{min-height:12mm;font-size:8pt}
    .dtr-sign-line.dtr-name-above{padding:0 0 .6mm}
    .dtr-officer-title{font-size:9pt}
    .dtr-officer-caption{font-size:8pt}
    .dtr-sign-line{width:92%;font-size:9pt}
    .dtr-signatures small{font-size:8pt;color:#333}
}
</style>
<?php render_footer(); ?>