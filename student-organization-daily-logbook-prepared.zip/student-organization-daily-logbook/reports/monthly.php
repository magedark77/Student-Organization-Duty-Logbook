<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$month = report_month_from_request();

/* Old bookmark: monthly.php?csv=1 is now export-csv.php. */
if (isset($_GET['csv'])) {
    redirect(url('reports/export-csv.php', ['month' => $month]));
}

$filters = student_filters_from_request();
$sort    = sort_from_request(REPORT_SORTS, 'name');
$report  = monthly_report($month, $filters, $sort);
$query   = clean_query(['month' => $month] + $filters);
$exportQ = clean_query($query + ['sort' => $sort[0], 'dir' => $sort[1]]);
$courses = students_courses();
$base    = url('reports/monthly.php');

render_header('Monthly Report', 'reports');
page_head('Monthly Report', date('F Y', (int) strtotime($report['start'])), [
    ['label' => 'Export CSV/Excel', 'href' => url('reports/export.php', ['report' => 'monthly', 'format' => 'csv'] + $exportQ)],
    ['label' => 'Export PDF', 'href' => url('reports/export.php', ['report' => 'monthly', 'format' => 'pdf'] + $exportQ)],
    ['label' => 'Print', 'class' => 'primary', 'attrs' => ['data-print' => true]],
    ['label' => 'Daily Time Record (DTR)', 'href' => url('reports/dtr.php', ['month' => $month])],
], [['Reports', null]]);
echo report_tabs('monthly');
?>
<p class="print-only report-id"><?= e(APP_NAME) ?> — Monthly Duty-Hour Report. <?= e(report_generated_line()) ?>. Filters: <?= e(report_filter_summary($filters)) ?></p>
<section class="card">
    <?= filter_bar(url('reports/monthly.php'), array_merge(
        ['<input type="month" name="month" value="' . e($month) . '" aria-label="Report month" data-autosubmit>'],
        student_filter_controls($filters, $courses, 'Any status', true, false)
    ), [
        'active' => count(clean_query($filters)),
        'hidden' => array_intersect_key($filters, ['course' => 1]) + sort_hidden($sort),
        'apply'  => null,
        'reset'  => null,
    ]) ?>

    <p class="report-meta">
        <strong>Period:</strong> <?= e(format_date($report['start'])) ?> to <?= e(format_date($report['end'])) ?>
        <span class="dot" aria-hidden="true">•</span>
        <strong>Required:</strong> <?= REQUIRED_HOURS ?> hours per year (counted <?= e(format_date($report['year_start'])) ?> to <?= e(format_date($report['end'])) ?>)
        <?php if ($filters['year'] !== ''): ?><span class="dot" aria-hidden="true">•</span><strong>Duty day:</strong> <?= e($filters['year']) ?><?php endif; ?>
        <span class="dot" aria-hidden="true">•</span><?= e(plural(count($report['rows']), 'student')) ?>
    </p>

    <?php if (!$report['rows']): ?>
        <?= empty_state(clean_query($filters) !== [] ? 'No students match your filters' : 'There are no students to report on yet', clean_query($filters) !== [] ? 'Try different filters or reset them.' : 'Add students first, then record attendance to see monthly totals here.', clean_query($filters) !== [] ? '<a class="btn secondary" href="' . e(url('reports/monthly.php', ['month' => $month])) . '">Reset filters</a>' : '<a class="btn primary" href="' . e(url('admin/students.php')) . '">Go to students</a>', 'chart') ?>
    <?php else: ?>
    <?php table_start('Monthly report'); ?>
        <thead>
            <tr>
                <?= sort_th('Student', 'name', $sort, $base, $query) ?>
                <?= sort_th('Course', 'course', $sort, $base, $query) ?>
                <?= sort_th('Days', 'days', $sort, $base, $query) ?>
                <?= sort_th('This Month', 'total', $sort, $base, $query) ?>
                <?= sort_th('Year to Date', 'year', $sort, $base, $query) ?>
                <?= sort_th('Remaining', 'remaining', $sort, $base, $query) ?>
                <?= sort_th('Progress', 'progress', $sort, $base, $query) ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($report['rows'] as $row): ?>
                <tr>
                    <td><?= e(student_label($row)) ?></td>
                    <td><?= e($row['course']) ?></td>
                    <td><?= (int) $row['days'] ?></td>
                    <td><?= format_duration($row['minutes']) ?></td>
                    <td><?= hours_span(format_duration($row['year_minutes']), 'done') ?></td>
                    <td><?= hours_span(format_duration($row['remaining']), $row['remaining'] > 0 ? 'left' : 'done') ?></td>
                    <td>
                        <div class="progress-cell">
                            <?= progress_bar($row['percent'], 'Progress for ' . $row['first_name'] . ' ' . $row['last_name']) ?>
                            <span><?= number_format($row['percent'], 1) ?>%</span>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <?php if ($report['rows']): ?>
            <tfoot>
                <tr>
                    <th scope="row" colspan="2">Total</th>
                    <td><?= (int) $report['totals']['days'] ?></td>
                    <td><?= format_duration($report['totals']['minutes']) ?></td>
                    <td><?= hours_span(format_duration($report['totals']['year_minutes']), 'done') ?></td>
                    <td colspan="2"></td>
                </tr>
            </tfoot>
        <?php endif; ?>
    <?php table_end(); ?>
    <?php endif; ?>
</section>
<?php render_footer();
