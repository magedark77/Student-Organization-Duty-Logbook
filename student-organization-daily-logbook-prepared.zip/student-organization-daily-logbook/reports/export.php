<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin(); // exports contain student information: administrators only

$report = get_choice('report', array_keys(EXPORTABLE_REPORTS));
$format = get_choice('format', ['csv', 'pdf']);
if ($report === '' || $format === '') {
    render_error_page(400, 'Unknown export', 'Choose a report and a format (CSV or PDF) from the Reports pages.');
}
report_export_send($report, $format);
