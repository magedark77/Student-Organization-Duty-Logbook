<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$year    = report_year_from_request();
$filters = student_filters_from_request();
$sort    = sort_from_request(OUTSTANDING_SORTS, 'remaining', 'desc');
$rows    = students_outstanding($year, $filters, $sort);
$query   = clean_query(['report_year' => $year === date('Y') ? '' : $year] + $filters);
$exportQ = $query + ['sort' => $sort[0], 'dir' => $sort[1]];
$courses = students_courses();
$base    = url('reports/outstanding.php');
$urgency = $year === date('Y') ? outstanding_urgency($year) : 'urgent'; // a finished year is overdue

render_header('Hours Not Completed', 'reports');
page_head('Students who have not completed ' . REQUIRED_HOURS . ' hours', 'Year ' . $year . ' — active students unless you choose another status.', [
    ['label' => 'Export CSV/Excel', 'href' => url('reports/export.php', ['report' => 'outstanding', 'format' => 'csv'] + $exportQ)],
    ['label' => 'Export PDF', 'href' => url('reports/export.php', ['report' => 'outstanding', 'format' => 'pdf'] + $exportQ)],
    ['label' => 'Print', 'class' => 'primary', 'attrs' => ['data-print' => true]],
], [['Reports', url('reports/monthly.php')], ['Hours not completed', null]]);
echo report_tabs('outstanding');
?>
<p class="print-only report-id"><?= e(APP_NAME) ?> — Students Who Have Not Completed Required Hours (<?= e($year) ?>). <?= e(report_generated_line()) ?>.</p>
<section class="card">
    <?= filter_bar($base, array_merge(
        [inline_field('Year', 'report_year', $year, ['type' => 'number', 'min' => 2000, 'max' => 2100])],
        student_filter_controls($filters, $courses, 'Active (default)', true, false)
    ), [
        'active' => count(clean_query($filters)),
        'hidden' => array_intersect_key($filters, ['course' => 1]) + sort_hidden($sort, ['remaining', 'desc']),
        'apply'  => null,
        'reset'  => null,
    ]) ?>
    <p class="report-meta"><strong>Required:</strong> <?= REQUIRED_HOURS ?> hours (1 Jan – 31 Dec <?= e($year) ?>) <span class="dot" aria-hidden="true">•</span> <strong><?= e(plural(count($rows), 'student')) ?></strong> below the requirement</p>

    <?php if (!$rows): ?>
        <?= clean_query($filters) !== []
            ? empty_state('No students match your filters', 'Try different filters, or reset them.', '<a class="btn secondary" href="' . e($base) . '">Reset</a>', 'search')
            : empty_state('Everyone has completed ' . REQUIRED_HOURS . ' hours', 'No active students are below the requirement for ' . $year . '.', '', 'check') ?>
    <?php else: ?>
        <?php table_start('Students below the required hours', true); ?>
            <thead><tr>
                <?= sort_th('Student', 'name', $sort, $base, $query) ?>
                <?= sort_th('Course', 'course', $sort, $base, $query) ?>
                <?= sort_th('Duty day', 'day', $sort, $base, $query) ?>
                <th scope="col">Days</th>
                <?= sort_th('Completed', 'done', $sort, $base, $query) ?>
                <?= sort_th('Remaining', 'remaining', $sort, $base, $query) ?>
                <th scope="col">Progress</th>
                <th scope="col">Status</th>
            </tr></thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td data-label="Student"><a href="<?= e(url('admin/student-view.php', ['id' => (int) $r['id']])) ?>"><?= e(student_label($r)) ?></a></td>
                        <td data-label="Course"><?= e($r['course']) ?></td>
                        <td data-label="Duty day"><?= e($r['year_level']) ?></td>
                        <td data-label="Days"><?= (int) $r['days'] ?></td>
                        <td data-label="Completed"><?= hours_span(format_duration($r['minutes']), 'done') ?></td>
                        <td data-label="Remaining"><?= hours_span(format_duration($r['remaining']), 'left') ?></td>
                        <td data-label="Progress"><div class="progress-cell"><?= progress_bar($r['percent'], 'Progress for ' . $r['first_name'] . ' ' . $r['last_name']) ?><span><?= number_format($r['percent'], 1) ?>%</span></div></td>
                        <td data-label="Status"><?= status_indicator($urgency, $urgency === 'urgent' ? 'Urgent' : 'Pending') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php table_end(); ?>
    <?php endif; ?>
</section>
<?php render_footer();
