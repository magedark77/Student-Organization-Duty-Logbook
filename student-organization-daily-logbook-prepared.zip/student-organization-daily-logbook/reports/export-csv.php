<?php
/* Kept so old bookmarks keep working: the monthly CSV now comes from export.php (same data, same filters). */
require __DIR__ . '/../app/bootstrap.php';
require_admin();

report_export_send('monthly', 'csv');
