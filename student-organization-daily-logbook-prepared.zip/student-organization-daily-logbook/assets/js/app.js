/**
 * Student Organization Logbook — progressive enhancement.
 *
 * Declarative hooks (no inline handlers in the markup):
 *   form[data-confirm="Message"]     ask before submitting
 *   form[data-no-loading]            skip the "Please wait…" state
 *   [data-print]                     print the page
 *   [data-autosubmit]                submit the surrounding form on change
 *   form[data-live-search]           its search box submits the form ~0.6 s after typing stops (and keeps focus after the reload)
 *   .modal                           dialog; close via [data-modal-close], Escape or backdrop
 *   .modal[data-clear-params="a,b"]  query-string keys removed from the URL on close
 *   .stat-value                      whole numbers count up on load (skipped for reduced motion)
 *   [data-notif-poll="url"]          bell link; its unread count is refreshed while the page is open
 *   input[type="time"][data-now]     gets a "Now" button that fills in the current time
 *   .alert.success / .alert.info     get a dismiss button
 *   [data-modal-open="id"]           button/link that opens the modal with that id
 *   button[data-confirm-click="..."] ask before this particular submit button sends its form
 *   form[data-confirm-change-select="name"][data-confirm-change-message="..."]
 *                                    ask only if that <select> differs from its data-original value
 *   [data-show-when="name=value"]    shown only while the named field of the same form has that value
 *   [data-menu-toggle]               mobile menu button (shown only when this script runs)
 *   form[data-attendance-form]       confirmation summary before saving, plus a live "record already exists" warning
 *   details.filter-details           filter bar; folds behind a "Filters" button on phones when no filter is active
 *   details.action-menu             row "More" menu; one open at a time, closes on outside click or Escape
 *   input[data-select-on-focus]      selects its text when focused (copy-friendly links)
 */
(() => {
  'use strict';

  const FOCUSABLE = [
    'a[href]',
    'button:not([disabled])',
    'input:not([disabled]):not([type="hidden"])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])',
  ].join(',');

  /* ---------------------------------------------------------------- Modals */

  let returnFocusTo = null;

  const openModal = (modal) => {
    returnFocusTo = document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');

    const first = modal.querySelector('input:not([type="hidden"]):not([readonly]), select, textarea');
    (first || modal.querySelector('.modal-box')).focus?.({ preventScroll: true });
  };

  const clearUrlParams = (modal) => {
    const names = (modal.dataset.clearParams || '').split(',').filter(Boolean);
    if (!names.length || !window.history.replaceState) return;

    const url = new URL(window.location.href);
    const present = names.filter((name) => url.searchParams.has(name));
    if (!present.length) return;

    present.forEach((name) => url.searchParams.delete(name));
    window.history.replaceState({}, '', url);
  };

  const prefersReducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const closeModal = (modal) => {
    if (modal.classList.contains('is-closing')) return;

    const finish = () => {
      modal.classList.remove('is-open', 'is-closing');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.toggle('modal-open', document.querySelector('.modal.is-open') !== null);
    };

    clearUrlParams(modal);
    if (returnFocusTo && document.contains(returnFocusTo)) returnFocusTo.focus();
    returnFocusTo = null;

    if (prefersReducedMotion()) {
      finish();
    } else {
      modal.classList.add('is-closing'); // plays the exit animation, then hides
      window.setTimeout(finish, 170);
    }
  };

  const trapFocus = (event, modal) => {
    const items = [...modal.querySelectorAll(FOCUSABLE)].filter((el) => el.offsetParent !== null);
    if (!items.length) return;

    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  /* --------------------------------------------------------------- Forms */

  const setLoading = (button) => {
    if (button.dataset.loading === 'true') return;
    button.dataset.loading = 'true';
    button.setAttribute('aria-busy', 'true');
    if (button.classList.contains('primary')) {
      button.dataset.originalText = button.textContent;
      button.textContent = 'Please wait…';
    }
    button.disabled = true;
  };

  const resetLoading = () => {
    document.querySelectorAll('button[data-loading="true"]').forEach((button) => {
      button.disabled = false;
      button.removeAttribute('aria-busy');
      delete button.dataset.loading;
      if (button.dataset.originalText) {
        button.textContent = button.dataset.originalText;
        delete button.dataset.originalText;
      }
    });
  };

  /* -------------------------------------------------------------- Events */

  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    if (target.closest('[data-print]')) {
      window.print();
      return;
    }

    const opener = target.closest('[data-modal-open]');
    if (opener) {
      const modal = document.getElementById(opener.getAttribute('data-modal-open'));
      if (modal) openModal(modal);
      return;
    }

    const confirmButton = target.closest('button[data-confirm-click]');
    if (confirmButton && !window.confirm(confirmButton.getAttribute('data-confirm-click'))) {
      event.preventDefault();
      return;
    }

    const menuButton = target.closest('[data-menu-toggle]');
    if (menuButton) {
      const open = document.body.classList.toggle('nav-open');
      menuButton.setAttribute('aria-expanded', String(open));
      return;
    }

    if (target.closest('[data-modal-close]')) {
      const modal = target.closest('.modal');
      if (modal) closeModal(modal);
      return;
    }

    // Click on the dimmed backdrop (not the dialog box) closes the modal.
    if (target.classList.contains('modal') && target.classList.contains('is-open')) {
      closeModal(target);
    }
  });

  document.addEventListener('keydown', (event) => {
    const modal = document.querySelector('.modal.is-open');
    if (!modal) return;

    if (event.key === 'Escape') {
      closeModal(modal);
    } else if (event.key === 'Tab') {
      trapFocus(event, modal);
    }
  });

  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;

    const message = form.dataset.confirm;
    if (message && !window.confirm(message)) {
      event.preventDefault();
      return;
    }

    // Role (or similar) changed in an edit dialog: make the administrator confirm the permission change.
    const watched = form.dataset.confirmChangeSelect;
    if (watched) {
      const select = form.elements[watched];
      if (select && select.dataset.original !== undefined && select.value !== select.dataset.original
          && !window.confirm(form.dataset.confirmChangeMessage || 'Change this setting?')) {
        event.preventDefault();
        return;
      }
    }

    if (form.hasAttribute('data-attendance-form') && !window.confirm(attendanceSummary(form))) {
      event.preventDefault();
      return;
    }
    if (form.hasAttribute('data-no-loading')) return;

    // Disable after the browser has collected the form data, to block double submits.
    const button = event.submitter || form.querySelector('button[type="submit"], button:not([type])');
    if (button) window.setTimeout(() => setLoading(button), 0);
  });

  document.addEventListener('change', (event) => {
    const target = event.target;
    if (target instanceof HTMLElement && target.hasAttribute('data-autosubmit') && target.form) {
      target.form.requestSubmit();
    }
  });

  /* Live search: filter bars without an Apply button submit shortly after typing stops, and the box keeps its focus. */
  const LIVE_KEY = 'live-search-field';
  const remember = (value) => { try { window.sessionStorage.setItem(LIVE_KEY, value); } catch (error) { /* storage blocked: focus is a nicety */ } };
  const recall = () => {
    try { const value = window.sessionStorage.getItem(LIVE_KEY); window.sessionStorage.removeItem(LIVE_KEY); return value; } catch (error) { return null; }
  };

  const startLiveSearch = () => {
    const recalled = recall(); // read once per page load
    document.querySelectorAll('form[data-live-search] input[type="search"]').forEach((input) => {
      const form = input.form;
      const key = location.pathname + '#' + input.name;
      let timer = 0;
      let last = input.value;

      input.addEventListener('input', () => {
        window.clearTimeout(timer);
        if (input.value.trim() === last.trim()) return;
        timer = window.setTimeout(() => { last = input.value; form.requestSubmit(); }, 600);
      });
      form.addEventListener('submit', () => { if (document.activeElement === input) remember(key); }); // not when a dropdown caused the submit

      if (recalled === key) { // the page was reloaded by this box: put the caret back at the end
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
      }
    });
  };

  // Restore buttons when the page is shown again from the back/forward cache.
  window.addEventListener('pageshow', (event) => {
    if (event.persisted) resetLoading();
  });

  /* ------------------------------------------------------------ Count-up */

  const countUp = (element) => {
    const target = Number(element.textContent.replace(/,/g, ''));
    if (!Number.isInteger(target) || target <= 0 || target > 100000) return;

    const start = performance.now();
    const duration = 900;
    const tick = (now) => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      element.textContent = Math.round(target * eased).toLocaleString();
      if (progress < 1) window.requestAnimationFrame(tick);
    };
    window.requestAnimationFrame(tick);
  };

  /* ------------------------------------------------- Notification badge */

  const NOTIF_POLL_MS = 60000;

  const startNotificationPolling = () => {
    const bell = document.querySelector('[data-notif-poll]');
    if (!bell || !('fetch' in window)) {
      return;
    }
    const endpoint = bell.getAttribute('data-notif-poll');

    const show = (count) => {
      document.querySelectorAll('[data-notif-badge]').forEach((badge) => {
        badge.textContent = count > 99 ? '99+' : String(count);
        badge.hidden = count <= 0;
      });
      bell.setAttribute('aria-label', count > 0 ? `Notifications (${count} unread)` : 'Notifications');
    };

    const refresh = () => {
      if (document.hidden) {
        return;
      }
      fetch(endpoint, { headers: { Accept: 'application/json' }, cache: 'no-store' })
        .then((response) => (response.ok ? response.json() : null))
        .then((data) => {
          if (data && Number.isInteger(data.unread)) {
            show(data.unread);
          }
        })
        .catch(() => { /* offline or signed out: keep what is shown */ });
    };

    setInterval(refresh, NOTIF_POLL_MS);
    document.addEventListener('visibilitychange', refresh);
  };

  /* ------------------------------------------------------- Small helpers */

  const pad = (n) => String(n).padStart(2, '0');

  // Put an input in a positioned wrapper and add a small button inside its right edge ("Now", "Show").
  // The wrapper (not the <label>) is the positioning context, so hints and error text below the input cannot push the button out of the field.
  const addInlineButton = (input, button, modifier) => {
    const wrap = document.createElement('span');
    wrap.className = `input-wrap ${modifier}`;
    input.before(wrap);
    wrap.append(input, button);
  };

  // "Now" button beside each time input: one click instead of typing the clock time.
  const enhanceTimeInputs = () => {
    document.querySelectorAll('input[type="time"][data-now]').forEach((input) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'field-now';
      button.textContent = 'Now';
      button.setAttribute('aria-label', 'Set to the current time');
      button.addEventListener('click', () => {
        const now = new Date();
        input.value = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.focus();
      });
      addInlineButton(input, button, 'has-now');
    });
  };

  // Success and info messages can be closed; warnings and errors stay until the page changes.
  const enhanceAlerts = () => {
    document.querySelectorAll('.alert.success, .alert.info').forEach((alertBox) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'alert-dismiss';
      button.innerHTML = '&times;';
      button.setAttribute('aria-label', 'Dismiss message');
      button.addEventListener('click', () => alertBox.remove());
      alertBox.classList.add('is-dismissible');
      alertBox.append(button);
    });
  };

  /* ------------------------------------------------- Attendance form helpers */

  const minutesOf = (value) => {
    const match = /^(\d{1,2}):(\d{2})/.exec(value || '');
    return match ? Number(match[1]) * 60 + Number(match[2]) : null;
  };

  const sessionText = (inValue, outValue) => (inValue && outValue ? `${inValue} – ${outValue}` : '—');

  // Same rule as the server (out minus in per session); the server remains the authority.
  const attendanceSummary = (form) => {
    const get = (name) => (form.elements[name] ? form.elements[name].value : '');
    const select = form.querySelector('[data-student-select]');
    const student = select
      ? (select.selectedOptions[0] ? select.selectedOptions[0].textContent.trim() : '')
      : (form.querySelector('[data-student-label]') || {}).value || '';
    let total = 0;
    [['morning_in', 'morning_out'], ['afternoon_in', 'afternoon_out']].forEach(([a, b]) => {
      const start = minutesOf(get(a));
      const end = minutesOf(get(b));
      if (start !== null && end !== null && end > start) total += end - start;
    });
    const hours = `${Math.floor(total / 60)}h ${total % 60}m`;
    const replace = form.elements.confirm_overwrite && form.elements.confirm_overwrite.checked ? '\n\nThis REPLACES the existing record.' : '';
    return `Save this attendance?\n\nStudent: ${student}\nDate: ${get('attendance_date')}\nMorning: ${sessionText(get('morning_in'), get('morning_out'))}\nAfternoon: ${sessionText(get('afternoon_in'), get('afternoon_out'))}\nTotal: ${hours}${replace}`;
  };

  // Warn as soon as a student and date are chosen if a record already exists for them.
  const startDuplicateCheck = (form) => {
    const url = form.dataset.checkUrl;
    const select = form.querySelector('[data-student-select]');
    const dateInput = form.querySelector('[data-date-input]');
    const box = form.querySelector('[data-duplicate-warning]');
    if (!url || !select || !dateInput || !box || !('fetch' in window)) return;
    const overwrite = form.querySelector('[data-overwrite-block]');
    const reason = form.querySelector('[data-reason-block]');

    const check = () => {
      if (!select.value || !dateInput.value) {
        box.hidden = true;
        return;
      }
      fetch(`${url}?student_id=${encodeURIComponent(select.value)}&date=${encodeURIComponent(dateInput.value)}`, { headers: { Accept: 'application/json' }, cache: 'no-store' })
        .then((response) => (response.ok ? response.json() : null))
        .then((data) => {
          if (!data || !data.exists) {
            box.hidden = true;
            if (overwrite && !overwrite.querySelector('.field-error')) overwrite.hidden = true;
            if (reason && !reason.querySelector('.field-error')) reason.hidden = true;
            return;
          }
          box.textContent = `A record already exists for this student on this date (morning ${data.morning}, afternoon ${data.afternoon}, total ${data.total}).`
            + (data.canReplace ? ' To change it, tick “Replace it” below and give a reason.' : ' Only an administrator can change an existing record.');
          box.hidden = false;
          if (data.canReplace) {
            if (overwrite) overwrite.hidden = false;
            if (reason) reason.hidden = false;
          }
        })
        .catch(() => { box.hidden = true; });
    };
    select.addEventListener('change', check);
    dateInput.addEventListener('change', check);
    check();
  };

  // Search box above the student dropdown. The <select> stays the source of truth (so the form,
  // duplicate check and confirm dialog work unchanged); typing just narrows its options.
  // Options are rebuilt rather than hidden because iOS/Safari ignore display:none on <option>.
  const startStudentSearch = (form) => {
    const select = form.querySelector('[data-student-select]');
    if (!select || select.dataset.searchReady) return;
    select.dataset.searchReady = '1';

    const normalize = (text) => (text || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    const placeholder = select.options[0] ? select.options[0].textContent : 'Select a student';

    // Snapshot every option once: [{ group, value, label, key }]
    const items = [];
    Array.from(select.querySelectorAll('option')).forEach((option) => {
      if (option.value === '') return;
      const group = option.parentElement.tagName === 'OPTGROUP' ? option.parentElement.label : '';
      const label = option.textContent.trim();
      items.push({ group, value: option.value, label, key: normalize(`${label} ${group}`) });
    });

    const search = document.createElement('input');
    search.type = 'search';
    search.className = 'student-search';
    search.placeholder = 'Search student by name or ID…';
    search.autocomplete = 'off';
    search.setAttribute('aria-label', 'Search students');
    search.enterKeyHint = 'search';

    const status = document.createElement('span');
    status.className = 'hint student-search-status';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');

    select.parentNode.insertBefore(search, select);
    select.parentNode.insertBefore(status, select.nextSibling);

    const render = (matches, selectedValue) => {
      select.innerHTML = '';
      const blank = document.createElement('option');
      blank.value = '';
      blank.textContent = placeholder;
      select.appendChild(blank);
      let currentGroup = null;
      let groupEl = null;
      matches.forEach((item) => {
        if (item.group !== currentGroup) {
          currentGroup = item.group;
          groupEl = item.group ? document.createElement('optgroup') : null;
          if (groupEl) {
            groupEl.label = item.group;
            select.appendChild(groupEl);
          }
        }
        const option = document.createElement('option');
        option.value = item.value;
        option.textContent = item.label;
        (groupEl && item.group ? groupEl : select).appendChild(option);
      });
      select.value = selectedValue;
    };

    const apply = () => {
      const terms = normalize(search.value).split(/\s+/).filter(Boolean);
      const previous = select.value;
      const matches = terms.length ? items.filter((item) => terms.every((term) => item.key.includes(term))) : items;
      // Keep an already chosen student available even if they no longer match the search.
      const shown = previous && !matches.some((item) => item.value === previous)
        ? items.filter((item) => item.value === previous || matches.includes(item))
        : matches;
      render(shown, previous);

      if (terms.length) {
        status.textContent = matches.length
          ? `${matches.length} student${matches.length === 1 ? '' : 's'} found`
          : 'No student matches your search';
        select.size = Math.min(Math.max(shown.length + 1, 2), 7); // show results as a list while searching
      } else {
        status.textContent = '';
        select.removeAttribute('size');
      }

      // A single match is picked for you so you can move straight on to the times.
      if (terms.length && matches.length === 1 && select.value !== matches[0].value) {
        select.value = matches[0].value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
    };

    search.addEventListener('input', apply);
    search.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault(); // never submit the form from the search box
        const first = Array.from(select.options).find((option) => option.value !== '');
        if (first && !select.value) {
          select.value = first.value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
        }
        search.value = '';
        apply();
      } else if (event.key === 'ArrowDown' && select.options.length > 1) {
        event.preventDefault();
        select.focus();
        if (!select.value) select.selectedIndex = 1;
      }
    });
    // Once a student is picked from the result list, collapse back to a normal dropdown.
    select.addEventListener('change', () => {
      if (select.value && search.value) {
        select.removeAttribute('size');
      }
    });
  };

  // Show a block only while a field of the same form has a given value (e.g. the urgent-confirmation box).
  const startConditionalBlocks = () => {
    document.querySelectorAll('[data-show-when]').forEach((block) => {
      const [name, value] = block.dataset.showWhen.split('=');
      const form = block.closest('form');
      const control = form && form.elements[name];
      if (!control) return;
      const update = () => { block.hidden = control.value !== value; };
      control.addEventListener('change', update);
      update();
    });
  };

  /* ------------------------------------------------ Filter bar and row menus */

  const startFilterBars = () => {
    const phone = window.matchMedia('(max-width: 680px)');
    const bars = document.querySelectorAll('details.filter-details');
    const apply = () => bars.forEach((bar) => { bar.open = !phone.matches || Number(bar.dataset.active) > 0; });
    apply();
    phone.addEventListener('change', () => bars.forEach((bar) => { if (!phone.matches) bar.open = true; }));
  };

  const startActionMenus = () => {
    const closeAll = (except) => document.querySelectorAll('details.action-menu[open]').forEach((menu) => { if (menu !== except) menu.open = false; });
    document.addEventListener('click', (event) => closeAll(event.target instanceof Element ? event.target.closest('details.action-menu') : null));
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;
      const open = document.querySelector('details.action-menu[open]');
      if (open) { open.open = false; open.querySelector('summary').focus(); }
    });
  };

  /* --------------------------------------------------------- Init on load */

  document.addEventListener('DOMContentLoaded', () => {
    const modal = document.querySelector('.modal.is-open');
    if (modal) openModal(modal);

    startNotificationPolling();

    if (!prefersReducedMotion()) {
      document.querySelectorAll('.stat-value').forEach(countUp);
    }

    enhanceTimeInputs();
    enhanceAlerts();
    startConditionalBlocks();
    startFilterBars();
    startLiveSearch();
    startActionMenus();
    document.querySelectorAll('form[data-attendance-form]').forEach(startStudentSearch);
    document.querySelectorAll('form[data-attendance-form]').forEach(startDuplicateCheck);

    // Mobile menu: the button only exists when JS runs, so the menu stays usable without it.
    const menuToggle = document.querySelector('[data-menu-toggle]');
    if (menuToggle) {
      menuToggle.hidden = false;
      document.body.classList.add('has-menu-toggle');
    }
    document.querySelectorAll('input[data-select-on-focus]').forEach((input) => {
      input.addEventListener('focus', () => input.select());
    });

    // Show/hide password buttons (added here so the page works without JS).
    document.querySelectorAll('input[type="password"][data-toggle]').forEach((input) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'field-toggle';
      button.textContent = 'Show';
      button.setAttribute('aria-label', 'Show password');
      button.addEventListener('click', () => {
        const visible = input.type === 'text';
        input.type = visible ? 'password' : 'text';
        button.textContent = visible ? 'Show' : 'Hide';
        button.setAttribute('aria-label', visible ? 'Show password' : 'Hide password');
      });
      addInlineButton(input, button, 'has-toggle');
    });
  });
  /* Account menu in the top bar: close it on an outside click or Escape. */
  document.addEventListener('click', (event) => {
    document.querySelectorAll('details[data-user-menu][open]').forEach((menu) => {
      if (!(event.target instanceof Node) || !menu.contains(event.target)) menu.removeAttribute('open');
    });
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('details[data-user-menu][open]').forEach((menu) => {
      menu.removeAttribute('open');
      menu.querySelector('summary')?.focus();
    });
  });
})();
