/*
 * QR attendance scanner (admin/qr-scanner.php).
 *
 * - Camera access starts only when the user presses "Start Camera".
 * - Frames are decoded in the browser with jsQR (assets/vendor/jsQR.js); the decoded text is only a lookup key.
 *   The SERVER finds the student, picks Time In or Time Out and stamps the time (admin/qr-scan.php).
 * - A scan is sent once; while it is processing the camera is ignored and the buttons are disabled.
 * - Every scan carries a random request id, so a retry after a network drop can never record twice.
 * - Everything shown from the server is inserted with textContent (never innerHTML).
 */
(function () {
  'use strict';

  var root = document.querySelector('[data-qr-scanner]');
  if (!root) return;

  var $ = function (selector) { return root.querySelector(selector); };
  var video = $('[data-qr-video]');
  var stage = $('[data-qr-stage]');
  var idle = $('[data-qr-idle]');
  var busyBox = $('[data-qr-busy]');
  var statusLine = $('[data-qr-status]');
  var btnStart = $('[data-qr-start]');
  var btnStop = $('[data-qr-stop]');
  var btnSwitch = $('[data-qr-switch]');
  var resultBox = $('[data-qr-result]');
  var recentList = $('[data-qr-recent]');
  var manualForm = $('[data-qr-manual]');
  var manualInput = manualForm ? manualForm.querySelector('input[name="code"]') : null;
  var manualBtn = manualForm ? manualForm.querySelector('button[type="submit"]') : null;
  var clockDate = $('[data-qr-clock-date]');
  var clockTime = $('[data-qr-clock-time]');

  var endpoint = root.getAttribute('data-endpoint');
  var csrf = root.getAttribute('data-csrf');
  var enabled = root.getAttribute('data-enabled') === '1';
  var timeZone = root.getAttribute('data-tz') || 'Asia/Manila';
  var serverOffset = Date.now() - Number(root.getAttribute('data-server-ms') || Date.now());

  var COOLDOWN_MS = 10000;     // the same code is ignored this long after it was read (a student still holding the card up)
  var RESULT_MS = 7000;        // how long a result stays on screen
  var MAX_ATTEMPTS = 3;        // initial try + 2 automatic retries after a network error
  var FRAME_MS = 110;          // time between decode attempts
  var MAX_WIDTH = 640;         // frames are scaled down to this width before decoding

  var stream = null;
  var timer = null;
  var processing = false;
  var wantCamera = false;
  var deviceIds = [];
  var deviceIndex = -1;
  var facing = 'environment';
  var lastText = '';
  var lastAt = 0;
  var resultTimer = null;
  var canvas = document.createElement('canvas');
  var ctx = canvas.getContext('2d', { willReadFrequently: true });
  var recent = [];

  /* ---------- small helpers ---------- */

  function setStatus(text, kind) {
    statusLine.textContent = text;
    statusLine.className = 'qr-status' + (kind ? ' is-' + kind : '');
  }

  function randomId() {
    var bytes = new Uint8Array(16);
    (window.crypto || window.msCrypto).getRandomValues(bytes);
    return Array.prototype.map.call(bytes, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function beep(ok) {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      var audio = beep.ctx || (beep.ctx = new Ctx());
      var osc = audio.createOscillator();
      var gain = audio.createGain();
      osc.frequency.value = ok ? 880 : 220;
      osc.type = 'sine';
      gain.gain.value = 0.08;
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.start();
      osc.stop(audio.currentTime + (ok ? 0.12 : 0.3));
    } catch (e) { /* sound is optional */ }
    try { if (navigator.vibrate) navigator.vibrate(ok ? 80 : [120, 60, 120]); } catch (e) { /* optional */ }
  }

  function setBusy(on) {
    processing = on;
    busyBox.hidden = !on;
    stage.classList.toggle('is-busy', on);
    if (manualBtn) manualBtn.disabled = on || !enabled;
    if (manualInput) manualInput.readOnly = on;
  }

  /* ---------- clock (server time, in the school's time zone) ---------- */

  function tickClock() {
    var now = new Date(Date.now() - serverOffset);
    try {
      clockDate.textContent = now.toLocaleDateString('en-US', { timeZone: timeZone, weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      clockTime.textContent = now.toLocaleTimeString('en-US', { timeZone: timeZone, hour: 'numeric', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      clockTime.textContent = now.toLocaleTimeString();
    }
  }
  tickClock();
  setInterval(tickClock, 1000);

  /* ---------- result panel ---------- */

  function clearResultLater() {
    clearTimeout(resultTimer);
    resultTimer = setTimeout(showIdle, RESULT_MS);
  }

  function showIdle() {
    resultBox.className = 'card qr-result is-idle';
    resultBox.textContent = '';
    resultBox.appendChild(el('div', 'qr-result-icon', '▣'));
    resultBox.appendChild(el('h2', null, enabled ? 'Ready to scan' : 'Scanning is switched off'));
    resultBox.appendChild(el('p', 'text-muted', enabled
      ? 'Hold a student QR code in front of the camera. The result appears here.'
      : 'An administrator has turned QR attendance off.'));
  }

  function avatar(student) {
    var wrap = el('div', 'qr-avatar');
    if (student && student.photo) {
      var img = document.createElement('img');
      img.alt = '';
      img.src = student.photo;
      img.addEventListener('error', function () {
        wrap.textContent = student.initials || '?';
      });
      wrap.appendChild(img);
    } else {
      wrap.textContent = (student && student.initials) || '?';
    }
    return wrap;
  }

  function showResult(data, httpStatus) {
    var kind;
    if (data.ok) kind = data.status === 'late' || data.status === 'early' ? 'warn' : 'ok';
    else kind = (data.reason === 'duplicate' || data.reason === 'complete') ? 'warn' : 'bad';

    resultBox.className = 'card qr-result is-' + kind;
    resultBox.textContent = '';
    var head = el('div', 'qr-result-head');
    if (data.student) head.appendChild(avatar(data.student));
    var who = el('div', 'qr-who');
    if (data.student) {
      who.appendChild(el('strong', 'qr-name', data.student.name));
      who.appendChild(el('span', 'qr-meta', 'ID ' + data.student.number + (data.student.course ? ' · ' + data.student.course : '')));
      if (data.student.position || data.student.duty_day) {
        who.appendChild(el('span', 'qr-meta', [data.student.position, data.student.duty_day].filter(Boolean).join(' · ')));
      }
    }
    head.appendChild(who);
    resultBox.appendChild(head);

    var msg = el('h2', 'qr-message', data.ok ? data.message : (data.message || 'Scan failed.'));
    resultBox.appendChild(msg);
    if (data.ok) {
      var badge = el('span', 'qr-pill is-' + (data.action === 'Time In' ? 'in' : 'out'), data.action + ' · ' + data.time);
      resultBox.appendChild(badge);
      if (data.status === 'late') resultBox.appendChild(el('span', 'qr-pill is-late', 'Late'));
      if (data.status === 'early') resultBox.appendChild(el('span', 'qr-pill is-late', 'Early departure'));
      if (data.detail) resultBox.appendChild(el('p', 'text-muted', data.detail));
      (data.notes || []).forEach(function (note) { resultBox.appendChild(el('p', 'qr-note', note)); });
      if (data.today) {
        var today = el('dl', 'qr-today');
        today.appendChild(el('dt', null, 'Morning'));
        today.appendChild(el('dd', null, data.today.morning));
        today.appendChild(el('dt', null, 'Afternoon'));
        today.appendChild(el('dd', null, data.today.afternoon));
        resultBox.appendChild(today);
      }
    }
    if (httpStatus === 401) {
      var link = el('a', 'btn primary', 'Sign in again');
      link.href = root.getAttribute('data-login-url');
      resultBox.appendChild(link);
    }
    beep(!!data.ok);
    clearResultLater();
  }

  function addRecent(label, kind, student) {
    var now = new Date(Date.now() - serverOffset);
    var time;
    try { time = now.toLocaleTimeString('en-US', { timeZone: timeZone, hour: 'numeric', minute: '2-digit' }); }
    catch (e) { time = now.toLocaleTimeString(); }
    recent.unshift({ time: time, label: label, kind: kind, name: student ? student.name : 'Unknown code' });
    recent = recent.slice(0, 8);
    recentList.textContent = '';
    recent.forEach(function (item) {
      var li = el('li', 'is-' + item.kind);
      li.appendChild(el('span', 'qr-recent-time', item.time));
      var body = el('span', 'qr-recent-body');
      body.appendChild(el('strong', null, item.name));
      body.appendChild(el('small', null, item.label));
      li.appendChild(body);
      recentList.appendChild(li);
    });
  }

  /* ---------- sending a scan ---------- */

  function sleep(ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); }

  function post(code, method, requestId) {
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var abortTimer = controller ? setTimeout(function () { controller.abort(); }, 12000) : null;
    var body = new FormData();
    body.append('code', code);
    body.append('method', method);
    body.append('request_id', requestId);
    body.append('csrf', csrf);
    return fetch(endpoint, {
      method: 'POST',
      body: body,
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { 'Accept': 'application/json' },
      signal: controller ? controller.signal : undefined
    }).then(function (response) {
      if (abortTimer) clearTimeout(abortTimer);
      return response.text().then(function (text) {
        var data = null;
        try { data = JSON.parse(text); } catch (e) { /* not JSON: a host error page */ }
        return { status: response.status, data: data };
      });
    }, function (err) {
      if (abortTimer) clearTimeout(abortTimer);
      throw err;
    });
  }

  async function submitScan(code, method) {
    if (processing || !enabled) return false;
    setBusy(true);
    setStatus('Checking…', 'busy');
    var requestId = randomId();
    var outcome = null;
    for (var attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        outcome = await post(code, method, requestId);
        // A 5xx without JSON is a temporary host/database problem: retry with the same request id (safe, see above).
        if (outcome.data === null && outcome.status >= 500 && attempt < MAX_ATTEMPTS) {
          setStatus('Server busy, retrying…', 'busy');
          await sleep(1200);
          continue;
        }
        break;
      } catch (err) {
        outcome = null;
        if (attempt < MAX_ATTEMPTS) {
          setStatus('Connection problem, retrying…', 'busy');
          await sleep(1200);
        }
      }
    }

    var ok = false;
    if (outcome && outcome.data) {
      showResult(outcome.data, outcome.status);
      ok = !!outcome.data.ok;
      var student = outcome.data.student || null;
      addRecent(ok ? outcome.data.action + ' · ' + outcome.data.time : (outcome.data.message || 'Refused'),
        ok ? 'ok' : (outcome.data.reason === 'duplicate' || outcome.data.reason === 'complete' ? 'warn' : 'bad'), student);
      setStatus(ok ? 'Recorded. Ready for the next student.' : 'Not recorded. Ready for the next scan.', ok ? 'ok' : 'bad');
    } else {
      var offline = outcome === null;
      showResult({
        ok: false,
        reason: offline ? 'network' : 'server',
        message: offline
          ? 'Could not reach the server. Nothing was recorded. Check the internet connection and scan again.'
          : 'The server had a problem (it may be the database). Nothing was recorded. Please scan again in a moment.'
      }, 0);
      addRecent(offline ? 'Connection failed' : 'Server error', 'bad', null);
      setStatus(offline ? 'No connection. Scan again when you are back online.' : 'Server error. Try again.', 'bad');
    }
    lastText = code;
    lastAt = Date.now();
    setBusy(false);
    return ok;
  }

  /* ---------- camera ---------- */

  function cameraError(err) {
    var name = err && err.name;
    var text;
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'SecurityError') {
      text = 'Camera permission was denied. Allow camera access for this site in the browser settings, then press Start Camera again. You can also type the student number below.';
    } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError' || name === 'OverconstrainedError') {
      text = 'No camera was found on this device. Use the manual entry below.';
    } else if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') {
      text = 'The camera is busy or cannot be opened. Close other apps or tabs that use it, then try again.';
    } else {
      text = 'The camera could not be started (' + (name || 'unknown error') + '). Use the manual entry below.';
    }
    setStatus(text, 'bad');
    showResult({ ok: false, reason: 'camera', message: text }, 0);
    revealManual();
  }

  function revealManual() {
    var box = $('[data-qr-manual-box]');
    if (box && box.tagName === 'DETAILS') box.open = true;
  }

  function updateButtons() {
    var running = !!stream;
    btnStart.hidden = running;
    btnStop.hidden = !running;
    btnSwitch.hidden = !running || deviceIds.length < 2;
    stage.classList.toggle('is-live', running);
    idle.hidden = running;
  }

  async function listCameras() {
    try {
      var all = await navigator.mediaDevices.enumerateDevices();
      deviceIds = all.filter(function (d) { return d.kind === 'videoinput' && d.deviceId; }).map(function (d) { return d.deviceId; });
    } catch (e) { deviceIds = []; }
  }

  async function startCamera(deviceId) {
    if (!enabled) return;
    if (!window.isSecureContext) {
      setStatus('The camera only works over HTTPS. Open this page with https:// in the address bar.', 'bad');
      showResult({ ok: false, reason: 'https', message: 'The camera needs a secure (HTTPS) connection. Open this page with https://.' }, 0);
      revealManual();
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('This browser cannot use the camera. Try Chrome, Edge, Firefox or Safari, or use manual entry.', 'bad');
      revealManual();
      return;
    }
    stopCamera(true);
    btnStart.disabled = true;
    setStatus('Starting camera… allow access if the browser asks.', 'busy');
    var video_ = { width: { ideal: 1280 }, height: { ideal: 720 } };
    if (deviceId) video_.deviceId = { exact: deviceId };
    else video_.facingMode = { ideal: facing };
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: video_, audio: false });
    } catch (err) {
      btnStart.disabled = false;
      stream = null;
      updateButtons();
      cameraError(err);
      return;
    }
    btnStart.disabled = false;
    wantCamera = true;
    video.srcObject = stream;
    try { await video.play(); } catch (e) { /* autoplay is allowed after a click; ignore */ }
    var track = stream.getVideoTracks()[0];
    var settings = track && track.getSettings ? track.getSettings() : {};
    await listCameras();
    deviceIndex = deviceIds.indexOf(settings.deviceId);
    updateButtons();
    setStatus('Camera on. Point it at a student QR code.', 'ok');
    schedule();
  }

  function stopCamera(silent) {
    clearTimeout(timer);
    timer = null;
    if (stream) {
      stream.getTracks().forEach(function (t) { t.stop(); });
      stream = null;
    }
    video.srcObject = null;
    if (!silent) {
      wantCamera = false;
      setStatus('Camera stopped.', '');
    }
    updateButtons();
  }

  function schedule() {
    clearTimeout(timer);
    if (stream) timer = setTimeout(tick, FRAME_MS);
  }

  function tick() {
    if (!stream) return;
    if (processing || video.readyState < 2 || !video.videoWidth) {
      schedule();
      return;
    }
    var scale = Math.min(1, MAX_WIDTH / video.videoWidth);
    var w = Math.max(1, Math.round(video.videoWidth * scale));
    var h = Math.max(1, Math.round(video.videoHeight * scale));
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;
    ctx.drawImage(video, 0, 0, w, h);
    var found = null;
    try {
      var image = ctx.getImageData(0, 0, w, h);
      found = window.jsQR ? window.jsQR(image.data, w, h, { inversionAttempts: 'dontInvert' }) : null;
    } catch (e) { found = null; }
    if (found && found.data) {
      var text = found.data;
      if (!(text === lastText && Date.now() - lastAt < COOLDOWN_MS)) {
        submitScan(text, 'camera').then(schedule, schedule);
        return;
      }
    }
    schedule();
  }

  async function switchCamera() {
    if (deviceIds.length > 1) {
      deviceIndex = (deviceIndex + 1) % deviceIds.length;
      await startCamera(deviceIds[deviceIndex]);
    } else {
      facing = facing === 'environment' ? 'user' : 'environment';
      await startCamera(null);
    }
  }

  /* ---------- wiring ---------- */

  btnStart.addEventListener('click', function () { startCamera(null); });
  btnStop.addEventListener('click', function () { stopCamera(false); });
  btnSwitch.addEventListener('click', switchCamera);

  if (manualForm) {
    manualForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var value = manualInput.value.trim();
      if (processing) return;
      if (value === '') {
        manualInput.focus();
        return;
      }
      submitScan(value, 'manual').then(function (ok) {
        if (ok) manualInput.value = '';
        manualInput.focus();
      });
    });
  }

  // Release the camera when the page is hidden or left; come back when the page is visible again.
  document.addEventListener('visibilitychange', function () {
    if (document.hidden && stream) {
      stopCamera(true);
    } else if (!document.hidden && wantCamera && !stream) {
      startCamera(deviceIds[deviceIndex] || null);
    }
  });
  window.addEventListener('pagehide', function () { stopCamera(true); });

  if (!enabled) {
    btnStart.disabled = true;
    if (manualBtn) manualBtn.disabled = true;
  }
  if (!window.jsQR) {
    setStatus('The QR reader file (assets/vendor/jsQR.js) did not load. Reload the page, or use manual entry.', 'bad');
    revealManual();
  }
  updateButtons();
  showIdle();
})();
