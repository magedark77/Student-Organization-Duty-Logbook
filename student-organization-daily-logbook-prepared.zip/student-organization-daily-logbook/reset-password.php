<?php
require __DIR__ . '/app/bootstrap.php';

// Public page: the secret token in the link is the only credential, and it works once.
$token   = is_post() ? post_str('token', false) : get_str('token');
$account = password_reset_lookup($token);
$error   = '';

if (is_post()) {
    if (!csrf_is_valid()) {
        $error = 'Your session expired. Please reload the page and try again.';
    } else {
        try {
            password_reset_apply($token, post_str('new_password', false), post_str('confirm_password', false));
            flash('success', 'Your password has been set. You can now sign in.');
            redirect(url('index.php'));
        } catch (ValidationException $e) {
            $error = $e->getMessage();
            $account = password_reset_lookup($token); // the link may have just been used
        }
    }
}

render_header('Reset password', '', ['bare' => true, 'bodyClass' => 'login']);
?>
<div class="login-card">
    <div class="login-mark"><?= brand_logo(64) ?></div>
    <h1>Set a new password</h1>
    <?php if ($error !== ''): ?><?php alert('danger', $error); ?><?php endif; ?>
    <?php if ($account === null): ?>
        <?php if ($error === ''): ?><?php alert('danger', 'This reset link is invalid, expired or has already been used. Ask an administrator for a new one.'); ?><?php endif; ?>
        <a class="btn secondary full" href="<?= e(url('index.php')) ?>">Back to sign in</a>
    <?php else: ?>
        <p class="text-muted">Choose a new password for <strong><?= e($account['username']) ?></strong>.</p>
        <form method="post" class="form-stack" action="<?= e(url('reset-password.php')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= e($token) ?>">
            <?= field_password('New password', 'new_password', ['required' => true, 'minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password', 'data-toggle' => true], 'At least ' . MIN_PASSWORD_LENGTH . ' characters.') ?>
            <?= field_password('Confirm new password', 'confirm_password', ['required' => true, 'minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password']) ?>
            <button class="btn primary full" type="submit">Save password</button>
        </form>
    <?php endif; ?>
    <div class="login-footer"><p>This link can be used only once.</p></div>
</div>
<?php render_footer(bare: true);
