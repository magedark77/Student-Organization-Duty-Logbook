<?php
require __DIR__ . '/../app/bootstrap.php';
require_student();
qr_ensure_ready();

$student = user()['student_id'] !== null ? student_find((int) user()['student_id']) : null;
if ($student === null) {
    render_error_page(404, 'Student record not found', 'Your account is not linked to a student record. Please contact the administrator.');
}

$active = $student['status'] === 'Active';
$token  = $active ? qr_code_ensure((int) $student['id']) : '';
$row    = $token !== '' ? db_one('SELECT is_active FROM qr_codes WHERE student_id = ?', [(int) $student['id']]) : null;
$off    = $row !== null && (int) $row['is_active'] !== 1;
$today  = attendance_find_for((int) $student['id'], date('Y-m-d'));

render_header('My QR Code', 'myqr', ['scripts' => ['vendor/qrcode.js', 'js/qr-admin.js'], 'styles' => ['css/qr.css']]);
page_head('My QR Code', 'Show this code to the person at the scanner to record your Time In and Time Out.', [], [['My QR Code', null]]);
?>
<section class="card qr-mine">
    <?php if (!$active): ?>
        <?php alert('warning', 'Your student record is not Active, so QR attendance is unavailable. Please contact the administrator.'); ?>
    <?php elseif ($off): ?>
        <?php alert('danger', 'Your QR code is disabled. Please contact the administrator for a new one.'); ?>
    <?php else: ?>
        <div class="qr-art" data-qr-text="<?= e(qr_payload($token)) ?>" role="img" aria-label="Your attendance QR code"></div>
        <h2><?= e($student['first_name'] . ' ' . $student['last_name']) ?></h2>
        <p class="text-muted"><?= e(student_subtitle($student)) ?></p>
        <button type="button" class="btn secondary" data-qr-download data-text="<?= e(qr_payload($token)) ?>"
                data-name="<?= e($student['first_name'] . ' ' . $student['last_name']) ?>" data-number="<?= e($student['student_number']) ?>"
                data-file="qr-<?= e(preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $student['student_number'])) ?>"><?= icon('download') ?> Save as image</button>
        <p class="hint">Turn your screen brightness up when scanning. This code is personal: do not share it. It contains no personal details; if it is lost or copied, ask the administrator to regenerate it.</p>
        <?php if ($today !== null): ?>
            <p class="text-muted"><strong>Today:</strong> Morning <?= e(format_time_range($today['morning_time_in'], $today['morning_time_out'])) ?> · Afternoon <?= e(format_time_range($today['afternoon_time_in'], $today['afternoon_time_out'])) ?></p>
        <?php endif; ?>
    <?php endif; ?>
</section>
<?php render_footer();
