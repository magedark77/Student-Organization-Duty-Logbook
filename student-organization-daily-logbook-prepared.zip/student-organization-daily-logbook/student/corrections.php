<?php
require __DIR__ . '/../app/bootstrap.php';
require_student();

$studentId = (int) (user()['student_id'] ?? 0);
$student   = $studentId > 0 ? student_find($studentId) : null;
if ($student === null) {
    render_error_page(404, 'Student record not found', 'Your account is not linked to a student record. Please contact the administrator.');
}
$pageUrl = url('student/corrections.php');

if (is_post()) {
    $result = handle_post([
        'request' => static function () use ($studentId): void {
            correction_create($studentId, [
                'attendance_date' => post_str('attendance_date'),
                'morning_in'      => post_str('morning_in'),
                'morning_out'     => post_str('morning_out'),
                'afternoon_in'    => post_str('afternoon_in'),
                'afternoon_out'   => post_str('afternoon_out'),
                'reason'          => post_str('reason'),
            ]);
            flash('success', 'Your request was sent. An administrator will review it and you will get a notification with the decision.');
        },
        'cancel' => static function () use ($studentId): void {
            correction_cancel((int) post_str('id'), $studentId); // ownership is checked inside
            flash('success', 'Request cancelled.');
        },
    ], 'correction');
    if ($result['outcome'] === ACTION_INVALID && $result['action'] === 'request') {
        remember_input($_POST);
    }
    redirect($pageUrl);
}

$date = get_str('date');
$date = is_valid_date($date) ? $date : date('Y-m-d');
$existing = attendance_find_for($studentId, (string) old('attendance_date', $date));
$timeValue = static fn(string $field, string $column): string =>
    (string) old($field, ($existing[$column] ?? null) !== null ? substr((string) $existing[$column], 0, 5) : '');
$requests = corrections_for_student($studentId);

render_header('My Corrections', 'corrections');
page_head('Attendance corrections', 'Ask an administrator to fix or add a day’s times. Nothing changes until the request is approved.', [], [['My Dashboard', url('student/dashboard.php')], ['Corrections', null]]);
?>
<section class="card card-form">
    <h2>Request a correction</h2>
    <p class="hint required-note"><span class="req" aria-hidden="true">*</span> marks required fields. Enter the times that <strong>should</strong> be on the record. You can ask for dates in the last <?= CORRECTION_WINDOW_DAYS ?> days.</p>
    <?php if ($existing): ?>
        <p class="hint">Current record for <?= e(format_date($existing['attendance_date'])) ?>: Morning <?= e(format_time_range($existing['morning_time_in'], $existing['morning_time_out'])) ?>, Afternoon <?= e(format_time_range($existing['afternoon_time_in'], $existing['afternoon_time_out'])) ?>.</p>
    <?php endif; ?>
    <form method="post" action="<?= e($pageUrl) ?>" class="form-stack" data-confirm="Send this correction request to the administrators?">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="request">
        <?= field_input('Date', 'attendance_date', (string) old('attendance_date', $date), ['type' => 'date', 'required' => true, 'max' => date('Y-m-d'), 'min' => date('Y-m-d', strtotime('-' . CORRECTION_WINDOW_DAYS . ' days'))]) ?>
        <div class="form-grid">
            <fieldset class="form-section"><legend>Morning</legend>
                <div class="form-grid">
                    <?= field_input('Time in', 'morning_in', $timeValue('morning_in', 'morning_time_in'), ['type' => 'time']) ?>
                    <?= field_input('Time out', 'morning_out', $timeValue('morning_out', 'morning_time_out'), ['type' => 'time']) ?>
                </div>
            </fieldset>
            <fieldset class="form-section"><legend>Afternoon</legend>
                <div class="form-grid">
                    <?= field_input('Time in', 'afternoon_in', $timeValue('afternoon_in', 'afternoon_time_in'), ['type' => 'time']) ?>
                    <?= field_input('Time out', 'afternoon_out', $timeValue('afternoon_out', 'afternoon_time_out'), ['type' => 'time']) ?>
                </div>
            </fieldset>
        </div>
        <?= field_textarea('What needs correcting, and why?', 'reason', (string) old('reason'), ['required' => true, 'maxlength' => 500, 'rows' => 3, 'placeholder' => 'e.g. I forgot to time out; I left at 4:30 PM with Ms. Reyes present.'], '5 to 500 characters.') ?>
        <div class="form-actions"><button class="btn primary" type="submit">Send request</button></div>
    </form>
</section>

<section class="card">
    <h2>My requests</h2>
    <?php if (!$requests): ?>
        <?= empty_state('No requests yet', 'Requests you send will be listed here with the administrator’s decision.', '', 'check') ?>
    <?php else: ?>
        <?php table_start('My correction requests', true); ?>
            <thead><tr><th scope="col">Date</th><th scope="col">Requested times</th><th scope="col">Status</th><th scope="col">Decision</th><th scope="col">Actions</th></tr></thead>
            <tbody>
                <?php foreach ($requests as $r): ?>
                    <tr>
                        <td data-label="Date"><?= e(format_date((string) $r['attendance_date'])) ?><span class="cell-sub">Sent <?= e(format_datetime((string) $r['created_at'])) ?></span></td>
                        <td data-label="Requested times">AM <?= e(format_time_range($r['morning_time_in'], $r['morning_time_out'])) ?><span class="cell-sub">PM <?= e(format_time_range($r['afternoon_time_in'], $r['afternoon_time_out'])) ?></span></td>
                        <td data-label="Status"><?= correction_status_badge($r['status']) ?></td>
                        <td data-label="Decision" class="cell-wrap"><?= $r['reviewed_at'] !== null ? e(format_datetime((string) $r['reviewed_at'])) . ($r['review_note'] ? '<span class="cell-sub">' . e($r['review_note']) . '</span>' : '') : '<span class="text-faint">—</span>' ?></td>
                        <td data-label="Actions"><?= $r['status'] === 'pending' ? action_form($pageUrl, 'cancel', (int) $r['id'], 'Cancel request', 'secondary', 'Cancel this request?') : '' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php table_end(); ?>
    <?php endif; ?>
</section>
<?php render_footer();
