<?php
require __DIR__ . '/../app/bootstrap.php';
require_student();

$student = user()['student_id'] !== null ? student_find((int) user()['student_id']) : null;
if ($student === null) {
    render_error_page(404, 'Student record not found', 'Your account is not linked to a student record. Please contact the administrator.');
}

$year       = date('Y');
$rows       = attendance_for_student((int) $student['id']);   // newest first
$yearRows   = attendance_rows_in_year($rows, $year);
$summary    = attendance_summarize($yearRows);                  // days present and hours for THIS year
$progress   = attendance_year_progress($rows);                  // the required hours are per calendar year
$months     = attendance_month_minutes($yearRows);
$incomplete = array_values(array_filter($rows, static fn(array $r): bool => attendance_incomplete_reasons($r) !== []));
$notices    = announcements_unread_summary((int) user()['id']);
$unreadNotifs = notifications_unread_count((int) user()['id']);
$showAll    = get_str('all') !== '';
$recent     = $showAll ? $rows : array_slice($rows, 0, 10);

$requiredMin = required_minutes();
$weeksLeft   = max(1, (int) ceil(days_left_in_year() / 7));
$perWeek     = $progress['remaining'] > 0 ? (int) ceil($progress['remaining'] / $weeksLeft) : 0;
$pendingFix  = student_pending_corrections_count((int) $student['id']);

render_header('My Logbook', 'dashboard');
page_head('My Logbook', student_subtitle($student));
hero('Welcome, ' . $student['first_name'] . '. ' . number_format($progress['percent'], 0) . '% of your ' . REQUIRED_HOURS . ' required hours are done for ' . $year . '.');
?>
<?php if ($notices['unread'] > 0 || $unreadNotifs > 0): ?>
    <section class="card inbox-banner" aria-label="Unread messages">
        <?php if ($notices['unread'] > 0): ?>
            <a class="inbox-link<?= $notices['urgent'] > 0 ? ' is-urgent' : '' ?>" href="<?= e(url('my-announcements.php')) ?>">
                <?= icon('send') ?><span><strong><?= e(plural($notices['unread'], 'unread announcement')) ?></strong><?= $notices['urgent'] > 0 ? ' · ' . $notices['urgent'] . ' urgent' : '' ?></span>
            </a>
        <?php endif; ?>
        <?php if ($unreadNotifs > 0): ?>
            <a class="inbox-link" href="<?= e(url('notifications.php')) ?>"><?= icon('bell') ?><span><strong><?= e(plural($unreadNotifs, 'unread notification')) ?></strong></span></a>
        <?php endif; ?>
    </section>
<?php endif; ?>

<?php if ($incomplete): ?>
    <?php alert('warning', plural(count($incomplete), 'attendance record') . ' ' . (count($incomplete) === 1 ? 'is' : 'are') . ' incomplete (a time-in or time-out is missing). If this is a mistake you can ask for a correction.'); ?>
<?php endif; ?>

<div class="stat-row stat-row-4">
    <?php
    stat_card('Days Present (' . $year . ')', (string) $summary['days'], count($rows) !== count($yearRows) ? attendance_days_present($rows) . ' all-time' : '', 'calendar');
    stat_card('Completed (' . $year . ')', format_duration($progress['minutes']), '', 'check', 'done');
    stat_card('Required per year', REQUIRED_HOURS . 'h', '', 'chart');
    stat_card('Remaining', format_duration($progress['remaining']), '', 'clock', $progress['remaining'] > 0 ? 'left' : 'done');
    ?>
</div>

<section class="card">
    <?php $urgency = outstanding_urgency($year); ?>
    <?= section_head('Duty Progress', '', $progress['remaining'] <= 0 ? status_indicator('complete', 'Completed') : status_indicator($urgency, $urgency === 'urgent' ? 'Urgent: year ending' : 'In progress')) ?>
    <p class="progress-summary"><?= number_format($progress['percent'], 1) ?>% of <?= REQUIRED_HOURS ?> required hours completed for <?= e($year) ?></p>
    <?= progress_bar($progress['percent'], 'Duty hours completed') ?>
    <div class="hours-split" aria-label="Hours summary">
        <div><span class="small">Completed</span><strong><?= e(format_duration($progress['minutes'])) ?></strong></div>
        <div><span class="small">Required</span><strong><?= REQUIRED_HOURS ?>h</strong></div>
        <div><span class="small">Remaining</span><strong><?= e(format_duration($progress['remaining'])) ?></strong></div>
    </div>
    <p class="hint progress-note">
        <?php if ($progress['remaining'] <= 0): ?>
            Great work! You have completed your required hours for <?= e($year) ?>.
        <?php elseif ($rows === []): ?>
            You have not logged any duty hours yet. Your hours appear here after an officer records your attendance.
        <?php else: ?>
            <strong>Reminder:</strong> you need <?= e(format_duration($progress['remaining'])) ?> more before the year ends in <?= e(plural(days_left_in_year(), 'day')) ?>
            — about <?= e(format_duration($perWeek)) ?> a week. Your duty day is <?= e($student['year_level']) ?>.
        <?php endif; ?>
    </p>
</section>

<section class="card">
    <h2>Hours per month, <?= e($year) ?></h2>
    <?= bar_chart('Duty hours logged per month in ' . $year, month_labels(), array_map(static fn(int $m): float => round($m / 60, 1), array_values($months))) ?>
</section>

<section class="card">
    <?= section_head('My Attendance', '', section_link($pendingFix > 0 ? plural($pendingFix, 'pending correction') : 'Request a correction', url('student/corrections.php'))) ?>
    <?php view('partials/attendance-table', [
        'rows'           => $recent,
        'showDate'       => true,
        'label'          => 'My attendance',
        'correctionLink' => true,
        'emptyHtml'      => empty_state('No attendance recorded yet', 'When an officer logs you in on your duty day (' . $student['year_level'] . '), your hours will show up here. If you were on duty and see nothing, you can ask for a correction.', '<a class="btn secondary" href="' . e(url('student/corrections.php')) . '">Request a correction</a>', 'clipboard'),
    ]); ?>
    <?php if (!$showAll && count($rows) > 10): ?>
        <p class="more-row"><a class="btn secondary" href="<?= e(url('student/dashboard.php', ['all' => 1])) ?>">Show all <?= count($rows) ?> records</a></p>
    <?php elseif ($showAll): ?>
        <p class="more-row"><a class="btn secondary" href="<?= e(url('student/dashboard.php')) ?>">Show only the latest 10</a></p>
    <?php endif; ?>
</section>
<?php render_footer();
