<?php
declare(strict_types=1);

/**
 * Copy this file to config.local.php and enter your own database settings.
 * Never commit config.local.php or share its credentials.
 */
return [
    'db_host' => 'localhost',
    'db_name' => 'your_database_name',
    'db_user' => 'your_database_username',
    'db_pass' => 'your_database_password',

    'duty_timezone' => 'Asia/Manila',
    'duty_start' => '08:00',
    'duty_end' => '17:00',
    'debug' => false,

    'backup_dir' => '',
    'backup_keep' => 10,
    'backup_auto_days' => 0,
    'backup_cron_token' => '',
];
