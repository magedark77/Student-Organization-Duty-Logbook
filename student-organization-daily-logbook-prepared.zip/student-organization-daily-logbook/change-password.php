<?php
require __DIR__ . '/app/bootstrap.php';
require_login();

$user  = user();
$error = '';

if (is_post()) {
    check_csrf();
    try {
        change_password(
            (int) $user['id'],
            post_str('current_password', false),
            post_str('new_password', false),
            post_str('confirm_password', false)
        );
        audit('UPDATE', 'users', (int) $user['id'], 'Changed account password');
        notify_password_changed((int) $user['id']);

        session_regenerate_id(true);
        unset($_SESSION['user'], $_SESSION['default_password']);
        flash('success', 'Password changed successfully. Please sign in again with your new password.');
        redirect(url('index.php'));
    } catch (ValidationException $e) {
        $error = $e->getMessage();
    }
}

render_header('Change Password', 'password');
page_head('Change Password', 'Signed in as ' . $user['username'], [
    ['label' => 'Back', 'href' => home_url()],
]);
if ($error !== '') {
    alert('danger', $error);
}
?>
<div class="card card-narrow">
    <form method="post" class="form-stack">
        <?= csrf_field() ?>
        <label>Current password
            <input type="password" name="current_password" required autocomplete="current-password">
        </label>
        <label>New password
            <input type="password" name="new_password" required minlength="<?= MIN_PASSWORD_LENGTH ?>" autocomplete="new-password">
            <span class="hint">Use at least <?= MIN_PASSWORD_LENGTH ?> characters.</span>
        </label>
        <label>Confirm new password
            <input type="password" name="confirm_password" required minlength="<?= MIN_PASSWORD_LENGTH ?>" autocomplete="new-password">
        </label>
        <div class="form-actions">
            <button class="btn primary" type="submit">Change password</button>
        </div>
    </form>
</div>
<?php render_footer();
