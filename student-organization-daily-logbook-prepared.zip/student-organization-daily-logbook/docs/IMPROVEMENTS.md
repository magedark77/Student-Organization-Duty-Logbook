# A–H improvements: what changed, what was tested, what is left

This is an honest account. "Tested" means a test was actually executed and its result is listed in section 6.
Anything not listed there was **not** tested.

## 1. Files

**New (22):**
`admin/announcement-history.php`, `admin/announcement-view.php`, `admin/attendance-check.php`, `admin/corrections.php`,
`admin/student-import.php`, `my-announcements.php`, `reset-password.php`, `student/corrections.php`,
`reports/analytics.php`, `reports/export.php`, `reports/incomplete.php`, `reports/outstanding.php`,
`app/core/pdf.php`, `app/core/ui.php`, `app/domain/accounts.php`, `app/domain/announcements.php`,
`app/domain/corrections.php`, `app/domain/imports.php`, `database/migrate_improvements.sql`,
`config/config.sample.php`, `tests/integration.php`, `docs/IMPROVEMENTS.md`.

**Modified (38):**
`admin/announcements.php`, `admin/attendance.php`, `admin/dashboard.php`, `admin/officers.php`, `admin/record-attendance.php`,
`admin/student-view.php`, `admin/students.php`, `index.php`, `reports/export-csv.php`, `reports/monthly.php`, `student/dashboard.php`,
`app/bootstrap.php`, `app/core/{auth,components,database,errors,forms,icons,layout,request,schema,session}.php`,
`app/domain/{attendance,audit,notifications,officers,reports,students}.php`,
`app/views/partials/{attendance-form,attendance-table,header,page-head,student-form}.php`,
`assets/css/style.css`, `assets/js/app.js`, `tests/run.php`, `README.md`, `CHANGELOG.md`.

Not touched: `notifications.php`, `notifications-count.php`, `change-password.php`, `logout.php`, `admin/audit-logs.php`,
`database/logbook.sql`, `.htaccess` files, the other migration scripts.

## 2. Existing features that were improved
- Admin dashboard: same statistics, now computed from the database with a needs-attention panel, quick actions, empty states.
  "Attendance rate" now counts only *active* students who timed in (it could exceed the active total before).
- Announcements: same four audiences; now stored as real records with priority, expiry, pinning, edit/cancel, history.
- Student list: same create/edit/view/search/filter/sort/delete; added paging, inline errors, specific duplicate messages,
  a stronger delete warning that states how many attendance records go with the student, and "Deactivate" as the safer option.
- Attendance entry: same sessions and rules; added duplicate warning, summary before saving, reasons and history.
  **Security fix:** an officer could previously overwrite an existing record by re-submitting the "record" form
  (the save was an upsert). Officers can now only add new records.
- Student dashboard: same figures, now for the correct period: "days present" and hours are for the current calendar year, and a
  record with no times is no longer counted as a day present. All-time days are shown as a sub-label.
- Reports: same monthly report/filters/sort/CSV (the old CSV URL still works and gives identical columns); added PDF and the new reports.
- Officer accounts: same create/edit/delete; added status column, deactivate/reactivate, reset link, role-change confirmation.
- Interface: sidebar/nav, forms and tables made consistent and responsive.

## 3. Genuinely new features
Announcement read receipts · announcement history/priority/pinning/expiry/cancel · recipient announcement inbox ·
incomplete-attendance detection and report · "hours not completed" report · monthly/yearly/course/duty-day charts ·
PDF export (no external library) · attendance change history (who/when/why) · correction-request workflow ·
student CSV import with preview · account deactivation (students and officers) · one-time password-reset links ·
breadcrumbs and mobile menu · live duplicate-attendance warning.

## 4. Database changes (additive only)
`database/migrate_improvements.sql` creates `announcements`, `announcement_recipients` (primary key `(announcement_id, user_id)`),
`attendance_changes`, `attendance_corrections`, `password_resets`, and adds `users.is_active DEFAULT 1`.
The app applies it automatically once per session; no existing data is modified or deleted. See README "Upgrading".

## 5. Design decisions worth knowing
- **Read receipts** exist only in `announcement_recipients.read_at`, set when the *recipient* opens the announcement. The user id
  comes from the session, never from the request. Marking the bell notification read does not create a receipt (tested).
  Announcements sent by the old version stay plain notifications and have no receipts, because the old data cannot say who read them.
- **Who may do what:** administrators manage every announcement; Director/Assistant Director only their own (and cannot pin).
  Only administrators edit/delete attendance, review corrections, manage students/officers/reports.
- **Password reset** needs no e-mail server (free hosts rarely have one): an administrator creates a link, shared privately.
  Only a SHA-256 hash is stored; a link works once, expires (1 hour; 7 days for imported students) and is replaced by a newer one.
  Administrator accounts cannot be given a link. Passwords are never read from CSV files: imported logins start unusable until the link is used.
- **Deactivation** blocks sign-in and signs out open sessions at the next request; all attendance and history are kept.
- **Incomplete record** = a time-in without time-out (or the reverse) in either session, or a record with no times at all.
  The entry form cannot create these (existing rule); they come from older/imported data.

## 6. Tests actually executed (PHP 8.3, MariaDB 10.11, headless Chromium)
| Suite | Result |
|---|---|
| `php tests/run.php` (unit; 104 original + 29 new) | 133 passed, 0 failed; also verified to run with the database unreachable |
| `php tests/integration.php` (real HTTP, real sessions/CSRF, DB checked after each step) | 395 passed, 0 failed |
| Browser interaction (Chromium, 390×844 touch): menu toggle, confirm dialogs, stacked tables, live duplicate warning, save summary, urgent confirmation, Esc closes dialog, field labels | 19 passed, 0 failed |
| Browser layout sweep: 3 roles × 3 widths (390/768/1366) × every main page: loads, no horizontal page overflow | 147 passed; the other 12 are not defects: Google Fonts cannot load in the offline sandbox (9) and a test-data mismatch where a student correctly got 404 for an announcement not addressed to them (3) |
| Upgrade test: database created and filled by the **original** code, then opened with the new code | row counts and the users table hash identical before/after; legacy logins, attendance, reports and legacy announcements still work |
| PDF output | opened with `pdftotext`/`pdfinfo`/`pdftoppm`: valid, multi-page, accents and brackets correct, page numbers right |

What the integration suite covers: login and the full role × URL access matrix (admin / director / manager / student / anonymous, 22 pages);
refused POSTs by unauthorized roles and missing CSRF tokens; student create/edit/duplicates/search/filter/sort/paging; attendance
create/duplicate/officer-overwrite attempt/reason/history/validation/delete; incomplete detection on dashboard, list, report and student view;
correction requests end to end; announcements (all audiences, priority, pin, expiry/archive, edit, cancel, permissions, history search/filter/sort,
read receipts, notification-vs-receipt distinction, non-recipient access, HTML escaping); deactivation/reactivation; CSV import (preview saves nothing,
duplicates/errors, commit, links, single download); password-reset (hash, single use, expiry, replacement, CSRF, session invalidation);
dashboard figures compared with independent SQL; progress/remaining hours; screen vs CSV vs PDF for the same filters; empty states;
crawling every link as three roles for broken links; audit-log entries; SQL-injection-style input.

## 7. Not done / limitations
- **Not tested:** real phones or tablets, Safari, Firefox, Edge, screen readers, MySQL 8 (only MariaDB), PHP versions other than 8.3,
  the InfinityFree hosting environment, or the Director/Assistant Director/Secretary *duty-hours* login restriction
  (tests ran with a 24-hour duty window so officers could sign in). Responsive behaviour was verified in emulated Chromium only.
- Colour contrast was not measured; the existing colour tokens were reused. Status indicators use icon + text, not colour alone.
- "Loading indicators" are the existing disabled/"Please wait…" submit-button state; there is no separate spinner.
- Reset links must be delivered by the administrator (no e-mail). Anyone holding a live link can set that account's password, so send it privately.
- Attendance deletion reason is optional (defaults to "Deleted by an administrator"); edits and corrections require a reason.
- An announcement's audience cannot change after publishing, and edits do not re-notify recipients (the bell text is updated).
- CSV import: max 500 rows / 1 MB, students only, no password column; a login is created only if "create logins" is ticked.
- PDF uses built-in Latin fonts: characters outside Western European text are shown as "?"; long cells are shortened with "...".
- Dates in `<input type="date">` follow the browser's locale; text dates use the app's existing format helpers.
- Student lists are paged in PHP after filtering (fine for hundreds of students, not tuned for tens of thousands).
- The original ZIP contained a `config/config.local.php` with real database credentials. **That file is not included here; please
  change that database password**, because it has now been shared outside your server.
