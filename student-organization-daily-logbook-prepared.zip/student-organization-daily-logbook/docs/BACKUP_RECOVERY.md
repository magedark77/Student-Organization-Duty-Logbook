# Backup and recovery guide

Open **Administrator → Backup & Recovery** (`admin/backups.php`). Only administrators can reach it; every action is POST + CSRF-protected,
and creating, downloading, deleting and restoring are written to the Audit Logs.

## How it works
- A backup is one plain `.sql` file made in PHP (no `mysqldump`, no `exec()`), so it works on shared hosting. One statement per line;
  it can also be imported with phpMyAdmin.
- After writing, the file is re-checked (header, every table present, forbidden statements, end marker) and its SHA-256 is stored.
  A file without the end marker is treated as interrupted and is deleted.
- File names are random (`logbook_YYYYMMDD_HHMMSS_xxxxxxxx.sql`). Downloads are chosen by database id, never by a name typed in the URL.
- The history table `db_backups` is not part of the dump, so history and restore events survive a restore.

## Where files are stored
1. `backup_dir` from `config/config.local.php`, if set (best: a folder outside the web root).
2. Otherwise `../logbook_backups` next to the web folder, if PHP can write there.
3. Otherwise `storage/backups/` inside the site, protected by `.htaccess` (deny all) and only served through the admin page.
   The page shows a notice when this fallback is used. **On InfinityFree, option 3 is the realistic one** (the folder above `htdocs` is not writable).
   Test it: browse to `https://your-site/storage/backups/index.html` - you must get "403 Forbidden", not a blank page. If it loads, your host ignores
   `.htaccess`: do not store real backups on the server; download and delete them immediately.

## Routine
- Create a backup before each term, before bulk imports, and before upgrades; **download it and keep a copy off the server** (the host can lose files).
- Retention: the newest `backup_keep` (default 10) manual/scheduled backups are kept. Safety copies made before a restore are never auto-deleted.

## Scheduled backups (hosting limits)
InfinityFree gives no cron jobs and kills long scripts. Two compatible options, both off by default:
- **On dashboard visit:** set `'backup_auto_days' => 7`. When an administrator opens the dashboard and the newest backup is older than that, one is made.
  It only runs when someone visits, so it is not a guarantee.
- **External scheduler:** set `'backup_cron_token'` to a random string of 24+ characters, then have a free service (e.g. cron-job.org) call
  `https://your-site/backup-cron.php?token=THE_TOKEN` daily. Without the token the file answers 404. The token appears in access logs: use a long random value and rotate it if exposed.

## Restoring (destructive)
1. Click **Verify** on the backup first (checks checksum and structure; changes nothing).
2. **Restore…** → enter your password, type `RESTORE`, tick the box.
3. The app re-verifies, **creates a "Before restore" safety backup (aborts if that fails)**, then replaces every table in the file.
4. Everything recorded after the backup was made is lost - including audit-log entries - except what is kept in the backup history. You may be signed out; sign in again.
5. MySQL cannot roll back table creation. If a restore stops part-way, the page names the safety backup: restore that one (or import it in phpMyAdmin).

## Test a restore on a separate database (never on production)
```
# create an empty database "logbook_test" first (phpMyAdmin or CREATE DATABASE)
php tools/restore-test.php /path/to/logbook_20261028_101500_a1b2c3d4.sql logbook_test
```
It refuses to run against the production database name, restores, and compares restored row counts with the backup's footer (PASS/MISMATCH).
Without command-line access, create a test database in phpMyAdmin and use **Import** with the `.sql` file instead.

## Hosting limits to expect
- PHP time/memory limits (often 30-60 s on free hosting) can interrupt backups of very large databases. The failure is logged and shown as "Failed";
  no partial file is kept. For a large database use phpMyAdmin **Export**.
- Restores of large files can hit the same limit; use phpMyAdmin Import (chunked) in that case.
- Backups contain private student data (password hashes included). Treat downloaded files as confidential.
