# QR Code Attendance

Students show a personal QR code to a camera; the server records Time In / Time Out in the existing `attendance` table.
Everything else (reports, hours, corrections, audit log, notifications) keeps working unchanged.

## How it works
- Each student has one random token (128 bits). The QR image contains only `SOLQR1:<token>`: no name, number or credentials.
- The scanner page (`admin/qr-scanner.php`) reads the code in the browser and sends the text to `admin/qr-scan.php`.
  The **server** looks up the student, decides Time In or Time Out, and stamps its own clock (`Asia/Manila`, see `APP_TIMEZONE`).
  The browser never says who the student is, what the time is, or which action to record.
- Sequence per day: Morning In → Morning Out → Afternoon In → Afternoon Out. A day's **first** scan before the cut-off
  (default 12:00) is a morning Time In, later an afternoon Time In. After the 4th scan the day is "complete".
- Late / early use **QR Settings** (defaults: morning 08:00–12:00, afternoon 13:00–17:00, 15 min late grace).
  The monitor applies the same rules to manually entered records.

## Install on InfinityFree
1. **Back up** your database (phpMyAdmin → Export) and files.
2. Upload this project over your existing one in `htdocs`. **Keep your own `config/config.local.php`** (it is not in the zip).
   Keep `assets/vendor/` (QR libraries, bundled: no CDN or internet dependency) and `assets/photos/`.
3. Database: nothing to do — the three new tables (`qr_codes`, `qr_scans`, `qr_settings`) are created automatically the next
   time an administrator opens a QR page. Or import `database/qr_attendance.sql` in phpMyAdmin (safe to re-run; it deletes nothing).
4. **HTTPS**: in the InfinityFree panel, install the free SSL certificate for your domain, then open the site with `https://`.
   Browsers refuse camera access on plain `http://`. Optional redirect — add to the top of `.htaccess`:
   ```
   RewriteEngine On
   RewriteCond %{HTTPS} !=on
   RewriteCond %{HTTP:X-Forwarded-Proto} !https
   RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```
   (If the site then loops or shows a 500 error, remove those lines; the scanner page works without them as long as you open it via `https://`.)
5. Sign in as administrator → **Student QR Codes**. Codes are created for every student automatically.

## First-run check (2 minutes)
1. Open `https://your-site/admin/qr-codes.php`: every student shows a QR code.
2. Open *Scan QR Attendance* on a phone, press Start Camera, scan a code printed or shown on another screen: green "Time In Recorded Successfully".
3. Scan it again: "Already scanned … seconds ago" (nothing new recorded). After a minute it records Time Out.
4. Open *QR Monitor*: the student appears; *Export CSV* downloads.

## Daily use
- **Generate / print / download**: Admin → *Student QR Codes*. Search or filter, tick students → *Print selected*, or *Print all (filtered)*;
  *PNG* saves one student's code with name and number. *Regenerate* makes a new code (old one stops working at once);
  *Disable* blocks a lost card without changing it.
- **Students' phones**: each student can open *My QR Code* after signing in and show it on screen.
- **Scan**: *Scan QR Attendance* (admins and officers; officers only during duty hours). Press **Start Camera**, allow access,
  hold the code in the frame. A green card shows name, ID, photo (if any), "Time In/Out Recorded Successfully", time and late/early notes.
  *Switch Camera* appears when the device has more than one. If the camera does not work, open
  "Enter the student number" (can be disabled in settings; logged as *manual*).
- **Monitor / reports**: Admin → *QR Monitor*: today's Time In/Out, late, still timed in, early departures, absent
  (expected = Active students whose duty day is that weekday). Filter by date, name/number, duty day, course, status.
  Auto-refreshes every 15 s. *Export CSV* opens in Excel. Existing monthly reports and CSV/PDF exports include QR records automatically.
- **Settings**: *QR Settings* — on/off switch, manual-entry switch, schedule, grace minutes, minimum seconds between scans (≥ 60).
- **Photos (optional)**: put `2024-001.jpg` (also .jpeg/.png/.webp; named after the student number) into `assets/photos/`.

## Security notes
- Every scan is validated on the server: signed-in admin/officer, CSRF token, token lookup (prepared statements), Active student,
  enabled code, per-student lock + transaction, order rules, minimum gap.
- Duplicate protection: ≥ 60 s between scans of one student, a one-time request id (a network retry never records twice),
  and a `UNIQUE (student_id, attendance_date)` key on `attendance`.
- Repeated unknown codes (25 in 5 min per user) pause the scanner. Every scan, accepted or refused, is in `qr_scans`
  (IP, user, method, result). Regenerations/settings/exports are in the audit log (tokens are never logged).
- Honest limitation: a static QR code can be photographed and shown by someone else. The scanner must be operated by staff
  who see the student; use *Regenerate* / *Disable* for lost or shared codes.
- The site-wide `Permissions-Policy` still blocks the camera everywhere except the scanner page.

## Troubleshooting
| Problem | Fix |
|---|---|
| "Camera needs HTTPS" | open the site with `https://` (install SSL in InfinityFree). |
| Permission denied | allow Camera for the site in the browser's address-bar/site settings, press Start Camera again. |
| QR not recognised | brightness up, hold 15–30 cm away; unreadable? use manual entry or print a fresh code. |
| "Already scanned N seconds ago" | normal; the minimum gap protects against accidental Time Outs. |
| Morning Time Out recorded after 1 PM | the student forgot to scan out at noon; correct it in *Attendance → Open*. |
| Wrong time shown | check `APP_TIMEZONE` in `app/core/config.php` (default Asia/Manila). |

## Tests
`php tests/qr.php` (rules, no database) and `php tests/run.php` (existing suite). See `CHANGELOG.md` for what was verified.
