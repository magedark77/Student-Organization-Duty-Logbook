# Refactoring report: code quality, UI/UX, performance, structure

Goal: cleaner and faster, **same behaviour**. Every claim below was measured or tested; section 6 lists what was not.

## 1. How "same behaviour" was checked
- **Golden outputs.** Before changing logic, every data function behind the reports, dashboard, student list and
  announcement composer was run from the untouched code and its results saved (352 result sets: many filter, sort,
  year and page combinations). After the refactor the same calls give **352 of 352 identical results** on two databases
  (a small one and a 1,000-student / 344,000-attendance-row one). A control comparing two *different* databases flags the differences,
  so the comparison can fail.
- **Existing suites, unchanged in intent:** 395 end-to-end checks over real HTTP (every role, CSRF, exports, imports, announcements,
  corrections, deactivation, reset links…) still pass. Unit tests grew from 133 to 163.
- **Browser:** 26 interaction checks, 5 keyboard checks, and a layout sweep of every main page for 3 roles at 390 / 768 / 1366 px
  (no horizontal page overflow). Two browser tests were updated because buttons moved behind "More"; no assertion about behaviour was weakened.

## 2. Performance (measured on 1,000 students, 344,000 attendance rows, same machine, real HTTP)
| Page | Original | Refactored | |
|---|---|---|---|
| Admin dashboard | 1,437 ms | 317 ms | 4.5× |
| Charts & summaries | 1,837 ms | 513 ms | 3.6× |
| Monthly report | 689 ms | 196 ms | 3.5× |
| Hours-not-completed report | 622 ms | 146 ms | 4.3× |
| Incomplete-attendance report | 245 ms | 205 ms | 1.2× (not changed; still one scan of the year) |
| Announcement composer | 14 ms | 5 ms | 2.9× |
| Student list, student dashboard | 5–9 ms | 5–7 ms | already fast |

Absolute times depend on the machine and were noisy; the ratios were stable across runs.

**What was wrong:** each report joined students to attendance first and grouped afterwards (and computed the minutes
expression twice per row); the dashboard ran the same yearly per-student aggregate three times; the charts page scanned the
year three times; the composer ran nine counting queries; the header counted unread notifications twice; the student list
loaded every student to show 25.

**What changed:**
- `students_with_totals()`: attendance is added up per student *first* (one pass over the date range), then joined to students.
  Monthly report, hours-not-completed, dashboard and charts all use it (previously five hand-written variants). Isolated in SQL
  this was 332 → 117 ms.
- Dashboard, charts and header reuse one result instead of recomputing (`students_requirement_counts($year, $list)`,
  `analytics_group(..., $totals)`).
- `announcement_audience_sizes()`: nine queries → one. `students_page()`: SQL `LIMIT`. `attendance_incomplete_counts()`: two → one.
  First-sign-in schema check: about 7 queries and a file read → 1 query.

**Considered and rejected:** a covering index on `attendance`. It helped (about 20% after the code fixes) but added ~35 MB
for a 22 MB table, which is a poor trade on small hosting. Not shipped.
**Already good, left alone:** gzip, year-long asset caching and versioned URLs; CSS has no dead rules (checked).

## 3. Structure
- `app/core/` is now infrastructure only; rendering helpers moved to **`app/ui/`** (`layout`, `forms`, `filters`, `components`,
  `charts`, `icons`, `page_actions`). The old `core/ui.php` was merged into `components.php` and `charts.php`.
- Domain files split by responsibility (moved verbatim by script, not retyped): `attendance` → `attendance`, `attendance_write`,
  `attendance_stats`; `reports` → `reports`, `report_totals`, `report_exports`.
- `bootstrap.php`: 26 `require` lines → three grouped lists.
- No public URL changed.

## 4. Code quality
- **`handle_post()`** replaces the same CSRF → read action → run → "Unknown action" → redirect skeleton in 8 pages. Pages keep their
  own handlers; shared ones (`student_lifecycle_handlers`, `reset_link_handler`) removed duplicated messages between pages.
- **`filter_bar()`** replaces 9 hand-written filter forms (which had drifted: "Apply"/"Filter", "Reset"/"Reset filters"/"Reset (today)");
  `student_filter_controls()` replaces the duty-day/course/status/search group repeated on four report pages.
- **`sort_rows()`** replaces two copies of the same `usort` block.
- Long functions split along their seams: `student_import_parse` (102 lines) → reader, row validator, two duplicate checkers;
  `report_export_build` → three builders behind a lookup; `attendance_save` → validation + rules + transactional write.
  The reader and validators are now unit-testable without a database.
- Small fix found by a new test: `analytics_group()`'s `average` is now always a float, as documented.
- One deliberate tightening: an unrecognised attendance action now shows "Unknown action." (it used to do nothing silently).

## 5. UI/UX (checked in a real browser)
- Row actions: **View / Edit** stay visible; **Deactivate / Delete** (and reset link) sit behind **More**, which opens in place
  (not a popover, which a scrolling table would clip), works with Tab / Enter / Esc, and closes when you click elsewhere.
- Filters fold behind a **Filters** button on phones (shows "n active", opens automatically when a filter is on); always visible on larger screens
  and without JavaScript. Apply and Reset stay together.
- Duty-day tabs use two columns on phones (block height 446 → 245 px). With the folded filters, the first student starts 477 px higher on a 390 px-wide screen (1,505 → 1,028 px from the top of the page).
- The admin dashboard shows "Needs attention" before the branding banner (previous update), and the sidebar scrolls on short screens.
- Stylesheet: new sections are in the table of contents and numbered; nothing was restyled.

## 6. Not done / limits
- Not tested on real devices, Safari, Firefox, MySQL 8 or your hosting. Responsive checks used emulated Chromium.
- The incomplete-attendance report is unchanged (about 200 ms at 344,000 rows); speeding it up would need an index.
- Large page scripts (`admin/dashboard.php`, `officers.php`) still mix a few queries with their markup; moving them to templates
  would be a larger change than "no behaviour change" allows.
- `app.js` was extended, not split; it is one file of labelled sections with no build step.
- Color contrast was still not measured.

## 7. Files (compared with the ZIP you uploaded)
**Added:** `app/ui/{layout,components,forms,icons}.php` (moved from `app/core/`), `app/ui/{filters,charts,page_actions}.php`,
`app/domain/{attendance_stats,attendance_write,report_totals,report_exports}.php`, `tests/{seed-large,benchmark}.php`, `docs/REFACTORING.md`.
**Removed:** `app/core/{layout,components,forms,icons,ui}.php` (moved or merged into `app/ui/`).
**Modified:** `README.md`, `CHANGELOG.md`, `app/bootstrap.php`, `app/core/{request,schema}.php`,
`app/domain/{announcements,attendance,imports,reports,students}.php`, `app/views/partials/header.php`, `assets/css/style.css`,
`assets/js/app.js`, `tests/run.php`, `admin/{announcement-history,announcement-view,announcements,attendance,audit-logs,corrections,dashboard,officers,student-import,student-view,students}.php`,
`reports/{analytics,incomplete,monthly,outstanding}.php`, `student/corrections.php`.

## Revision 8
Pages no longer contain SQL; filter bars without Apply submit the search box after a short pause (see CHANGELOG).
