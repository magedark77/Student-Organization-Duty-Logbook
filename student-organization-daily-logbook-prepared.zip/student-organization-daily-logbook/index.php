<?php
require __DIR__ . '/app/bootstrap.php';

if (user()) {
    redirect(home_url());
}

$error = '';
if (is_post()) {
    $error = csrf_is_valid()
        ? login_user(post_str('username'), post_str('password', false))
        : 'Your session expired. Please try signing in again.';
    if ($error === null) {
        redirect(home_url());
    }
}
$flash = get_flash();

render_header('Sign in', '', ['bare' => true, 'bodyClass' => 'login']);
?>
<div class="login-card">
    <div class="login-mark"><?= brand_logo(64) ?></div>
    <h1><?= e(APP_SHORT_NAME) ?> Logbook</h1>
    <p class="text-muted">A simple, secure way to manage student duty hours and attendance.</p>

    <?php if ($flash): alert($flash[0], $flash[1]); endif; ?>
    <?php if ($error): alert('danger', $error); endif; ?>

    <form method="post" class="form-stack">
        <?= csrf_field() ?>
        <label>Username
            <input name="username" required autofocus autocomplete="username" value="<?= e(post_str('username')) ?>">
        </label>
        <label>Password
            <input type="password" name="password" required autocomplete="current-password" data-toggle>
        </label>
        <button class="btn primary full" type="submit">Sign in</button>
    </form>

    <div class="login-footer">
        <p>Forgot your password? Ask an administrator for a one-time reset link.</p>
        <p><a href="<?= e(url('recover-admin.php')) ?>">Forgot administrator password?</a></p>
        <p>Secure access for authorized users</p>
    </div>
</div>
<?php render_footer(bare: true);
