# Student Office Daily Logbook

A PHP/MySQL web app for tracking student-office duty hours: student records and logins,
morning/afternoon time in/out, progress toward the required hours (100 by default),
monthly reports with CSV export, and an audit trail.

## Features
- Admin and student sign-in; students get a read-only dashboard of their own hours
- Student CRUD with an automatic login account (admin assigns username and password)
- The required hours (100 by default, `REQUIRED_HOURS`) are **per calendar year**: reports and student pages measure progress from 1 January
- Attendance with morning/afternoon sessions, minute-accurate durations, one record per student per day
- Dashboard, search, monthly report, CSV export (Excel-friendly), print view
- Audit log with old/new values, filters and pagination (50 entries per page)
- Security: prepared statements, password hashing, CSRF tokens, session hardening, output escaping, sign-in throttling (6 failed attempts per username or 20 per address pauses sign-in for 10 minutes; see `LOGIN_*` in `app/core/config.php`)
- Responsive layout for phones, tablets and desktop

## Backup & recovery
Administrators can create, verify, download and restore database backups from **Backup & Recovery**. See `docs/BACKUP_RECOVERY.md` (including hosting limits and how to test a restore on a separate database) and `docs/TEST_STATUS.md` (what has and has not been verified).

## QR code attendance
Administrators and officers can record Time In / Time Out by scanning each student's personal QR code with a phone or
webcam (HTTPS required for the camera). Student QR codes, a live monitor with CSV export, and rules for late arrivals are
under **Scan QR Attendance**, **QR Monitor** and **Student QR Codes** in the sidebar; students see **My QR Code**.
Full guide, InfinityFree steps and troubleshooting: `docs/QR_ATTENDANCE.md`.

## Requirements
PHP 8.1+ and MySQL 8 / MariaDB 10.4+ (InfinityFree and XAMPP both work).

## Installation
1. Create a MySQL database (InfinityFree: **MySQL Databases** in the control panel).
2. Import `database/logbook.sql` using phpMyAdmin (**Import** tab).
3. Upload the project files to `htdocs` (or your web root).
4. Copy `config/config.sample.php` to `config/config.local.php` and enter the database host, name, username and password.
5. Open the site and sign in with the default administrator account (created automatically when no admin exists):
   - Username: `admin`
   - Password: `Admin@12345`
6. **Change the password immediately** from **Change Password**. A warning banner is shown on every
   page until you do.

> `config/config.local.php` holds your database password. It is excluded from version control and
> blocked from web access by `config/.htaccess`. Never commit or share it.

If the site returns a *500 error* straight after upload, your host may not allow the directives in
`.htaccess`; delete the root `.htaccess` file and the site will work (the `app/`, `config/` and
`database/` folders are additionally protected by their own `.htaccess` files).

## Officer accounts and duty hours
Administrators open **Officer Accounts** in the sidebar to create separate logins for the President,
Internal Vice President, External Vice President and Secretary: choose a username, a role and an initial password. The officer then uses
**Change Password**. Passwords are stored as hashes and every creation is written to the audit log.

To change an officer, use **Edit** on their row: you can rename the login, change the role or set a new
password (leave the password blank to keep it). **Delete** removes the login; attendance they recorded is kept.
Edits and deletions are written to the audit log (never the password), and an officer who is renamed, given a
new password or deleted is signed out of any open session on their next click. Administrator and student
accounts cannot be edited or deleted from this page. Accounts that still carry an older role (Director, Assistant Director,
Manager I – VIII) are flagged until you assign one of the current roles.

Officers can view attendance and add records. They cannot edit or delete records, manage students, open
audit logs or export reports; the server enforces this on every page. They can sign in only during the duty
schedule, set in `config/config.local.php` with `duty_timezone` (default `Asia/Manila`), `duty_start`
(`08:00`) and `duty_end` (`17:00`), in 24-hour `HH:MM`. The schedule applies every day.

Existing databases need no manual migration for the officer roles: the `users.role` column is widened
automatically the first time anyone signs in. Create the officer logins from **Officer Accounts**, give each
person their initial password privately, and ask them to change it after the first sign-in.

## Notifications
Every signed-in user has a bell in the top bar (and a **Notifications** link in the sidebar) showing the
number of unread notifications; it refreshes about once a minute while a page is open. The Notifications page
lists them newest first, with **All / Unread** tabs, per-item *Mark read* and *Delete*, *Mark all as read* and
*Clear read*. Opening a notification marks it read and takes you to the related page. Notifications older than
180 days are removed automatically.

They are created automatically when:
- attendance is recorded or updated for a student, or an administrator deletes a record (the student is told);
- an officer (President, Internal VP, External VP, Secretary) records attendance (administrators are told);
- a student reaches the required yearly hours (the student and the administrators are told, once per year);
- someone changes their password (they see it the next time they sign in).

Administrators can also open **Announcements** to send a message to everyone, all active students, all
officers, or the active students of one duty day. Every announcement is written to the audit log.

Notifications can never block the action that triggered them: if the table is unavailable the attendance
record is still saved and the problem is written to the server error log. Existing databases get the
`notifications` table automatically the next time anyone signs in.

## Student accounts
Self-registration is disabled. Administrators create students under **Students → Add Student**:
the *username* is usually the student number, and the administrator sets the initial password.
Students can change their own password after signing in.

## Upgrading an existing installation
Replace the files but **keep your existing `config/config.local.php`** (the release zip does not
contain one). If you are coming from a very old version, create it from `config/config.sample.php`.
The database needs no manual steps: an old `students.section` column is renamed to `position`, and
two audit-log indexes are added, both automatically once per session. Delete the old
`ADMIN_LOGIN.txt` if you still have it.

## What the A–H improvements added
See `docs/IMPROVEMENTS.md` for the full list (files, features, tests, limitations). In short:
- **Dashboard** – a "Needs attention" panel (incomplete attendance, open sessions, pending corrections, students below the yearly hours), quick actions, empty states, text+icon status indicators.
- **Announcements** – a real `announcements` table with priority, pinning, expiry, edit/cancel, history with search/filter/sort, and per-recipient **read receipts**. Recipients read them at *Announcements* (`my-announcements.php`). A notification's own read flag is never treated as a receipt.
- **Students** – CSV import with preview, specific duplicate messages, deactivate/reactivate (history kept), profile/summary page, paging.
- **Attendance** – duplicate warning (live and server-side), officers can no longer overwrite an existing record, date/time validation, "who/when/why" change history, student **correction requests** reviewed by the administrator.
- **Reports** – PDF export, "hours not completed", charts by month/year/course/duty day. Screen, CSV and PDF are built from the same filters.
- **Accounts** – deactivate officers/students, one-time **password-reset links** (hashed token, 1 hour for officers/students, 7 days for imported students), role-change confirmation.
- **Interface** – breadcrumbs, mobile menu, stacked table cards on phones, inline field errors, required markers, consistent filters/reset.

## Upgrading to this version
1. Back up the database and files. 2. Replace the files, **keeping your `config/config.local.php`**.
3. Sign in once. The app creates the new tables and the `users.is_active` column automatically and never deletes data.
4. Old announcements remain as ordinary notifications. They have **no** read receipts (the old data cannot say who opened them); announcements published from now on do.

## Project structure
```
index.php, logout.php, change-password.php, notifications.php,
my-announcements.php, reset-password.php         Entry points any signed-in user (or, for sign-in/reset, anyone) can reach
admin/        Dashboard, students (+ import, profile), attendance, corrections, announcements (+ history, detail),
              officers, audit logs, QR scanner / monitor / codes / settings. Administrators; officers see only attendance,
              recording, the QR scanner (and announcements if allowed)
student/      Student dashboard, personal QR code and correction requests
reports/      Monthly, hours-not-completed, charts; export.php serves every CSV/PDF
app/
  bootstrap.php          Loads everything in three grouped lists (core, ui, domain); the first line of every page
  core/                  Infrastructure with no HTML: config, errors, request (input, redirects, run_action, handle_post),
                         session (flash, old input, field errors), security, database, schema (auto-upgrade), auth, pdf
  ui/                    Everything that renders HTML, reused by the pages:
                           layout (url, nav, page head)     forms (fields, sorting, pagination)
                           filters (filter_bar, search/select controls, student filter group)
                           components (alerts, badges, tables, modals, action_menu, breadcrumbs, status indicators)
                           charts (SVG bars)    icons    page_actions (POST handlers shared by several pages)
  domain/                Rules and data; all SQL lives here, grouped by responsibility:
                           students, imports            qr_attendance (codes, scans, rules)
                           attendance (queries), attendance_write (validate/save/history),
                           attendance_stats (totals, incomplete detection)
                           reports (monthly), report_totals (shared per-student totals, outstanding, charts),
                           report_exports (CSV/PDF definitions)
                           announcements, corrections, accounts (deactivate, reset links), notifications, officers, audit, duration
  views/partials/        header, footer, page head, duty-day tabs, attendance table and forms
assets/css, assets/js    style.css (numbered sections, colour tokens first, print last) + qr.css; app.js (progressive enhancement),
                         qr-scanner.js and qr-admin.js (QR pages only); vendor/ holds the two licensed QR libraries
config/                  config.sample.php (copy to config.local.php); config/.htaccess blocks web access
database/                logbook.sql (schema for a new install); upgrades are applied automatically by app/core/schema.php
tests/                   run.php (unit, no database), integration.php (end to end), seed-large.php + benchmark.php (performance);
                         blocked from web access
docs/                    IMPROVEMENTS.md (A-H update), REFACTORING.md (code quality, performance, structure);
                         prototypes/ holds static design mock-ups that are not part of the running app
```

### Conventions for adding to the project
- **A new list page:** build the filters with `filter_bar($action, $controls, $options)` + `student_filter_controls()`/`search_input()`/`toolbar_select()` (options: `active`, `hidden`, `extra`, `apply`, `reset`; use `sort_hidden()` to keep the sort), show results with `table_start(..., true)` (cards on phones), and `pagination()`.
- **A new form action:** register a handler per action name and call `handle_post([...])`; handlers `flash()` success and `throw new ValidationException(...)` to refuse. CSRF, unknown actions and error reporting are handled for you.
- **A card heading:** `section_head($title, $icon, $aside)` with `section_link($label, $href)` for the right-hand "View All →" link; do not hand-write `.section-head` markup.
- **Row actions:** keep one or two safe actions visible and put the rest in `action_menu([...])`.
- **Hours per student for a period:** use `students_with_totals()` (one query, one definition); do not write another attendance-join.

## Security checklist before going live
- Keep `config/config.local.php` **out of zips, repositories and chats**. If it was ever shared, change the database password in your host's control panel and update the file.
- Do not upload database exports (`*.sql` with data) to the web root; `database/logbook.sql` is the only schema file a server needs.
  `php tests/run.php` fails if any other `.sql` file is left in `database/`.
- Change the default `admin` password on first sign-in.

## Local testing
Run the automated checks (no database needed) from the project root:
```
php tests/run.php
```
End-to-end tests drive the real site over HTTP (sessions, CSRF, every role) and check the database.
**They wipe every table of the configured database**, so use a throw-away one:
```
php -S 127.0.0.1:8082 -t .        # in one terminal, config.local.php pointing at a TEST database,
                                  # with 'duty_start' => '00:00', 'duty_end' => '23:59'
php tests/integration.php http://127.0.0.1:8082
```
(needs the PHP `curl` extension; PDF checks use `pdftotext` if installed.)
The unit tests cover duration and progress math, formatting, CSV safety, URL and pagination helpers, the CSV import
reader and validators, the filter bar and menu components, and the server-side validation rules.

**Performance.** `tests/seed-large.php` fills a throw-away database (name must contain test/bench/demo/sample) with
realistic volume, and `tests/benchmark.php` times the data behind the heavy pages (`--max-ms=N` fails if any is slower):
```
php tests/seed-large.php --yes 1000 150     # 1,000 students x 150 days
php tests/benchmark.php --max-ms=1000
```

To try the app, use XAMPP (PHP 8.1+, MySQL/MariaDB). Create a database, import `database/logbook.sql`, create
`config/config.local.php`, then open `http://localhost/<folder>/`.
Set `'debug' => true` in `config.local.php` to see technical error messages while troubleshooting.

## Conventions for contributors
- Every page starts with `require app/bootstrap.php` and a guard (`require_admin()`, `require_attendance_access()`, ...).
- All SQL goes through prepared statements (`db_run($sql, $params)`) and lives in `app/domain/`, never in pages.
  Column names in `ORDER BY` cannot be bound, so they come from a fixed allow-list.
- State-changing POST handlers call `check_csrf()`, then `run_action()`, then `redirect()`.
- Read query-string input with `get_str()` / `get_choice()`, escape output with `e()`.
- Build links with `url('admin/attendance.php', ['date' => $date])` (empty values are dropped) and
  counts with `plural($n, 'record')`.
- Fetch rows with `db_all()`, one row with `db_one()`, a single value with `db_value()`.
- Tables use `table_start($label)` / `table_end()`; dashboards use `hero()`. Colours come from the
  tokens at the top of `style.css`, never hard-coded in a rule.
- Filter toolbars use `toolbar_select()` and `sort_controls()`; long lists use `paginate()` for the offset and `pagination()` for the links.
- Read a whole form from `$_POST` in a domain function (`student_input_from_post()`, `attendance_input_from_post()`), not in the page.
- Catch duplicate-key errors with `db_is_duplicate_key($e)`; build `IN (...)` lists with `sql_placeholders()`.
