<?php
/**
 * Times the data functions behind the heavy pages (read-only; safe on any database).
 *
 *   php tests/benchmark.php                 print a table (best of 3 runs each)
 *   php tests/benchmark.php --max-ms=500    also exit with an error if any function is slower than that
 *
 * Use tests/seed-large.php on a throw-away database first to get realistic volume.
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$_SERVER['SCRIPT_FILENAME'] = dirname(__DIR__) . '/index.php';
$_SERVER['REQUEST_METHOD']  = 'GET';
$_GET = [];
require dirname(__DIR__) . '/app/bootstrap.php';
$_SESSION['user'] = ['id' => 1, 'username' => 'benchmark', 'role' => 'admin', 'student_id' => null];

$budget = null;
foreach ($argv as $arg) {
    if (preg_match('/^--max-ms=(\d+)$/', $arg, $m)) {
        $budget = (int) $m[1];
    }
}
$year  = date('Y');
$today = date('Y-m-d');
$none  = ['year' => '', 'course' => '', 'status' => '', 'q' => ''];

$cases = [
    'Admin dashboard (outstanding + counts)' => static function () use ($year, $today): void {
        $below = students_outstanding($year);
        students_requirement_counts($year, $below);
        attendance_incomplete_counts($year . '-01-01', $today, $today);
        attendance_total_minutes();
        attendance_day_stats($today);
    },
    'Monthly report'                  => static fn() => monthly_report(date('Y-m'), [], ['name', 'asc']),
    'Hours-not-completed report'      => static fn() => students_outstanding($year, [], ['remaining', 'desc']),
    'Charts & summaries'              => static function () use ($year): void {
        $totals = students_with_totals($year . '-01-01', $year . '-12-31');
        analytics_monthly_minutes($year);
        analytics_yearly_minutes();
        analytics_group($year, 'course', [], $totals);
        analytics_group($year, 'year_level', [], $totals);
    },
    'Student list, page 1'            => static fn() => students_page($none, ['name', 'asc'], 1),
    'Announcement composer sizes'     => static fn() => announcement_audience_sizes(),
];

printf("%-42s %9s\n", 'Case (best of 3)', 'ms');
$worst = 0;
foreach ($cases as $label => $run) {
    $best = INF;
    for ($i = 0; $i < 3; $i++) {
        $start = microtime(true);
        $run();
        $best = min($best, (microtime(true) - $start) * 1000);
    }
    $worst = max($worst, $best);
    printf("%-42s %9.0f\n", $label, $best);
}
if ($budget !== null && $worst > $budget) {
    fwrite(STDERR, sprintf("Slowest case took %.0f ms, over the %d ms budget.\n", $worst, $budget));
    exit(1);
}
