<?php
/**
 * End-to-end tests: drives the running site over HTTP (real sessions, CSRF tokens, redirects) and checks the database.
 *
 *   php -S 127.0.0.1:8082 -t .            (in the project folder, using a THROW-AWAY database)
 *   php tests/integration.php http://127.0.0.1:8082
 *
 * WARNING: this wipes every table of the database in config/config.local.php. Never run it against real data.
 * Requires the curl extension, and config.local.php with duty_start 00:00 / duty_end 23:59 so officers can sign in.
 */
declare(strict_types=1);

$_SERVER['SCRIPT_FILENAME'] = __FILE__;
$_SERVER['REQUEST_METHOD']  = 'GET';
require __DIR__ . '/../app/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    exit('Run from the command line.');
}
$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8082', '/');

/* ------------------------------------------------------------------ tiny test framework */
$passed = 0; $failed = 0; $failures = [];
function ok(string $name, bool $cond, string $detail = ''): void
{
    global $passed, $failed, $failures;
    if ($cond) { $passed++; return; }
    $failed++; $failures[] = $name . ($detail !== '' ? " — $detail" : '');
    echo "  FAIL: $name" . ($detail !== '' ? " — $detail" : '') . "\n";
}
function section(string $title): void { echo "\n== $title\n"; }
function has(string $haystack, string $needle): bool { return str_contains($haystack, $needle); }

/* ------------------------------------------------------------------ HTTP client with its own cookie jar */
final class Client
{
    public string $jar;
    public function __construct(private string $base, public string $name)
    {
        $this->jar = tempnam(sys_get_temp_dir(), 'jar');
    }
    /** @return array{status:int, body:string, location:string, type:string, url:string} */
    public function req(string $method, string $path, array $post = [], bool $follow = true, array $files = []): array
    {
        $ch = curl_init(str_starts_with($path, 'http') ? $path : $this->base . '/' . ltrim($path, '/'));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => true, CURLOPT_COOKIEJAR => $this->jar, CURLOPT_COOKIEFILE => $this->jar,
            CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_MAXREDIRS => 6, CURLOPT_TIMEOUT => 30,
        ]);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $files ? $post + $files : http_build_query($post));
        }
        $raw = (string) curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $headers = substr($raw, 0, $info['header_size']);
        // With redirects followed there are several header blocks; the last one belongs to the final response.
        $blocks = array_values(array_filter(preg_split("/\r\n\r\n/", trim($headers)) ?: []));
        $last = (string) end($blocks);
        preg_match('/^Location:\s*(.+)$/mi', $last, $m);
        preg_match('/^Content-Type:\s*([^\r\n;]+)/mi', $last, $t);
        return ['status' => (int) $info['http_code'], 'body' => substr($raw, $info['header_size']), 'location' => trim($m[1] ?? ''), 'type' => trim($t[1] ?? ''), 'url' => (string) $info['url']];
    }
    public function get(string $path, bool $follow = true): array { return $this->req('GET', $path, [], $follow); }
    /** CSRF token of this session, read from a page that has a form. */
    public function csrf(string $fromPage = 'change-password.php'): string
    {
        $r = $this->get($fromPage);
        preg_match('/name="csrf" value="([a-f0-9]{64})"/', $r['body'], $m);
        return $m[1] ?? '';
    }
    public function post(string $path, array $fields, ?string $csrfFrom = null, bool $follow = true): array
    {
        $fields += ['csrf' => $this->csrf($csrfFrom ?? $path)];
        return $this->req('POST', $path, $fields, $follow);
    }
    /** POST with a deliberately wrong/missing token. */
    public function postNoCsrf(string $path, array $fields): array { return $this->req('POST', $path, $fields + ['csrf' => 'bad'], false); }
    public function login(string $user, string $pass): array
    {
        $this->req('GET', 'index.php');
        $token = $this->csrfRaw('index.php');
        return $this->req('POST', 'index.php', ['csrf' => $token, 'username' => $user, 'password' => $pass]);
    }
    private function csrfRaw(string $page): string
    {
        $r = $this->get($page);
        preg_match('/name="csrf" value="([a-f0-9]{64})"/', $r['body'], $m);
        return $m[1] ?? '';
    }
}

/* ------------------------------------------------------------------ DB helpers */
function dbq(string $sql, array $p = []): array { return db_all($sql, $p); }
function dbv(string $sql, array $p = []): mixed { return db_value($sql, $p); }
function dbx(string $sql, array $p = []): void { db_run($sql, $p); }

function wipe(): void
{
    $pdo = db();
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    foreach (['announcement_recipients', 'announcements', 'attendance_changes', 'attendance_corrections', 'password_resets', 'notifications', 'audit_logs', 'attendance', 'users', 'students'] as $t) {
        $pdo->exec("TRUNCATE TABLE `$t`");
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
}

function mkStudent(string $number, string $first, string $last, string $course, string $day, ?string $username = null, string $password = 'Student#1234'): int
{
    dbx("INSERT INTO students (student_number, first_name, last_name, course, year_level, status) VALUES (?, ?, ?, ?, ?, 'Active')", [$number, $first, $last, $course, $day]);
    $id = (int) db()->lastInsertId();
    if ($username !== null) {
        dbx("INSERT INTO users (username, password, role, student_id) VALUES (?, ?, 'student', ?)", [$username, password_hash($password, PASSWORD_DEFAULT), $id]);
    }
    return $id;
}
function mkOfficer(string $username, string $role, string $password = 'Officer#1234'): int
{
    dbx('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [$username, password_hash($password, PASSWORD_DEFAULT), $role]);
    return (int) db()->lastInsertId();
}
function uid(string $username): int { return (int) dbv('SELECT id FROM users WHERE username = ?', [$username]); }
function att(int $student, string $date, ?string $mi, ?string $mo, ?string $ai = null, ?string $ao = null): void
{
    dbx('INSERT INTO attendance (student_id, attendance_date, morning_time_in, morning_time_out, afternoon_time_in, afternoon_time_out) VALUES (?, ?, ?, ?, ?, ?)', [$student, $date, $mi, $mo, $ai, $ao]);
}

$today     = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$thisYear  = date('Y');
/* Attendance dates must lie in the current year for the year-based figures; use days that exist in every year. */
$earlyDays = [];
for ($i = 0; $i < 16; $i++) { $earlyDays[] = $thisYear . '-01-' . sprintf('%02d', 2 + $i); } // 16 days in January, all <= today

echo "Integration tests against $BASE\n";
wipe();

/* =========================================================================================== */
section('Setup: admin signs in, accounts and students exist');
$admin = new Client($BASE, 'admin');
$anon  = new Client($BASE, 'anon');
$anon->get('index.php'); // first request seeds the default administrator
$r = $admin->login('admin', 'Admin@12345');
ok('default admin is seeded on first use', (int) dbv("SELECT COUNT(*) FROM users WHERE role = 'admin'") === 1);
ok('admin can sign in', has($r['body'], 'Dashboard') && $r['status'] === 200, 'status ' . $r['status']);
$bad = (new Client($BASE, 'bad'))->login('admin', 'wrong-password');
ok('wrong password is rejected', has($bad['body'], 'Invalid username or password'));

mkOfficer('director1', 'president');
mkOfficer('mgr1', 'external_vp');
$sMon1 = mkStudent('2026-0001', 'Ana', 'Alba', 'BSCS', 'Monday', 'stud1');
$sMon2 = mkStudent('2026-0002', 'Ben', 'Bautista', 'BSIT', 'Monday', 'stud2');
$sTue  = mkStudent('2026-0003', 'Cara', 'Cruz', 'BSCS', 'Tuesday', 'stud3');
$sNoLogin = mkStudent('2026-0004', 'Dan', 'Dela Paz', 'BSIT', 'Friday');

$dir = new Client($BASE, 'director'); $mgr = new Client($BASE, 'mgr');
$st1 = new Client($BASE, 'stud1'); $st2 = new Client($BASE, 'stud2'); $st3 = new Client($BASE, 'stud3');
ok('director signs in', has($dir->login('director1', 'Officer#1234')['body'], 'Attendance'));
ok('manager signs in', has($mgr->login('mgr1', 'Officer#1234')['body'], 'Attendance'));
ok('student 1 signs in', has($st1->login('stud1', 'Student#1234')['body'], 'My Logbook'));
$st2->login('stud2', 'Student#1234'); $st3->login('stud3', 'Student#1234');

/* =========================================================================================== */
section('Access control matrix (direct URL access)');
$pages = [
    // path                                   admin  director mgr  student anon
    'admin/dashboard.php'                  => [200, 403, 403, 403, 302],
    'admin/students.php'                   => [200, 403, 403, 403, 302],
    'admin/student-import.php'             => [200, 403, 403, 403, 302],
    'admin/officers.php'                   => [200, 403, 403, 403, 302],
    'admin/corrections.php'                => [200, 403, 403, 403, 302],
    'admin/audit-logs.php'                 => [200, 403, 403, 403, 302],
    'admin/announcements.php'              => [200, 200, 403, 403, 302],
    'admin/announcement-history.php'       => [200, 200, 403, 403, 302],
    'admin/attendance.php'                 => [200, 200, 200, 403, 302],
    'admin/record-attendance.php'          => [200, 200, 200, 403, 302],
    'admin/attendance-check.php?student_id=1&date=' . $today => [200, 200, 200, 403, 302],
    'reports/monthly.php'                  => [200, 403, 403, 403, 302],
    'reports/outstanding.php'              => [200, 403, 403, 403, 302],
    'reports/analytics.php'                => [200, 403, 403, 403, 302],
    'reports/export.php?report=monthly&format=csv' => [200, 403, 403, 403, 302],
    'reports/export.php?report=monthly&format=pdf' => [200, 403, 403, 403, 302],
    'reports/export-csv.php'               => [200, 403, 403, 403, 302],
    'student/dashboard.php'                => [302, 302, 302, 200, 302],
    'student/corrections.php'              => [302, 302, 302, 200, 302],
    'my-announcements.php'                 => [200, 200, 200, 200, 302],
    'notifications.php'                    => [200, 200, 200, 200, 302],
];
$actors = [$admin, $dir, $mgr, $st1, $anon];
foreach ($pages as $path => $expected) {
    foreach ($actors as $i => $client) {
        $r = $client->get($path, false);
        ok("$path as {$client->name}", $r['status'] === $expected[$i], "expected {$expected[$i]}, got {$r['status']}");
    }
}
ok('student-view as student is 403', $st1->get('admin/student-view.php?id=' . $sMon2, false)['status'] === 403);
ok('student-view as officer is 403', $mgr->get('admin/student-view.php?id=' . $sMon2, false)['status'] === 403);
ok('announcement-view as manager is 403', $mgr->get('admin/announcement-view.php?id=1', false)['status'] === 403);

/* =========================================================================================== */
section('Unauthorized state-changing requests are refused and change nothing');
$before = (int) dbv('SELECT COUNT(*) FROM students');
$r = $st1->post('admin/students.php', ['action' => 'delete', 'id' => $sMon2], 'student/dashboard.php', false);
ok('student cannot delete a student', $r['status'] === 403 && (int) dbv('SELECT COUNT(*) FROM students') === $before);
$r = $mgr->post('admin/officers.php', ['action' => 'delete', 'id' => uid('director1')], 'admin/attendance.php', false);
ok('officer cannot delete an officer', $r['status'] === 403 && uid('director1') > 0);
$r = $mgr->post('admin/students.php', ['action' => 'deactivate', 'id' => $sMon1], 'admin/attendance.php', false);
ok('officer cannot deactivate a student', $r['status'] === 403 && dbv('SELECT status FROM students WHERE id = ?', [$sMon1]) === 'Active');
$r = $mgr->post('admin/announcements.php', ['audience' => 'students', 'title' => 'x', 'message' => 'y'], 'admin/attendance.php', false);
ok('manager cannot publish announcements', $r['status'] === 403 && (int) dbv('SELECT COUNT(*) FROM announcements') === 0);
$r = $st1->post('admin/corrections.php', ['action' => 'approve', 'id' => 1], 'student/dashboard.php', false);
ok('student cannot approve corrections', $r['status'] === 403);
$r = $dir->post('admin/corrections.php', ['action' => 'approve', 'id' => 1], 'admin/attendance.php', false);
ok('director cannot approve corrections', $r['status'] === 403);
$r = $mgr->post('admin/attendance.php', ['action' => 'delete', 'id' => 1, 'attendance_date' => $today], 'admin/record-attendance.php', false);
ok('officer cannot delete attendance', $r['status'] === 403);
$r = $st1->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '12:00'], 'student/dashboard.php', false);
ok('student cannot record attendance', $r['status'] === 403 && (int) dbv('SELECT COUNT(*) FROM attendance') === 0);
$r = $mgr->post('reports/export.php', [], 'admin/attendance.php', false);
ok('officer cannot export reports', $mgr->get('reports/export.php?report=outstanding&format=csv', false)['status'] === 403);
$admin->csrf('admin/students.php');
$r = $admin->postNoCsrf('admin/students.php', ['action' => 'save', 'student_number' => '9', 'first_name' => 'No', 'last_name' => 'Csrf', 'course' => 'X', 'year_level' => 'Monday', 'status' => 'Active']);
ok('POST without valid CSRF token is rejected (419)', $r['status'] === 419 && (int) dbv("SELECT COUNT(*) FROM students WHERE student_number = '9'") === 0, 'status ' . $r['status']);
foreach (['admin/announcements.php' => ['audience' => 'students', 'title' => 't', 'message' => 'm'], 'admin/officers.php' => ['action' => 'create', 'username' => 'zz1', 'role' => 'president', 'password' => 'longpassword1'], 'student/corrections.php' => ['action' => 'request']] as $path => $fields) {
    $c = str_starts_with($path, 'student') ? $st1 : $admin;
    ok("CSRF enforced on $path", $c->postNoCsrf($path, $fields)['status'] === 419);
}

/* =========================================================================================== */
section('Students: create/edit with inline validation, duplicates, search, filters, pagination');
$r = $admin->post('admin/students.php', ['action' => 'save', 'id' => 0, 'student_number' => '2026-0001', 'first_name' => 'Dup', 'last_name' => 'Licate', 'course' => 'BSCS', 'year_level' => 'Monday', 'status' => 'Active', 'username' => 'dupuser', 'password' => 'Longpass#1'], 'admin/students.php');
ok('duplicate student number refused with a message naming the owner', has($r['body'], 'already used by Ana Alba'));
ok('…and the message is attached to the field', has($r['body'], 'id="err-student_number"') && has($r['body'], 'aria-invalid="true"'));
ok('…and typed values are kept (first name)', has($r['body'], 'value="Dup"'));
ok('…and no duplicate row was created', (int) dbv("SELECT COUNT(*) FROM students WHERE student_number = '2026-0001'") === 1);
$r = $admin->post('admin/students.php', ['action' => 'save', 'id' => 0, 'student_number' => '2026-0900', 'first_name' => 'Taken', 'last_name' => 'Name', 'course' => 'BSCS', 'year_level' => 'Monday', 'status' => 'Active', 'username' => 'stud1', 'password' => 'Longpass#1'], 'admin/students.php');
ok('duplicate username refused on the username field', has($r['body'], 'is already taken') && (int) dbv("SELECT COUNT(*) FROM students WHERE student_number = '2026-0900'") === 0);
$r = $admin->post('admin/students.php', ['action' => 'save', 'id' => 0, 'student_number' => '2026-0901', 'first_name' => 'New', 'last_name' => 'Kid', 'course' => 'BSIT', 'year_level' => 'Wednesday', 'status' => 'Active', 'username' => 'newkid', 'password' => 'Longpass#1'], 'admin/students.php');
ok('valid student is created with a success message', has($r['body'], 'Student created.') && (int) dbv("SELECT COUNT(*) FROM students WHERE student_number = '2026-0901'") === 1);
ok('new student login exists and hashes the password', password_verify('Longpass#1', (string) dbv("SELECT password FROM users WHERE username = 'newkid'")) && !has((string) dbv("SELECT password FROM users WHERE username = 'newkid'"), 'Longpass'));
$r = $admin->post('admin/students.php', ['action' => 'save', 'id' => 0, 'student_number' => '', 'first_name' => 'No', 'last_name' => 'Number', 'course' => 'BSIT', 'year_level' => 'Monday', 'status' => 'Active'], 'admin/students.php');
ok('missing required field gives an inline message', has($r['body'], 'Student number is required'));
$r = $admin->post('admin/students.php', ['action' => 'save', 'id' => $sTue, 'student_number' => '2026-0003', 'first_name' => 'Cara', 'last_name' => 'Cruz-Edited', 'course' => 'BSCS', 'year_level' => 'Tuesday', 'status' => 'Active', 'username' => 'stud3', 'password' => ''], 'admin/students.php');
ok('student edit succeeds', has($r['body'], 'Student updated.') && dbv('SELECT last_name FROM students WHERE id = ?', [$sTue]) === 'Cruz-Edited');

$list = $admin->get('admin/students.php?q=Bautista')['body'];
ok('search by name', has($list, '>2026-0002<') && !has($list, '>2026-0001<'));
$list = $admin->get('admin/students.php?q=2026-0003')['body'];
ok('search by student number', has($list, 'Cruz-Edited') && !has($list, '>2026-0002<'));
$list = $admin->get('admin/students.php?course=BSIT')['body'];
ok('filter by course', has($list, '>2026-0002<') && !has($list, '>2026-0001<'));
$list = $admin->get('admin/students.php?year=Tuesday')['body'];
ok('filter by duty day', has($list, '>2026-0003<') && !has($list, '>2026-0002<'));
$list = $admin->get('admin/students.php?q=zzzznomatch')['body'];
ok('empty search shows an empty state + reset link', has($list, 'No students match your filters') && has($list, 'Reset filters'));
$list = $admin->get('admin/students.php?sort=name&dir=desc')['body'];
ok('sort descending puts Kid before Alba', strpos($list, 'Kid') < strpos($list, 'Alba'));
for ($i = 0; $i < 60; $i++) { mkStudent('BULK-' . sprintf('%03d', $i), 'Bulk', 'Student' . sprintf('%03d', $i), 'BSCS', 'Saturday'); }
$p1 = $admin->get('admin/students.php?course=BSCS&year=Saturday')['body'];
ok('pagination: page 1 shows 25 rows', substr_count($p1, '>BULK-') === 25, 'got ' . substr_count($p1, '>BULK-'));
ok('pagination links keep the active filters', has($p1, 'page=2') && has($p1, 'course=BSCS') && has($p1, 'year=Saturday'));
$p3 = $admin->get('admin/students.php?course=BSCS&year=Saturday&page=3')['body'];
ok('pagination: last page shows the remaining 10', substr_count($p3, '>BULK-') === 10, 'got ' . substr_count($p3, '>BULK-'));
dbx("DELETE FROM students WHERE student_number LIKE 'BULK-%'");

/* =========================================================================================== */
section('Attendance: record, duplicates, officer restrictions, reasons, change history, durations');
$mgr->get('admin/record-attendance.php');
$r = $mgr->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '12:00', 'afternoon_in' => '13:00', 'afternoon_out' => '16:30'], 'admin/record-attendance.php');
ok('officer records attendance', has($r['body'], 'Attendance recorded successfully'));
$row = dbq('SELECT * FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sMon1, $today])[0] ?? null;
ok('record stored with the right times', $row && substr($row['morning_time_in'], 0, 5) === '08:00' && substr($row['afternoon_time_out'], 0, 5) === '16:30');
ok('duration is 7h 30m (4h + 3h30)', $row && attendance_minutes($row)['total'] === 450 && format_duration(450) === '7h 30m');
ok('who/when is in the change history as "create"', (int) dbv("SELECT COUNT(*) FROM attendance_changes WHERE attendance_id = ? AND change_type = 'create' AND changed_by = ?", [$row['id'], uid('mgr1')]) === 1);
$r = $mgr->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '09:00', 'morning_out' => '10:00'], 'admin/record-attendance.php');
ok('officer CANNOT overwrite an existing record', has($r['body'], 'already exists') && substr((string) dbv('SELECT morning_time_in FROM attendance WHERE id = ?', [$row['id']]), 0, 5) === '08:00');
$r = $mgr->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '09:00', 'morning_out' => '10:00', 'confirm_overwrite' => '1', 'reason' => 'trying'], 'admin/record-attendance.php');
ok('…even by sending confirm_overwrite + reason', substr((string) dbv('SELECT morning_time_in FROM attendance WHERE id = ?', [$row['id']]), 0, 5) === '08:00');
$j = json_decode($mgr->get('admin/attendance-check.php?student_id=' . $sMon1 . '&date=' . $today)['body'], true);
ok('duplicate-check endpoint reports the existing record (officer cannot replace)', ($j['exists'] ?? false) === true && ($j['canReplace'] ?? true) === false && ($j['total'] ?? '') === '7h 30m');
$j = json_decode($admin->get('admin/attendance-check.php?student_id=' . $sMon1 . '&date=' . $today)['body'], true);
ok('…and tells an administrator they can replace', ($j['canReplace'] ?? false) === true);
$j = json_decode($admin->get('admin/attendance-check.php?student_id=' . $sMon1 . '&date=2020-01-01')['body'], true);
ok('duplicate-check says no record when none', ($j['exists'] ?? true) === false);

$r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '11:00'], 'admin/record-attendance.php');
ok('admin re-submitting a new entry for an existing day gets a duplicate warning, not a silent overwrite', has($r['body'], 'already exists') && substr((string) dbv('SELECT morning_time_out FROM attendance WHERE id = ?', [$row['id']]), 0, 5) === '12:00');
ok('…and the replace/reason boxes are shown', has($r['body'], 'name="confirm_overwrite"') && !has(preg_replace('/\s+/', ' ', $r['body']), 'data-overwrite-block hidden'));
$r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '11:00', 'confirm_overwrite' => '1', 'reason' => ''], 'admin/record-attendance.php');
ok('replacing without a reason is refused', has($r['body'], 'reason') && substr((string) dbv('SELECT morning_time_out FROM attendance WHERE id = ?', [$row['id']]), 0, 5) === '12:00');
$r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon1, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '11:00', 'afternoon_in' => '13:00', 'afternoon_out' => '16:30', 'confirm_overwrite' => '1', 'reason' => 'Student left early, confirmed with officer'], 'admin/record-attendance.php');
ok('admin replaces with confirmation + reason', has($r['body'], 'Attendance updated successfully') && substr((string) dbv('SELECT morning_time_out FROM attendance WHERE id = ?', [$row['id']]), 0, 5) === '11:00');
$chg = dbq("SELECT c.*, u.username FROM attendance_changes c JOIN users u ON u.id = c.changed_by WHERE c.attendance_id = ? AND c.change_type = 'update'", [$row['id']])[0] ?? null;
ok('change history records who, when, why, old and new', $chg && $chg['username'] === 'admin' && $chg['reason'] === 'Student left early, confirmed with officer' && !empty($chg['changed_at']) && has((string) $chg['old_values'], '12:00') && has((string) $chg['new_values'], '11:00'));
ok('duration recalculated: 3h + 3h30 = 6h 30m', attendance_minutes(dbq('SELECT * FROM attendance WHERE id = ?', [$row['id']])[0])['total'] === 390);
ok('audit log has the attendance update', (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE table_name = 'attendance' AND action = 'UPDATE'") >= 1);
$edit = $admin->get('admin/attendance.php?date=' . $today . '&edit=' . $row['id'])['body'];
ok('edit dialog shows the change history', has($edit, 'Change history') && has($edit, 'Student left early'));

foreach ([
    'future date'              => ['attendance_date' => date('Y-m-d', strtotime('+3 days')), 'morning_in' => '08:00', 'morning_out' => '12:00'],
    'out before in'            => ['attendance_date' => $yesterday, 'morning_in' => '12:00', 'morning_out' => '08:00'],
    'unpaired time'            => ['attendance_date' => $yesterday, 'morning_in' => '08:00'],
    'overlapping sessions'     => ['attendance_date' => $yesterday, 'morning_in' => '08:00', 'morning_out' => '12:00', 'afternoon_in' => '11:00', 'afternoon_out' => '14:00'],
    'invalid time'             => ['attendance_date' => $yesterday, 'morning_in' => '25:99', 'morning_out' => '26:00'],
] as $label => $fields) {
    $before = (int) dbv('SELECT COUNT(*) FROM attendance');
    $r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon2] + $fields, 'admin/record-attendance.php');
    ok("server rejects: $label", (int) dbv('SELECT COUNT(*) FROM attendance') === $before && has($r['body'], 'alert danger'));
}
$r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon2, 'attendance_date' => $yesterday, 'morning_in' => '12:00', 'morning_out' => '08:00', 'remarks' => 'keep me'], 'admin/record-attendance.php');
ok('failed attendance form keeps the typed values', has($r['body'], 'value="12:00"') && has($r['body'], 'value="08:00"'));
$r = $admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sMon2, 'attendance_date' => $yesterday, 'morning_in' => '08:00', 'morning_out' => '12:00'], 'admin/record-attendance.php');
ok('admin records a normal day', has($r['body'], 'Attendance recorded successfully'));
$r = $admin->post('admin/attendance.php', ['action' => 'delete', 'id' => (int) dbv('SELECT id FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sMon2, $yesterday]), 'attendance_date' => $yesterday, 'reason' => 'Entered for the wrong student'], 'admin/attendance.php');
ok('admin deletes a record', has($r['body'], 'Attendance deleted') && (int) dbv('SELECT COUNT(*) FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sMon2, $yesterday]) === 0);
ok('deletion is kept in the history with the reason', (int) dbv("SELECT COUNT(*) FROM attendance_changes WHERE change_type = 'delete' AND reason = 'Entered for the wrong student'") === 1);

/* incomplete records (cannot be created through the form, so insert them like legacy data) */
$dTwo = date('Y-m-d', strtotime('-2 days')); $dThree = date('Y-m-d', strtotime('-3 days'));
att($sMon2, $yesterday, '08:00', null);                       // time-in, no time-out
att($sTue, $dTwo, null, null, null, '16:00');                  // time-out only
att($sNoLogin, $dThree, null, null, null, null);               // empty record
$page = $admin->get('admin/attendance.php?date=' . $yesterday)['body'];
ok('attendance list names the problem', has($page, 'Morning time-out missing'));
ok('attendance list marks the row', has($page, 'row-incomplete'));
ok('attendance list shows a warning above the table', has($page, 'a missing time-in or time-out'));
$dash = $admin->get('admin/dashboard.php')['body'];
ok('dashboard alert counts incomplete records', has($dash, '3 attendance records') && has($dash, 'Needs attention'));
$s2dash = $st2->get('student/dashboard.php')['body'];
ok('student sees their own incomplete record highlighted', has($s2dash, 'incomplete') && has($s2dash, 'Morning time-out missing'));
ok("student does not see anyone else's data", !has($s2dash, '2026-0001') && !has($s2dash, 'Alba'));
dbx('DELETE FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sTue, $dTwo]);

/* =========================================================================================== */
section('Correction requests');
$fix = ['action' => 'request', 'attendance_date' => $yesterday, 'morning_in' => '08:00', 'morning_out' => '12:00', 'reason' => 'I forgot to time out; left at noon.'];
$r = $st2->post('student/corrections.php', $fix);
ok('student submits a correction request', has($r['body'], 'Your request was sent') && (int) dbv("SELECT COUNT(*) FROM attendance_corrections WHERE student_id = ? AND status = 'pending'", [$sMon2]) === 1);
ok('admins are notified of the request', (int) dbv("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND ref LIKE 'correction:%'", [uid('admin')]) === 1);
$r = $st2->post('student/corrections.php', $fix);
ok('duplicate pending request for the same date is refused', has($r['body'], 'already have a pending request') && (int) dbv('SELECT COUNT(*) FROM attendance_corrections') === 1);
foreach (['future date' => ['attendance_date' => date('Y-m-d', strtotime('+1 day'))], 'too old' => ['attendance_date' => date('Y-m-d', strtotime('-200 days'))], 'no reason' => ['attendance_date' => $dTwo, 'reason' => ''], 'bad times' => ['attendance_date' => $dTwo, 'morning_in' => '12:00', 'morning_out' => '08:00']] as $label => $over) {
    $n = (int) dbv('SELECT COUNT(*) FROM attendance_corrections');
    $st2->post('student/corrections.php', $over + $fix);
    ok("correction rejected: $label", (int) dbv('SELECT COUNT(*) FROM attendance_corrections') === $n);
}
$cid = (int) dbv("SELECT id FROM attendance_corrections WHERE student_id = ?", [$sMon2]);
$r = $st1->post('student/corrections.php', ['action' => 'cancel', 'id' => $cid]);
ok("a student cannot cancel someone else's request", dbv('SELECT status FROM attendance_corrections WHERE id = ?', [$cid]) === 'pending');
$page = $admin->get('admin/corrections.php?status=pending')['body'];
ok('admin sees the request with current vs requested times', has($page, 'Bautista') && has($page, 'Current record') && has($page, 'forgot to time out'));
$r = $admin->post('admin/corrections.php', ['action' => 'reject', 'id' => $cid, 'note' => ''], 'admin/corrections.php');
ok('rejecting needs a note', dbv('SELECT status FROM attendance_corrections WHERE id = ?', [$cid]) === 'pending');
$r = $admin->post('admin/corrections.php', ['action' => 'approve', 'id' => $cid, 'note' => 'ok'], 'admin/corrections.php');
ok('admin approves', has($r['body'], 'Request approved') && dbv('SELECT status FROM attendance_corrections WHERE id = ?', [$cid]) === 'approved');
$fixed = dbq('SELECT * FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sMon2, $yesterday])[0];
ok('approval updated the attendance record', substr($fixed['morning_time_out'], 0, 5) === '12:00' && attendance_incomplete_reasons($fixed) === []);
$ch = dbq("SELECT * FROM attendance_changes WHERE attendance_id = ? AND change_type = 'correction'", [$fixed['id']])[0] ?? null;
ok('approval is in the change history with the student reason', $ch && has((string) $ch['reason'], 'forgot to time out') && (int) $ch['changed_by'] === uid('admin'));
ok('the admin list shows who decided the request', has($admin->get('admin/corrections.php')['body'], ' by admin'));
ok('student was notified of the decision', (int) dbv("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND title = 'Correction approved'", [uid('stud2')]) === 1);
$r = $admin->post('admin/corrections.php', ['action' => 'approve', 'id' => $cid, 'note' => ''], 'admin/students.php');
ok('a decided request cannot be decided twice', has($r['body'], 'already been approved'));
$st2->post('student/corrections.php', ['attendance_date' => $dTwo] + $fix);
$cid2 = (int) dbv("SELECT id FROM attendance_corrections WHERE status = 'pending'");
$admin->post('admin/corrections.php', ['action' => 'reject', 'id' => $cid2, 'note' => 'No evidence'], 'admin/corrections.php');
ok('rejection leaves attendance untouched', (int) dbv('SELECT COUNT(*) FROM attendance WHERE student_id = ? AND attendance_date = ?', [$sMon2, $dTwo]) === 0 && dbv('SELECT status FROM attendance_corrections WHERE id = ?', [$cid2]) === 'rejected');
ok('student sees the decision and note', has($st2->get('student/corrections.php')['body'], 'No evidence'));
$st2->post('student/corrections.php', ['attendance_date' => $dThree] + $fix);
$cid3 = (int) dbv("SELECT id FROM attendance_corrections WHERE status = 'pending'");
$st2->post('student/corrections.php', ['action' => 'cancel', 'id' => $cid3]);
ok('student can cancel their own pending request', dbv('SELECT status FROM attendance_corrections WHERE id = ?', [$cid3]) === 'cancelled');

/* =========================================================================================== */
section('Announcements: audiences, priority, pinning, expiry, read receipts, edit/cancel permissions');
/* Announcements can only be sent to "all active students". Older audiences (officers, everyone, duty days) remain readable in history,
 * so they are seeded straight into the database here to keep covering that data. */
function seedLegacyAnnouncement(string $audience, string $title, string $message, int $author): int
{
    dbx("INSERT INTO announcements (title, message, audience, priority, created_by) VALUES (?, ?, ?, 'normal', ?)", [$title, $message, $audience, $author]);
    $id = (int) db()->lastInsertId();
    [$from, $params] = announcement_recipient_query($audience);
    dbx("INSERT INTO announcement_recipients (announcement_id, user_id) SELECT {$id}, u.id {$from}", $params);
    return $id;
}
dbx("UPDATE students SET status = 'Inactive' WHERE id = ?", [$sTue]); // an inactive student is not a recipient
$nAll = (int) dbv("SELECT COUNT(*) FROM users u JOIN students s ON s.id = u.student_id WHERE u.is_active = 1 AND u.role = 'student' AND s.status = 'Active'");
$r = $dir->post('admin/announcements.php', ['audience' => 'students', 'priority' => 'important', 'title' => 'Monday duty briefing', 'message' => "Bring your ID.\nSecond line.", 'expires_on' => date('Y-m-d', strtotime('+3 days')), 'pinned' => '1'], 'admin/announcements.php');
$a1 = (int) dbv("SELECT id FROM announcements WHERE title = 'Monday duty briefing'");
dbx("UPDATE students SET status = 'Active' WHERE id = ?", [$sTue]);
ok('director publishes to all active students', $a1 > 0 && has($r['body'], "Announcement published to {$nAll} people"));
ok('recipients = exactly the active students (not the inactive one)', (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ?', [$a1]) === $nAll && (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud3')]) === 0 && (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ? AND user_id IN (?, ?)', [$a1, uid('stud1'), uid('stud2')]) === 2);
ok('a director cannot pin (admin-only)', (int) dbv('SELECT is_pinned FROM announcements WHERE id = ?', [$a1]) === 0);
ok('priority and expiry stored', dbv('SELECT priority FROM announcements WHERE id = ?', [$a1]) === 'important' && dbv('SELECT expires_at FROM announcements WHERE id = ?', [$a1]) !== null);
ok('each recipient also got a bell notification linked to it', (int) dbv("SELECT COUNT(*) FROM notifications WHERE ref = ? AND type = 'announcement'", ['announcement:' . $a1]) === $nAll);
ok('no read receipts yet', (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ? AND read_at IS NOT NULL', [$a1]) === 0);
ok('bell unread count counts the notification', notifications_unread_count(uid('stud1')) >= 1);

$r = $st3->get('my-announcements.php?id=' . $a1, false);
ok('a non-recipient (inactive student) gets 404', $r['status'] === 404);
ok('…and no receipt was created for them', (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud3')]) === 0);
ok('inbox of a non-recipient does not list it', !has($st3->get('my-announcements.php')['body'], 'Monday duty briefing'));
$inbox = $st1->get('my-announcements.php')['body'];
ok('recipient inbox lists it as New with priority', has($inbox, 'Monday duty briefing') && has($inbox, 'New') && has($inbox, 'Important'));
ok('student nav shows an unread announcement count', has($st1->get('student/dashboard.php')['body'], '1 unread announcement'));

/* Individual notification read status is NOT an announcement read receipt */
$nid = (int) dbv("SELECT id FROM notifications WHERE user_id = ? AND ref = ?", [uid('stud2'), 'announcement:' . $a1]);
$st2->post('notifications.php', ['action' => 'read', 'id' => $nid]);
ok('marking the bell notification read sets the notification flag', (int) dbv('SELECT is_read FROM notifications WHERE id = ?', [$nid]) === 1);
ok('…but does NOT create an announcement read receipt', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud2')]) === null);
$st2->post('notifications.php', ['action' => 'read_all']);
ok('"mark all read" also does not create receipts', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud2')]) === null);

/* Opening the announcement records the receipt for that user only */
$view = $st1->get('my-announcements.php?id=' . $a1);
ok('recipient can open the announcement', $view['status'] === 200 && has($view['body'], 'Bring your ID.') && has($view['body'], 'Second line.'));
ok('opening records THEIR receipt', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud1')]) !== null);
ok("…and not anyone else's", dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud2')]) === null);
ok('…and that user\'s bell notification is marked read', (int) dbv("SELECT is_read FROM notifications WHERE user_id = ? AND ref = ?", [uid('stud1'), 'announcement:' . $a1]) === 1);
$st1->get('my-announcements.php?id=' . $a1 . '&user_id=' . uid('stud2') . '&read=1');
$st1->post('my-announcements.php?id=' . $a1, ['user_id' => uid('stud2'), 'action' => 'read']);
ok('a user cannot mark another user\'s announcement as read (extra params ignored)', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud2')]) === null);
$first = dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud1')]);
sleep(1); $st1->get('my-announcements.php?id=' . $a1);
ok('re-opening keeps the first read time', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud1')]) === $first);
try { db()->prepare('INSERT INTO announcement_recipients (announcement_id, user_id) VALUES (?, ?)')->execute([$a1, uid('stud1')]); $dupOk = true; } catch (PDOException $e) { $dupOk = false; }
ok('DB enforces one receipt row per (announcement, recipient)', $dupOk === false);

/* Receipts and counts, history, filters */
$v = $dir->get('admin/announcement-view.php?id=' . $a1)['body'];
ok('owner sees read/unread counts', has($v, "1 of {$nAll} read") && has($v, 'Unread') && has($v, 'Read on'));
ok('owner sees which recipient has read it', preg_match('/stud1.*?Read/s', $v) === 1 && has($v, 'stud2'));
$hist = $dir->get('admin/announcement-history.php')['body'];
ok('history shows counts', has($hist, "1/{$nAll}") && has($hist, ($nAll - 1) . ' unread') && has($hist, 'Monday duty briefing'));

$r = $admin->post('admin/announcements.php', ['audience' => 'students', 'priority' => 'urgent', 'title' => 'Fire drill', 'message' => 'Urgent drill at 3pm', 'pinned' => '1'], 'admin/announcements.php');
ok('urgent without confirmation is refused', (int) dbv("SELECT COUNT(*) FROM announcements WHERE title = 'Fire drill'") === 0 && has($r['body'], 'confirm that this urgent announcement'));
ok('…and the typed text is kept', has($r['body'], 'Fire drill') && has($r['body'], 'Urgent drill at 3pm'));
$r = $admin->post('admin/announcements.php', ['audience' => 'students', 'priority' => 'urgent', 'title' => 'Fire drill', 'message' => 'Urgent drill at 3pm', 'pinned' => '1', 'confirm_urgent' => '1'], 'admin/announcements.php');
$a2 = (int) dbv("SELECT id FROM announcements WHERE title = 'Fire drill'");
ok('urgent with confirmation is published to all active students', $a2 > 0 && (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ?', [$a2]) === (int) dbv("SELECT COUNT(*) FROM users u JOIN students s ON s.id = u.student_id WHERE s.status = 'Active'"));
ok('admin can pin; urgent notification is labelled', (int) dbv('SELECT is_pinned FROM announcements WHERE id = ?', [$a2]) === 1 && (int) dbv("SELECT COUNT(*) FROM notifications WHERE ref = ? AND title LIKE '[Urgent]%'", ['announcement:' . $a2]) > 0);
$inbox = $st1->get('my-announcements.php')['body'];
ok('pinned/urgent announcement is listed before the older one', strpos($inbox, 'Fire drill') < strpos($inbox, 'Monday duty briefing') && has($inbox, 'Pinned'));
ok('urgent unread is flagged on the dashboard', has($st1->get('student/dashboard.php')['body'], 'urgent'));
$a3Id = seedLegacyAnnouncement('officers', 'Officer memo', 'Staff only', uid('admin'));
$a3 = (int) dbv("SELECT id FROM announcements WHERE title = 'Officer memo'");
ok('officers audience reaches only officers', $a3 > 0 && (int) dbv("SELECT COUNT(*) FROM announcement_recipients r JOIN users u ON u.id = r.user_id WHERE r.announcement_id = ? AND u.role = 'student'", [$a3]) === 0 && (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ?', [$a3]) === 2);
seedLegacyAnnouncement('everyone', 'Hello all', 'Welcome', uid('admin'));
$a4 = (int) dbv("SELECT id FROM announcements WHERE title = 'Hello all'");
ok('"everyone" reaches active students and officers, not admins', (int) dbv("SELECT COUNT(*) FROM announcement_recipients r JOIN users u ON u.id = r.user_id WHERE r.announcement_id = ? AND u.role = 'admin'", [$a4]) === 0 && (int) dbv("SELECT COUNT(*) FROM announcement_recipients r JOIN users u ON u.id = r.user_id WHERE r.announcement_id = ? AND u.role = 'president'", [$a4]) === 1);
foreach (['officers', 'everyone', 'day:Monday', 'day:Saturday', 'bogus'] as $badAudience) {
    $r = $admin->post('admin/announcements.php', ['audience' => $badAudience, 'priority' => 'normal', 'title' => 'Refused ' . $badAudience, 'message' => 'x'], 'admin/announcements.php');
}
ok('only "all active students" can be chosen: every other audience is refused', (int) dbv("SELECT COUNT(*) FROM announcements WHERE title LIKE 'Refused %'") === 0 && has($r['body'], 'Choose who should receive'));
ok('the send form offers just that one group', substr_count($admin->get('admin/announcements.php')['body'], '<option value="students"') === 1 && !has($admin->get('admin/announcements.php')['body'], 'value="officers"') && !has($admin->get('admin/announcements.php')['body'], 'value="everyone"'));
$r = $admin->post('admin/announcements.php', ['audience' => 'students', 'priority' => 'normal', 'title' => 'Past', 'message' => 'x', 'expires_on' => '2001-01-01'], 'admin/announcements.php');
ok('past expiry date refused', (int) dbv("SELECT COUNT(*) FROM announcements WHERE title = 'Past'") === 0 && has($r['body'], 'cannot be in the past'));

ok('director cannot open an announcement they did not publish', $dir->get('admin/announcement-view.php?id=' . $a2, false)['status'] === 403);
$dh = $dir->get('admin/announcement-history.php')['body'];
ok("director's history lists only their own", has($dh, 'Monday duty briefing') && !has($dh, 'Fire drill') && !has($dh, 'Officer memo'));
$r = $dir->post('admin/announcement-view.php?id=' . $a2, ['action' => 'cancel', 'id' => $a2], 'admin/announcement-view.php?id=' . $a1, false);
ok("director cannot cancel someone else's announcement", $r['status'] === 403 && dbv('SELECT status FROM announcements WHERE id = ?', [$a2]) === 'active');
$r = $dir->post('admin/announcement-view.php?id=' . $a2, ['action' => 'update', 'id' => $a2, 'title' => 'Hacked', 'message' => 'x', 'priority' => 'normal'], 'admin/announcement-view.php?id=' . $a1, false);
ok("director cannot edit someone else's announcement", $r['status'] === 403 && dbv('SELECT title FROM announcements WHERE id = ?', [$a2]) === 'Fire drill');
$r = $dir->post('admin/announcement-view.php?id=' . $a1, ['action' => 'pin', 'id' => $a1], 'admin/announcement-view.php?id=' . $a1);
ok('director cannot pin even their own', (int) dbv('SELECT is_pinned FROM announcements WHERE id = ?', [$a1]) === 0);
$r = $dir->post('admin/announcement-view.php?id=' . $a1, ['action' => 'update', 'id' => $a1, 'title' => 'Monday duty briefing (updated)', 'message' => 'New room: B204', 'priority' => 'urgent', 'expires_on' => ''], 'admin/announcement-view.php?id=' . $a1);
ok('owner edits title/message/priority/expiry', has($r['body'], 'Announcement updated') && dbv('SELECT title FROM announcements WHERE id = ?', [$a1]) === 'Monday duty briefing (updated)' && dbv('SELECT expires_at FROM announcements WHERE id = ?', [$a1]) === null && dbv('SELECT priority FROM announcements WHERE id = ?', [$a1]) === 'urgent');
ok('edit also refreshes the bell notification text', (int) dbv("SELECT COUNT(*) FROM notifications WHERE ref = ? AND message = 'New room: B204'", ['announcement:' . $a1]) === $nAll);
ok('edit keeps existing read receipts', dbv('SELECT read_at FROM announcement_recipients WHERE announcement_id = ? AND user_id = ?', [$a1, uid('stud1')]) !== null);
$r = $dir->post('admin/announcement-view.php?id=' . $a1, ['action' => 'update', 'id' => $a1, 'title' => '', 'message' => 'x', 'priority' => 'normal'], 'admin/announcement-view.php?id=' . $a1);
ok('invalid edit is refused with the edit dialog reopened', dbv('SELECT title FROM announcements WHERE id = ?', [$a1]) === 'Monday duty briefing (updated)' && has($r['body'], 'Enter a title'));
$r = $admin->post('admin/announcement-view.php?id=' . $a1, ['action' => 'pin', 'id' => $a1], 'admin/announcement-view.php?id=' . $a1);
ok('admin pins an existing announcement', (int) dbv('SELECT is_pinned FROM announcements WHERE id = ?', [$a1]) === 1);

/* history search / filter / sort */
$h = $admin->get('admin/announcement-history.php?q=drill')['body'];
ok('history search by title', has($h, 'Fire drill') && !has($h, 'Officer memo'));
$h = $admin->get('admin/announcement-history.php?q=Staff+only')['body'];
ok('history search by message', has($h, 'Officer memo') && !has($h, 'Fire drill'));
$h = $admin->get('admin/announcement-history.php?priority=urgent')['body'];
ok('history filter by priority', has($h, 'Fire drill') && !has($h, 'Officer memo'));
$h = $admin->get('admin/announcement-history.php?audience=officers')['body'];
ok('history filter by audience', has($h, 'Officer memo') && !has($h, 'Fire drill'));
$h = $admin->get('admin/announcement-history.php?sort=title&dir=asc')['body'];
ok('history sort by title', strpos($h, 'Fire drill') < strpos($h, 'Hello all') && strpos($h, 'Hello all') < strpos($h, 'Officer memo'));
$h = $admin->get('admin/announcement-history.php?sort=reads&dir=desc')['body'];
ok('history sort by read count', strpos($h, 'Monday duty briefing') < strpos($h, 'Officer memo'));
ok('history empty state', has($admin->get('admin/announcement-history.php?q=nothingmatches')['body'], 'No announcements match your filters'));

/* expiry and archive */
dbx("UPDATE announcements SET expires_at = ? WHERE id = ?", [date('Y-m-d H:i:s', strtotime('-1 hour')), $a4]);
ok('expired announcement leaves the current inbox', !has($st1->get('my-announcements.php')['body'], 'Hello all'));
ok('…and appears in the archive tab', has($st1->get('my-announcements.php?tab=archive')['body'], 'Hello all'));
ok('history shows it as Expired', has($admin->get('admin/announcement-history.php?status=expired')['body'], 'Hello all') && !has($admin->get('admin/announcement-history.php?status=active')['body'], 'Hello all'));
ok('expired announcements no longer count as unread', announcements_unread_summary(uid('stud2'))['unread'] === announcements_unread_summary(uid('stud2'))['unread'] && !has($st2->get('my-announcements.php')['body'], 'Hello all'));

/* cancel */
$r = $dir->post('admin/announcement-view.php?id=' . $a1, ['action' => 'cancel', 'id' => $a1], 'admin/announcement-view.php?id=' . $a1);
ok('owner cancels their announcement', has($r['body'], 'Announcement cancelled') && dbv('SELECT status FROM announcements WHERE id = ?', [$a1]) === 'cancelled');
ok('cancelled: recipients get 404 and bell items are removed', $st1->get('my-announcements.php?id=' . $a1, false)['status'] === 404 && (int) dbv("SELECT COUNT(*) FROM notifications WHERE ref = ?", ['announcement:' . $a1]) === 0);
ok('cancelled: receipts and history are preserved', (int) dbv('SELECT COUNT(*) FROM announcement_recipients WHERE announcement_id = ?', [$a1]) === $nAll && has($admin->get('admin/announcement-history.php?status=cancelled')['body'], 'Monday duty briefing'));
ok('cancelled announcement cannot be edited', has($dir->post('admin/announcement-view.php?id=' . $a1, ['action' => 'update', 'id' => $a1, 'title' => 'again', 'message' => 'x', 'priority' => 'normal'], 'admin/announcements.php')['body'], 'cannot be edited') && dbv('SELECT title FROM announcements WHERE id = ?', [$a1]) !== 'again');
ok('announcement audit trail exists (create, update, cancel)', (int) dbv("SELECT COUNT(DISTINCT action) FROM audit_logs WHERE table_name = 'announcements'") >= 2 && (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE table_name = 'announcements' AND description LIKE 'Cancelled%'") === 1);

/* =========================================================================================== */
section('Deactivation, reactivation and history preservation');
att($sTue, $yesterday, '08:00', '12:00');
$attBefore = (int) dbv('SELECT COUNT(*) FROM attendance WHERE student_id = ?', [$sTue]);
$r = $admin->post('admin/students.php', ['action' => 'deactivate', 'id' => $sTue], 'admin/students.php');
ok('admin deactivates a student', has($r['body'], 'Student deactivated') && dbv('SELECT status FROM students WHERE id = ?', [$sTue]) === 'Inactive' && (int) dbv("SELECT is_active FROM users WHERE username = 'stud3'") === 0);
ok('attendance history is preserved', (int) dbv('SELECT COUNT(*) FROM attendance WHERE student_id = ?', [$sTue]) === $attBefore);
$r = $st3->get('student/dashboard.php', false);
ok('an already-open session is signed out on the next click', $r['status'] === 403 || $r['status'] === 302);
$c = new Client($BASE, 'stud3b'); $r = $c->login('stud3', 'Student#1234');
ok('deactivated student cannot sign in (clear message)', has($r['body'], 'has been deactivated') && !has($r['body'], 'My Logbook'));
ok('wrong password still looks like an ordinary failure (no account probing)', has((new Client($BASE, 'x'))->login('stud3', 'nope')['body'], 'Invalid username or password'));
ok('deactivated students receive no new announcements', (int) dbv("SELECT COUNT(*) FROM announcement_recipients r JOIN announcements a ON a.id = r.announcement_id WHERE r.user_id = ? AND a.id > ?", [uid('stud3'), $a4]) === 0);
ok('…and cannot be recorded for new attendance', has($admin->post('admin/attendance.php', ['action' => 'save', 'student_id' => $sTue, 'attendance_date' => $today, 'morning_in' => '08:00', 'morning_out' => '09:00'], 'admin/record-attendance.php')['body'], 'Active students'));
$r = $admin->post('admin/students.php', ['action' => 'deactivate', 'id' => $sTue], 'admin/students.php');
ok('deactivating twice gives a clear message', has($r['body'], 'already inactive'));
$r = $admin->post('admin/students.php', ['action' => 'reactivate', 'id' => $sTue], 'admin/students.php');
ok('reactivation restores status and login', has($r['body'], 'Student reactivated') && dbv('SELECT status FROM students WHERE id = ?', [$sTue]) === 'Active' && has((new Client($BASE, 's3c'))->login('stud3', 'Student#1234')['body'], 'My Logbook'));
$p = $admin->get('admin/student-view.php?id=' . $sMon1)['body'];
ok('student summary: profile, account, hours, remaining, history', has($p, 'Profile') && has($p, 'Account') && has($p, 'stud1') && has($p, '2026-0001') && has($p, 'remaining') && has($p, 'Attendance History') && has($p, '6h 30m'));
ok('student without a login explains it', has($admin->get('admin/student-view.php?id=' . $sNoLogin)['body'], 'No login created'));
ok('unknown student id is a 404', $admin->get('admin/student-view.php?id=99999', false)['status'] === 404);
$r = $admin->post('admin/students.php', ['action' => 'delete', 'id' => $sNoLogin], 'admin/students.php');
ok('permanent delete still works (existing feature kept)', has($r['body'], 'Student deleted') && (int) dbv('SELECT COUNT(*) FROM students WHERE id = ?', [$sNoLogin]) === 0);

/* =========================================================================================== */
section('CSV import: preview, validation, duplicates, commit, reset links');
$csv = "student_number,first_name,middle_name,last_name,course,duty_day,position,status\n"
     . "IMP-001,Ivy,M,Ibarra,BSCS,Monday,,Active\n"
     . "IMP-002,Jon,,Jimenez,BSIT,Tuesday,,Active\n"
     . "2026-0001,Dupe,,Existing,BSCS,Monday,,Active\n"
     . "IMP-001,Dupe,,InFile,BSCS,Monday,,Active\n"
     . "IMP-003,Bad,,Day,BSCS,Funday,,Active\n"
     . "IMP-004,,,NoFirst,BSCS,Monday,,Active\n"
     . "IMP-005,Bad,,Pos,BSCS,Monday,Nonsense,Active\n";
$tmp = tempnam(sys_get_temp_dir(), 'csv'); file_put_contents($tmp, $csv);
$studentsBefore = (int) dbv('SELECT COUNT(*) FROM students');
$token = $admin->csrf('admin/student-import.php');
$r = $admin->req('POST', 'admin/student-import.php', ['csrf' => $token, 'action' => 'upload'], true, ['csv' => new CURLFile($tmp, 'text/csv', 'students.csv')]);
ok('preview is shown after upload', has($r['body'], 'Preview: students.csv') && has($r['body'], 'Nothing has been saved yet'));
ok('NOTHING is saved by the preview', (int) dbv('SELECT COUNT(*) FROM students') === $studentsBefore);
ok('preview: 2 ready, 2 duplicates, 3 errors', preg_match('/Ready to import.*?>2<.*?Duplicates.*?>2<.*?Errors.*?>3</s', $r['body']) === 1);
ok('preview names the problems', has($r['body'], 'A student with this number already exists') && has($r['body'], 'Same student number as line 2') && has($r['body'], 'valid duty day') && has($r['body'], 'First name is required') && has($r['body'], 'valid position'));
$r = $admin->post('admin/student-import.php', ['action' => 'commit', 'import_token' => 'wrong'], 'admin/student-import.php');
ok('commit without the right preview token is refused', has($r['body'], 'preview has expired') && (int) dbv('SELECT COUNT(*) FROM students') === $studentsBefore);
$pv = $admin->get('admin/student-import.php')['body'];
preg_match('/name="import_token" value="([a-f0-9]+)"/', $pv, $m);
$r = $admin->post('admin/student-import.php', ['action' => 'commit', 'import_token' => $m[1] ?? '', 'create_logins' => '1'], 'admin/student-import.php');
ok('commit imports only the valid rows', has($r['body'], 'Import finished: 2 students added') && (int) dbv('SELECT COUNT(*) FROM students') === $studentsBefore + 2 && (int) dbv("SELECT COUNT(*) FROM students WHERE student_number IN ('IMP-001','IMP-002')") === 2);
ok('the existing student with the duplicate number was not changed', dbv("SELECT last_name FROM students WHERE student_number = '2026-0001'") === 'Alba');
ok('logins were created with an UNUSABLE password (no shared default)', (int) dbv("SELECT COUNT(*) FROM users WHERE username IN ('IMP-001','IMP-002')") === 2 && !password_verify('IMP-001', (string) dbv("SELECT password FROM users WHERE username = 'IMP-001'")));
ok('reset tokens are stored hashed (64-hex), never in plain text', (int) dbv('SELECT COUNT(*) FROM password_resets WHERE LENGTH(token_hash) = 64') === 2);
$dl = $admin->get('admin/student-import.php?download_links=1');
ok('reset links download as CSV once', has($dl['type'], 'text/csv') && has($dl['body'], 'reset-password.php?token=') && substr_count($dl['body'], 'IMP-00') >= 2);
ok('…and are gone afterwards', !has($admin->get('admin/student-import.php?download_links=1')['body'], 'reset-password.php?token='));
preg_match('/IMP-001.*?(http[^,"\s]+token=([a-f0-9]{64}))/s', $dl['body'], $lk);
$link = $lk[1] ?? ''; $tok = $lk[2] ?? '';
ok('link works for a new student: shows the set-password form', $link !== '' && has($anon->get($link)['body'], 'Set a new password'));
ok('import is audited', (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE description LIKE 'Student CSV import:%'") === 1 && (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE description LIKE 'Imported student from CSV%'") === 2);
$tpl = $admin->get('admin/student-import.php?template=1');
ok('template downloads', has($tpl['type'], 'text/csv') && has($tpl['body'], 'student_number'));
file_put_contents($tmp, "name,age\nx,1\n");
$r = $admin->req('POST', 'admin/student-import.php', ['csrf' => $admin->csrf('admin/student-import.php'), 'action' => 'upload'], true, ['csv' => new CURLFile($tmp, 'text/csv', 'bad.csv')]);
ok('file without the required columns is refused with a clear message', has($r['body'], 'Missing required column'));
file_put_contents($tmp, 'x');
$r = $admin->req('POST', 'admin/student-import.php', ['csrf' => $admin->csrf('admin/student-import.php'), 'action' => 'upload'], true, ['csv' => new CURLFile($tmp, 'text/csv', 'evil.php')]);
ok('non-CSV extension refused', has($r['body'], 'Only .csv files'));
unlink($tmp);

/* =========================================================================================== */
section('Password reset (single-use, expiring, hashed) and account deactivation for officers');
$mgrId = uid('mgr1');
$r = $admin->post('admin/officers.php', ['action' => 'reset_link', 'id' => $mgrId], 'admin/officers.php');
preg_match('/value="(http[^"]+reset-password\.php\?token=([a-f0-9]{64}))"/', $r['body'], $m);
$rl = $m[1] ?? ''; $rt = $m[2] ?? '';
ok('admin creates a reset link for an officer and sees it once', $rl !== '' && has($r['body'], 'works <strong>once</strong>'));
ok('…not shown again on reload', !has($admin->get('admin/officers.php')['body'], 'reset-password.php?token='));
ok('token is stored only as a SHA-256 hash', (int) dbv('SELECT COUNT(*) FROM password_resets WHERE token_hash = ?', [hash('sha256', $rt)]) === 1 && (int) dbv('SELECT COUNT(*) FROM password_resets WHERE token_hash = ?', [$rt]) === 0);
ok('audit log notes the link creation but never the token', (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE description LIKE 'Created a password-reset link for mgr1%'") === 1 && (int) dbv('SELECT COUNT(*) FROM audit_logs WHERE description LIKE ?', ['%' . $rt . '%']) === 0);
$page = $anon->get($rl)['body'];
ok('valid link shows the form for that user', has($page, 'Set a new password') && has($page, 'mgr1'));
$tokenCsrf = (function () use ($page) { preg_match('/name="csrf" value="([a-f0-9]{64})"/', $page, $m); return $m[1] ?? ''; })();
$r = $anon->req('POST', 'reset-password.php', ['csrf' => $tokenCsrf, 'token' => $rt, 'new_password' => 'short', 'confirm_password' => 'short']);
ok('short password refused, link still valid', has($r['body'], 'at least') && (int) dbv('SELECT COUNT(*) FROM password_resets WHERE token_hash = ? AND used_at IS NULL', [hash('sha256', $rt)]) === 1);
$r = $anon->req('POST', 'reset-password.php', ['csrf' => $tokenCsrf, 'token' => $rt, 'new_password' => 'Brand#New1234', 'confirm_password' => 'Mismatch#1234']);
ok('mismatched confirmation refused', has($r['body'], 'do not match'));
$r = $anon->req('POST', 'reset-password.php', ['csrf' => 'bad', 'token' => $rt, 'new_password' => 'Brand#New1234', 'confirm_password' => 'Brand#New1234']);
ok('reset form requires CSRF token', has($r['body'], 'session expired') && password_verify('Officer#1234', (string) dbv('SELECT password FROM users WHERE id = ?', [$mgrId])));
$r = $anon->req('POST', 'reset-password.php', ['csrf' => $tokenCsrf, 'token' => $rt, 'new_password' => 'Brand#New1234', 'confirm_password' => 'Brand#New1234']);
ok('valid reset sets the password', has($r['body'], 'Your password has been set') && password_verify('Brand#New1234', (string) dbv('SELECT password FROM users WHERE id = ?', [$mgrId])));
ok('the old password no longer works; the new one does', has((new Client($BASE, 'o'))->login('mgr1', 'Officer#1234')['body'], 'Invalid username') && has((new Client($BASE, 'n'))->login('mgr1', 'Brand#New1234')['body'], 'Attendance'));
ok('the open session of the officer was invalidated by the password change', $mgr->get('admin/attendance.php', false)['status'] !== 200);
$r = $anon->req('POST', 'reset-password.php', ['csrf' => $tokenCsrf, 'token' => $rt, 'new_password' => 'Another#12345', 'confirm_password' => 'Another#12345']);
ok('a used link cannot be used again', has($r['body'], 'invalid, expired or has already been used') && password_verify('Brand#New1234', (string) dbv('SELECT password FROM users WHERE id = ?', [$mgrId])));
ok('the password-set event is audited', (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE description LIKE 'Password set using a reset link by mgr1'") === 1);
$r = $admin->post('admin/officers.php', ['action' => 'reset_link', 'id' => $mgrId], 'admin/officers.php');
preg_match('/token=([a-f0-9]{64})/', $r['body'], $m); $t2 = $m[1] ?? '';
$r = $admin->post('admin/officers.php', ['action' => 'reset_link', 'id' => $mgrId], 'admin/officers.php');
ok('a newer link invalidates the previous unused one', has($anon->get('reset-password.php?token=' . $t2)['body'], 'invalid, expired or has already been used'));
preg_match('/token=([a-f0-9]{64})/', $r['body'], $m); $t3 = $m[1] ?? '';
dbx('UPDATE password_resets SET expires_at = ? WHERE token_hash = ?', [date('Y-m-d H:i:s', strtotime('-1 minute')), hash('sha256', $t3)]);
ok('an expired link is refused', has($anon->get('reset-password.php?token=' . $t3)['body'], 'invalid, expired or has already been used'));
ok('garbage tokens are refused', has($anon->get('reset-password.php?token=abc')['body'], 'invalid, expired') && has($anon->get('reset-password.php')['body'], 'invalid, expired'));
$r = $admin->post('admin/officers.php', ['action' => 'reset_link', 'id' => uid('admin')], 'admin/officers.php');
ok('no reset link can be created for the administrator account', (int) dbv('SELECT COUNT(*) FROM password_resets WHERE user_id = ?', [uid('admin')]) === 0);

/* officer lifecycle */
$mgrNew = new Client($BASE, 'mgrNew'); $mgrNew->login('mgr1', 'Brand#New1234');
$recordedByMgr = (int) dbv('SELECT COUNT(*) FROM attendance WHERE recorded_by = ?', [$mgrId]);
$r = $admin->post('admin/officers.php', ['action' => 'deactivate', 'id' => $mgrId], 'admin/officers.php');
ok('admin deactivates an officer', has($r['body'], 'Account deactivated') && (int) dbv('SELECT is_active FROM users WHERE id = ?', [$mgrId]) === 0);
ok('officer is signed out at once', $mgrNew->get('admin/attendance.php', false)['status'] !== 200);
ok('officer cannot sign in while deactivated', has((new Client($BASE, 'd'))->login('mgr1', 'Brand#New1234')['body'], 'has been deactivated'));
ok('attendance they recorded is kept', (int) dbv('SELECT COUNT(*) FROM attendance WHERE recorded_by = ?', [$mgrId]) === $recordedByMgr);
ok('reset links are refused for deactivated accounts', has($admin->post('admin/officers.php', ['action' => 'reset_link', 'id' => $mgrId], 'admin/officers.php')['body'], 'Reactivate the account'));
$list = $admin->get('admin/officers.php')['body'];
ok('officer list shows role AND status with text', has($list, 'External Vice President') && has($list, 'Deactivated') && has($list, 'Active'));
$r = $admin->post('admin/officers.php', ['action' => 'reactivate', 'id' => $mgrId], 'admin/officers.php');
ok('reactivation works', has($r['body'], 'Account reactivated') && has((new Client($BASE, 'r'))->login('mgr1', 'Brand#New1234')['body'], 'Attendance'));
$r = $admin->post('admin/officers.php', ['action' => 'deactivate', 'id' => uid('admin')], 'admin/officers.php');
ok('the administrator account cannot be deactivated here', (int) dbv("SELECT is_active FROM users WHERE username = 'admin'") === 1);
$r = $admin->post('admin/officers.php', ['action' => 'update', 'id' => $mgrId, 'username' => 'mgr1', 'role' => 'secretary', 'password' => ''], 'admin/officers.php');
ok('role change saves and is audited with old/new values', dbv('SELECT role FROM users WHERE id = ?', [$mgrId]) === 'secretary' && (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE table_name = 'users' AND record_id = ? AND action = 'UPDATE'", [$mgrId]) >= 1);
$r = $admin->post('admin/officers.php', ['action' => 'create', 'id' => 0, 'username' => 'x', 'role' => 'president', 'password' => 'longpassword1'], 'admin/officers.php');
ok('invalid username shows an inline message and keeps the input', has($r['body'], 'id="err-username"') && (int) dbv("SELECT COUNT(*) FROM users WHERE username = 'x'") === 0);
$r = $admin->post('admin/officers.php', ['action' => 'create', 'username' => 'newdir', 'role' => 'president', 'password' => 'short'], 'admin/officers.php');
ok('short password refused on the password field', has($r['body'], 'id="err-password"'));
$r = $admin->post('admin/officers.php', ['action' => 'create', 'username' => 'newdir', 'role' => 'admin', 'password' => 'longpassword1'], 'admin/officers.php');
ok('an officer account cannot be created with the admin role (privilege escalation blocked)', (int) dbv("SELECT COUNT(*) FROM users WHERE username = 'newdir'") === 0);
$r = $admin->post('admin/officers.php', ['action' => 'update', 'id' => uid('admin'), 'username' => 'admin', 'role' => 'president', 'password' => ''], 'admin/officers.php');
ok('the admin account cannot be edited through the officers page', dbv("SELECT role FROM users WHERE username = 'admin'") === 'admin');
$r = $admin->post('admin/officers.php', ['action' => 'update', 'id' => $mgrId, 'username' => 'mgr1', 'role' => 'external_vp', 'password' => ''], 'admin/officers.php');

/* =========================================================================================== */
section('Duty-hour progress, dashboards, reports (screen = CSV = PDF)');
$sDone = mkStudent('2026-0777', 'Dora', 'Done', 'BSCS', 'Wednesday', 'stud7');
foreach ($earlyDays as $d) { att($sDone, $d, '08:00', '12:00', '13:00', '17:00'); }   // 16 days x 8h = 128h
$sHalf = mkStudent('2026-0778', 'Hal', 'Half', 'BSIT', 'Wednesday', 'stud8');
foreach (array_slice($earlyDays, 0, 6) as $d) { att($sHalf, $d, '08:00', '12:00', '13:00', '17:00'); }  // 6 x 8h = 48h
$sPrev = mkStudent('2026-0779', 'Pia', 'Prev', 'BSIT', 'Wednesday', 'stud9');
att($sPrev, ($thisYear - 1) . '-12-30', '08:00', '12:00', '13:00', '17:00'); // last year only: must not count toward this year
$pDone = attendance_year_progress(attendance_for_student($sDone));
$pHalf = attendance_year_progress(attendance_for_student($sHalf));
$pPrev = attendance_year_progress(attendance_for_student($sPrev));
ok('progress: 128h completed, 0 remaining, 100%', $pDone['minutes'] === 7680 && $pDone['remaining'] === 0 && $pDone['percent'] === 100.0);
ok('progress: 48h completed, 52h remaining', $pHalf['minutes'] === 2880 && $pHalf['remaining'] === 3120);
ok("last year's hours do not count toward this year", $pPrev['minutes'] === 0);

$st8 = new Client($BASE, 'stud8'); $st8->login('stud8', 'Student#1234');
$d8 = $st8->get('student/dashboard.php')['body'];
ok('student dashboard: completed 48h / required 100h / remaining 52h', has($d8, '48h') && has($d8, '52h') && has($d8, '100h') && has($d8, '48.0%'));
ok('student dashboard: progress bar, reminder and monthly chart', has($d8, 'role="progressbar"') && has($d8, 'Reminder') && has($d8, '<svg class="chart"') && has($d8, 'Hours per month'));
ok('student dashboard: 6 days present this year', preg_match('/Days Present \(' . $thisYear . '\).*?>6</s', $d8) === 1);
ok('student dashboard: newest records first', strpos($d8, format_date($earlyDays[5])) < strpos($d8, format_date($earlyDays[0])));
$st9 = new Client($BASE, 'stud9'); $st9->login('stud9', 'Student#1234');
ok('student with only last-year hours: 100h remaining this year', has($st9->get('student/dashboard.php')['body'], '100h'));
$sEmpty = mkStudent('2026-0780', 'Eve', 'Empty', 'BSCS', 'Thursday', 'stud10');
$st10 = new Client($BASE, 'stud10'); $st10->login('stud10', 'Student#1234');
$d10 = $st10->get('student/dashboard.php')['body'];
ok('student with no records sees a helpful empty state', has($d10, 'No attendance recorded yet') && has($d10, 'You have not logged any duty hours yet'));

/* three incomplete records, dated this January, for the dashboard and report checks below */
$sInc = mkStudent('2026-0790', 'Ida', 'Incomplete', 'BSCS', 'Thursday');
att($sInc, $thisYear . '-01-20', '08:00', null);            // time-in, no time-out
att($sInc, $thisYear . '-01-21', null, null, null, '16:00'); // time-out only
att($sInc, $thisYear . '-01-22', null, null, null, null);    // empty

/* admin dashboard vs the database */
$dash = $admin->get('admin/dashboard.php')['body'];
$activeCount = (int) dbv("SELECT COUNT(*) FROM students WHERE status = 'Active'");
ok('dashboard: active students = DB count', preg_match('/Active Students.*?stat-value">' . $activeCount . '</s', $dash) === 1, "expected $activeCount");
$presentToday = (int) dbv('SELECT COUNT(*) FROM attendance WHERE attendance_date = ? AND (morning_time_in IS NOT NULL OR afternoon_time_in IS NOT NULL)', [$today]);
ok('dashboard: present today = DB count', preg_match('/Present Today.*?stat-value">' . $presentToday . '</s', $dash) === 1, "expected $presentToday");
ok('dashboard: total logged = DB sum', has($dash, format_duration((int) attendance_total_minutes())));
$openToday = (int) dbv('SELECT COUNT(*) FROM attendance WHERE attendance_date = ? AND ((morning_time_in IS NOT NULL AND morning_time_out IS NULL) OR (afternoon_time_in IS NOT NULL AND afternoon_time_out IS NULL))', [$today]);
ok('dashboard: open sessions = DB count', preg_match('/Currently In.*?stat-value">' . $openToday . '</s', $dash) === 1);
$below = (int) dbv("SELECT COUNT(*) FROM (SELECT s.id, COALESCE(SUM(TIMESTAMPDIFF(MINUTE, CONCAT('2000-01-01 ', a.morning_time_in), CONCAT('2000-01-01 ', a.morning_time_out))), 0) + COALESCE(SUM(TIMESTAMPDIFF(MINUTE, CONCAT('2000-01-01 ', a.afternoon_time_in), CONCAT('2000-01-01 ', a.afternoon_time_out))), 0) AS m FROM students s LEFT JOIN attendance a ON a.student_id = s.id AND YEAR(a.attendance_date) = ? WHERE s.status = 'Active' GROUP BY s.id) t WHERE m < 6000", [$thisYear]);
ok('dashboard: students below ' . REQUIRED_HOURS . 'h = independent SQL count (' . $below . ')', has($dash, plural($below, 'active student') . '</strong> of ' . $activeCount) || has($dash, '<strong>' . plural($below, 'active student')));
ok('dashboard: outstanding list is shown, caps at 6 and excludes the student who finished', has($dash, 'behind-list') && substr_count($dash, 'behind-name') <= 6 && !has($dash, 'Dora') && has($dash, 'Showing the'));
ok('dashboard: quick actions to announcements, students, attendance, reports, officers', has($dash, 'admin/announcements.php') && has($dash, 'admin/students.php') && has($dash, 'admin/attendance.php') && has($dash, 'reports/monthly.php') && has($dash, 'admin/officers.php'));
ok('dashboard: status indicators carry text', has($dash, 'status-') && (has($dash, 'Pending') || has($dash, 'Urgent')));

/* outstanding report */
$o = $admin->get('reports/outstanding.php')['body'];
ok('outstanding report lists students below 100h and not the finished one', has($o, 'Half') && has($o, 'Prev') && !has($o, 'Done, Dora') && !has($o, 'Dora'));
ok('outstanding report shows hours and remaining', has($o, '48h') && has($o, '52h'));
ok('outstanding report: course filter', !has($admin->get('reports/outstanding.php?course=BSCS')['body'], 'Half') && has($admin->get('reports/outstanding.php?course=BSIT')['body'], 'Half'));
ok('outstanding report: sort by remaining asc puts Half before Prev', ($p = $admin->get('reports/outstanding.php?sort=remaining&dir=asc')['body']) && strpos($p, 'Half') < strpos($p, 'Prev'));
ok('outstanding report: empty state', has($admin->get('reports/outstanding.php?q=zzzz')['body'], 'No students match your filters'));
ok('outstanding report: another year works', has($admin->get('reports/outstanding.php?report_year=' . ($thisYear - 1))['body'], 'Prev'));

/* monthly: screen vs CSV vs PDF */
$month = date('Y-m');
$screen = $admin->get('reports/monthly.php?month=' . $month . '&course=BSIT')['body'];
$csvR   = $admin->get('reports/export.php?report=monthly&format=csv&month=' . $month . '&course=BSIT');
$csvHead = str_getcsv(strtok(substr($csvR['body'], 3), "\n"));
ok('CSV: UTF-8 BOM and the original column headings', has($csvR['type'], 'text/csv') && str_starts_with($csvR['body'], "\xEF\xBB\xBF") && array_slice($csvHead, 0, 6) === ['Student Number', 'Name', 'Course', 'Duty Day', 'Status', 'Days Present'] && count($csvHead) === 10);
$csvRows = array_map('str_getcsv', array_values(array_filter(explode("\n", trim(substr($csvR['body'], 3))))));
array_shift($csvRows);
$screenNumbers = []; preg_match_all('/(2026-0\d{3}|IMP-\d{3})/', strip_tags($screen), $mm); $screenNumbers = array_unique($mm[1]);
$csvNumbers = array_unique(array_column($csvRows, 0));
sort($screenNumbers); sort($csvNumbers);
ok('CSV rows = on-screen rows for the same filters', $screenNumbers === $csvNumbers && count($csvNumbers) > 0, json_encode([$screenNumbers, $csvNumbers]));
ok('CSV excludes filtered-out students', !in_array('2026-0777', $csvNumbers, true));
$ytd = array_column($csvRows, 7, 0);
ok('CSV year-to-date hours match the screen', ($ytd['2026-0778'] ?? '') === '48h 0m' && has($screen, '48h 0m'));
$legacy = $admin->get('reports/export-csv.php?month=' . $month . '&course=BSIT');
ok('legacy export-csv.php URL still works and matches', $legacy['body'] === $csvR['body']);
$pdfR = $admin->get('reports/export.php?report=monthly&format=pdf&month=' . $month . '&course=BSIT');
ok('PDF: correct content type and signature', $pdfR['type'] === 'application/pdf' && str_starts_with($pdfR['body'], '%PDF-1.4'));
file_put_contents('/tmp/monthly.pdf', $pdfR['body']);
$txt = (string) shell_exec('pdftotext -layout /tmp/monthly.pdf - 2>/dev/null');
ok('PDF text: title, period, generated-by line, student, totals', has($txt, 'Monthly Duty-Hour Report') && has($txt, 'Period:') && has($txt, 'Generated on') && has($txt, 'admin (Administrator)') && has($txt, 'Half') && has($txt, 'Total'));
ok('PDF honours the filter (BSCS student absent)', !has($txt, 'Done, Dora') && !has($txt, 'Alba'));
$pdfEmpty = $admin->get('reports/export.php?report=monthly&format=pdf&q=zzzzz');
file_put_contents('/tmp/empty.pdf', $pdfEmpty['body']);
ok('empty PDF is still valid and says so', str_starts_with($pdfEmpty['body'], '%PDF') && has((string) shell_exec('pdftotext /tmp/empty.pdf - 2>/dev/null'), 'No records match'));
$csvEmpty = $admin->get('reports/export.php?report=monthly&format=csv&q=zzzzz');
ok('empty CSV has only the header', count(array_filter(explode("\n", trim(substr($csvEmpty['body'], 3))))) === 1);
ok('monthly screen shows empty state', has($admin->get('reports/monthly.php?q=zzzzz')['body'], 'No students match your filters'));
$o_csv = $admin->get('reports/export.php?report=outstanding&format=csv');
$oRows = array_map('str_getcsv', array_values(array_filter(explode("\n", trim(substr($o_csv['body'], 3))))));
$oNums = array_column(array_slice($oRows, 1), 0);
ok('outstanding CSV = outstanding screen', !in_array('2026-0777', $oNums, true) && in_array('2026-0778', $oNums, true) && in_array('2026-0779', $oNums, true) && has($o, '2026-0778') === in_array('2026-0778', $oNums, true));
$o_pdf = $admin->get('reports/export.php?report=outstanding&format=pdf');
file_put_contents('/tmp/out.pdf', $o_pdf['body']);
ok('outstanding PDF is valid and lists the student', str_starts_with($o_pdf['body'], '%PDF') && has((string) shell_exec('pdftotext -layout /tmp/out.pdf - 2>/dev/null'), 'Half'));
ok('unknown export type is refused', $admin->get('reports/export.php?report=students&format=csv', false)['status'] === 400);
ok('exports are audited', (int) dbv("SELECT COUNT(*) FROM audit_logs WHERE action = 'EXPORT'") >= 4);
$a = $admin->get('reports/analytics.php')['body'];
ok('analytics: monthly + yearly charts, by course and by duty day', has($a, '<svg class="chart"') && has($a, 'Hours per month') && has($a, 'Hours per year') && has($a, 'By course') && has($a, 'By duty day') && has($a, 'BSCS') && has($a, 'Wednesday'));
ok('analytics: chart has a text alternative (table + title)', has($a, 'View data as a table') && has($a, '<title id="chart-t'));
ok('analytics: filters work', !has($admin->get('reports/analytics.php?course=BSIT')['body'], 'hbar-label">BSCS<') && has($admin->get('reports/analytics.php?course=BSIT')['body'], 'hbar-label">BSIT<'));
ok('analytics: empty state', has($admin->get('reports/analytics.php?report_year=1999')['body'], 'No attendance data') || has($admin->get('reports/analytics.php?report_year=1999')['body'], 'Hours per year'));
ok('print layout identifies the report', has($screen, 'print-only') && has($screen, 'Generated on'));

/* =========================================================================================== */
section('Navigation and links: permission-aware menus; no broken internal links');
$menu = fn(Client $c, string $page) => $c->get($page)['body'];
$am = $menu($admin, 'admin/dashboard.php');
ok('admin menu has every admin area', has($am, 'admin/students.php') && has($am, 'admin/corrections.php') && has($am, 'reports/monthly.php') && has($am, 'admin/officers.php') && has($am, 'admin/audit-logs.php') && has($am, 'admin/announcements.php'));
$mgrFresh = new Client($BASE, 'mgrFresh'); $mgrFresh->login('mgr1', 'Brand#New1234');
$mm_ = $menu($mgrFresh, 'admin/attendance.php');
ok('manager menu hides admin-only links', !has($mm_, 'admin/students.php') && !has($mm_, 'reports/monthly.php') && !has($mm_, 'admin/officers.php') && !has($mm_, 'admin/announcements.php') && has($mm_, 'my-announcements.php'));
$dm = $menu($dir, 'admin/attendance.php');
ok('director menu includes announcement management only in addition', has($dm, 'admin/announcements.php') && !has($dm, 'admin/students.php'));
$sm = $menu($st1, 'student/dashboard.php');
ok('student menu: dashboard, corrections, announcements only', has($sm, 'student/corrections.php') && has($sm, 'my-announcements.php') && !has($sm, 'admin/') && !has($sm, 'reports/'));
ok('active menu item is marked (aria-current)', has($am, 'aria-current="page"'));
ok('menu has a mobile toggle with ARIA state', has($am, 'data-menu-toggle') && has($am, 'aria-expanded="false"') && has($am, 'aria-controls="site-nav"'));
ok('pages carry breadcrumbs back to the dashboard', has($admin->get('admin/announcement-history.php')['body'], 'aria-label="Breadcrumb"') && has($admin->get('reports/outstanding.php')['body'], 'Breadcrumb'));
ok('pages set the viewport meta tag for mobile', has($am, 'name="viewport"'));
ok('skip-to-content link exists for keyboard users', has($am, 'skip-link'));

function crawl(Client $c, array $seeds, string $base): array
{
    $seen = []; $queue = $seeds; $bad = [];
    while ($queue && count($seen) < 120) {
        $path = array_shift($queue);
        if (isset($seen[$path])) { continue; }
        $seen[$path] = true;
        $r = $c->get($path, false);
        if ($r['status'] >= 400 && $r['status'] !== 403) { $bad[] = "$path => {$r['status']}"; continue; }
        if ($r['status'] !== 200 || !has($r['type'], 'html')) { continue; }
        preg_match_all('/href="([^"#]+)"/', $r['body'], $m);
        foreach ($m[1] as $href) {
            $href = html_entity_decode($href);
            if (preg_match('#^(https?:|mailto:|javascript:|data:)#', $href) || str_contains($href, 'logout.php') || str_contains($href, 'download_links') || str_contains($href, 'assets/') || str_contains($href, 'export')) { continue; }
            $queue[] = ltrim(preg_replace('#^\.\./#', '', $href), '/');
        }
    }
    return [count($seen), $bad];
}
$mgr2 = new Client($BASE, 'mgr2'); $mgr2->login('mgr1', 'Brand#New1234');
[$n, $bad] = crawl($admin, ['admin/dashboard.php'], $BASE);
ok("crawl as admin: $n pages, no broken links", $bad === [], implode('; ', $bad));
[$n, $bad] = crawl($st1, ['student/dashboard.php'], $BASE);
ok("crawl as student: $n pages, no broken links", $bad === [], implode('; ', $bad));
[$n, $bad] = crawl($dir, ['admin/attendance.php'], $BASE);
ok("crawl as director: $n pages, no broken links", $bad === [], implode('; ', $bad));


/* =========================================================================================== */
section('Existing features still work: edit dialogs, officer delete, student reset link');
$e = $admin->get('admin/students.php?edit=' . $sMon1)['body'];
ok('student edit dialog opens pre-filled', has($e, 'Edit Student') && has($e, 'value="Alba"') && has($e, 'value="stud1"') && preg_match('/modal is-open/', $e) === 1);
$e = $admin->get('admin/officers.php?edit=' . uid('director1'))['body'];
ok('officer edit dialog opens pre-filled with a role-change confirmation hook', has($e, 'value="director1"') && has($e, 'data-confirm-change-select="role"') && has($e, 'data-original="president"'));
$r = $admin->post('admin/student-view.php?id=' . $sMon1, ['action' => 'reset_link', 'id' => $sMon1], 'admin/student-view.php?id=' . $sMon1);
preg_match('/value="(http[^"]+token=([a-f0-9]{64}))"/', $r['body'], $m);
ok('student page issues a one-time reset link', !empty($m[1]) && has($r['body'], 'works <strong>once</strong>'));
$anon2 = new Client($BASE, 'anon2'); $pg = $anon2->get($m[1])['body']; preg_match('/name="csrf" value="([a-f0-9]{64})"/', $pg, $cm);
$r = $anon2->req('POST', 'reset-password.php', ['csrf' => $cm[1] ?? '', 'token' => $m[2] ?? '', 'new_password' => 'Chosen#Pass99', 'confirm_password' => 'Chosen#Pass99']);
ok('student chooses their own password via the link and can sign in', has($r['body'], 'Your password has been set') && has((new Client($BASE, 'q'))->login('stud1', 'Chosen#Pass99')['body'], 'My Logbook'));
$tmpId = mkOfficer('tempofficer', 'external_vp');
$r = $admin->post('admin/officers.php', ['action' => 'delete', 'id' => $tmpId], 'admin/officers.php');
ok('officer delete (existing feature) still works', has($r['body'], 'Officer account deleted') && (int) dbv('SELECT COUNT(*) FROM users WHERE id = ?', [$tmpId]) === 0);
$r = $admin->post('admin/officers.php', ['action' => 'delete', 'id' => uid('admin')], 'admin/officers.php');
ok('the administrator account cannot be deleted through the officers page', (int) dbv("SELECT COUNT(*) FROM users WHERE username = 'admin'") === 1);
ok('change-password page still works for each role', $st2->get('change-password.php')['status'] === 200 && $dir->get('change-password.php')['status'] === 200);
ok('audit log page lists the new events', has($admin->get('admin/audit-logs.php?q=reset')['body'], 'reset'));

/* =========================================================================================== */
section('Output safety');
$xss = '<script>alert(1)</script>';
$admin->post('admin/announcements.php', ['audience' => 'students', 'priority' => 'normal', 'title' => $xss, 'message' => $xss . "\n<img src=x onerror=alert(1)>"], 'admin/announcements.php');
$xid = (int) dbv("SELECT id FROM announcements WHERE title = ?", [$xss]);
$vv = $st1->get('my-announcements.php?id=' . $xid)['body'] . $st1->get('my-announcements.php')['body'] . $admin->get('admin/announcement-history.php')['body'] . $admin->get('admin/announcement-view.php?id=' . $xid)['body'] . $st1->get('notifications.php')['body'];
ok('announcement HTML is escaped everywhere it is displayed', !has($vv, '<script>alert(1)') && !has($vv, '<img src=x') && has($vv, '&lt;script&gt;'));
$sq = $admin->get("admin/students.php?q=" . urlencode("' OR 1=1 -- ")); ok('SQL-injection style search does not error or list everyone', $sq['status'] === 200 && !has($sq['body'], '>2026-0001<'));
$sq = $admin->get("admin/announcement-history.php?q=" . urlencode("%' OR '1'='1")); ok('LIKE wildcards in announcement search are handled', $sq['status'] === 200);
ok('error pages do not leak file paths or SQL', !has($admin->get('admin/student-view.php?id=abc')['body'], '/home/') && !has($admin->get('my-announcements.php?id=999999', false)['body'], 'SQLSTATE'));
ok('security headers present', (function () use ($BASE) { $h = get_headers($BASE . '/index.php', true); $h = array_change_key_case($h, CASE_LOWER); return isset($h['x-frame-options']) || isset($h['content-security-policy']) || isset($h['x-content-type-options']); })());

/* =========================================================================================== */
section('Sign-in throttling');
dbx('DELETE FROM login_attempts');
for ($i = 0; $i < LOGIN_MAX_FAILURES_PER_USER; $i++) {
    (new Client($BASE, 'thr' . $i))->login('stud2', 'wrong-password-' . $i);
}
$locked = (new Client($BASE, 'thrLocked'))->login('stud2', 'Student#1234');
ok('after repeated failures even the right password is paused', has($locked['body'], 'Too many failed sign-in attempts'));
dbx('DELETE FROM login_attempts');
ok('sign-in works again once the failures are cleared', has((new Client($BASE, 'thrOk'))->login('stud2', 'Student#1234')['body'], 'My Logbook'));

/* ----------------------------------------------------------------------------------------- */
echo "\n" . str_repeat('=', 60) . "\n";
echo "$passed passed, $failed failed\n";
if ($failures) { echo "Failures:\n - " . implode("\n - ", $failures) . "\n"; }
exit($failed > 0 ? 1 : 0);
