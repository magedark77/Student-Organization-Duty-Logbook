<?php
/**
 * Dependency-free tests for the logic that needs no database.
 * Run from the project root:  php tests/run.php
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$_SERVER['SCRIPT_FILENAME'] = dirname(__DIR__) . '/index.php';
$_SERVER['REQUEST_METHOD']  = 'GET';
require dirname(__DIR__) . '/app/bootstrap.php';

$passed = 0;
$failed = [];

function check(string $name, mixed $actual, mixed $expected): void
{
    global $passed, $failed;
    if ($actual === $expected) {
        $passed++;
        return;
    }
    $failed[] = sprintf("%s\n    expected: %s\n    actual:   %s", $name, var_export($expected, true), var_export($actual, true));
}

function throws(string $name, callable $fn, string $class = ValidationException::class): void
{
    try {
        $fn();
        check($name, 'no exception', $class);
    } catch (Throwable $e) {
        check($name, $e instanceof $class, true);
    }
}

/* ---- Durations --------------------------------------------------------- */
check('time_to_minutes HH:MM', time_to_minutes('08:30'), 510);
check('time_to_minutes HH:MM:SS', time_to_minutes('13:05:00'), 785);
check('time_to_minutes invalid', time_to_minutes('8am'), null);
check('time_to_minutes null', time_to_minutes(null), null);
check('duration_minutes', duration_minutes('08:00', '12:15'), 255);
check('duration_minutes never negative', duration_minutes('12:00', '08:00'), 0);
check('duration_minutes missing side', duration_minutes('08:00', null), 0);
check('attendance_minutes', attendance_minutes([
    'morning_time_in' => '08:00:00', 'morning_time_out' => '12:00:00',
    'afternoon_time_in' => '13:00:00', 'afternoon_time_out' => '16:30:00',
]), ['morning' => 240, 'afternoon' => 210, 'total' => 450]);
check('attendance_minutes empty row', attendance_minutes([])['total'], 0);
check('format_duration', format_duration(125), '2h 5m');
check('format_duration numeric string', format_duration('60'), '1h 0m');
check('format_clock noon', format_clock('12:00:00'), '12:00 PM');
check('format_clock midnight', format_clock('00:05'), '12:05 AM');
check('format_clock afternoon', format_clock('13:05:00'), '1:05 PM');
check('format_time_range empty', format_time_range(null, null), '—');
check('format_time_range open session', format_time_range('08:00', null), '8:00 AM – …');
check('is_valid_date ok', is_valid_date('2026-02-28'), true);
check('is_valid_date impossible', is_valid_date('2026-02-30'), false);
check('is_valid_date garbage', is_valid_date('yesterday'), false);

/* ---- Yearly progress --------------------------------------------------- */
check('required_minutes', required_minutes(), REQUIRED_HOURS * 60);
check('remaining_minutes floors at zero', remaining_minutes(required_minutes() + 50), 0);
check('progress_percent caps at 100', progress_percent(required_minutes() * 2), 100.0);
check('progress_percent half', progress_percent(required_minutes() / 2), 50.0);
$rows = [
    ['attendance_date' => '2025-12-31', 'morning_time_in' => '08:00', 'morning_time_out' => '12:00'],
    ['attendance_date' => '2026-01-02', 'morning_time_in' => '08:00', 'morning_time_out' => '10:00'],
    ['attendance_date' => '2026-03-05', 'afternoon_time_in' => '13:00', 'afternoon_time_out' => '14:30'],
];
check('year progress counts only that year', attendance_year_progress($rows, '2026')['minutes'], 210);
check('summary totals', attendance_summarize($rows)['total'], 450);

/* ---- SQL helpers (string building only) -------------------------------- */
check('sql_attendance_minutes mentions both sessions',
    substr_count(sql_attendance_minutes('a'), 'TIME_TO_SEC') === 4, true);
check('sql_duty_day_order', str_starts_with(sql_duty_day_order(), "FIELD(year_level, 'Monday'"), true);

/* ---- CSV safety -------------------------------------------------------- */
check('csv_safe formula', csv_safe('=SUM(A1)'), "'=SUM(A1)");
check('csv_safe plus', csv_safe('+1'), "'+1");
check('csv_safe plain', csv_safe('Cruz, Juan'), 'Cruz, Juan');

/* ---- Output helpers ---------------------------------------------------- */
check('e() escapes', e('<b a="1">&\''), '&lt;b a=&quot;1&quot;&gt;&amp;&#039;');
check('plural one', plural(1, 'record'), '1 record');
check('plural many', plural(1200, 'record'), '1,200 records');
check('plural irregular', plural(2, 'entry', 'entries'), '2 entries');
check('url() plain', url('admin/students.php'), 'admin/students.php');
check('url() query drops empties', url('admin/attendance.php', ['date' => '2026-01-02', 'q' => '', 'edit' => 5]), 'admin/attendance.php?date=2026-01-02&edit=5');
check('url() appends to existing query', url('a.php?x=1', ['y' => 2]), 'a.php?x=1&y=2');
check('url() root', url(), './');
check('html_attrs', html_attrs(['required' => true, 'disabled' => false, 'maxlength' => 50]), ' required maxlength="50"');
check('sort_th plain when not sortable', sort_th('Morning', 'morning', null), '<th scope="col">Morning</th>');
check('sort_th marks active column', str_contains(sort_th('Name', 'name', ['name', 'asc'], 'x.php'), 'aria-sort="ascending"'), true);
check('pagination hidden for one page', pagination(1, 1, 'x.php'), '');
check('pagination keeps filters', str_contains(pagination(2, 5, 'x.php', ['q' => 'a']), 'x.php?q=a&amp;page=3'), true);
check('progress_bar clamps', str_contains(progress_bar(250.0), 'width:100.0%'), true);
check('role_label known', role_label('internal_vp'), 'Internal Vice President');
check('role_label president', role_label('president'), 'President');
check('role_label external VP', role_label('external_vp'), 'External Vice President');
check('staff roles are exactly the four officer roles', STAFF_ROLES, ['president', 'internal_vp', 'external_vp', 'secretary']);
check('old director/manager roles are no longer staff roles', count(array_intersect(['director', 'assistant_director', 'manager_1', 'manager_8'], STAFF_ROLES)), 0);
check('role_label unknown', role_label('night_guard'), 'Night Guard');

/* ---- Validation (no database needed: it fails before any query) --------- */
throws('attendance needs a student', fn() => attendance_save(['student_id' => 0, 'attendance_date' => '2026-01-02']));
throws('attendance rejects bad date', fn() => attendance_save(['student_id' => 1, 'attendance_date' => 'nope']));
throws('attendance rejects bad time', fn() => attendance_save(['student_id' => 1, 'attendance_date' => '2026-01-02', 'morning_in' => '99:99']));
throws('attendance needs paired times', fn() => attendance_save(['student_id' => 1, 'attendance_date' => '2026-01-02', 'morning_in' => '08:00']));
throws('attendance out after in', fn() => attendance_save(['student_id' => 1, 'attendance_date' => '2026-01-02', 'morning_in' => '12:00', 'morning_out' => '08:00']));
throws('attendance remarks length', fn() => attendance_save(['student_id' => 1, 'attendance_date' => '2026-01-02', 'remarks' => str_repeat('x', 256)]));
$base = ['student_number' => '1', 'first_name' => 'A', 'last_name' => 'B', 'course' => 'C', 'year_level' => 'Monday', 'status' => 'Active'];
check('student_validate normalises optionals', student_validate($base, null)['position'], null);
check('recovery code is normalised', recovery_code_normalise(' abcd efgh-jklm '), 'ABCD-EFGH-JKLM');
check('malformed recovery code is rejected', recovery_code_normalise('abc'), '');
throws('student requires first name', fn() => student_validate(['first_name' => ''] + $base, null));
check('Members is an accepted position', student_validate(['position' => 'Members'] + $base, null)['position'], 'Members');
throws('student rejects unknown duty day', fn() => student_validate(['year_level' => 'Sunday'] + $base, null));
check('student keeps legacy duty day when unchanged', student_validate(['year_level' => '1st Year'] + $base, ['year_level' => '1st Year'])['year_level'], '1st Year');
throws('officer rejects bad username', fn() => officer_create('a b', 'longenough1', 'president'));
throws('officer rejects non-staff role', fn() => officer_create('someone', 'longenough1', 'admin'));
throws('officer rejects the old manager role', fn() => officer_create('someone', 'longenough1', 'manager_9'));
throws('officer_validate rejects bad username', fn() => officer_validate('a b', 'president'));
throws('officer_validate rejects non-staff role', fn() => officer_validate('someone', 'student'));
check('officer_validate accepts an officer role', officer_validate('vp.one-2', 'external_vp'), null);
throws('officer rejects short password', fn() => officer_create('someone', 'short', 'president'));

/* ---- Notifications (no database needed) --------------------------------- */
$base = strtotime('2026-10-15 12:00:00');
check('age just now', notification_age('2026-10-15 11:59:30', $base), 'Just now');
check('age minutes', notification_age('2026-10-15 11:55:00', $base), '5 min ago');
check('age hours', notification_age('2026-10-15 09:00:00', $base), '3 h ago');
check('age days', notification_age('2026-10-13 12:00:00', $base), '2 d ago');
check('age old shows date', notification_age('2026-09-01 08:00:00', $base), 'Tue, Sep 1, 2026');
check('href plain page', notification_href(['link' => 'student/dashboard.php']), 'student/dashboard.php');
check('href with query', notification_href(['link' => 'admin/attendance.php?date=2026-10-15']), 'admin/attendance.php?date=2026-10-15');
check('href empty', notification_href(['link' => null]), null);
check('href rejects external', notification_href(['link' => 'https://evil.example/x.php']), null);
check('href rejects javascript', notification_href(['link' => 'javascript:alert(1)']), null);
check('badge hidden at zero', str_contains(notification_badge(0), ' hidden'), true);
check('badge shows count', str_contains(notification_badge(7), '>7<'), true);
check('badge caps at 99+', str_contains(notification_badge(250), '>99+<'), true);
check('audiences include every duty day', count(array_filter(array_keys(announcement_audiences()), static fn(string $k): bool => str_starts_with($k, 'day:'))), count(DUTY_DAYS));
check('every notification type has label and tone', count(array_filter(NOTIFICATION_TYPES, static fn(array $t): bool => count($t) === 2)), count(NOTIFICATION_TYPES));
throws('announcement needs valid audience', fn() => announcement_send('nobody', 'Title', 'Body'));
throws('announcement needs title', fn() => announcement_send('students', '  ', 'Body'));
throws('announcement needs message', fn() => announcement_send('students', 'Title', ''));
throws('announcement title length', fn() => announcement_send('students', str_repeat('x', 151), 'Body'));
throws('announcement message length', fn() => announcement_send('students', 'Title', str_repeat('x', ANNOUNCEMENT_MESSAGE_MAX + 1)));
throws('announcement bad priority', fn() => announcement_send('students', 'Title', 'Body', ['priority' => 'critical']));
throws('urgent announcement needs confirmation', fn() => announcement_send('students', 'Title', 'Body', ['priority' => 'urgent']));
throws('announcement expiry in the past', fn() => announcement_send('students', 'Title', 'Body', ['expires_on' => '2001-01-01']));
throws('announcement expiry not a date', fn() => announcement_send('students', 'Title', 'Body', ['expires_on' => 'soon']));
check('announcement status: cancelled', announcement_status(['status' => 'cancelled', 'expires_at' => null]), 'cancelled');
check('announcement status: expired', announcement_status(['status' => 'active', 'expires_at' => '2020-01-01 23:59:59']), 'expired');
check('announcement status: active', announcement_status(['status' => 'active', 'expires_at' => '2999-01-01 23:59:59']), 'active');
check('announcement status: no expiry', announcement_status(['status' => 'active', 'expires_at' => null]), 'active');

/* ---- attendance validation added in the improvements ---- */
throws('attendance: future date', fn() => attendance_save(['student_id' => 1, 'attendance_date' => date('Y-m-d', strtotime('+2 days')), 'morning_in' => '08:00', 'morning_out' => '12:00']));
throws('attendance: date before 2000', fn() => attendance_save(['student_id' => 1, 'attendance_date' => '1999-12-31']));
throws('attendance: afternoon before morning ends', fn() => attendance_validate_times(['morning_in' => '08:00', 'morning_out' => '12:00', 'afternoon_in' => '11:00', 'afternoon_out' => '15:00']));
check('attendance: back-to-back sessions allowed', attendance_validate_times(['morning_in' => '08:00', 'morning_out' => '12:00', 'afternoon_in' => '12:00', 'afternoon_out' => '15:00'])['afternoon_in'], '12:00');
throws('attendance: unpaired time', fn() => attendance_validate_times(['morning_in' => '08:00']));
throws('attendance: out before in', fn() => attendance_validate_times(['morning_in' => '09:00', 'morning_out' => '08:00']));
throws('attendance: reason required for changes', fn() => attendance_validate_reason('  ', true));
check('attendance: reason optional for new', attendance_validate_reason('', false), '');
check('incomplete: missing out', attendance_incomplete_reasons(['morning_time_in' => '08:00', 'morning_time_out' => null, 'afternoon_time_in' => null, 'afternoon_time_out' => null]), ['Morning time-out missing']);
check('incomplete: missing in', attendance_incomplete_reasons(['morning_time_in' => null, 'morning_time_out' => null, 'afternoon_time_in' => null, 'afternoon_time_out' => '16:00']), ['Afternoon time-in missing']);
check('incomplete: empty record', attendance_incomplete_reasons(['morning_time_in' => null, 'morning_time_out' => null, 'afternoon_time_in' => null, 'afternoon_time_out' => null]), ['No times recorded']);
check('incomplete: complete record', attendance_incomplete_reasons(['morning_time_in' => '08:00', 'morning_time_out' => '12:00', 'afternoon_time_in' => null, 'afternoon_time_out' => null]), []);

/* ---- password reset token format, CSV import parsing, PDF, charts ---- */
check('reset lookup rejects junk token', password_reset_lookup('not-a-token'), null);
throws('reset password too short', fn() => password_reset_apply(str_repeat('a', 64), 'short', 'short'));
throws('reset passwords must match', fn() => password_reset_apply(str_repeat('a', 64), 'longenough1', 'longenough2'));
$pdf = pdf_table_report('T', ['m'], [['label' => 'A', 'weight' => 1]], [['x (y) \\ z']], null, 'f');
check('pdf has header and trailer', str_starts_with($pdf, '%PDF-1.4') && str_ends_with(trim($pdf), '%%EOF'), true);
check('bar chart has an accessible title', str_contains(bar_chart('My chart', ['a'], [1.0]), '<title id="chart-t'), true);
check('bar chart empty data', bar_chart('x', [], []), '');
check('status indicator has text not just colour', str_contains(status_indicator('urgent'), 'Urgent'), true);
check('outstanding urgency near year end', outstanding_urgency('2026', strtotime('2026-12-10')), 'urgent');
check('outstanding urgency early in year', outstanding_urgency('2026', strtotime('2026-03-10')), 'pending');

/* ---- Shared helpers ---------------------------------------------------------- */
check('sql_placeholders', sql_placeholders(3), '?,?,?');
check('sql_placeholders never empty', sql_placeholders(0), '?');
check('duplicate key detected', db_is_duplicate_key(new PDOException('dup', 23000)), true);
check('other SQL errors are not duplicates', db_is_duplicate_key(new PDOException('bad', 1064)), false);
check('other errors are not duplicates', db_is_duplicate_key(new RuntimeException('x')), false);
check('paginate first page', paginate(120, 50, 1), ['page' => 1, 'pages' => 3, 'offset' => 0]);
check('paginate clamps high page', paginate(120, 50, 99), ['page' => 3, 'pages' => 3, 'offset' => 100]);
check('paginate clamps low page', paginate(120, 50, -4), ['page' => 1, 'pages' => 3, 'offset' => 0]);
check('paginate empty list', paginate(0, 50, 2), ['page' => 1, 'pages' => 1, 'offset' => 0]);
check('staff roles share one group', role_group('external_vp') === role_group('president'), true);
check('admin and student groups are separate', [role_group('admin'), role_group('student')], ['admin', 'student']);
check('config problem is null without a config file', app_config_error(), null);
check('icon known', str_contains(icon('bell'), '<svg'), true);
check('icon unknown', icon('nope'), '');
check('year minutes SQL is bounded by student and year', substr_count(sql_attendance_minutes('a'), 'GREATEST') === 2, true);
check('brand logo uses colour tokens', str_contains(brand_logo(), '#'), false);

/* ---- Report ---------------------------------------------------------------- */
check('report month default', preg_match('/^\d{4}-\d{2}$/', report_month_from_request()), 1);


/* ---- Refactored building blocks (all pure: no database) ---- */
check('sort_rows ascending', array_column(sort_rows([['v' => 3], ['v' => 1], ['v' => 2]], static fn(array $r) => $r['v'], 'asc'), 'v'), [1, 2, 3]);
check('sort_rows descending', array_column(sort_rows([['v' => 3], ['v' => 1], ['v' => 2]], static fn(array $r) => $r['v'], 'desc'), 'v'), [3, 2, 1]);
check('sort_rows is stable for ties', array_column(sort_rows([['v' => 1, 'n' => 'a'], ['v' => 1, 'n' => 'b'], ['v' => 1, 'n' => 'c']], static fn(array $r) => $r['v'], 'desc'), 'n'), ['a', 'b', 'c']);

$totals = [
    ['course' => 'BSIT', 'year_level' => 'Tuesday', 'days' => '2', 'minutes' => '600'],
    ['course' => 'BSCS', 'year_level' => 'Monday',  'days' => '5', 'minutes' => '1800'],
    ['course' => 'BSCS', 'year_level' => 'Tuesday', 'days' => '0', 'minutes' => '0'],
];
$byCourse = analytics_group('2026', 'course', [], $totals);
check('analytics by course: most hours first', array_column($byCourse, 'label'), ['BSCS', 'BSIT']);
check('analytics by course: students, days, minutes', [$byCourse[0]['students'], $byCourse[0]['days'], $byCourse[0]['minutes']], [2, 5, 1800]);
check('analytics by course: average per student', $byCourse[0]['average'], 900.0);
check('analytics by duty day: calendar order', array_column(analytics_group('2026', 'year_level', [], $totals), 'label'), ['Monday', 'Tuesday']);
check('analytics with no students', analytics_group('2026', 'course', [], []), []);

$bar = filter_bar('/list.php', [search_input('q', 'a"b', 'Search')], ['active' => 2, 'hidden' => ['year' => 'Monday', 'blank' => ''], 'extra' => ['<button>Print</button>'], 'reset' => '/list.php?x=1&y=2']);
check('filter_bar: GET search form', str_contains($bar, 'method="get"') && str_contains($bar, 'role="search"'), true);
check('filter_bar: keeps hidden values', str_contains($bar, '<input type="hidden" name="year" value="Monday">'), true);
check('filter_bar: shows the active-filter count', str_contains($bar, '2 active') && str_contains($bar, 'data-active="2"'), true);
check('filter_bar: no badge when nothing is active', str_contains(filter_bar('/x', []), 'badge'), false);
check('filter_bar: empty hidden values are skipped', str_contains($bar, 'name="blank"'), false);
check('filter_bar: Reset defaults to the form URL', str_contains(filter_bar('/x', []), 'href="/x"'), true);
$bare = filter_bar('/x', [], ['apply' => null, 'reset' => null]);
check('filter_bar: live search only without Apply', [str_contains($bare, 'data-live-search'), str_contains($bar, 'data-live-search')], [true, false]);
check('filter_bar: Apply and Reset can be left out', str_contains($bare, 'Apply') || str_contains($bare, 'Reset') || str_contains($bare, 'filter-actions'), false);
check('filter_bar: extras alone still get an actions row', str_contains(filter_bar('/x', [], ['apply' => null, 'reset' => null, 'extra' => ['<i>x</i>']]), 'filter-actions'), true);
check('sort_hidden: nothing for the default sort', sort_hidden(['name', 'asc']), []);
check('sort_hidden: keeps a custom sort', sort_hidden(['total', 'desc']), ['sort' => 'total', 'dir' => 'desc']);
check('sort_hidden: honours a page-specific default', sort_hidden(['date', 'desc'], ['date', 'desc']), []);
check('filter_bar: escapes values and URLs', str_contains($bar, 'value="a&quot;b"') && str_contains($bar, 'href="/list.php?x=1&amp;y=2"'), true);
check('filter_bar: Apply, Reset and extras are present', str_contains($bar, '>Apply<') && str_contains($bar, 'Reset filters') && str_contains($bar, '<button>Print</button>'), true);
check('student_filter_controls: four controls with search', count(student_filter_controls(['year' => '', 'course' => '', 'status' => '', 'q' => ''], ['BSCS'])), 4);
check('student_filter_controls: no course select when withCourse is false', count(student_filter_controls(['year' => '', 'course' => '', 'status' => '', 'q' => ''], ['BSCS'], 'Any status', true, false)), 3);
check('student_filter_controls: three without search', count(student_filter_controls(['year' => '', 'course' => '', 'status' => '', 'q' => ''], [], 'Any status', false)), 3);

$menu = action_menu(['<button>Delete</button>'], 'More actions for "Ana"');
check('action_menu: closed <details> with the items inside', str_contains($menu, '<details class="action-menu">') && str_contains($menu, '<button>Delete</button>') && !str_contains($menu, ' open'), true);
check('action_menu: accessible name is escaped', str_contains($menu, 'aria-label="More actions for &quot;Ana&quot;"'), true);

throws('reset link handler refuses a person with no login', static fn() => reset_link_handler(null, 'student', 'No login yet')());
check('student lifecycle handlers', array_keys(student_lifecycle_handlers(1)), ['deactivate', 'reactivate']);

/* Sign-in throttling: settings are sane and the table is part of the schema */
check('login throttle: per-user limit is lower than per-address limit', LOGIN_MAX_FAILURES_PER_USER < LOGIN_MAX_FAILURES_PER_IP, true);
check('login throttle: lockout is a positive number of minutes', LOGIN_LOCKOUT_MINUTES > 0, true);
check('login throttle: login_attempts is created by the upgrade code', array_key_exists('login_attempts', IMPROVEMENT_TABLES_SQL), true);

/* CSV import: the file reader and row validator are separate from the database checks */
$csvFile = static function (string $content): string {
    $path = tempnam(sys_get_temp_dir(), 'csv');
    file_put_contents($path, $content);
    return $path;
};
$good = $csvFile("\xEF\xBB\xBFStudent No,First Name,Last Name,Course,Day\n2026-1,Ana,Cruz,BSCS,monday\n\n2026-2,Ben,Diaz,BSIT,Tuesday\n");
$csv  = import_read_csv($good);
check('import: BOM stripped and header aliases understood', $csv['columns'], ['student_number', 'first_name', 'last_name', 'course', 'duty_day']);
check('import: blank lines skipped, line numbers kept', array_column($csv['records'], 'line'), [2, 4]);
$ana = import_validate_row($csv['columns'], $csv['records'][0]['cells'], 2);
check('import: row validated and day normalised', [$ana['status'], $ana['data']['duty_day'], $ana['data']['status']], ['ok', 'Monday', 'Active']);
$bad = import_validate_row($csv['columns'], ['2026-3', 'Cy', 'Eve', 'BSCS', 'Funday'], 5);
check('import: bad duty day reported on its line', [$bad['status'], str_contains($bad['message'], 'duty day')], ['error', true]);
$semi = import_read_csv($csvFile("student_number;first_name;last_name;course;duty_day\n1;A;B;C;Monday\n"));
check('import: semicolon-separated files', count($semi['records']), 1);
$cp = import_read_csv($csvFile(mb_convert_encoding("student_number,first_name,last_name,course,duty_day\n1,José,Peña,BSCS,Monday\n", 'Windows-1252', 'UTF-8')));
check('import: Windows-1252 file converted to UTF-8', $cp['records'][0]['cells'][1], 'José');
throws('import: missing required column', static fn() => import_read_csv($csvFile("student_number,first_name\n1,A\n")));
throws('import: header only', static fn() => import_read_csv($csvFile("student_number,first_name,last_name,course,duty_day\n")));
throws('import: empty file', static fn() => import_read_csv($csvFile('')));
$dups = import_flag_file_duplicates([
    ['line' => 2, 'data' => ['student_number' => 'A-1'], 'status' => 'ok', 'message' => ''],
    ['line' => 3, 'data' => ['student_number' => 'a-1'], 'status' => 'ok', 'message' => ''],
    ['line' => 4, 'data' => ['student_number' => 'A-1'], 'status' => 'error', 'message' => 'x'],
]);
check('import: in-file duplicates are case-insensitive and point at the first line', [$dups[0]['status'], $dups[1]['status'], $dups[1]['message'], $dups[2]['status']], ['ok', 'duplicate', 'Same student number as line 2 of this file.', 'error']);

/* ---- Section headings ------------------------------------------------- */
check('section_head: plain title', section_head('Profile'), '<div class="section-head"><h2>Profile</h2></div>');
check('section_head: title is escaped', str_contains(section_head('A <b>&</b>'), 'A &lt;b&gt;&amp;&lt;/b&gt;'), true);
check('section_head: icon, aside and id', section_head('Today', 'clock', '<i>x</i>', 'today-title'), '<div class="section-head"><h2 id="today-title">' . icon('clock') . ' Today</h2><i>x</i></div>');
check('section_link: escapes label and href', section_link('See <all>', 'a.php?x=1&y=2'), '<a class="link-more" href="a.php?x=1&amp;y=2">See &lt;all&gt; ' . icon('arrow') . '</a>');

/* ---- Project hygiene ---------------------------------------------------
 * Database exports hold real accounts and student data; only the empty schema may live in the project.
 */
$dumps = array_map('basename', glob(dirname(__DIR__) . '/database/*.sql') ?: []);
check('database/ contains only the schema files', $dumps, ['logbook.sql', 'qr_attendance.sql']);
foreach (QR_TABLES_SQL as $table => $statement) {
    check("qr_attendance.sql defines {$table} exactly as schema_tables.php does", str_contains((string) file_get_contents(dirname(__DIR__) . '/database/qr_attendance.sql'), $statement . ';'), true);
    check("logbook.sql also defines {$table}", str_contains((string) file_get_contents(dirname(__DIR__) . '/database/logbook.sql'), $statement . ';'), true);
}
$sample = require dirname(__DIR__) . '/config/config.sample.php';
check('config.sample.php returns the documented settings', array_keys(array_intersect_key($sample, array_flip(['db_host', 'db_name', 'db_user', 'db_pass', 'duty_timezone', 'duty_start', 'duty_end', 'debug']))), ['db_host', 'db_name', 'db_user', 'db_pass', 'duty_timezone', 'duty_start', 'duty_end', 'debug']);

/* ---- Schema: the install file and the in-code upgrade must describe the same tables ------------------ */
$schemaFile = (string) file_get_contents(dirname(__DIR__) . '/database/logbook.sql');
foreach (IMPROVEMENT_TABLES_SQL as $table => $statement) {
    check("logbook.sql defines {$table} exactly as schema_tables.php does", str_contains($schemaFile, $statement . ';'), true);
}
check('logbook.sql defines users.is_active', (bool) preg_match('/CREATE TABLE IF NOT EXISTS users \(.*?is_active\s+TINYINT\(1\) NOT NULL DEFAULT 1/s', $schemaFile), true);

/* ---- Content-Security-Policy guard -------------------------------------
 * Scripts are limited to 'self', so an inline event handler (onclick="…") is silently ignored by the browser.
 * Pages must use the data-* hooks in assets/js/app.js instead.
 */
$inlineHandlers = [];
$pages = new RegexIterator(new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__), FilesystemIterator::SKIP_DOTS)), '/\.php$/');
foreach ($pages as $file) {
    $path = $file->getPathname();
    if (str_contains($path, '/tests/') || str_contains($path, '/config/')) {
        continue;
    }
    if (preg_match('/<[a-z][^>]*\son[a-z]+\s*=/i', (string) file_get_contents($path))) {
        $inlineHandlers[] = substr($path, strlen(dirname(__DIR__)) + 1);
    }
}
check('no page uses an inline event handler (blocked by the CSP)', $inlineHandlers, []);

/* ---- Backup file verification (no database needed) ---------------------- */
$tmp   = sys_get_temp_dir() . '/solbackup_test_' . bin2hex(random_bytes(4)) . '.sql';
$good  = "-- Student Office Daily Logbook backup\n" . BACKUP_MAGIC . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n"
       . "DROP TABLE IF EXISTS `t`;\nCREATE TABLE `t` ( `id` int ) ENGINE=InnoDB;\nINSERT INTO `t` VALUES ('1'),('2');\n"
       . "SET FOREIGN_KEY_CHECKS=1;\n" . BACKUP_END_MARKER . " tables=1 rows=2\n";
file_put_contents($tmp, $good);
$r = backup_verify_file($tmp);
check('backup: valid file passes', $r['ok'], true);
check('backup: counts read from footer', [$r['tables'], $r['rows']], [1, 2]);
file_put_contents($tmp, str_replace(BACKUP_END_MARKER . ' tables=1 rows=2' . "\n", '', $good));
check('backup: truncated file (no end marker) fails', backup_verify_file($tmp)['ok'], false);
file_put_contents($tmp, str_replace("INSERT INTO `t` VALUES ('1'),('2');", "DROP DATABASE x;", $good));
check('backup: forbidden statement fails', backup_verify_file($tmp)['ok'], false);
file_put_contents($tmp, str_replace('tables=1', 'tables=3', $good));
check('backup: table count mismatch fails', backup_verify_file($tmp)['ok'], false);
file_put_contents($tmp, ltrim(str_replace(BACKUP_MAGIC . "\n", '', $good)));
check('backup: missing header fails', backup_verify_file($tmp)['ok'], false);
@unlink($tmp);
check('backup: missing file fails', backup_verify_file($tmp)['ok'], false);
check('backup: file-name pattern accepts generated names', backup_valid_file_name('logbook_20261028_101500_a1b2c3d4.sql'), true);
check('backup: file-name pattern rejects traversal', backup_valid_file_name('../config/config.local.php'), false);
check('backup: file-name pattern rejects other names', backup_valid_file_name('logbook_20261028_101500_a1b2c3d4.sql.php'), false);

echo "\n" . $passed . ' passed, ' . count($failed) . " failed\n";
foreach ($failed as $message) {
    echo "  FAIL: " . $message . "\n";
}
exit($failed ? 1 : 0);
