<?php
/**
 * Fills a THROW-AWAY database with realistic volume so benchmark.php has something to measure.
 *
 *   php tests/seed-large.php --yes [students=1000] [rows-per-student=150]
 *
 * Adds students named BENCH-00001…, a student login for each (password "Bench#12345"), and attendance every other day
 * ending today (about 1 record in 97 is incomplete). Refuses to run unless the database name contains test, bench,
 * demo or sample, and needs --yes, so it cannot be pointed at real data by accident. Remove the data again with:
 *   DELETE FROM students WHERE student_number LIKE 'BENCH-%';   (logins and attendance go with them)
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$_SERVER['SCRIPT_FILENAME'] = dirname(__DIR__) . '/index.php';
$_SERVER['REQUEST_METHOD']  = 'GET';
require dirname(__DIR__) . '/app/bootstrap.php';

$args     = array_values(array_filter(array_slice($argv, 1), static fn(string $a): bool => $a !== '--yes'));
$students = max(1, (int) ($args[0] ?? 1000));
$perStudent = max(1, (int) ($args[1] ?? 150));
$dbName   = (string) db()->query('SELECT DATABASE()')->fetchColumn();
if (!in_array('--yes', $argv, true) || !preg_match('/test|bench|demo|sample/i', $dbName)) {
    fwrite(STDERR, "Refusing to run: pass --yes and use a database whose name contains test, bench, demo or sample (current: {$dbName}).\n");
    exit(1);
}

$pdo = db();
$pdo->beginTransaction();
$hash   = password_hash('Bench#12345', PASSWORD_DEFAULT);
$days   = DUTY_DAYS;
$courses = ['BSCS', 'BSIT', 'BSBA', 'BSED', 'BSN'];
$ids = [];
$insertStudent = $pdo->prepare("INSERT INTO students (student_number, first_name, last_name, course, year_level, status) VALUES (?, ?, ?, ?, ?, ?)");
$insertUser    = $pdo->prepare("INSERT INTO users (username, password, role, student_id) VALUES (?, ?, 'student', ?)");
for ($i = 1; $i <= $students; $i++) {
    $number = sprintf('BENCH-%05d', $i);
    $insertStudent->execute([$number, "First{$i}", "Last{$i}", $courses[$i % 5], $days[$i % count($days)], $i % 25 === 0 ? 'Inactive' : 'Active']);
    $id = (int) $pdo->lastInsertId();
    $insertUser->execute([strtolower($number), $hash, $id]);
    $ids[] = $id;
}

$today = strtotime('today');
$rows  = 0;
$batch = [];
$flush = static function () use (&$batch, $pdo, &$rows): void {
    if (!$batch) {
        return;
    }
    $sql = 'INSERT IGNORE INTO attendance (student_id, attendance_date, morning_time_in, morning_time_out, afternoon_time_in, afternoon_time_out) VALUES '
        . implode(',', array_fill(0, count($batch), '(?, ?, ?, ?, ?, ?)'));
    $pdo->prepare($sql)->execute(array_merge(...$batch));
    $rows += count($batch);
    $batch = [];
};
foreach ($ids as $id) {
    for ($n = 0; $n < $perStudent; $n++) {
        $incomplete = ($id + $n) % 97 === 0;
        $batch[] = [$id, date('Y-m-d', $today - $n * 2 * 86400), '08:00', '12:00', $incomplete ? null : '13:00', $incomplete ? null : '16:00'];
        if (count($batch) >= 1000) {
            $flush();
        }
    }
}
$flush();
$pdo->commit();
echo "Seeded {$students} students and about {$rows} attendance records into {$dbName}.\n";
