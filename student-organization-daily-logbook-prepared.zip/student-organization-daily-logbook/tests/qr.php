<?php
/**
 * Database-free tests for the QR attendance rules. Run from the project root:  php tests/qr.php
 */
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

$_SERVER['SCRIPT_FILENAME'] = dirname(__DIR__) . '/index.php';
$_SERVER['REQUEST_METHOD']  = 'GET';
require dirname(__DIR__) . '/app/bootstrap.php';

$passed = 0; $failed = [];
function check(string $name, mixed $actual, mixed $expected): void {
    global $passed, $failed;
    $actual === $expected ? $passed++ : $failed[] = "$name\n    expected: " . var_export($expected, true) . "\n    actual:   " . var_export($actual, true);
}
$S = QR_SETTING_DEFAULTS;

check('token format', (bool) preg_match('/^[a-f0-9]{32}$/', qr_token_new()), true);
check('tokens differ', qr_token_new() !== qr_token_new(), true);
check('payload round trip', qr_extract_token(qr_payload(str_repeat('0a', 16))), str_repeat('0a', 16));
foreach (['', 'hello', 'https://x.test', 'SOLQR1:abc', 'SOLQR2:' . str_repeat('a', 32), 'SOLQR1:' . str_repeat('g', 32), "SOLQR1:' OR 1=1", str_repeat('A', 5000)] as $bad) {
    check('rejects ' . substr($bad, 0, 20), qr_extract_token($bad), null);
}
check('first scan before cut-off', qr_next_slot(null, '07:59:59', $S), 'morning_time_in');
check('first scan at cut-off', qr_next_slot(null, '12:00:00', $S), 'afternoon_time_in');
check('after morning in', qr_next_slot(['morning_time_in' => '08:00:00'], '09:00:00', $S), 'morning_time_out');
check('after morning out', qr_next_slot(['morning_time_in' => '08:00:00', 'morning_time_out' => '12:00:00'], '12:30:00', $S), 'afternoon_time_in');
check('after afternoon in', qr_next_slot(['afternoon_time_in' => '13:00:00'], '15:00:00', $S), 'afternoon_time_out');
check('day complete', qr_next_slot(['afternoon_time_out' => '17:00:00'], '17:30:00', $S), null);
check('on time at grace limit', qr_scan_status('morning_time_in', '08:15:59', $S), ['status' => 'on_time', 'minutes' => 0]);
check('late after grace', qr_scan_status('morning_time_in', '08:16:00', $S), ['status' => 'late', 'minutes' => 16]);
check('afternoon late', qr_scan_status('afternoon_time_in', '13:45:00', $S), ['status' => 'late', 'minutes' => 45]);
check('early morning out', qr_scan_status('morning_time_out', '11:30:00', $S), ['status' => 'early', 'minutes' => 30]);
check('not early at end', qr_scan_status('afternoon_time_out', '17:00:00', $S), ['status' => 'on_time', 'minutes' => 0]);
check('gap floor is 60 s', qr_effective_gap(['min_gap' => '10']), 60);
check('seconds since last', qr_seconds_since_last(['morning_time_in' => '08:00:00'], '08:00:45'), 45);
check('row flags', qr_row_flags(['morning_time_in' => '09:00:00', 'morning_time_out' => null], $S)['late'] && qr_row_flags(['morning_time_in' => '09:00:00'], $S)['open'], true);
try { qr_validate_times(['morning_time_in' => '10:30:00', 'morning_time_out' => '10:10:00']); check('out before in', 'accepted', 'rejected'); } catch (ValidationException) { $passed++; }
try { qr_validate_times(['morning_time_out' => '10:10:00']); check('out without in', 'accepted', 'rejected'); } catch (ValidationException) { $passed++; }
qr_validate_times(['morning_time_in' => '08:00:00']); $passed++;
try { qr_validate_settings(['morning_start' => '25:00'] + $S); check('bad time', 'accepted', 'rejected'); } catch (ValidationException) { $passed++; }
check('defaults valid', qr_validate_settings($S)['late_grace'], '15');
check('csv safe formula', csv_safe('=1+1'), "'=1+1");

echo "\n$passed passed, " . count($failed) . " failed\n";
foreach ($failed as $f) echo "FAIL: $f\n";
exit($failed ? 1 : 0);
