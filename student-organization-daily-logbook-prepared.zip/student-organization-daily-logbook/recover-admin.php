<?php
require __DIR__ . '/app/bootstrap.php';

if (user()) {
    redirect(home_url());
}

$error = '';
if (is_post()) {
    if (!csrf_is_valid()) {
        $error = 'Your session expired. Please reload the page and try again.';
    } else {
        try {
            admin_recover_account(post_str('username'), post_str('recovery_code'), post_str('new_password', false), post_str('confirm_password', false));
            flash('success', 'Your password has been reset. You can now sign in. Generate a fresh set of recovery codes after signing in.');
            redirect(url('index.php'));
        } catch (ValidationException $e) {
            $error = $e->getMessage();
        }
    }
}

render_header('Recover administrator account', '', ['bare' => true, 'bodyClass' => 'login']);
?>
<div class="login-card">
    <div class="login-mark"><?= brand_logo(64) ?></div>
    <h1>Recover administrator account</h1>
    <p class="text-muted">Enter your administrator username, one unused recovery code and a new password.</p>
    <?php if ($error !== ''): ?><?php alert('danger', $error); ?><?php endif; ?>
    <form method="post" class="form-stack" action="<?= e(url('recover-admin.php')) ?>">
        <?= csrf_field() ?>
        <label>Username
            <input name="username" required autofocus autocomplete="username" value="<?= e(post_str('username')) ?>">
        </label>
        <label>Recovery code
            <input name="recovery_code" required autocomplete="off" placeholder="XXXX-XXXX-XXXX" class="input-upper">
        </label>
        <?= field_password('New password', 'new_password', ['required' => true, 'minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password', 'data-toggle' => true], 'At least ' . MIN_PASSWORD_LENGTH . ' characters.') ?>
        <?= field_password('Confirm new password', 'confirm_password', ['required' => true, 'minlength' => MIN_PASSWORD_LENGTH, 'autocomplete' => 'new-password']) ?>
        <button class="btn primary full" type="submit">Reset password</button>
    </form>
    <div class="login-footer">
        <p><a href="<?= e(url('index.php')) ?>">Back to sign in</a></p>
        <p>Each recovery code can be used once.</p>
        <p>No codes? Generate them under Account Recovery while signed in.</p>
    </div>
</div>
<?php render_footer(bare: true);
