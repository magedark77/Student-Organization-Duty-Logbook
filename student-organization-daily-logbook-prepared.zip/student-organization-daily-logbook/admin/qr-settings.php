<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();
qr_ensure_ready();

$pageUrl = url('admin/qr-settings.php');

if (is_post()) {
    $result = handle_post([
        'save' => static function (): void {
            qr_settings_save($_POST);
            flash('success', 'QR attendance settings saved.');
        },
    ], 'qr settings');
    if ($result['outcome'] === ACTION_INVALID) {
        remember_input($_POST);
    }
    redirect($pageUrl);
}

$s = qr_settings();
$v = static fn(string $key): string => (string) old($key, $s[$key]);
$checked = static function (string $key) use ($s): bool {
    $old = old_input();
    return $old !== [] ? !empty($old[$key]) : $s[$key] === '1';
};

render_header('QR Settings', 'qrmonitor', ['styles' => ['css/qr.css']]);
page_head('QR Settings', 'Switch QR attendance on or off and set the rules used for late arrivals and early departures.', [
    ['label' => '← QR Monitor', 'href' => url('admin/qr-attendance.php')],
], [['QR Monitor', url('admin/qr-attendance.php')], ['Settings', null]]);
?>
<form method="post" action="<?= e($pageUrl) ?>" class="form-stack">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <section class="card card-form">
        <h2>Scanning</h2>
        <label class="qr-check"><input type="checkbox" name="enabled" value="1"<?= $checked('enabled') ? ' checked' : '' ?>>
            <span>QR attendance is on<br><small class="hint">When off, the scanner page refuses every scan.</small></span></label>
        <label class="qr-check"><input type="checkbox" name="allow_manual" value="1"<?= $checked('allow_manual') ? ' checked' : '' ?>>
            <span>Allow manual entry of a student number when the camera is unavailable<br><small class="hint">Manual entries are logged as “manual”.</small></span></label>
        <?= field_input('Minimum seconds between two scans of the same student', 'min_gap', $v('min_gap'), ['type' => 'number', 'min' => 60, 'max' => 3600, 'step' => 1, 'required' => true]) ?>
        <p class="hint">Repeated scans inside this time are refused so a student cannot create a Time Out by accident. At least 60 seconds.</p>
    </section>

    <section class="card card-form">
        <h2>Daily schedule (24-hour time)</h2>
        <div class="qr-settings-grid">
            <?= field_input('Morning starts', 'morning_start', $v('morning_start'), ['type' => 'time', 'required' => true]) ?>
            <?= field_input('Morning ends', 'morning_end', $v('morning_end'), ['type' => 'time', 'required' => true]) ?>
            <?= field_input('Afternoon starts', 'afternoon_start', $v('afternoon_start'), ['type' => 'time', 'required' => true]) ?>
            <?= field_input('Afternoon ends', 'afternoon_end', $v('afternoon_end'), ['type' => 'time', 'required' => true]) ?>
            <?= field_input('Morning / afternoon cut-off', 'session_cutoff', $v('session_cutoff'), ['type' => 'time', 'required' => true]) ?>
        </div>
        <p class="hint">A student’s <strong>first scan of the day</strong> before the cut-off is a morning Time In; at or after it, an afternoon Time In. Every later scan fills the next empty slot: Morning Out → Afternoon In → Afternoon Out.</p>
    </section>

    <section class="card card-form">
        <h2>Late and early rules</h2>
        <div class="qr-settings-grid">
            <?= field_input('Late after (grace minutes)', 'late_grace', $v('late_grace'), ['type' => 'number', 'min' => 0, 'max' => 120, 'step' => 1, 'required' => true]) ?>
            <?= field_input('Early departure before end (grace minutes)', 'early_grace', $v('early_grace'), ['type' => 'number', 'min' => 0, 'max' => 120, 'step' => 1, 'required' => true]) ?>
        </div>
        <p class="hint">Example: morning starts 08:00 with 15 grace minutes → a Time In at 08:16 or later is “late”. The same rules mark late and early records entered by hand.</p>
    </section>

    <div class="form-actions"><button class="btn primary" type="submit">Save settings</button></div>
</form>
<?php render_footer();
