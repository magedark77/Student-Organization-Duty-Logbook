<?php
require __DIR__ . '/../app/bootstrap.php';
require_attendance_access();

$date = get_str('date');
if (!is_valid_date($date)) {
    $date = date('Y-m-d');
}
$listUrl  = url('admin/attendance.php', ['date' => $date]);
$students = students_active();

render_header('Record Attendance', 'attendance');
page_head('Record Attendance', "Enter the student's attendance details for the selected date.", [
    ['label' => '← Back to Attendance', 'href' => $listUrl],
], [['Attendance', $listUrl], ['Record Attendance', null]]);
?>
<section class="card card-form">
    <h2>New attendance record</h2>
    <?php if (!$students): ?>
        <?php alert('warning', 'There are no active students yet. Add or reactivate a student first.'); ?>
    <?php else: ?>
        <?php view('partials/attendance-form', [
            'students'   => $students,
            'date'       => $date,
            'context'    => 'page',
            'cancelHref' => $listUrl,
            'preselect'  => get_str('student_id'),
        ]); ?>
    <?php endif; ?>
</section>
<?php render_footer();
