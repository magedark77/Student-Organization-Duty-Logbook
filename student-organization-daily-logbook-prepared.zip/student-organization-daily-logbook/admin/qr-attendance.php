<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();
qr_ensure_ready();

$f       = qr_monitor_filters_from_request();
$pageUrl = url('admin/qr-attendance.php');
$query   = clean_query([
    'date' => $f['date'] !== date('Y-m-d') ? $f['date'] : '', 'q' => $f['q'], 'course' => $f['course'],
    'day' => $f['year'], 'status' => $f['status'], 'all' => $f['all'] ? '1' : '',
]);
$monitor = qr_monitor($f);

/** The part of the page that refreshes by itself: counters, the table and the latest scans. */
function qr_monitor_fragment(array $monitor, array $f): void
{
    $s = $monitor['stats'];
    $rows = $monitor['rows'];
    echo '<div data-qr-fragment>';
    echo '<div class="qr-stats">';
    stat_card('Expected', (string) $s['expected'], $f['all'] ? 'all active students' : 'duty day: ' . date('l', strtotime($f['date'])), 'users');
    stat_card('Present', (string) $s['present'], 'have a record', 'check', 'done');
    stat_card('Late', (string) $s['late'], '', 'clock', 'left');
    stat_card('Timed in', (string) $s['open'], 'no Time Out yet', 'activity');
    stat_card('Early out', (string) $s['early'], '', 'logout');
    stat_card('Absent', (string) $s['absent'], 'expected, no record', 'alert', 'left');
    echo '</div>';

    echo '<section class="card">';
    echo section_head(format_date($f['date']), '', '<span class="small">' . e(plural(count($rows), 'student')) . '</span>');
    if (!$rows) {
        echo empty_state('Nothing to show', 'No students match these filters for this date.', '', 'clipboard');
    } else {
        table_start('QR attendance for ' . format_date($f['date']), true);
        echo '<thead><tr><th scope="col">Student</th><th scope="col">Duty day</th><th scope="col">Morning</th><th scope="col">Afternoon</th><th scope="col">Hours</th><th scope="col">Status</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>';
            echo '<td data-label="Student"><a href="' . e(url('admin/student-view.php', ['id' => $r['sid']])) . '"><strong>' . e($r['last_name'] . ', ' . $r['first_name']) . '</strong></a><br><small class="text-muted">' . e($r['student_number']) . ($r['course'] !== '' ? ' · ' . e($r['course']) : '') . '</small></td>';
            echo '<td data-label="Duty day">' . e($r['year_level']) . '</td>';
            echo '<td data-label="Morning">' . e($r['attendance_id'] !== null ? format_time_range($r['morning_time_in'], $r['morning_time_out']) : '—') . '</td>';
            echo '<td data-label="Afternoon">' . e($r['attendance_id'] !== null ? format_time_range($r['afternoon_time_in'], $r['afternoon_time_out']) : '—') . '</td>';
            echo '<td data-label="Hours">' . ($r['minutes'] > 0 ? e(format_duration($r['minutes'])) : '—') . '</td>';
            echo '<td data-label="Status">' . qr_state_badge($r) . '</td>';
            echo '<td data-label="">' . ($r['attendance_id'] !== null
                ? '<a class="btn secondary btn-sm" href="' . e(url('admin/attendance.php', ['edit' => $r['attendance_id']])) . '">Open</a>'
                : '<a class="btn secondary btn-sm" href="' . e(url('admin/record-attendance.php', ['date' => $f['date'], 'student_id' => $r['sid']])) . '">Record</a>') . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        table_end();
    }
    echo '</section>';

    $feed = qr_recent_scans($f['date']);
    echo '<section class="card">' . section_head('Latest scans', 'activity');
    if (!$feed) {
        echo '<p class="text-muted">No scans on this date yet.</p>';
    } else {
        echo '<ul class="qr-scan-feed">';
        foreach ($feed as $x) {
            $who = $x['student_number'] !== null ? $x['last_name'] . ', ' . $x['first_name'] : 'Unknown code';
            $tone = match ($x['result']) { 'ok' => in_array($x['status'], ['late', 'early'], true) ? 'warning' : 'success', 'duplicate', 'complete' => 'warning', default => 'danger' };
            $what = $x['result'] === 'ok' ? qr_slot_label((string) $x['slot']) : ucfirst((string) $x['result']);
            echo '<li><span class="small">' . e(format_clock((string) $x['scanned_time'])) . '</span> <strong>' . e($who) . '</strong> '
                . '<span class="badge ' . $tone . '">' . e($what) . '</span>'
                . ($x['method'] === 'manual' ? ' <span class="badge neutral">manual</span>' : '')
                . ($x['status'] === 'late' ? ' <span class="badge warning">late</span>' : '')
                . ($x['result'] !== 'ok' ? ' <small class="text-muted">' . e((string) $x['message']) . '</small>' : '') . '</li>';
        }
        echo '</ul>';
    }
    echo '</section></div>';
}

/* The auto-refresh script fetches just the fragment. */
if (get_str('partial') === '1') {
    header('Cache-Control: no-store');
    qr_monitor_fragment($monitor, $f);
    exit;
}

if (get_str('export') === 'csv') {
    [$header, $rows] = qr_monitor_csv($monitor, $f['date']);
    audit('EXPORT', 'qr_attendance', null, 'Exported QR attendance for ' . $f['date'] . ' (' . count($rows) . ' rows)');
    send_csv('qr-attendance-' . $f['date'] . '.csv', $header, $rows);
}

$liveUrl = url('admin/qr-attendance.php', $query + ['partial' => 1]);
$csvUrl  = url('admin/qr-attendance.php', $query + ['export' => 'csv']);
render_header('QR Attendance Monitor', 'qrmonitor', ['scripts' => ['js/qr-admin.js'], 'styles' => ['css/qr.css']]);
page_head('QR Attendance Monitor', 'Live view of Time In, Time Out, late arrivals and absences. The page refreshes by itself.', [
    ['label' => 'Export CSV', 'href' => $csvUrl],
    ['label' => 'QR Settings', 'href' => url('admin/qr-settings.php')],
    ['label' => 'Scan QR Attendance', 'href' => url('admin/qr-scanner.php'), 'class' => 'primary'],
], [['QR Attendance Monitor', null]]);
?>
<?php if (!qr_enabled()): ?>
    <?php alert('warning', 'QR attendance is currently switched off, so scans are refused. Turn it on in QR Settings.'); ?>
<?php endif; ?>

<section class="card">
    <?= filter_bar($pageUrl, [
        '<input type="date" name="date" value="' . e($f['date']) . '" aria-label="Date" data-autosubmit>',
        search_input('q', $f['q'], 'Search name or number', 'Search students'),
        toolbar_select('day', 'Duty day', DUTY_DAYS, $f['year'], 'All duty days'),
        toolbar_select('course', 'Class / course', students_courses(), $f['course'], 'All courses'),
        toolbar_select('status', 'Attendance status', QR_STATUS_FILTERS, $f['status'], 'Any status'),
        '<label class="qr-check"><input type="checkbox" name="all" value="1" data-autosubmit' . ($f['all'] ? ' checked' : '') . '> <span>Include students whose duty day is not ' . e(date('l', strtotime($f['date']))) . '</span></label>',
    ], [
        'active' => ($f['q'] !== '' ? 1 : 0) + ($f['year'] !== '' ? 1 : 0) + ($f['course'] !== '' ? 1 : 0) + ($f['status'] !== '' ? 1 : 0) + ($f['all'] ? 1 : 0),
        'apply'  => null,
        'extra'  => ['<button type="button" class="btn secondary" data-print>Print</button>'],
    ]) ?>
    <div class="qr-live-bar">
        <span class="qr-live-dot" data-qr-live-dot aria-hidden="true"></span>
        <label><input type="checkbox" data-qr-live-toggle checked> Auto-refresh</label>
        <span data-qr-live-stamp role="status">Updated <?= e(date('g:i:s A')) ?></span>
    </div>
</section>

<div data-qr-live="<?= e($liveUrl) ?>" data-interval="15">
    <?php qr_monitor_fragment($monitor, $f); ?>
</div>
<?php render_footer();
