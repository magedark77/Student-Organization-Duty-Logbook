<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$status = get_choice('status', array_keys(CORRECTION_STATUSES));
$term   = get_str('q');
$query  = clean_query(['status' => $status, 'q' => $term]);
$pageUrl = url('admin/corrections.php');

if (is_post()) {
    $id = (int) post_str('id');
    $review = static fn(bool $approve): callable => static function () use ($id, $approve): void {
        correction_review($id, $approve, post_str('note'));
        flash('success', $approve
            ? 'Request approved. The attendance record was updated and the change was added to its history.'
            : 'Request rejected. The student was notified.');
    };
    handle_post(['approve' => $review(true), 'reject' => $review(false)], 'correction');
    redirect($pageUrl . ($query ? '?' . http_build_query($query) : ''));
}

$result  = corrections_search($status, $term, (int) get_str('page'));
$pending = corrections_pending_count();

render_header('Attendance Corrections', 'corrections');
page_head('Attendance corrections', $pending > 0 ? plural($pending, 'request') . ' waiting for review.' : 'Review requests from students to fix their attendance.', [], [['Corrections', null]]);
?>
<section class="card">
    <?= filter_bar($pageUrl, [
        search_input('q', $term, 'Search student name or number', 'Search corrections by student'),
        toolbar_select('status', 'Status', array_map(static fn(array $s): string => $s[0], CORRECTION_STATUSES), $status, 'Any status'),
    ], ['active' => count($query), 'apply' => null, 'reset' => null]) ?>

    <?php if (!$result['rows']): ?>
        <?= $query
            ? empty_state('No requests match your filters', 'Try a different search or reset the filters.', '<a class="btn secondary" href="' . e($pageUrl) . '">Reset filters</a>', 'search')
            : empty_state('No correction requests yet', 'When a student asks for an attendance fix, it will appear here for approval.', '', 'check') ?>
    <?php else: ?>
        <ul class="request-list">
            <?php foreach ($result['rows'] as $r):
                $current = attendance_find_for((int) $r['student_id'], (string) $r['attendance_date']); ?>
                <li class="request-item">
                    <div class="request-head">
                        <div>
                            <strong><a href="<?= e(url('admin/student-view.php', ['id' => (int) $r['student_id']])) ?>"><?= e($r['last_name'] . ', ' . $r['first_name']) ?></a></strong>
                            <span class="cell-sub"><?= e($r['student_number']) ?> · for <?= e(format_date((string) $r['attendance_date'])) ?> · sent <?= e(format_datetime((string) $r['created_at'])) ?></span>
                        </div>
                        <?= correction_status_badge($r['status']) ?>
                    </div>
                    <div class="compare">
                        <div><span class="small">Current record</span>
                            <?php if ($current): ?>
                                <div>AM <?= e(format_time_range($current['morning_time_in'], $current['morning_time_out'])) ?></div>
                                <div>PM <?= e(format_time_range($current['afternoon_time_in'], $current['afternoon_time_out'])) ?></div>
                            <?php else: ?><div class="text-faint">No record for this date</div><?php endif; ?></div>
                        <div><span class="small">Requested</span>
                            <div>AM <?= e(format_time_range($r['morning_time_in'], $r['morning_time_out'])) ?></div>
                            <div>PM <?= e(format_time_range($r['afternoon_time_in'], $r['afternoon_time_out'])) ?></div></div>
                    </div>
                    <p class="request-reason"><strong>Reason:</strong> <?= e($r['reason']) ?></p>
                    <?php if ($r['status'] === 'pending'): ?>
                        <form method="post" action="<?= e($pageUrl . ($query ? '?' . http_build_query($query) : '')) ?>" class="form-stack review-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                            <label>Note to the student <span class="text-faint">(required when rejecting)</span>
                                <textarea name="note" rows="2" maxlength="500" placeholder="Optional for approval"></textarea></label>
                            <div class="actions">
                                <button class="btn primary btn-sm" type="submit" name="action" value="approve" data-confirm-click="Approve this request and update the attendance record?">Approve &amp; update record</button>
                                <button class="btn danger btn-sm" type="submit" name="action" value="reject" data-confirm-click="Reject this request?">Reject</button>
                            </div>
                        </form>
                    <?php elseif ($r['reviewed_at'] !== null): ?>
                        <p class="small">Decided <?= e(format_datetime((string) $r['reviewed_at'])) ?><?= $r['reviewer'] ? ' by ' . e($r['reviewer']) : '' ?><?= $r['review_note'] ? ' — ' . e($r['review_note']) : '' ?></p>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <p class="small result-count"><?= e(plural($result['total'], 'request')) ?></p>
        <?= pagination($result['page'], $result['pages'], $pageUrl, $query) ?>
    <?php endif; ?>
</section>
<?php render_footer();
