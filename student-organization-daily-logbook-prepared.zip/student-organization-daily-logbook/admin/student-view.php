<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$id      = (int) (is_post() ? post_str('id') : get_str('id'));
$student = $id > 0 ? student_profile($id) : null;
if ($student === null) {
    render_error_page(404, 'Student not found', 'This student does not exist or has been deleted.');
}
$pageUrl = url('admin/student-view.php', ['id' => $id]);

if (is_post()) {
    handle_post(student_lifecycle_handlers($id) + [
        'reset_link' => reset_link_handler($student['user_id'] !== null ? (int) $student['user_id'] : null, 'student',
            'This student has no login yet. Edit the student to create one first.'),
    ], 'student');
    redirect($pageUrl);
}

$resetLink = pull_reset_link();

$rows       = attendance_for_student($id);
$year       = date('Y');
$yearRows   = attendance_rows_in_year($rows, $year);
$summary    = attendance_summarize($yearRows);
$progress   = attendance_year_progress($rows); // the required hours are per calendar year
$incomplete = count(array_filter($rows, static fn(array $r): bool => attendance_incomplete_reasons($r) !== []));
$loginOn    = $student['user_id'] !== null && (int) $student['login_active'] === 1;
$name       = $student['first_name'] . ' ' . $student['last_name'];
$state      = $progress['remaining'] <= 0 ? 'complete' : outstanding_urgency($year);

render_header($name, 'students');
page_head($name, student_subtitle($student), [
    ['label' => 'Edit', 'href' => url('admin/students.php', ['edit' => $id])],
    ['label' => 'Back to students', 'href' => url('admin/students.php')],
], [['Students', url('admin/students.php')], [$name, null]]);
?>
<?php if ($resetLink): ?>
    <section class="card reset-link-card" aria-live="polite">
        <h2>Password-reset link for <?= e($resetLink['username']) ?></h2>
        <p>Send this link to the student privately. It works <strong>once</strong> and expires on <?= e(format_datetime($resetLink['expires_at'])) ?>. It will not be shown again.</p>
        <label>Reset link <input type="text" readonly value="<?= e($resetLink['url']) ?>" data-select-on-focus></label>
    </section>
<?php endif; ?>
<?php if ($incomplete > 0): ?>
    <?php alert('warning', plural($incomplete, 'attendance record') . ' for this student ' . ($incomplete === 1 ? 'has' : 'have') . ' a missing time-in or time-out. Look for the “Incomplete” markers below.'); ?>
<?php endif; ?>

<div class="grid cols-2">
    <section class="card">
        <?= section_head('Profile', '', status_badge($student['status'])) ?>
        <dl class="detail-list">
            <div><dt>Student number</dt><dd><?= e($student['student_number']) ?></dd></div>
            <div><dt>Full name</dt><dd><?= e(trim($student['first_name'] . ' ' . ($student['middle_name'] ?? '') . ' ' . $student['last_name'])) ?></dd></div>
            <div><dt>Course</dt><dd><?= e($student['course']) ?></dd></div>
            <div><dt>Duty day</dt><dd><?= e($student['year_level']) ?></dd></div>
            <div><dt>Position</dt><dd><?= ($student['position'] ?? '') !== '' ? e($student['position']) : '<span class="text-faint">—</span>' ?></dd></div>
        </dl>
    </section>
    <section class="card">
        <?= section_head('Account', '', account_status_badge($student['user_id'] !== null ? ['is_active' => $student['login_active']] : null)) ?>
        <dl class="detail-list">
            <div><dt>Username</dt><dd><?= $student['username'] !== null ? e($student['username']) : '<span class="text-faint">No login created</span>' ?></dd></div>
            <div><dt>Login created</dt><dd><?= $student['login_created'] !== null ? e(format_date(substr((string) $student['login_created'], 0, 10))) : '—' ?></dd></div>
            <div><dt>Attendance records</dt><dd><?= number_format(count($rows)) ?> (kept if the account is deactivated)</dd></div>
        </dl>
        <div class="actions manage-actions">
            <?php if ($student['status'] === 'Active' && ($student['user_id'] === null || $loginOn)): ?>
                <?= action_form($pageUrl, 'deactivate', $id, 'Deactivate account', 'secondary', 'Deactivate ' . $name . '? They can no longer sign in or receive new attendance. All ' . count($rows) . ' attendance record(s) are kept, and you can reactivate at any time.') ?>
            <?php else: ?>
                <?= action_form($pageUrl, 'reactivate', $id, 'Reactivate account', 'primary') ?>
            <?php endif; ?>
            <?php if ($loginOn): ?>
                <?= action_form($pageUrl, 'reset_link', $id, 'Create reset link', 'secondary', 'Create a one-time password-reset link for ' . $name . '? Any earlier unused link stops working.') ?>
            <?php endif; ?>
        </div>
    </section>
</div>

<div class="grid cols-4">
    <?php
    stat_card('Days Present (' . $year . ')', (string) $summary['days'], count($rows) !== count($yearRows) ? attendance_days_present($rows) . ' all-time' : '', 'calendar');
    stat_card('Morning (' . $year . ')', format_duration($summary['morning']), '', 'clock');
    stat_card('Afternoon (' . $year . ')', format_duration($summary['afternoon']), '', 'clock');
    stat_card('Total (' . $year . ')', format_duration($summary['total']), '', 'chart');
    ?>
</div>

<section class="card">
    <?= section_head('Progress toward ' . REQUIRED_HOURS . ' hours (' . $year . ')', '', status_indicator($state, $state === 'complete' ? 'Completed' : ($state === 'urgent' ? 'Urgent: year ending' : 'In progress'))) ?>
    <p class="progress-summary">
        <?= hours_span(format_duration($progress['minutes']) . ' completed this year', 'done') ?> • <?= hours_span(format_duration($progress['remaining']) . ' remaining', $progress['remaining'] > 0 ? 'left' : 'done') ?> • <?= number_format($progress['percent'], 1) ?>%
    </p>
    <?= progress_bar($progress['percent'], 'Duty hours completed') ?>
</section>

<section class="card">
    <h2>Attendance History</h2>
    <?php view('partials/attendance-table', [
        'rows'         => $rows,
        'showDate'     => true,
        'label'        => 'Attendance history',
        'emptyHtml'    => empty_state('No attendance recorded yet', 'Records will appear here once this student has been logged in on the attendance page.', '<a class="btn primary" href="' . e(url('admin/record-attendance.php', ['student_id' => $id])) . '">Record attendance</a>', 'clipboard'),
    ]); ?>
</section>
<?php render_footer();
