<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();
backup_auto_if_due((int) (user()['id'] ?? 0) ?: null); // no-op unless 'backup_auto_days' is set

$today          = date('Y-m-d');
$year           = date('Y');
$activeStudents = students_count_active();
$dayStats       = attendance_day_stats($today);
$todayRows      = attendance_recent_for_date($today, 50);
$totalMinutes   = attendance_total_minutes();

// Rate = active students who timed in today / active students (never above 100%).
$attendanceRate = $activeStudents > 0 ? min(100.0, $dayStats['present_active'] / $activeStudents * 100) : 0.0;
$hour           = (int) date('G');
$greeting       = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

$recent         = audit_recent(4);

// Things that need attention, all counted from the database.
$incomplete      = attendance_incomplete_counts($year . '-01-01', $today, $today);
$incompleteTotal = $incomplete['total'];
$incompleteToday = $incomplete['on_date'];
$pendingFixes    = corrections_pending_count();
$belowRequired   = students_outstanding($year);            // computed once; the counts and the top-6 list both come from it
$requirement     = students_requirement_counts($year, $belowRequired);
$urgency         = outstanding_urgency($year);
$behind          = array_slice($belowRequired, 0, 6);
$daysLeft        = days_left_in_year();
$needsAttention  = $incompleteTotal > 0 || $pendingFixes > 0 || $dayStats['open'] > 0 || $requirement['outstanding'] > 0;

// Latest active announcements for the side panel (the page works without them if the query fails).
try {
    $latestNotices = announcements_latest_active(3);
} catch (Throwable $e) {
    error_log('[studentbody] dashboard announcements failed: ' . $e->getMessage());
    $latestNotices = [];
}

// [label, link, icon, highlighted]
$quickActions = [
    ['Record Attendance', url('admin/record-attendance.php', ['date' => $today]), 'clipboard', true],
    ['Announce',          url('admin/announcements.php'),                           'megaphone', false],
    ['Manage Students',   url('admin/students.php'),                                'users',     false],
    ['View Reports',      url('reports/monthly.php'),                               'chart',     false],
];

render_header('Dashboard', 'dashboard');
page_head('Dashboard', date('l, F j, Y'));
?>
<div class="dash">
    <div class="dash-main">
        <?php
        hero(
            $greeting . ', Administrator. Monitor student records, attendance, and duty-hour progress from one place.',
            '<a class="btn hero-btn" href="' . e(url('admin/record-attendance.php', ['date' => $today])) . '">Record Attendance ' . icon('arrow') . '</a>'
            . '<a class="btn hero-btn is-ghost" href="' . e(url('admin/announcements.php')) . '">New Announcement ' . icon('send') . '</a>'
        );
        ?>

        <div class="stat-row">
            <?php
            stat_card('Active Students', (string) $activeStudents, 'Currently enrolled', 'users');
            stat_card('Present Today', (string) $dayStats['present'], 'Checked in today', 'check');
            stat_card('Currently In', (string) $dayStats['open'], 'Open sessions', 'clock');
            stat_card('Attendance Rate', number_format($attendanceRate, 0) . '%', 'Of active students', 'activity');
            stat_card('Total Logged', format_duration($totalMinutes), 'All duty hours', 'chart');
            ?>
        </div>

        <section class="card attention-card" aria-labelledby="attention-title">
            <?= section_head('Needs attention', 'alert', '', 'attention-title') ?>
            <?php if (!$needsAttention): ?>
                <p class="all-clear"><?= status_indicator('complete', 'All clear') ?> No open issues: no incomplete records, pending corrections or students behind on hours.</p>
            <?php else: ?>
            <ul class="attention-list">
                <?php if ($incompleteTotal > 0): ?>
                    <li><?= status_indicator($incompleteToday > 0 ? 'urgent' : 'incomplete') ?>
                        <span><strong><?= e(plural($incompleteTotal, 'attendance record')) ?></strong> in <?= e($year) ?> <?= $incompleteTotal === 1 ? 'is' : 'are' ?> missing a time-in or time-out<?= $incompleteToday > 0 ? ' (' . $incompleteToday . ' today)' : '' ?>.</span></li>
                <?php endif; ?>
                <?php if ($dayStats['open'] > 0): ?>
                    <li><?= status_indicator('pending', 'Open today') ?>
                        <span><strong><?= e(plural($dayStats['open'], 'student')) ?></strong> timed in today without a time-out yet.</span>
                        <a class="btn secondary btn-sm" href="<?= e(url('admin/attendance.php', ['date' => $today])) ?>">View</a></li>
                <?php endif; ?>
                <?php if ($pendingFixes > 0): ?>
                    <li><?= status_indicator('pending', 'Pending review') ?>
                        <span><strong><?= e(plural($pendingFixes, 'correction request')) ?></strong> waiting for your decision.</span>
                        <a class="btn secondary btn-sm" href="<?= e(url('admin/corrections.php', ['status' => 'pending'])) ?>">Review</a></li>
                <?php endif; ?>
                <?php if ($requirement['outstanding'] > 0): ?>
                    <li><?= status_indicator($urgency === 'urgent' ? 'urgent' : 'pending', $urgency === 'urgent' ? 'Urgent' : 'In progress') ?>
                        <span><strong><?= e(plural($requirement['outstanding'], 'active student')) ?></strong> of <?= $requirement['active'] ?> <?= $requirement['outstanding'] === 1 ? 'has' : 'have' ?> not yet completed <?= REQUIRED_HOURS ?> hours for <?= e($year) ?> (<?= e(plural($daysLeft, 'day')) ?> left in the year).</span>
                        <a class="btn secondary btn-sm" href="<?= e(url('reports/outstanding.php')) ?>">See who</a></li>
                <?php endif; ?>
            </ul>
            <?php endif; ?>
        </section>

        <section class="card">
            <?= section_head("Today's Attendance", 'clipboard', section_link('View All', url('admin/attendance.php', ['date' => $today]))) ?>
            <?php view('partials/attendance-table', [
                'rows'        => $todayRows,
                'showStudent' => true,
                'label'       => "Today's attendance",
                'emptyHtml'   => empty_state('No attendance recorded today', 'Entries appear here as soon as they are recorded.', '<a class="btn primary" href="' . e(url('admin/record-attendance.php', ['date' => $today])) . '">+ Record Attendance</a>', 'clipboard'),
            ]); ?>
        </section>

        <section class="card">
            <?= section_head('Duty hours still to complete (' . $year . ')', 'chart', section_link('Full report', url('reports/outstanding.php'))) ?>
            <?php if (!$behind): ?>
                <?= $requirement['active'] === 0
                    ? empty_state('No active students yet', 'Add students to start tracking their duty hours.', '<a class="btn primary" href="' . e(url('admin/students.php', ['add' => 1])) . '">Add a student</a>', 'users')
                    : '<p class="all-clear">' . status_indicator('complete', 'All students complete') . ' Every active student has reached ' . REQUIRED_HOURS . ' hours for ' . e($year) . '.</p>' ?>
            <?php else: ?>
                <ul class="behind-list">
                    <?php foreach ($behind as $b): ?>
                        <li>
                            <div class="behind-name"><a href="<?= e(url('admin/student-view.php', ['id' => (int) $b['id']])) ?>"><?= e($b['last_name'] . ', ' . $b['first_name']) ?></a>
                                <span class="cell-sub"><?= e($b['student_number'] . ' · ' . $b['course'] . ' · ' . $b['year_level']) ?></span></div>
                            <div class="behind-bar"><?= progress_bar($b['percent'], 'Duty hours completed by ' . $b['first_name']) ?></div>
                            <div class="behind-hours"><?= e(format_duration($b['minutes'])) ?> done · <strong><?= e(format_duration($b['remaining'])) ?> left</strong></div>
                            <?= status_indicator($urgency, $urgency === 'urgent' ? 'Urgent' : 'Pending') ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($requirement['outstanding'] > count($behind)): ?><p class="hint">Showing the <?= count($behind) ?> students with the most hours left, out of <?= $requirement['outstanding'] ?>.</p><?php endif; ?>
            <?php endif; ?>
        </section>

        <section class="card cta-strip" aria-label="Reports">
            <?= icon('users') ?>
            <div>
                <strong>Keep every duty hour on record.</strong>
                <span>Record attendance as it happens, review corrections, and export monthly reports for your organization.</span>
            </div>
            <a class="btn primary" href="<?= e(url('reports/monthly.php')) ?>">Open Reports <?= icon('arrow') ?></a>
        </section>
    </div>

    <aside class="dash-side">
        <section class="card">
            <?= section_head('Today', 'calendar', section_link('View All', url('admin/attendance.php', ['date' => $today]))) ?>
            <div class="today-row">
                <span class="date-block" aria-hidden="true"><span><?= e(date('M')) ?></span><b><?= e(date('j')) ?></b></span>
                <div>
                    <strong><?= e(date('l, F j')) ?></strong>
                    <span class="small"><?= $dayStats['present_active'] ?> of <?= $activeStudents ?> active students present</span>
                </div>
            </div>
            <?= progress_bar($attendanceRate, 'Attendance coverage today') ?>
            <p class="hint overview-note"><?= number_format($attendanceRate, 1) ?>% attendance coverage for today.</p>
        </section>

        <section class="card">
            <?= section_head('Announcements', 'megaphone', section_link('View All', url('admin/announcement-history.php'))) ?>
            <?php if (!$latestNotices): ?>
                <?= empty_state('No announcements yet', 'Send one to reach students and officers.', '<a class="btn secondary btn-sm" href="' . e(url('admin/announcements.php')) . '">New announcement</a>', 'megaphone') ?>
            <?php else: ?>
                <ul class="feed">
                    <?php foreach ($latestNotices as $n): ?>
                        <li>
                            <span class="feed-dot" aria-hidden="true"></span>
                            <div>
                                <div class="feed-row">
                                    <strong><?= e($n['title']) ?></strong>
                                    <time datetime="<?= e(date('c', strtotime((string) $n['published_at']))) ?>"><?= e(date('M d, Y', strtotime((string) $n['published_at']))) ?></time>
                                </div>
                                <p><?= e(mb_strimwidth((string) $n['message'], 0, 90, '…')) ?></p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>

        <section class="card">
            <?= section_head('Quick Actions', 'bolt') ?>
            <div class="quick-actions">
                <?php foreach ($quickActions as [$label, $href, $qaIcon, $primary]): ?>
                    <a class="qa<?= $primary ? ' primary' : '' ?>" href="<?= e($href) ?>"><?= icon($qaIcon) ?><span><?= e($label) ?> <?= icon('arrow') ?></span></a>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="card">
            <?= section_head('Recent Activity', 'activity', section_link('View All', url('admin/audit-logs.php'))) ?>
            <?php if (!$recent): ?>
                <?= empty_state('No activity yet', 'Changes made in the system will be listed here.', '', 'activity') ?>
            <?php else: ?>
                <ul class="feed">
                    <?php foreach ($recent as $log): ?>
                        <li>
                            <span class="feed-dot" aria-hidden="true"></span>
                            <div>
                                <strong><?= e($log['description']) ?></strong>
                                <small><?= e($log['username'] ?? 'System') ?> • <?= e(date('M j, g:i A', strtotime((string) $log['created_at']))) ?></small>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    </aside>
</div>
<?php render_footer();
