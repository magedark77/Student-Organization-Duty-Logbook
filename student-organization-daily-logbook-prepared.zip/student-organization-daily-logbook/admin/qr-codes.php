<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();
qr_ensure_ready();

$filters = student_filters_from_request();
$pageNo  = (int) get_str('page');
$query   = clean_query($filters);
$pageUrl = url('admin/qr-codes.php');

/* ---- Handle form posts (then redirect) -------------------------------- */
if (is_post()) {
    $id = (int) post_str('id');
    handle_post([
        'regenerate' => static function () use ($id): void {
            qr_code_regenerate($id);
            flash('success', 'A new QR code was created. The old printed or saved code no longer works.');
        },
        'disable' => static function () use ($id): void {
            qr_code_set_active($id, false);
            flash('success', 'QR code disabled. Scans of it are refused until you enable it again.');
        },
        'enable' => static function () use ($id): void {
            qr_code_set_active($id, true);
            flash('success', 'QR code enabled.');
        },
    ], 'qr code');
    redirect($pageUrl . ($query ? '?' . http_build_query($query + ($pageNo > 1 ? ['page' => $pageNo] : [])) : ''));
}

/* ---- Page data -------------------------------------------------------- */
$created = qr_codes_generate_missing(); // every registered student always has a code
$data    = qr_codes_search($filters, $pageNo);
$rows    = $data['rows'];
$courses = students_courses();
$printUrl = url('admin/qr-print.php');

render_header('Student QR Codes', 'qrcodes', ['scripts' => ['vendor/qrcode.js', 'js/qr-admin.js'], 'styles' => ['css/qr.css']]);
page_head('Student QR Codes', 'Every student has a unique code. It contains only a random token, never a name or number.', [
    ['label' => 'Print all (filtered)', 'href' => $printUrl . ($query ? '?' . http_build_query($query + ['all' => 1]) : '?all=1'), 'attrs' => ['target' => '_blank', 'rel' => 'noopener']],
    ['label' => 'Scan QR Attendance', 'href' => url('admin/qr-scanner.php'), 'class' => 'primary'],
], [['Student QR Codes', null]]);
?>
<?php if ($created > 0): ?>
    <?php alert('info', plural($created, 'new QR code') . ' created for students who did not have one yet.'); ?>
<?php endif; ?>

<section class="card">
    <?= filter_bar($pageUrl, student_filter_controls($filters, $courses), [
        'active' => count($query),
        'apply'  => null,
    ]) ?>

    <div class="qr-bulk no-print">
        <label class="qr-check"><input type="checkbox" data-qr-select-all> <span>Select all on this page</span></label>
        <a class="btn secondary btn-sm" href="<?= e($printUrl) ?>" target="_blank" rel="noopener" data-qr-print-selected data-base="<?= e($printUrl) ?>"><?= icon('file') ?> Print selected</a>
        <span class="small"><?= e(plural($data['total'], 'student')) ?></span>
    </div>

    <?php if (!$rows): ?>
        <?= empty_state('No students match your filters', 'Try a different search, or reset the filters.', '', 'users') ?>
    <?php else: ?>
        <ul class="qr-grid">
            <?php foreach ($rows as $s):
                $name  = $s['last_name'] . ', ' . $s['first_name'];
                $off   = (int) ($s['is_active'] ?? 1) !== 1;
                $token = (string) $s['token'];
                $file  = 'qr-' . preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $s['student_number']); ?>
                <li class="qr-card<?= $off ? ' is-off' : '' ?>">
                    <label class="qr-card-pick"><input type="checkbox" data-qr-pick value="<?= (int) $s['id'] ?>" aria-label="Select <?= e($name) ?>"></label>
                    <div class="qr-art" data-qr-text="<?= e(qr_payload($token)) ?>" role="img" aria-label="QR code of <?= e($name) ?>"></div>
                    <h3><?= e($name) ?></h3>
                    <p><?= e($s['student_number']) ?> · <?= e($s['course']) ?></p>
                    <p><?= status_badge($s['status']) ?><?= $off ? ' <span class="badge danger">Disabled</span>' : '' ?></p>
                    <?php if ($s['regenerated_at']): ?><p>Regenerated <?= e(format_datetime((string) $s['regenerated_at'])) ?></p><?php endif; ?>
                    <div class="qr-card-actions">
                        <button type="button" class="btn secondary btn-sm" data-qr-download data-text="<?= e(qr_payload($token)) ?>"
                                data-name="<?= e($s['first_name'] . ' ' . $s['last_name']) ?>" data-number="<?= e($s['student_number']) ?>" data-file="<?= e($file) ?>"><?= icon('download') ?> PNG</button>
                        <a class="btn secondary btn-sm" href="<?= e($printUrl . '?ids=' . (int) $s['id']) ?>" target="_blank" rel="noopener">Print</a>
                        <?= action_form($pageUrl, 'regenerate', (int) $s['id'], 'Regenerate', 'secondary',
                            'Create a new QR code for ' . $name . '? The current code (printed or on their phone) will stop working immediately.', $query + ($pageNo > 1 ? ['page' => $pageNo] : [])) ?>
                        <?= $off
                            ? action_form($pageUrl, 'enable', (int) $s['id'], 'Enable', 'secondary', '', $query)
                            : action_form($pageUrl, 'disable', (int) $s['id'], 'Disable', 'danger', 'Disable the QR code of ' . $name . '? Scans of it will be refused.', $query) ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <?= pagination($data['page'], $data['pages'], $pageUrl, $query) ?>
    <?php endif; ?>
</section>
<?php render_footer();
