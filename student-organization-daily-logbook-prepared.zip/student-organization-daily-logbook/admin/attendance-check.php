<?php
/* Tiny JSON endpoint behind the "a record already exists" warning on the attendance form. Read-only. */
require __DIR__ . '/../app/bootstrap.php';
require_attendance_access();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$studentId = (int) get_str('student_id');
$date      = get_str('date');
$out       = ['exists' => false];
if ($studentId > 0 && is_valid_date($date)) {
    $row = attendance_find_for($studentId, $date);
    if ($row !== null) {
        $m = attendance_minutes($row);
        $out = [
            'exists'     => true,
            'morning'    => format_time_range($row['morning_time_in'], $row['morning_time_out']),
            'afternoon'  => format_time_range($row['afternoon_time_in'], $row['afternoon_time_out']),
            'total'      => format_duration($m['total']),
            'incomplete' => attendance_incomplete_reasons($row),
            'canReplace' => can_modify_attendance(),
        ];
    }
}
echo json_encode($out);
