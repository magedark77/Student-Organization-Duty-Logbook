<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();
qr_ensure_ready();

// ?ids=1,2,3 prints those students; ?all=1 prints everyone matching the same filters as the QR Codes page.
if (get_str('all') === '1') {
    $ids = array_column(qr_codes_search(student_filters_from_request(), 1, 500, true)['rows'], 'id');
} else {
    $ids = array_filter(explode(',', get_str('ids')), 'ctype_digit');
}
$students = qr_codes_for_ids($ids);

render_header('Print QR Codes', 'qrcodes', ['scripts' => ['vendor/qrcode.js', 'js/qr-admin.js'], 'styles' => ['css/qr.css']]);
page_head('Print QR Codes', plural(count($students), 'card') . '. Cut along the dashed lines; laminate for durable ID cards.', [
    ['label' => 'Back', 'href' => url('admin/qr-codes.php')],
    ['label' => 'Print', 'class' => 'primary', 'attrs' => ['data-print' => '']],
], [['Student QR Codes', url('admin/qr-codes.php')], ['Print', null]]);
?>
<?php if (!$students): ?>
    <?= empty_state('Nothing to print', 'Choose students on the QR Codes page first.', '', 'users') ?>
<?php else: ?>
    <div class="qr-sheet">
        <?php foreach ($students as $s):
            $off = (int) $s['is_active'] !== 1; ?>
            <div class="qr-card">
                <div class="qr-art" data-qr-text="<?= e(qr_payload((string) $s['token'])) ?>" role="img" aria-label="QR code of <?= e($s['last_name']) ?>"></div>
                <h3><?= e($s['first_name'] . ' ' . $s['last_name']) ?></h3>
                <p><?= e($s['student_number']) ?><?= $s['course'] !== '' ? ' · ' . e($s['course']) : '' ?></p>
                <p><?= e(APP_SHORT_NAME) ?><?= $off ? ' · DISABLED' : '' ?></p>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php render_footer();
