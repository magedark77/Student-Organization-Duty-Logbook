<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$pageUrl = url('admin/student-import.php');

/* Example file */
if (get_str('template') !== '') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="student-import-template.csv"');
    echo student_import_template();
    exit;
}

/* One-time download of the reset links created by the last import (then they are forgotten). */
if (get_str('download_links') !== '' && !empty($_SESSION['import_result']['links'])) {
    $links = $_SESSION['import_result']['links'];
    unset($_SESSION['import_result']['links']);
    send_csv('student-reset-links.csv', ['Student number', 'Name', 'Username', 'Password-reset link'],
        array_map(static fn(array $l): array => [$l['student_number'], $l['name'], $l['username'], $l['url']], $links));
}

if (is_post()) {
    handle_post([
        'upload' => static function (): void {
            $file = $_FILES['csv'] ?? null;
            if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                throw new ValidationException('Choose a CSV file to upload.', 'csv');
            }
            if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
                throw new ValidationException('The file could not be uploaded (it may be too large). Please try again.', 'csv');
            }
            if (!in_array(strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION)), ['csv', 'txt'], true)) {
                throw new ValidationException('Only .csv files are accepted. In Excel use “Save as → CSV (Comma delimited)”.', 'csv');
            }
            $parsed = student_import_parse($file['tmp_name']);
            $_SESSION['student_import'] = $parsed + ['name' => mb_substr(basename((string) $file['name']), 0, 100), 'token' => bin2hex(random_bytes(16))];
            unset($_SESSION['import_result']);
            flash('info', 'Nothing has been saved yet. Review the preview below, then confirm the import.');
        },
        'discard' => static function (): void {
            unset($_SESSION['student_import']);
            flash('info', 'Import cancelled. Nothing was saved.');
        },
        'commit' => static function (): void {
            $pending = $_SESSION['student_import'] ?? null;
            if (!$pending || !hash_equals((string) $pending['token'], post_str('import_token', false))) {
                throw new ValidationException('The preview has expired. Please upload the file again.');
            }
            if ($pending['ok'] === 0) {
                throw new ValidationException('There are no valid rows to import. Fix the file and upload it again.');
            }
            $result = student_import_commit($pending['rows'], post_str('create_logins') === '1');
            unset($_SESSION['student_import']);
            $_SESSION['import_result'] = $result;
            flash('success', 'Import finished: ' . plural($result['created'], 'student') . ' added' . ($result['skipped'] ? ', ' . plural($result['skipped'], 'row') . ' skipped' : '') . '.');
        },
    ], 'student import');
    redirect($pageUrl);
}

$pending = $_SESSION['student_import'] ?? null;
$result  = $_SESSION['import_result'] ?? null;

render_header('Import Students', 'students');
page_head('Import students from CSV', 'Upload a file, review exactly what will be saved, then confirm.', [
    ['label' => 'Back to students', 'href' => url('admin/students.php')],
], [['Students', url('admin/students.php')], ['Import CSV', null]]);
?>
<?php if ($result): ?>
    <section class="card">
        <h2>Import result</h2>
        <p><?= e(plural($result['created'], 'student')) ?> added, <?= e(plural($result['skipped'], 'row')) ?> skipped, <?= e(plural($result['logins'], 'login')) ?> created.</p>
        <?php if (!empty($result['links'])): ?>
            <?php alert('warning', 'Logins were created with no usable password. Each student sets their own password with a one-time link (valid 7 days). Download the links now; they are shown only once.'); ?>
            <p><a class="btn primary" href="<?= e(url('admin/student-import.php', ['download_links' => 1])) ?>"><?= icon('download') ?> Download reset links (CSV)</a></p>
        <?php endif; ?>
        <p><a class="btn secondary" href="<?= e(url('admin/students.php')) ?>">View students</a></p>
    </section>
<?php endif; ?>

<?php if ($pending): ?>
    <section class="card">
        <?= section_head('Preview: ' . $pending['name']) ?>
        <div class="grid cols-3 import-summary">
            <?php stat_card('Ready to import', (string) $pending['ok'], 'Valid and new', 'check', 'done'); ?>
            <?php stat_card('Duplicates', (string) $pending['duplicates'], 'Will be skipped', 'alert', $pending['duplicates'] ? 'left' : 'done'); ?>
            <?php stat_card('Errors', (string) $pending['errors'], 'Will be skipped', 'alert', $pending['errors'] ? 'left' : 'done'); ?>
        </div>
        <?php table_start('Import preview', true); ?>
            <thead><tr><th scope="col">Line</th><th scope="col">Student No.</th><th scope="col">Name</th><th scope="col">Course</th><th scope="col">Duty day</th><th scope="col">Result</th></tr></thead>
            <tbody>
                <?php foreach ($pending['rows'] as $row): $d = $row['data']; ?>
                    <tr class="<?= $row['status'] === 'ok' ? '' : 'row-incomplete' ?>">
                        <td data-label="Line"><?= (int) $row['line'] ?></td>
                        <td data-label="Student No."><?= e($d['student_number'] ?? '') ?></td>
                        <td data-label="Name"><?= e(trim(($d['last_name'] ?? '') . ', ' . ($d['first_name'] ?? ''), ', ')) ?></td>
                        <td data-label="Course"><?= e($d['course'] ?? '') ?></td>
                        <td data-label="Duty day"><?= e($d['duty_day'] ?? '') ?></td>
                        <td data-label="Result" class="cell-wrap">
                            <?php if ($row['status'] === 'ok'): ?>
                                <?= status_indicator('complete', 'Ready') ?>
                            <?php elseif ($row['status'] === 'duplicate'): ?>
                                <?= status_indicator('pending', 'Duplicate') ?> <span class="cell-sub"><?= e($row['message']) ?></span>
                            <?php else: ?>
                                <?= status_indicator('urgent', 'Error') ?> <span class="cell-sub"><?= e($row['message']) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php table_end(); ?>

        <form method="post" action="<?= e($pageUrl) ?>" class="form-stack import-confirm" data-confirm="Import <?= (int) $pending['ok'] ?> student(s) now? Rows with errors or duplicates are skipped.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="commit">
            <input type="hidden" name="import_token" value="<?= e($pending['token']) ?>">
            <label class="check"><input type="checkbox" name="create_logins" value="1"> <span>Also create a login for each new student (username = student number). Students set their own password through a one-time link.</span></label>
            <div class="form-actions">
                <button type="submit" class="btn primary"<?= $pending['ok'] === 0 ? ' disabled' : '' ?>>Import <?= (int) $pending['ok'] ?> student(s)</button>
            </div>
        </form>
        <form method="post" action="<?= e($pageUrl) ?>" class="inline-form">
            <?= csrf_field() ?><input type="hidden" name="action" value="discard">
            <button type="submit" class="btn secondary">Cancel and upload a different file</button>
        </form>
    </section>
<?php else: ?>
    <section class="card card-form">
        <h2>Upload a CSV file</h2>
        <form method="post" action="<?= e($pageUrl) ?>" enctype="multipart/form-data" class="form-stack">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="upload">
            <label><?= field_label_text('CSV file', ['required' => true]) ?>
                <input type="file" name="csv" accept=".csv,text/csv" required<?= field_error('csv') !== '' ? ' aria-invalid="true" aria-describedby="err-csv"' : '' ?>>
                <span class="hint">Up to <?= IMPORT_MAX_ROWS ?> students and <?= IMPORT_MAX_BYTES / 1048576 ?> MB per file.</span>
                <?= field_error_html('csv') ?>
            </label>
            <div class="form-actions"><button class="btn primary" type="submit">Upload and preview</button></div>
        </form>
        <h3>Expected columns</h3>
        <p><strong>Required:</strong> <?= e(implode(', ', IMPORT_REQUIRED)) ?>.<br>
           <strong>Optional:</strong> <?= e(implode(', ', IMPORT_OPTIONAL)) ?> (status defaults to Active).<br>
           Duty day must be one of <?= e(implode(', ', DUTY_DAYS)) ?>. Passwords are never read from the file.</p>
        <p><a class="btn secondary" href="<?= e(url('admin/student-import.php', ['template' => 1])) ?>"><?= icon('download') ?> Download template</a></p>
    </section>
<?php endif; ?>
<?php render_footer();
