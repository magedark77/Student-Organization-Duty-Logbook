<?php
/**
 * JSON endpoint behind the scanner page: receives the text read from a QR code, validates it on the server and records
 * Time In or Time Out. Nothing the browser says about the student, the time or the action is trusted.
 *
 * POST fields: code, method (camera|manual), request_id (32 hex), csrf
 */
require __DIR__ . '/../app/bootstrap.php';

/** Send a JSON answer and stop. */
function qr_json(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (!is_post()) {
    header('Allow: POST');
    qr_json(405, ['ok' => false, 'reason' => 'method', 'message' => 'Use the scanner page to record attendance.']);
}

try {
    // Same sign-in rules as every other page, but answered in JSON instead of a redirect.
    if (!user()) {
        qr_json(401, ['ok' => false, 'reason' => 'auth', 'message' => 'Your session has ended. Please sign in again.']);
    }
    if (!session_is_current()) {
        session_end();
        qr_json(401, ['ok' => false, 'reason' => 'auth', 'message' => 'This account was changed or deactivated. Please sign in again.']);
    }
    if (!is_admin() && !is_restricted_staff()) {
        qr_json(403, ['ok' => false, 'reason' => 'forbidden', 'message' => 'Only administrators and officers can record attendance.']);
    }
    if (is_restricted_staff() && !within_duty_hours()) {
        qr_json(403, ['ok' => false, 'reason' => 'forbidden', 'message' => 'Officers can record attendance only during duty hours (' . duty_hours_label() . ').']);
    }
    if (!csrf_is_valid()) {
        qr_json(419, ['ok' => false, 'reason' => 'csrf', 'message' => 'This page has expired. Reload it and scan again.']);
    }
    qr_ensure_ready();
    session_write_close(); // let other requests of this session (page refreshes) continue while the database works

    $result = qr_process_scan(post_str('code', false), post_str('request_id'), post_str('method'));
    qr_json(200, $result);
} catch (QrScanException $e) {
    qr_json($e->httpStatus, [
        'ok'      => false,
        'reason'  => $e->reason,
        'message' => $e->getMessage(),
        'student' => $e->student,
    ] + $e->extra);
} catch (Throwable $e) {
    error_log('[studentbody] QR scan failed: ' . $e->getMessage());
    $database = $e instanceof PDOException;
    qr_json(500, [
        'ok'      => false,
        'reason'  => $database ? 'database' : 'server',
        'message' => ($database ? 'The database is not reachable right now.' : 'The server could not record this scan.') . ' Nothing was saved. Please scan again in a moment.',
    ]);
}
