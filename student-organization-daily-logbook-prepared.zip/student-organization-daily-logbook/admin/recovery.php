<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$me       = user();
$newCodes = null;

if (is_post()) {
    check_csrf();
    try {
        $newCodes = recovery_codes_generate(post_str('current_password', false));
    } catch (ValidationException $e) {
        flash('danger', $e->getMessage());
        redirect(url('admin/recovery.php'));
    }
}

$remaining = recovery_codes_remaining((int) $me['id']);
$flash     = get_flash();

render_header('Account Recovery', 'recovery');
page_head('Account Recovery', 'Recovery codes let you get back into this administrator account if you forget the password.', [], [['Account Recovery', null]]);
if ($flash) {
    alert($flash[0], $flash[1]);
}
?>
<?php if ($newCodes !== null): ?>
<div class="card card-narrow">
    <h2>Your new recovery codes</h2>
    <?php alert('warning', 'Save these now: print them or store them in a password manager. They are shown only once, and any older codes no longer work.'); ?>
    <ol class="recovery-codes">
        <?php foreach ($newCodes as $code): ?><li><?= e($code) ?></li><?php endforeach; ?>
    </ol>
    <p class="text-muted">Each code works once. Use one at <strong>Forgot administrator password?</strong> on the sign-in page.</p>
    <div class="form-actions"><button class="btn secondary" type="button" data-print>Print</button></div>
</div>
<?php else: ?>
<div class="card card-narrow">
    <h2>Recovery codes</h2>
    <p>Unused codes: <strong><?= (int) $remaining ?></strong> of <?= RECOVERY_CODE_COUNT ?>.</p>
    <?php if ($remaining === 0): ?><?php alert('warning', 'You have no recovery codes. If you forget your password you will have no way back in, so generate a set now.'); ?><?php endif; ?>
    <form method="post" class="form-stack">
        <?= csrf_field() ?>
        <label>Current password
            <input type="password" name="current_password" required autocomplete="current-password">
            <span class="hint">Generating a new set replaces any codes you already have.</span>
        </label>
        <div class="form-actions"><button class="btn primary" type="submit"><?= $remaining > 0 ? 'Generate new codes' : 'Generate recovery codes' ?></button></div>
    </form>
</div>
<?php endif; ?>
<?php render_footer();
