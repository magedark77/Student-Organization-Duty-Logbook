<?php
require __DIR__ . '/../app/bootstrap.php';
require_announcer();

$id  = (int) (is_post() ? post_str('id') : get_str('id'));
$row = $id > 0 ? announcement_find($id) : null;
if ($row === null) {
    render_error_page(404, 'Announcement not found', 'This announcement does not exist.');
}
// Server-side permission: administrators manage everything, announcers only their own.
if (!announcement_can_manage($row)) {
    render_error_page(403, 'Access denied', 'You can only view announcements that you published.');
}
$pageUrl = url('admin/announcement-view.php', ['id' => $id]);

if (is_post()) {
    $pin = static fn(bool $pinned): callable => static function () use ($id, $pinned): void {
        announcement_set_pinned($id, $pinned);
        flash('success', $pinned ? 'Announcement pinned to the top.' : 'Announcement unpinned.');
    };
    $result = handle_post([
        'update' => static function () use ($id): void {
            announcement_update($id, post_str('title'), post_str('message'), post_str('priority'), post_str('expires_on'), post_str('pinned') === '1');
            flash('success', 'Announcement updated. Recipients will see the new wording.');
        },
        'cancel' => static function () use ($id): void {
            announcement_cancel($id);
            flash('success', 'Announcement cancelled. Recipients can no longer see it; the read history is kept.');
        },
        'pin'   => $pin(true),
        'unpin' => $pin(false),
    ], 'announcement');
    if ($result['outcome'] === ACTION_INVALID && $result['action'] === 'update') {
        remember_input($_POST);
        redirect(url('admin/announcement-view.php', ['id' => $id, 'edit' => 1]));
    }
    redirect($pageUrl);
}

$status   = announcement_status($row);
$receipts = announcement_receipts($id);
$total    = (int) $row['recipient_count'];
$read     = (int) $row['read_count'];
$editable = $row['status'] !== 'cancelled';
$editOpen = $editable && get_str('edit') !== '';

render_header($row['title'], 'announce');
$actions = [['label' => 'Back to history', 'href' => url('admin/announcement-history.php')]];
if ($editable) {
    array_unshift($actions, ['label' => 'Edit', 'attrs' => ['data-modal-open' => 'announcement-modal']]);
}
page_head('Announcement', 'Published ' . format_datetime((string) $row['published_at']) . ' by ' . ($row['author'] ?? 'unknown'), $actions,
    [['Announcements', url('admin/announcements.php')], ['History', url('admin/announcement-history.php')], [mb_strimwidth($row['title'], 0, 40, '…'), null]]);
?>
<?php if ($status === 'cancelled'): ?><?php alert('warning', 'This announcement was cancelled on ' . format_datetime((string) $row['cancelled_at']) . '. Recipients can no longer open it.'); ?><?php endif; ?>
<?php if ($status === 'expired'): ?><?php alert('info', 'This announcement expired on ' . format_date(substr((string) $row['expires_at'], 0, 10)) . ' and has moved to recipients’ archive.'); ?><?php endif; ?>

<div class="grid cols-4">
    <?php
    stat_card('Recipients', (string) $total, announcement_audience_label($row['audience']), 'users');
    stat_card('Read', (string) $read, $total > 0 ? number_format($read / $total * 100, 0) . '% of recipients' : '', 'check', 'done');
    stat_card('Unread', (string) ($total - $read), 'Have not opened it yet', 'clock', $total - $read > 0 ? 'left' : 'done');
    ?>
    <div class="card stat-card"><div class="stat-body">
        <div class="stat-label">Status</div>
        <div class="badge-line"><?= announcement_status_badge($row) ?> <?= announcement_priority_badge($row['priority']) ?><?php if ($row['is_pinned']): ?> <span class="badge info"><?= icon('pin') ?>Pinned</span><?php endif; ?></div>
        <div class="stat-sub">Expires: <?= $row['expires_at'] !== null ? e(format_date(substr((string) $row['expires_at'], 0, 10))) : 'never' ?></div>
    </div></div>
</div>

<section class="card">
    <?= section_head($row['title']) ?>
    <div class="announcement-body"><?= nl2br(e($row['message'])) ?></div>
    <?php if ($row['edited_at'] !== null): ?><p class="hint">Last edited <?= e(format_datetime((string) $row['edited_at'])) ?>.</p><?php endif; ?>
    <?php if ($editable): ?>
        <div class="actions no-print manage-actions">
            <?php if (is_admin()): ?>
                <?= action_form($pageUrl, $row['is_pinned'] ? 'unpin' : 'pin', $id, $row['is_pinned'] ? 'Unpin' : 'Pin to top', 'secondary', '', []) ?>
            <?php endif; ?>
            <?= action_form($pageUrl, 'cancel', $id, 'Cancel announcement', 'danger', 'Cancel this announcement? Recipients will no longer see it and their notifications are removed. The read history stays in the record.') ?>
        </div>
    <?php endif; ?>
</section>

<section class="card">
    <?= section_head('Read receipts', '', '<span class="small">' . $read . ' of ' . $total . ' read</span>') ?>
    <?= progress_bar($total > 0 ? $read / $total * 100 : 0, 'Share of recipients who have read this announcement') ?>
    <?php if (!$receipts): ?>
        <?= empty_state('No recipients', 'This announcement was not delivered to anyone.') ?>
    <?php else: ?>
        <?php table_start('Read receipts', true); ?>
            <thead><tr><th scope="col">Recipient</th><th scope="col">Role</th><th scope="col">Status</th><th scope="col">Read on</th></tr></thead>
            <tbody>
                <?php foreach ($receipts as $r): ?>
                    <tr>
                        <td data-label="Recipient"><strong><?= e($r['username']) ?></strong>
                            <?php if ($r['first_name'] !== null): ?><span class="cell-sub"><?= e($r['student_number'] . ' · ' . $r['first_name'] . ' ' . $r['last_name']) ?></span><?php endif; ?></td>
                        <td data-label="Role"><?= e(role_label((string) $r['role'])) ?></td>
                        <td data-label="Status"><?= $r['read_at'] !== null ? '<span class="badge success">' . icon('check') . 'Read</span>' : '<span class="badge warning">' . icon('clock') . 'Unread</span>' ?></td>
                        <td data-label="Read on"><?= $r['read_at'] !== null ? e(format_datetime((string) $r['read_at'])) : '<span class="text-faint">—</span>' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php table_end(); ?>
    <?php endif; ?>
</section>

<?php if ($editable):
    modal_start('announcement-modal', 'Edit announcement', $editOpen, ['edit']); ?>
    <form method="post" action="<?= e($pageUrl) ?>" class="form-stack">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?= $id ?>">
        <p class="hint">The audience cannot be changed after publishing. Edits are visible to everyone who received it and are written to the audit log.</p>
        <?= field_input('Title', 'title', (string) old('title', $row['title']), ['required' => true, 'maxlength' => ANNOUNCEMENT_TITLE_MAX]) ?>
        <?= field_textarea('Message', 'message', (string) old('message', $row['message']), ['required' => true, 'maxlength' => ANNOUNCEMENT_MESSAGE_MAX, 'rows' => 7]) ?>
        <div class="form-grid">
            <label>Priority
                <select name="priority">
                    <?php foreach (ANNOUNCEMENT_PRIORITIES as $key => [$label]): ?>
                        <option value="<?= e($key) ?>"<?= (string) old('priority', $row['priority']) === $key ? ' selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <?= field_error_html('priority') ?>
            </label>
            <?= field_input('Expires on (optional)', 'expires_on', (string) old('expires_on', $row['expires_at'] !== null ? substr((string) $row['expires_at'], 0, 10) : ''), ['type' => 'date']) ?>
        </div>
        <?php if (is_admin()): ?>
            <label class="check"><input type="checkbox" name="pinned" value="1"<?= ((string) old('pinned', $row['is_pinned'] ? '1' : '')) === '1' ? ' checked' : '' ?>> <span>Pin to the top</span></label>
        <?php endif; ?>
        <div class="form-actions">
            <button type="button" class="btn secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn primary">Save changes</button>
        </div>
    </form>
<?php modal_end(); endif;
render_footer();
