<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$pageUrl = url('admin/officers.php');

/* ---- Handle form posts (then redirect) -------------------------------- */
if (is_post()) {
    $id     = (int) post_str('id');
    $result = handle_post([
        'create' => static function (): void {
            officer_create(post_str('username'), post_str('password', false), post_str('role'));
            flash('success', 'Officer account created.');
        },
        'update' => static function () use ($id): void {
            officer_update($id, post_str('username'), post_str('role'), post_str('password', false));
            flash('success', 'Officer account updated.');
        },
        'delete' => static function () use ($id): void {
            officer_delete($id);
            flash('success', 'Officer account deleted.');
        },
        'deactivate' => static function () use ($id): void {
            account_set_active($id, false);
            flash('success', 'Account deactivated. The officer is signed out and cannot sign in until reactivated.');
        },
        'reactivate' => static function () use ($id): void {
            account_set_active($id, true);
            flash('success', 'Account reactivated. The officer can sign in again.');
        },
        'reset_link' => static function () use ($id): void {
            // Officers only: never create a link for an administrator or student through this page.
            $officer = officer_find($id);
            reset_link_handler($officer !== null ? (int) $officer['id'] : null, 'officer', 'That officer account no longer exists.')();
        },
    ], 'officer');

    $target = $pageUrl;
    if ($result['outcome'] === ACTION_INVALID && in_array($result['action'], ['create', 'update'], true)) {
        remember_input($_POST);
        $target = $pageUrl . '?' . http_build_query($result['action'] === 'update' && $id > 0 ? ['edit' => $id] : ['add' => 1]);
    }
    redirect($target);
}

/* ---- Page data -------------------------------------------------------- */
$edit = null;
if (get_str('edit') !== '') {
    $edit = officer_find((int) get_str('edit'));
    if ($edit === null) {
        flash('warning', 'That officer account could not be found.');
    }
}
$modalOpen = $edit !== null || get_str('add') !== '';
$officers  = officer_accounts();
$resetLink = pull_reset_link();
$roles     = officer_role_options();

render_header('Officer Accounts', 'officers');
page_head('Officer Accounts', 'Logins for the President, Vice Presidents and Secretary. Officers can sign in only during duty hours (' . duty_hours_label() . ').', [
    ['label' => '+ Add Officer', 'href' => $pageUrl . '?add=1', 'class' => 'primary'],
], [['Officer Accounts', null]]);
?>
<?php if ($resetLink): ?>
    <section class="card reset-link-card" aria-live="polite">
        <h2>Password-reset link for <?= e($resetLink['username']) ?></h2>
        <p>Send this link to the officer privately. It works <strong>once</strong> and expires on <?= e(format_datetime($resetLink['expires_at'])) ?>. It will not be shown again.</p>
        <label>Reset link <input type="text" readonly value="<?= e($resetLink['url']) ?>" data-select-on-focus></label>
    </section>
<?php endif; ?>

<section class="card">
    <p class="small result-count"><?= e(plural(count($officers), 'officer account')) ?></p>
    <?php if (!$officers): ?>
        <?= empty_state('No officer accounts yet', 'Add a login for the President, a Vice President or the Secretary.', '<a class="btn primary" href="' . e($pageUrl . '?add=1') . '">Add the first officer</a>', 'officers') ?>
    <?php else: ?>
    <?php table_start('Officer accounts', true); ?>
        <thead>
            <tr>
                <th scope="col">Username</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
                <th scope="col">Created</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($officers as $officer):
                $oid       = (int) $officer['id'];
                $isActive  = (int) $officer['is_active'] === 1;
                $needsRole = !in_array($officer['role'], STAFF_ROLES, true); // old or blank role: cannot sign in until reassigned ?>
                <tr>
                    <td data-label="Username"><?= e($officer['username']) ?></td>
                    <td data-label="Role">
                        <?= e($officer['role'] === '' ? 'No role' : role_label((string) $officer['role'])) ?>
                        <?= $needsRole ? ' <span class="badge warning">Old role: edit to assign a new one</span>' : '' ?>
                    </td>
                    <td data-label="Status"><?= account_status_badge($officer) ?></td>
                    <td data-label="Created"><?= e(format_datetime((string) $officer['created_at'])) ?></td>
                    <td data-label="Actions">
                        <div class="actions">
                            <a class="btn secondary btn-sm" href="<?= e($pageUrl . '?edit=' . $oid) ?>">Edit</a>
                            <?= action_menu([
                                $isActive
                                    ? action_form($pageUrl, 'deactivate', $oid, 'Deactivate', 'secondary',
                                        'Deactivate ' . $officer['username'] . '? They are signed out at once and cannot sign in. Attendance they recorded is kept. You can reactivate the account at any time.')
                                    : action_form($pageUrl, 'reactivate', $oid, 'Reactivate', 'secondary'),
                                action_form($pageUrl, 'reset_link', $oid, 'Create reset link', 'secondary',
                                    'Create a one-time password-reset link for ' . $officer['username'] . '? Any earlier unused link stops working.'),
                                delete_form($pageUrl, $oid,
                                    'PERMANENTLY delete the officer account ' . $officer['username'] . '? Attendance they recorded is kept. Use Deactivate instead to keep the account.'),
                            ], 'More actions for ' . $officer['username']) ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php table_end(); ?>
    <?php endif; ?>
</section>

<?php
modal_start('officer-modal', $edit ? 'Edit Officer' : 'Add Officer', $modalOpen, ['edit', 'add']);
view('partials/officer-form', ['edit' => $edit, 'formAction' => $pageUrl, 'roles' => $roles]);
modal_end();

render_footer();
