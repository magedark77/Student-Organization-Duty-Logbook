<?php
require __DIR__ . '/../app/bootstrap.php';
require_announcer();

$pageUrl   = url('admin/announcements.php');
$audiences = announcement_send_audiences();

if (is_post()) {
    check_csrf();
    $created = 0;
    $outcome = run_action('announcement', static function () use (&$created): void {
        $result  = announcement_send(post_str('audience'), post_str('title'), post_str('message'), [
            'priority'       => post_str('priority') ?: 'normal',
            'expires_on'     => post_str('expires_on'),
            'pinned'         => post_str('pinned') === '1',
            'confirm_urgent' => post_str('confirm_urgent') === '1',
        ]);
        $created = $result['id'];
        flash('success', 'Announcement published to ' . plural($result['recipients'], 'person', 'people') . '. You can follow who has read it below.');
    });
    if ($outcome === ACTION_INVALID) {
        remember_input($_POST); // keep what was typed so nothing has to be retyped
    }
    redirect($outcome === ACTION_OK ? url('admin/announcement-view.php', ['id' => $created]) : $pageUrl);
}

$sizes = announcement_audience_sizes();

render_header('Announcements', 'announce');
page_head('Announcements', 'Publish a notice to a group. Recipients get a notification and can open the full text, which records that they have read it.', [
    ['label' => 'History & read receipts', 'href' => url('admin/announcement-history.php')],
], [['Announcements', null]]);
?>
<section class="card card-form">
    <h2>New announcement</h2>
    <p class="hint required-note"><span class="req" aria-hidden="true">*</span> marks required fields.</p>
    <form method="post" action="<?= e($pageUrl) ?>" class="form-stack" data-confirm="Publish this announcement now? Recipients are notified immediately. You can edit or cancel it later from the history page.">
        <?= csrf_field() ?>
        <label><?= field_label_text('Send to', ['required' => true]) ?>
            <select name="audience" required<?= field_error('audience') !== '' ? ' aria-invalid="true" aria-describedby="err-audience"' : '' ?>>
                <option value="">Choose a group</option>
                <?php foreach ($audiences as $key => $label): ?>
                    <option value="<?= e($key) ?>"<?= (string) old('audience') === $key ? ' selected' : '' ?>><?= e($label) ?> — <?= e(plural($sizes[$key], 'recipient')) ?></option>
                <?php endforeach; ?>
            </select>
            <?= field_error_html('audience') ?>
        </label>
        <div class="form-grid">
            <label>Priority
                <select name="priority" data-priority>
                    <?php foreach (ANNOUNCEMENT_PRIORITIES as $key => [$label]): ?>
                        <option value="<?= e($key) ?>"<?= (string) old('priority', 'normal') === $key ? ' selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <?= field_error_html('priority') ?>
                <span class="hint">Urgent notices are marked in red and need a confirmation.</span>
            </label>
            <?= field_input('Expires on (optional)', 'expires_on', (string) old('expires_on'), ['type' => 'date', 'min' => date('Y-m-d')]) ?>
        </div>
        <?= field_input('Title', 'title', (string) old('title'), ['required' => true, 'maxlength' => ANNOUNCEMENT_TITLE_MAX, 'autocomplete' => 'off']) ?>
        <?= field_textarea('Message', 'message', (string) old('message'), ['required' => true, 'maxlength' => ANNOUNCEMENT_MESSAGE_MAX, 'rows' => 6, 'placeholder' => 'What should they know?'], 'Up to ' . number_format(ANNOUNCEMENT_MESSAGE_MAX) . ' characters. Plain text only.') ?>
        <?php if (is_admin()): ?>
            <label class="check"><input type="checkbox" name="pinned" value="1"<?= (string) old('pinned') === '1' ? ' checked' : '' ?>> <span>Pin to the top of recipients’ announcements</span></label>
        <?php endif; ?>
        <div data-show-when="priority=urgent">
            <label class="check urgent-confirm"><input type="checkbox" name="confirm_urgent" value="1"<?= (string) old('confirm_urgent') === '1' ? ' checked' : '' ?>>
                <span>I confirm this <strong>urgent</strong> announcement should be sent now.</span></label>
            <?= field_error_html('confirm_urgent') ?>
        </div>
        <div class="form-actions"><button class="btn primary" type="submit">Publish announcement</button></div>
    </form>
</section>
<?php render_footer();
