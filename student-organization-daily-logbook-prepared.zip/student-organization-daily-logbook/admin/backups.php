<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$me      = user();
$pageUrl = url('admin/backups.php');

/* ---- Download (GET). The file is chosen by database id; a file name from the request is never used. ---- */
if (isset($_GET['download'])) {
    $row  = db_one("SELECT * FROM db_backups WHERE id = ? AND status = 'ok' AND file_name IS NOT NULL", [(int) $_GET['download']]);
    $path = $row ? backup_path((string) $row['file_name']) : null;
    if (!$row || $path === null || !is_file($path)) {
        render_error_page(404, 'Backup not found', 'That backup file no longer exists.');
    }
    $check = backup_verify_record($row);
    if (!$check['ok']) {
        render_error_page(409, 'Backup is damaged', $check['message']);
    }
    audit('EXPORT', 'db_backups', (int) $row['id'], 'Downloaded database backup ' . $row['file_name']);
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $row['file_name'] . '"');
    header('Content-Length: ' . (string) filesize($path));
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

/* ---- State-changing actions (POST + CSRF + administrator only) ---- */
if (is_post()) {
    $id = (int) post_str('id');
    handle_post([
        'create' => static function () use ($me): void {
            $row = backup_create('manual', (int) $me['id']);
            audit('BACKUP', 'db_backups', (int) $row['id'], 'Manual database backup created: ' . $row['file_name'], null, ['size_bytes' => (int) $row['size_bytes'], 'tables' => (int) $row['table_count'], 'rows' => (int) $row['row_count']]);
            flash('success', 'Backup created and verified (' . backup_format_size((int) $row['size_bytes']) . ', ' . number_format((int) $row['row_count']) . ' rows). Download a copy and keep it somewhere other than this server.');
        },
        'verify' => static function () use ($id): void {
            $row = db_one("SELECT * FROM db_backups WHERE id = ? AND file_name IS NOT NULL", [$id]);
            if (!$row) {
                throw new ValidationException('That backup was not found.');
            }
            $check = backup_verify_record($row);
            if (!$check['ok']) {
                throw new ValidationException('Verification failed: ' . $check['message']);
            }
            flash('success', 'Backup verified: checksum matches, ' . $check['tables'] . ' tables, ' . number_format($check['rows']) . ' rows. Nothing was changed.');
        },
        'delete' => static function () use ($id): void {
            $row = db_one('SELECT file_name FROM db_backups WHERE id = ?', [$id]);
            backup_delete($id);
            audit('DELETE', 'db_backups', $id, 'Deleted database backup ' . ($row['file_name'] ?? '(no file)'));
            flash('success', 'Backup deleted.');
        },
        'restore' => static function () use ($id, $me): void {
            $hash = db_value('SELECT password FROM users WHERE id = ?', [(int) $me['id']]);
            if (!is_string($hash) || !password_verify(post_str('password', false), $hash)) {
                throw new ValidationException('Your password is incorrect. Nothing was restored.', 'password');
            }
            if (post_str('confirm_text') !== 'RESTORE') {
                throw new ValidationException('Type RESTORE (capital letters) to confirm. Nothing was restored.', 'confirm_text');
            }
            if (post_str('understand') !== '1') {
                throw new ValidationException('Tick the box to confirm you understand that current data will be replaced.');
            }
            $result = backup_restore_record($id, (int) $me['id']);
            flash('success', 'Database restored (' . number_format($result['statements']) . ' statements). A safety copy of the previous data was saved as ' . $result['safety_backup']['file_name'] . '. If you are signed out, sign in again.');
        },
    ], 'backup');
    redirect($pageUrl);
}

$history = backup_history(50);
$last    = backup_last_ok();
$public  = backup_dir_is_public();
$flash   = get_flash();
$cron    = (string) app_config('backup_cron_token', '') !== '';
$autoDay = (int) app_config('backup_auto_days', 0);
$stale   = !$last || strtotime((string) $last['created_at']) < time() - 7 * 86400;

render_header('Backup & Recovery', 'backups');
page_head('Backup & Recovery', 'Create, verify, download and restore copies of the whole database.', [], [['Backup & Recovery', null]]);
if ($flash) {
    alert($flash[0], $flash[1]);
}
if ($stale) {
    alert('warning', $last ? 'The newest backup is more than 7 days old (' . format_datetime((string) $last['created_at']) . ').' : 'No backup exists yet. Create one now.');
}
if ($public) {
    alert('info', 'Backups are stored inside the website folder and protected by an access rule (.htaccess). They are served only through this page. If your host ignores .htaccess, set "backup_dir" in config/config.local.php to a folder outside the web root.');
}
?>
<section class="card">
    <?= section_head('Create a backup', 'shield') ?>
    <p>Saves every table (students, attendance, users, notifications, audit logs, settings) to a SQL file, then checks the file before reporting success.
       Passwords are stored only as hashes, but a backup still contains private student data: keep downloaded files safe.</p>
    <form method="post" action="<?= e($pageUrl) ?>" data-confirm="Create a database backup now?">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <button class="btn primary" type="submit"><?= icon('plus') ?> Create backup now</button>
    </form>
    <p class="small text-muted">
        Automatic backups: <?= $autoDay > 0 ? 'on (when an administrator opens the dashboard and the newest backup is over ' . $autoDay . ' day(s) old)' : 'off (set "backup_auto_days" in config/config.local.php)' ?>.
        External scheduler URL: <?= $cron ? 'enabled' : 'disabled (set "backup_cron_token")' ?>. See docs/BACKUP_RECOVERY.md.
    </p>
</section>

<section class="card">
    <?= section_head('Backup history', 'clipboard') ?>
    <?php table_start('Backup history', true); ?>
        <thead><tr><th>Date</th><th>Type</th><th>File</th><th>Size</th><th>Rows</th><th>Status</th><th>By</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (!$history): echo empty_row(8, 'No backups yet.'); endif; ?>
        <?php foreach ($history as $b):
            $ok    = $b['status'] === 'ok';
            $hasFile = $b['file_name'] !== null && $b['kind'] !== 'restore';
            $exists  = $hasFile && ($p = backup_path((string) $b['file_name'])) !== null && is_file($p); ?>
            <tr>
                <td data-label="Date"><?= e(format_datetime((string) $b['created_at'])) ?></td>
                <td data-label="Type"><?= e(BACKUP_KINDS[$b['kind']] ?? $b['kind']) ?></td>
                <td data-label="File"><?= $b['file_name'] ? e($b['file_name']) : '—' ?><?= $b['message'] ? '<span class="cell-sub">' . e($b['message']) . '</span>' : '' ?></td>
                <td data-label="Size"><?= $hasFile && $ok ? e(backup_format_size((int) $b['size_bytes'])) : '—' ?></td>
                <td data-label="Rows"><?= $hasFile && $ok ? number_format((int) $b['row_count']) : '—' ?></td>
                <td data-label="Status"><?= $ok ? '<span class="badge success">OK</span>' : '<span class="badge danger">Failed</span>' ?><?= $hasFile && $ok && !$exists ? ' <span class="badge warning">File missing</span>' : '' ?></td>
                <td data-label="By"><?= e($b['username'] ?? 'System') ?></td>
                <td data-label="Actions">
                <?php if ($hasFile && $ok && $exists): ?>
                    <a class="btn secondary btn-sm" href="<?= e($pageUrl . '?download=' . (int) $b['id']) ?>">Download</a>
                    <form method="post" action="<?= e($pageUrl) ?>" class="inline-form">
                        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                        <button class="btn secondary btn-sm" type="submit" name="action" value="verify">Verify</button>
                    </form>
                    <button class="btn danger btn-sm" type="button" data-modal-open="restore-<?= (int) $b['id'] ?>">Restore…</button>
                    <form method="post" action="<?= e($pageUrl) ?>" class="inline-form">
                        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                        <button class="btn danger btn-sm" type="submit" name="action" value="delete" data-confirm-click="Delete this backup file permanently? This cannot be undone.">Delete</button>
                    </form>
                <?php elseif ($hasFile && !$exists): ?>
                    <form method="post" action="<?= e($pageUrl) ?>" class="inline-form">
                        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                        <button class="btn danger btn-sm" type="submit" name="action" value="delete" data-confirm-click="Remove this history entry?">Remove entry</button>
                    </form>
                <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    <?php table_end(); ?>
</section>

<?php foreach ($history as $b):
    if ($b['status'] !== 'ok' || $b['kind'] === 'restore' || $b['file_name'] === null) { continue; } ?>
    <?php modal_start('restore-' . (int) $b['id'], 'Restore this backup'); ?>
        <?php alert('danger', 'This REPLACES all current data (students, attendance, users, audit logs) with the data in the backup from ' . format_datetime((string) $b['created_at']) . '. Anything recorded since then is lost. A safety backup of the current data is made first.'); ?>
        <form method="post" action="<?= e($pageUrl) ?>" class="form-stack">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="restore">
            <input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
            <label>Your administrator password
                <input type="password" name="password" required autocomplete="current-password"></label>
            <label>Type <strong>RESTORE</strong> to confirm
                <input type="text" name="confirm_text" required autocomplete="off" pattern="RESTORE" title="Type RESTORE in capital letters"></label>
            <label class="check"><input type="checkbox" name="understand" value="1" required> I understand that current data will be replaced.</label>
            <div class="form-actions">
                <button class="btn danger" type="submit">Restore database</button>
                <button class="btn secondary" type="button" data-modal-close>Cancel</button>
            </div>
        </form>
    <?php modal_end(); ?>
<?php endforeach; ?>
<?php render_footer();
