<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$sort    = sort_from_request(AUDIT_SORTS, 'date', 'desc');
$filters = audit_filters_from_request();
$query   = clean_query($filters);
$result  = audit_search($filters, $sort, (int) get_str('page'));
$options = audit_filter_options();
$base    = url('admin/audit-logs.php');

$first = $result['total'] === 0 ? 0 : ($result['page'] - 1) * AUDIT_PAGE_SIZE + 1;
$last  = $first === 0 ? 0 : $first + count($result['rows']) - 1;

render_header('Audit Logs', 'audit');
page_head('Audit Logs', $result['total'] === 0
    ? 'No entries to show.'
    : 'Showing ' . number_format($first) . '–' . number_format($last) . ' of ' . plural($result['total'], 'entry', 'entries') . '.');
?>
<section class="card">
    <?= filter_bar($base, [
        toolbar_select('user', 'User', [AUDIT_SYSTEM_USER => 'System'] + array_combine($options['users'], $options['users']), $filters['user'], 'All users'),
        toolbar_select('action', 'Action', $options['actions'], $filters['action'], 'All actions'),
        search_input('q', $filters['q'], 'Search description'),
    ], [
        'active' => count(array_filter($filters, static fn($v): bool => $v !== '')),
        'hidden' => array_intersect_key($filters, ['table' => 1, 'from' => 1, 'to' => 1]) + sort_hidden($sort, ['date', 'desc']),
        'apply'  => null,
        'reset'  => null,
    ]) ?>
    <?php table_start('Audit log entries'); ?>
        <thead>
            <tr>
                <?= sort_th('Date', 'date', $sort, $base, $query) ?>
                <?= sort_th('User', 'user', $sort, $base, $query) ?>
                <?= sort_th('Action', 'action', $sort, $base, $query) ?>
                <?= sort_th('Table', 'table', $sort, $base, $query) ?>
                <th scope="col">Description</th>
                <th scope="col">Changes</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$result['rows']): ?>
                <?= empty_row(6, $query ? 'No log entries match your filters.' : 'No activity has been recorded yet.') ?>
            <?php endif; ?>
            <?php foreach ($result['rows'] as $log):
                $changes = audit_changes_json($log); ?>
                <tr>
                    <td><?= e(format_datetime($log['created_at'])) ?></td>
                    <td><?= e($log['username'] ?? 'System') ?></td>
                    <td><?= action_badge($log['action']) ?></td>
                    <td><?= e($log['table_name']) ?></td>
                    <td class="cell-wrap"><?= e($log['description']) ?></td>
                    <td>
                        <?php if ($changes !== null): ?>
                            <details>
                                <summary>View</summary>
                                <pre><?= e($changes) ?></pre>
                            </details>
                        <?php else: ?>
                            <span class="text-faint">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php table_end(); ?>
    <?= pagination($result['page'], $result['pages'], $base, $query + ['sort' => $sort[0], 'dir' => $sort[1]]) ?>
</section>
<?php render_footer();
