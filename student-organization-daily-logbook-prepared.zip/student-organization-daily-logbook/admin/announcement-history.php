<?php
require __DIR__ . '/../app/bootstrap.php';
require_announcer();

$filters = announcement_filters_from_request();
$sort    = sort_from_request(ANNOUNCEMENT_SORTS, 'date', 'desc');
$query   = clean_query($filters);
$result  = announcement_search_page($filters, $sort);
$base    = url('admin/announcement-history.php');
$hasFilter = $query !== [];

render_header('Announcement History', 'announce');
page_head('Announcement history', is_admin() ? 'Every announcement, who it reached and who has read it.' : 'The announcements you published and who has read them.', [
    ['label' => '+ New announcement', 'href' => url('admin/announcements.php'), 'class' => 'primary'],
], [['Announcements', url('admin/announcements.php')], ['History', null]]);
?>
<section class="card">
    <?= filter_bar($base, [
        search_input('q', $filters['q'], 'Search title or message', 'Search announcements'),
        toolbar_select('status', 'Status', ANNOUNCEMENT_STATUSES, $filters['status'], 'Any status'),
        toolbar_select('priority', 'Priority', array_map(static fn(array $p): string => $p[0], ANNOUNCEMENT_PRIORITIES), $filters['priority'], 'Any priority'),
        toolbar_select('audience', 'Audience', announcement_audiences(), $filters['audience'], 'Any audience'),
        sort_controls(ANNOUNCEMENT_SORTS, $sort, ['desc' => 'Newest / High first', 'asc' => 'Oldest / Low first']),
    ], ['active' => count($query)]) ?>

    <?php if (!$result['rows']): ?>
        <?= $hasFilter
            ? empty_state('No announcements match your filters', 'Try a different search or reset the filters.', '<a class="btn secondary" href="' . e($base) . '">Reset filters</a>', 'search')
            : empty_state('No announcements yet', 'Published announcements and their read receipts will appear here.', '<a class="btn primary" href="' . e(url('admin/announcements.php')) . '">Write the first announcement</a>', 'send') ?>
    <?php else: ?>
        <?php table_start('Announcement history', true); ?>
            <thead>
                <tr>
                    <?= sort_th('Announcement', 'title', $sort, $base, $query) ?>
                    <?= sort_th('Priority', 'priority', $sort, $base, $query) ?>
                    <th scope="col">Audience</th>
                    <?= sort_th('Published', 'date', $sort, $base, $query) ?>
                    <?= sort_th('Expires', 'expires', $sort, $base, $query) ?>
                    <th scope="col">Status</th>
                    <?= sort_th('Read', 'reads', $sort, $base, $query) ?>
                    <th scope="col" class="no-print">Open</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($result['rows'] as $a):
                    $total = (int) $a['recipient_count']; $read = (int) $a['read_count']; ?>
                    <tr>
                        <td data-label="Announcement" class="cell-wrap">
                            <strong><?php if ($a['is_pinned']): ?><span class="pin" title="Pinned"><?= icon('pin') ?><span class="sr-only">Pinned: </span></span><?php endif; ?><?= e($a['title']) ?></strong>
                            <span class="cell-sub">by <?= e($a['author'] ?? 'unknown') ?></span>
                        </td>
                        <td data-label="Priority"><?= announcement_priority_badge($a['priority']) ?></td>
                        <td data-label="Audience" class="cell-wrap"><?= e(announcement_audience_label($a['audience'])) ?></td>
                        <td data-label="Published"><?= e(format_datetime((string) $a['published_at'])) ?></td>
                        <td data-label="Expires"><?= $a['expires_at'] !== null ? e(format_date(substr((string) $a['expires_at'], 0, 10))) : '<span class="text-faint">Never</span>' ?></td>
                        <td data-label="Status"><?= announcement_status_badge($a) ?></td>
                        <td data-label="Read">
                            <div class="progress-cell"><?= progress_bar($total > 0 ? $read / $total * 100 : 0, 'Read by ' . $read . ' of ' . $total) ?><span><?= $read ?>/<?= $total ?></span></div>
                            <span class="cell-sub"><?= $total - $read ?> unread</span>
                        </td>
                        <td data-label="Open" class="no-print"><a class="btn secondary btn-sm" href="<?= e(url('admin/announcement-view.php', ['id' => (int) $a['id']])) ?>">View</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php table_end(); ?>
        <p class="small result-count"><?= e(plural($result['total'], 'announcement')) ?></p>
        <?= pagination($result['page'], $result['pages'], $base, $query + ['sort' => $sort[0], 'dir' => $sort[1]]) ?>
    <?php endif; ?>
</section>
<?php render_footer();
