<?php
require __DIR__ . '/../app/bootstrap.php';
require_admin();

$filters = student_filters_from_request();                 // year (duty day), course, status, q
$sort    = sort_from_request(STUDENT_SORTS, 'name');
$pageNo  = (int) get_str('page');

// URL pieces: filters only (for sort links), plus the sort (for everything else), minus the day (for the day tabs).
$filterQuery = clean_query($filters);
$listQuery   = $filterQuery + ($sort !== ['name', 'asc'] ? ['sort' => $sort[0], 'dir' => $sort[1]] : []);
$tabQuery    = array_diff_key($listQuery, ['year' => true]);
$hasFilter   = $filterQuery !== [];
$pageUrl     = url('admin/students.php');

/** Directory URL that keeps the current filters, sort and page. */
$listUrl = static function (array $extra = []) use ($listQuery, $pageUrl, $pageNo): string {
    $query = http_build_query($listQuery + ($pageNo > 1 ? ['page' => $pageNo] : []) + $extra);
    return $pageUrl . ($query !== '' ? '?' . $query : '');
};

/* ---- Handle form posts (then redirect) -------------------------------- */
if (is_post()) {
    $id     = (int) post_str('id');
    $result = handle_post([
        'save' => static function () use ($id): void {
            student_save(student_input_from_post(), $id);
            flash('success', $id > 0 ? 'Student updated.' : 'Student created.');
        },
        'delete' => static function () use ($id): void {
            $count = student_attendance_count($id);
            student_delete($id);
            flash('success', 'Student deleted together with their login and ' . plural($count, 'attendance record') . '.');
        },
    ] + student_lifecycle_handlers($id), 'student');

    $target = $listUrl();
    if ($result['outcome'] === ACTION_INVALID && $result['action'] === 'save') {
        remember_input($_POST);
        $target = $listUrl($id > 0 ? ['edit' => $id] : ['add' => 1]);
    }
    redirect($target);
}

/* ---- Page data -------------------------------------------------------- */
$edit = null;
if (get_str('edit') !== '') {
    $edit = student_find_with_username((int) get_str('edit'));
    if ($edit === null) {
        flash('warning', 'That student could not be found.');
    }
}
$modalOpen = $edit !== null || get_str('add') !== '';

$result   = students_page($filters, $sort, $pageNo);
$students = $result['rows'];
$pageNo   = $result['page'];
$courses  = students_courses();
$counts   = students_duty_day_counts();
$attCount = student_attendance_counts(array_column($students, 'id'));
$logins   = student_login_states(array_column($students, 'id'));

render_header('Students', 'students');
page_head('Student Management', '', [
    ['label' => '+ Add Student', 'href' => $listUrl(['add' => 1]), 'class' => 'primary'],
    ['label' => 'Import CSV', 'href' => url('admin/student-import.php')],
], [['Students', null]]);
?>
<section class="card library-card">
    <div class="library-head">
        <div>
            <span class="eyebrow">STUDENT DIRECTORY</span>
            <h2>Student Library</h2>
            <p>Search, add and manage every student record from one place.</p>
        </div>
        <div class="library-total">
            <strong><?= number_format($counts['all']) ?></strong>
            <span>Total Students</span>
        </div>
    </div>
</section>

<section class="card">
    <?= filter_bar($pageUrl, [
        search_input('q', $filters['q'], 'Search name or student number', 'Search students by name or student number'),
        toolbar_select('status', 'Status', STUDENT_STATUSES, $filters['status'], 'Any status'),
    ], [
        'active' => count(array_diff_key($filterQuery, ['year' => true, 'course' => true])),
        'hidden' => array_intersect_key($filterQuery, ['year' => true, 'course' => true]) + sort_hidden($sort),
        'apply'  => null,
        'reset'  => null,
    ]) ?>
    <p class="small result-count"><?= e(plural($result['total'], 'student')) ?><?= $hasFilter ? ' match your filters' : '' ?></p>

    <?php if (!$students): ?>
        <?= $hasFilter
            ? empty_state('No students match your filters', 'Try a different search, or reset the filters to see everyone.', '<a class="btn secondary" href="' . e($pageUrl) . '">Reset filters</a>', 'search')
            : empty_state('No students yet', 'Add a student, or import a whole class from a CSV file.', '<a class="btn primary" href="' . e($listUrl(['add' => 1])) . '">Add the first student</a>', 'users') ?>
    <?php else: ?>
    <?php table_start('Students', true); ?>
        <thead>
            <tr>
                <?= sort_th('Student No.', 'number', $sort, $pageUrl, $filterQuery) ?>
                <?= sort_th('Name', 'name', $sort, $pageUrl, $filterQuery) ?>
                <?= sort_th('Course', 'course', $sort, $pageUrl, $filterQuery) ?>
                <?= sort_th('Day / Position', 'day', $sort, $pageUrl, $filterQuery) ?>
                <?= sort_th('Status', 'status', $sort, $pageUrl, $filterQuery) ?>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student):
                $sid = (int) $student['id'];
                $login = $logins[$sid] ?? null; // null = no login account
                $isActive = $student['status'] === 'Active' && ($login === null || $login === 1); ?>
                <tr>
                    <td data-label="Student No."><?= e($student['student_number']) ?></td>
                    <td data-label="Name"><?= e(student_display_name($student)) ?></td>
                    <td data-label="Course"><?= e($student['course']) ?></td>
                    <td data-label="Day / Position"><?= e($student['year_level'] . (($student['position'] ?? '') !== '' ? ' / ' . $student['position'] : '')) ?></td>
                    <td data-label="Status"><?= status_badge($student['status']) ?><?= $login === 0 ? ' <span class="badge danger">Login off</span>' : '' ?></td>
                    <td data-label="Actions">
                        <div class="actions">
                            <a class="btn secondary btn-sm" href="<?= e(url('admin/student-view.php', ['id' => $sid])) ?>">View</a>
                            <a class="btn secondary btn-sm" href="<?= e($listUrl(['edit' => $sid])) ?>">Edit</a>
                            <?= action_menu([
                                $isActive
                                    ? action_form($listUrl(), 'deactivate', $sid, 'Deactivate', 'secondary',
                                        'Deactivate ' . $student['first_name'] . ' ' . $student['last_name'] . '? They will no longer be able to sign in or be given new attendance, but all ' . $attCount[$sid] . ' attendance record(s) are kept. You can reactivate them at any time.')
                                    : action_form($listUrl(), 'reactivate', $sid, 'Reactivate', 'secondary'),
                                delete_form($listUrl(), $sid,
                                    'PERMANENTLY delete ' . $student['first_name'] . ' ' . $student['last_name'] . ', their login and ' . plural($attCount[$sid], 'attendance record') . '? This cannot be undone. Use Deactivate instead to keep the history.'),
                            ], 'More actions for ' . student_display_name($student)) ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php table_end(); ?>
    <?= pagination($result['page'], $result['pages'], $pageUrl, $listQuery) ?>
    <?php endif; ?>
</section>

<?php
modal_start('student-modal', $edit ? 'Edit Student' : 'Add Student', $modalOpen, ['edit', 'add']);
view('partials/student-form', ['edit' => $edit, 'formAction' => $listUrl()]);
modal_end();

render_footer();
