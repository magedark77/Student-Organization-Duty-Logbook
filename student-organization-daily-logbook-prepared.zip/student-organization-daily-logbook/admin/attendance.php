<?php
require __DIR__ . '/../app/bootstrap.php';
require_attendance_access();

/* Old bookmark: attendance.php?record=1 now lives on its own page. */
if (get_str('record') === '1') {
    redirect(url('admin/record-attendance.php', ['date' => get_str('date') ?: date('Y-m-d')]));
}

/* ---- Handle form posts (then redirect) -------------------------------- */
if (is_post()) {
    $date   = post_str('attendance_date');
    $editId = (int) post_str('edit_id');
    $day    = is_valid_date($date) ? $date : date('Y-m-d');

    $result = handle_post([
        'save' => static function () use ($editId): void {
            // Only an administrator may replace an existing record, and only when editing it or after ticking the
            // "replace" box. Officers can only add new records, so they can never overwrite one by re-submitting.
            $mayReplace = can_modify_attendance() && ($editId > 0 || post_str('confirm_overwrite') === '1');
            try {
                $created = attendance_save(attendance_input_from_post(), post_str('reason'), $mayReplace);
            } catch (DuplicateAttendanceException $e) {
                if (can_modify_attendance()) {
                    throw new ValidationException('A record for this student and date already exists. Tick “Replace it” and enter a reason if you want to change it.', 'confirm_overwrite');
                }
                throw $e;
            }
            flash('success', $created ? 'Attendance recorded successfully.' : 'Attendance updated successfully. The change was saved to the history with your reason.');
        },
        'delete' => static function (): void {
            if (!can_modify_attendance()) {
                throw new ValidationException('Only administrators can delete attendance.');
            }
            attendance_delete((int) post_str('id'), post_str('reason'));
            flash('success', 'Attendance deleted. The deletion is kept in the change history.');
        },
    ], 'attendance', static function (string $action) use ($editId): void {
        if (is_restricted_staff() && ($action !== 'save' || $editId > 0)) {
            render_error_page(403, 'Access denied', 'Staff roles may only create attendance records; editing and deleting are restricted to administrators.');
        }
    });

    $target = url('admin/attendance.php', ['date' => $day]);
    if ($result['outcome'] === ACTION_INVALID && $result['action'] === 'save') {
        // Send the user back to the form with what they typed.
        remember_input($_POST);
        $target = $editId > 0
            ? url('admin/attendance.php', ['edit' => $editId])
            : url('admin/record-attendance.php', ['date' => $day]);
    }
    redirect($target);
}

/* ---- Page data -------------------------------------------------------- */
$date = get_str('date');
if (!is_valid_date($date)) {
    $date = date('Y-m-d');
}
$term  = get_str('q');
$day   = get_choice('day', DUTY_DAYS);
$sort  = sort_from_request(ATTENDANCE_SORTS, 'name');
$query = clean_query(['date' => $date, 'q' => $term, 'day' => $day]);

// Only administrators can edit; staff roles never see the edit dialog.
$edit = null;
if (get_str('edit') !== '' && !is_restricted_staff()) {
    $edit = attendance_find((int) get_str('edit'));
    if ($edit !== null) {
        $date = $edit['attendance_date'];
    } else {
        flash('warning', 'That attendance record could not be found.');
    }
}
$rows = attendance_for_date($date, $term, $day, $sort);

render_header('Attendance', 'attendance');
$incompleteCount = attendance_incomplete_count(null, $date, $date);
page_head('Attendance', '', [
    ['label' => '+ Record Attendance', 'href' => url('admin/record-attendance.php', ['date' => $date]), 'class' => 'primary'],
], [['Attendance', null]]);
?>
<section class="card">
    <?= filter_bar(url('admin/attendance.php'), [
        '<input type="date" name="date" value="' . e($date) . '" aria-label="Attendance date" data-autosubmit>',
        search_input('q', $term, 'Search student'),
        toolbar_select('day', 'Duty day', DUTY_DAYS, $day, 'All duty days'),
    ], [
        'active' => ($term !== '' ? 1 : 0) + ($day !== '' ? 1 : 0),
        'hidden' => sort_hidden($sort),
        'extra'  => ['<button type="button" class="btn secondary" data-print>Print</button>'],
        'apply'  => null,
        'reset'  => null,
    ]) ?>

    <?php if ($incompleteCount > 0): ?>
        <?php alert('warning', plural($incompleteCount, 'record') . ' on this date ' . ($incompleteCount === 1 ? 'has' : 'have') . ' a missing time-in or time-out (marked “Incomplete” below).'); ?>
    <?php endif; ?>
    <?= section_head(format_date($date), '', '<span class="small">' . e(plural(count($rows), 'record')) . '</span>') ?>

    <?php view('partials/attendance-table', [
        'rows'         => $rows,
        'showStudent'  => true,
        'actions'      => !is_restricted_staff(),
        'date'         => $date,
        'sort'         => $sort,
        'sortBase'     => url('admin/attendance.php'),
        'sortQuery'    => $query,
        'label'        => 'Attendance for ' . format_date($date),
        'emptyHtml'    => $rows ? '' : empty_state(($term !== '' || $day !== '') ? 'No records match your filters' : 'No attendance recorded for this date',
            ($term !== '' || $day !== '') ? 'Try a different search, or reset the filters.' : 'Use “Record Attendance” to add the first entry for ' . format_date($date) . '.',
            '<a class="btn primary" href="' . e(url('admin/record-attendance.php', ['date' => $date])) . '">+ Record Attendance</a>', 'clipboard'),
    ]); ?>
</section>

<?php
if ($edit !== null) {
    modal_start('attendance-modal', 'Edit Attendance', true, ['edit']);
    view('partials/attendance-form', ['edit' => $edit, 'date' => $date, 'context' => 'modal']);
    $history = attendance_changes_for((int) $edit['student_id'], (string) $edit['attendance_date']);
    if ($history): ?>
        <h3 class="history-title">Change history</h3>
        <ul class="feed history-feed">
            <?php foreach ($history as $h): ?>
                <li><span class="feed-dot" aria-hidden="true"></span><div>
                    <strong><?= e(ucfirst($h['change_type'])) ?><?= $h['reason'] ? ': ' . e($h['reason']) : '' ?></strong>
                    <small><?= e($h['username'] ?? 'Unknown user') ?> • <?= e(format_datetime((string) $h['changed_at'])) ?></small>
                </div></li>
            <?php endforeach; ?>
        </ul>
    <?php endif;
    modal_end();
}

render_footer();
