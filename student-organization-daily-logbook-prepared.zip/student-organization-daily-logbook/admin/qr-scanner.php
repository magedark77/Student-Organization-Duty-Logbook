<?php
require __DIR__ . '/../app/bootstrap.php';
require_attendance_access();
qr_ensure_ready();

// The site-wide policy blocks the camera; this one page may use it (and nothing else).
header('Permissions-Policy: camera=(self), microphone=(), geolocation=()');

$settings = qr_settings();
$enabled  = $settings['enabled'] === '1';
$https    = request_is_https() || in_array(strtolower((string) parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST)), ['localhost', '127.0.0.1', '[::1]', '::1'], true);
$httpsUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? '');

render_header('Scan QR Attendance', 'qrscan', ['scripts' => ['vendor/jsQR.js', 'js/qr-scanner.js'], 'styles' => ['css/qr.css']]);
page_head('Scan QR Attendance', 'Students show their QR code to the camera. The system decides Time In or Time Out and records the server time.', [
    ['label' => 'Today’s attendance', 'href' => url('admin/attendance.php')],
], [['Scan QR Attendance', null]]);
?>
<?php if (!$enabled): ?>
    <?php alert('warning', 'QR attendance is switched off' . (is_admin() ? '. Turn it on under QR Settings.' : '. Ask an administrator to turn it on.')); ?>
<?php endif; ?>
<?php if (!$https): ?>
    <div class="alert warning" role="alert"><strong>This page is not using HTTPS.</strong> Browsers allow camera access only on secure pages.
        <a href="<?= e($httpsUrl) ?>">Open the secure (https://) version</a>. Manual entry still works.</div>
<?php endif; ?>

<div class="qr-scan" data-qr-scanner
     data-endpoint="<?= e(url('admin/qr-scan.php')) ?>"
     data-login-url="<?= e(url('index.php')) ?>"
     data-csrf="<?= e(csrf_token()) ?>"
     data-enabled="<?= $enabled ? '1' : '0' ?>"
     data-tz="<?= e(APP_TIMEZONE) ?>"
     data-server-ms="<?= (int) round(microtime(true) * 1000) ?>">
    <section class="card qr-camera-card" aria-label="Camera">
        <div class="qr-stage" data-qr-stage>
            <video data-qr-video playsinline muted autoplay></video>
            <div class="qr-frame" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
            <div class="qr-idle" data-qr-idle>
                <?= icon('camera') ?>
                <p><strong>Camera is off</strong></p>
                <p>Press <b>Start Camera</b> and allow access when your browser asks.</p>
            </div>
            <div class="qr-busy" data-qr-busy hidden><span class="qr-spinner" aria-hidden="true"></span><span>Processing…</span></div>
        </div>
        <div class="qr-controls">
            <button type="button" class="btn primary" data-qr-start><?= icon('camera') ?> Start Camera</button>
            <button type="button" class="btn danger" data-qr-stop hidden>Stop Camera</button>
            <button type="button" class="btn secondary" data-qr-switch hidden>Switch Camera</button>
        </div>
        <p class="qr-status" data-qr-status role="status" aria-live="polite"></p>
        <ol class="qr-steps">
            <li>Press <b>Start Camera</b>.</li>
            <li>Hold the student’s QR code inside the frame, about 15–30 cm from the lens.</li>
            <li>Wait for the green confirmation before the next student.</li>
        </ol>
    </section>

    <div class="qr-side">
        <section class="card qr-clock" aria-label="Server time">
            <span class="qr-clock-label">Server time (<?= e(APP_TIMEZONE) ?>)</span>
            <strong data-qr-clock-time><?= e(date('g:i:s A')) ?></strong>
            <span data-qr-clock-date><?= e(date('l, F j, Y')) ?></span>
        </section>

        <section class="card qr-result is-idle" data-qr-result aria-live="assertive" aria-atomic="true"></section>

        <?php if ($settings['allow_manual'] === '1'): ?>
        <details class="card qr-manual-box" data-qr-manual-box>
            <summary>Camera not working? Enter the student number</summary>
            <form class="qr-manual" data-qr-manual data-no-loading autocomplete="off">
                <label>Student number
                    <input type="text" name="code" maxlength="60" inputmode="text" autocapitalize="off" spellcheck="false" placeholder="e.g. 2024-001">
                </label>
                <button type="submit" class="btn primary">Record attendance</button>
                <p class="hint">Manual entries are recorded the same way and are marked “manual” in the scan log.</p>
            </form>
        </details>
        <?php endif; ?>

        <section class="card" aria-labelledby="qr-recent-title">
            <?= section_head('This session', 'clock', '', 'qr-recent-title') ?>
            <ul class="qr-recent" data-qr-recent><li class="qr-recent-empty text-muted">No scans yet.</li></ul>
        </section>
    </div>
</div>
<?php render_footer();
