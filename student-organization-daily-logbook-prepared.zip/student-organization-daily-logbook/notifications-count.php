<?php
/** Tiny JSON endpoint: the signed-in user's unread count, polled by assets/js/app.js. */
require __DIR__ . '/app/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!user()) {
    http_response_code(401);
    echo '{"unread":0}';
    exit;
}
if (is_restricted_staff() && !within_duty_hours()) {
    http_response_code(403);
    echo '{"unread":0}';
    exit;
}
echo json_encode(['unread' => notifications_unread_count()]);
