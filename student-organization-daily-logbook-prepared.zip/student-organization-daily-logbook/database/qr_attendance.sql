-- QR code attendance: extra tables (kept identical to QR_TABLES_SQL in app/core/schema_tables.php).
-- Import once in phpMyAdmin (Import tab). Safe to re-run: every statement uses IF NOT EXISTS and nothing is deleted.
-- The app also creates these tables by itself the first time an administrator opens a QR page.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS qr_codes (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id     BIGINT UNSIGNED NOT NULL,
    token          CHAR(32) NOT NULL,
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    regenerated_at DATETIME NULL,
    regenerated_by BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_qr_student (student_id),
    UNIQUE KEY uq_qr_token (token),
    FOREIGN KEY (student_id)     REFERENCES students (id) ON DELETE CASCADE,
    FOREIGN KEY (regenerated_by) REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS qr_scans (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id      CHAR(32) NULL,
    student_id      BIGINT UNSIGNED NULL,
    attendance_id   BIGINT UNSIGNED NULL,
    attendance_date DATE NOT NULL,
    slot            VARCHAR(20) NULL,
    scanned_time    TIME NOT NULL,
    result          VARCHAR(20) NOT NULL,
    status          VARCHAR(20) NULL,
    minutes_off     SMALLINT UNSIGNED NULL,
    method          VARCHAR(10) NOT NULL DEFAULT 'camera',
    message         VARCHAR(255) NULL,
    scanned_by      BIGINT UNSIGNED NULL,
    ip              VARCHAR(45) NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_qr_scans_request (request_id),
    INDEX idx_qr_scans_date (attendance_date, result),
    INDEX idx_qr_scans_student (student_id, created_at),
    INDEX idx_qr_scans_user (scanned_by, result, created_at),
    FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE SET NULL,
    FOREIGN KEY (scanned_by) REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS qr_settings (
    setting_key   VARCHAR(50)  NOT NULL PRIMARY KEY,
    setting_value VARCHAR(100) NOT NULL,
    updated_by    BIGINT UNSIGNED NULL,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
