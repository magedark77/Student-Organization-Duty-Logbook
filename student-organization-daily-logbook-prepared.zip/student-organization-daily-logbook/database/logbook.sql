-- Student Office Daily Logbook — database schema
-- Import this file once (phpMyAdmin > Import) into an empty database.
-- Safe to re-run: every statement uses IF NOT EXISTS.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS students (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_number VARCHAR(50)  NOT NULL UNIQUE,
    first_name     VARCHAR(100) NOT NULL,
    middle_name    VARCHAR(100) NULL,
    last_name      VARCHAR(100) NOT NULL,
    course         VARCHAR(150) NOT NULL,
    year_level     VARCHAR(50)  NOT NULL,
    position       VARCHAR(50)  NULL,
    status         ENUM('Active', 'Inactive', 'Graduated') NOT NULL DEFAULT 'Active',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (last_name),
    INDEX (first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    role       ENUM('admin', 'student', 'president', 'internal_vp', 'external_vp', 'secretary') NOT NULL,
    student_id BIGINT UNSIGNED NULL,
    is_active  TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS attendance (
    id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id         BIGINT UNSIGNED NOT NULL,
    attendance_date    DATE NOT NULL,
    morning_time_in    TIME NULL,
    morning_time_out   TIME NULL,
    afternoon_time_in  TIME NULL,
    afternoon_time_out TIME NULL,
    remarks            VARCHAR(255) NULL,
    recorded_by        BIGINT UNSIGNED NULL,
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_date (student_id, attendance_date),
    INDEX (attendance_date),
    FOREIGN KEY (student_id)  REFERENCES students (id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT UNSIGNED NULL,
    action      VARCHAR(50)  NOT NULL,
    table_name  VARCHAR(100) NOT NULL,
    record_id   BIGINT UNSIGNED NULL,
    description VARCHAR(500) NOT NULL,
    old_values  JSON NULL,
    new_values  JSON NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id),
    INDEX (created_at),
    INDEX idx_audit_action (action),
    INDEX idx_audit_table (table_name),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- In-app notifications (one row per recipient).
CREATE TABLE IF NOT EXISTS notifications (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT UNSIGNED NOT NULL,
    type       VARCHAR(30)  NOT NULL,
    title      VARCHAR(150) NOT NULL,
    message    VARCHAR(500) NULL,
    link       VARCHAR(255) NULL,
    ref        VARCHAR(100) NULL,
    is_read    TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notifications_user (user_id, is_read, created_at),
    INDEX idx_notifications_ref (user_id, ref),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Single-use administrator recovery codes (only SHA-256 hashes are stored).
CREATE TABLE IF NOT EXISTS admin_recovery_codes (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT UNSIGNED NOT NULL,
    code_hash  CHAR(64) NOT NULL,
    used_at    DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_recovery_lookup (code_hash),
    INDEX idx_recovery_user (user_id, used_at),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Added after the first release (kept identical to IMPROVEMENT_TABLES_SQL in app/core/schema_tables.php).

CREATE TABLE IF NOT EXISTS announcements (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(150) NOT NULL,
    message      TEXT NOT NULL,
    audience     VARCHAR(50)  NOT NULL,
    priority     VARCHAR(20)  NOT NULL DEFAULT 'normal',
    status       VARCHAR(20)  NOT NULL DEFAULT 'active',
    is_pinned    TINYINT(1)   NOT NULL DEFAULT 0,
    published_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at   DATETIME     NULL,
    created_by   BIGINT UNSIGNED NULL,
    edited_at    DATETIME     NULL,
    edited_by    BIGINT UNSIGNED NULL,
    cancelled_at DATETIME     NULL,
    cancelled_by BIGINT UNSIGNED NULL,
    INDEX idx_announcements_status (status, published_at),
    INDEX idx_announcements_created_by (created_by),
    FOREIGN KEY (created_by)   REFERENCES users (id) ON DELETE SET NULL,
    FOREIGN KEY (edited_by)    REFERENCES users (id) ON DELETE SET NULL,
    FOREIGN KEY (cancelled_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS announcement_recipients (
    announcement_id BIGINT UNSIGNED NOT NULL,
    user_id         BIGINT UNSIGNED NOT NULL,
    read_at         DATETIME NULL,
    PRIMARY KEY (announcement_id, user_id),
    INDEX idx_recipients_user (user_id, read_at),
    FOREIGN KEY (announcement_id) REFERENCES announcements (id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)         REFERENCES users (id)         ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS attendance_changes (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    attendance_id   BIGINT UNSIGNED NULL,
    student_id      BIGINT UNSIGNED NULL,
    attendance_date DATE NOT NULL,
    change_type     VARCHAR(20)  NOT NULL,
    reason          VARCHAR(500) NULL,
    old_values      JSON NULL,
    new_values      JSON NULL,
    changed_by      BIGINT UNSIGNED NULL,
    changed_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_changes_attendance (attendance_id),
    INDEX idx_changes_student_date (student_id, attendance_date),
    INDEX idx_changes_type (change_type),
    FOREIGN KEY (changed_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS attendance_corrections (
    id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id         BIGINT UNSIGNED NOT NULL,
    attendance_date    DATE NOT NULL,
    morning_time_in    TIME NULL,
    morning_time_out   TIME NULL,
    afternoon_time_in  TIME NULL,
    afternoon_time_out TIME NULL,
    reason             VARCHAR(500) NOT NULL,
    status             VARCHAR(20)  NOT NULL DEFAULT 'pending',
    requested_by       BIGINT UNSIGNED NULL,
    reviewed_by        BIGINT UNSIGNED NULL,
    reviewed_at        DATETIME NULL,
    review_note        VARCHAR(500) NULL,
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_corrections_student (student_id, status),
    INDEX idx_corrections_status (status, created_at),
    FOREIGN KEY (student_id)   REFERENCES students (id) ON DELETE CASCADE,
    FOREIGN KEY (requested_by) REFERENCES users (id)    ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by)  REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS password_resets (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at    DATETIME NULL,
    created_by BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_resets_token (token_hash),
    INDEX idx_resets_user (user_id, used_at),
    FOREIGN KEY (user_id)    REFERENCES users (id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(100) NOT NULL,
    ip_address   VARCHAR(45)  NOT NULL,
    attempted_at DATETIME     NOT NULL,
    INDEX idx_login_attempts_user (username, attempted_at),
    INDEX idx_login_attempts_ip (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- QR code attendance (also available separately as database/qr_attendance.sql).

CREATE TABLE IF NOT EXISTS qr_codes (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id     BIGINT UNSIGNED NOT NULL,
    token          CHAR(32) NOT NULL,
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    regenerated_at DATETIME NULL,
    regenerated_by BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_qr_student (student_id),
    UNIQUE KEY uq_qr_token (token),
    FOREIGN KEY (student_id)     REFERENCES students (id) ON DELETE CASCADE,
    FOREIGN KEY (regenerated_by) REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS qr_scans (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id      CHAR(32) NULL,
    student_id      BIGINT UNSIGNED NULL,
    attendance_id   BIGINT UNSIGNED NULL,
    attendance_date DATE NOT NULL,
    slot            VARCHAR(20) NULL,
    scanned_time    TIME NOT NULL,
    result          VARCHAR(20) NOT NULL,
    status          VARCHAR(20) NULL,
    minutes_off     SMALLINT UNSIGNED NULL,
    method          VARCHAR(10) NOT NULL DEFAULT 'camera',
    message         VARCHAR(255) NULL,
    scanned_by      BIGINT UNSIGNED NULL,
    ip              VARCHAR(45) NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_qr_scans_request (request_id),
    INDEX idx_qr_scans_date (attendance_date, result),
    INDEX idx_qr_scans_student (student_id, created_at),
    INDEX idx_qr_scans_user (scanned_by, result, created_at),
    FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE SET NULL,
    FOREIGN KEY (scanned_by) REFERENCES users (id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS qr_settings (
    setting_key   VARCHAR(50)  NOT NULL PRIMARY KEY,
    setting_value VARCHAR(100) NOT NULL,
    updated_by    BIGINT UNSIGNED NULL,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Backup history (files live on the server; see docs/BACKUP_RECOVERY.md). Created automatically on upgrade too.
CREATE TABLE IF NOT EXISTS db_backups (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kind        VARCHAR(20)  NOT NULL DEFAULT 'manual',
    file_name   VARCHAR(100) NULL,
    size_bytes  BIGINT UNSIGNED NOT NULL DEFAULT 0,
    sha256      CHAR(64)     NULL,
    table_count INT UNSIGNED NOT NULL DEFAULT 0,
    row_count   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    status      VARCHAR(20)  NOT NULL DEFAULT 'ok',
    message     VARCHAR(255) NULL,
    created_by  BIGINT UNSIGNED NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_db_backups_created (created_at),
    INDEX idx_db_backups_status (status, kind, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
