<?php
/**
 * Scheduled backup endpoint for hosts without cron (e.g. InfinityFree). Point a free external scheduler
 * (cron-job.org, UptimeRobot "keyword" monitor, ...) at:   https://YOUR-SITE/backup-cron.php?token=YOUR_TOKEN
 * It does nothing unless "backup_cron_token" is set in config/config.local.php. The token is compared in constant time.
 */
require __DIR__ . '/app/bootstrap.php';

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

$expected = (string) app_config('backup_cron_token', '');
$given    = (string) ($_GET['token'] ?? ($_SERVER['HTTP_X_BACKUP_TOKEN'] ?? ''));

if (strlen($expected) < 24 || !hash_equals($expected, $given)) {
    usleep(500000); // slow down guessing
    http_response_code(404);
    exit("Not found\n");
}

try {
    $row = backup_create('scheduled', null);
    audit('BACKUP', 'db_backups', (int) $row['id'], 'Scheduled backup created via backup-cron.php: ' . $row['file_name']);
    echo 'OK ' . $row['file_name'] . "\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo "FAILED (see server error log)\n";
}
