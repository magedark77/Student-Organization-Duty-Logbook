# Changelog

## Backup & recovery, sign-in audit, package fixes
- **Added:** Backup & Recovery module (`admin/backups.php`, `app/domain/backups.php`): manual backups, integrity check + SHA-256, downloadable `.sql`,
  history (date, size, rows, status), verify, delete, restore with password + typed confirmation + mandatory pre-restore safety backup,
  optional dashboard-triggered schedule, token-protected `backup-cron.php` for external schedulers, `tools/restore-test.php` for restoring into a separate test database.
  New table `db_backups` (created automatically; also in `database/logbook.sql`). Guide: `docs/BACKUP_RECOVERY.md`.
- **Added:** successful and failed sign-ins are now written to the audit log (`LOGIN`, `LOGIN_FAILED`; username and IP only, never the password).
- **Fixed (package):** `config/config.local.php` with live database credentials was inside the ZIP; it is removed and `config/config.sample.php` (referenced by the README but missing) is restored.
  **Change that database password**, because it was exposed in the file you shared.
- **Tests:** 10 new checks for backup verification in `tests/run.php`. **None of this was executed: PHP and MySQL were not available in the build environment.**

## Review pass: sign-in throttling, token cleanup, documentation (no change to existing features)
- **Security:** sign-in is now throttled. After 6 failed attempts for one username, or 20 from one address, within 10 minutes, sign-in pauses
  (`LOGIN_MAX_FAILURES_PER_USER`, `LOGIN_MAX_FAILURES_PER_IP`, `LOGIN_LOCKOUT_MINUTES` in `app/core/config.php`). Failures are stored in the new
  `login_attempts` table (created automatically; also in `database/logbook.sql`), cleared on a successful sign-in and purged after a day.
  If the bookkeeping fails, sign-in still works. Trade-off: someone can pause a known username for 10 minutes by guessing wrongly on purpose.
- **Cleanup:** removed `announcement_audience_size()` (unused; `announcement_audience_sizes()` is the one in use). `qr.css` hard-coded 10 colours that
  the README says must be tokens; they are now tokens in `style.css` section 1 with identical values (no visual change).
- **Docs:** the README still described the old officer roles (Director, Manager I – VIII) and left the QR pages out of the project structure; both fixed.
- **Tests:** 3 unit checks and 2 integration checks for the throttle. **Not run here: PHP was not available**, so the edited PHP was only checked for
  balanced brackets. Run `php tests/run.php` and `php tests/integration.php` (throw-away database) before deploying.

## QR code attendance
- Added: scanner page, JSON scan endpoint, student QR codes (view, print, PNG, regenerate, disable), student "My QR Code",
  live monitor with filters and CSV export, QR settings, scan log. Tables: `qr_codes`, `qr_scans`, `qr_settings` (created automatically).
- Added: `config/config.sample.php` (the README referred to it but it was missing from the package).
- Changed (backwards compatible): `render_header()` accepts extra `scripts`/`styles`; `notify_attendance_saved()` has an optional
  4th argument to skip administrator notifications; sidebar has new links; `tests/run.php` allows `database/qr_attendance.sql`.
- Verified here with a SQLite stand-in for MySQL (97 rule checks, 49 HTTP checks, 22 headless-browser checks with a fake webcam showing a
  real QR code). **Not yet run against a real MySQL/MariaDB server**: after uploading, do the short checklist in `docs/QR_ATTENDANCE.md`
  (scan one student twice, open the monitor, export CSV).


## Cleanup pass: hygiene, accessibility, shared components (no behaviour change)
- **Security / hygiene:** a phpMyAdmin export of the live database (student numbers and names, phone numbers, password
  hashes, audit and SMS logs) was inside the project zip at `database/`. It is removed, `.gitignore` now excludes every
  `database/*.sql` except `logbook.sql`, and `tests/run.php` fails if another dump appears. **If that archive was shared,
  treat the data as exposed: change the admin and student passwords and the database password.**
- **Setup fix:** `config/` was missing, so a fresh install could not follow the README. `config/config.sample.php` (every
  setting documented) and `config/.htaccess` are back.
- **Bug fix: error pages** (403/419/500) drew a near-black card on the light page with dark text (contrast 1.35:1); they now use a white card.
- **Accessibility:** measured WCAG contrast of the colour tokens and fixed the ones under 4.5:1: secondary text on the page
  background (4.34 -> 5.09), completed-hours green (3.88 -> 4.75 on its tint), remaining-hours orange (4.29 -> 5.07),
  `.text-faint` now uses the muted colour, `.small` text 11px -> 12px.
- **Reusable components:** `section_head()` / `section_link()` replace 16 hand-written card headings (dashboard, student
  profile, student dashboard, attendance, announcement view, import preview). The officer edit dialog's role select now uses
  `field_select()`; the pass-through `officer_role_options_labelled()` is gone.
- **Performance:** the dashboard's announcement panel used the full history search (page query, COUNT and two sub-selects per
  row) to show three rows; `announcements_latest_active()` is one small query. `hero.jpg` re-encoded: 160 KB -> 90 KB, visually
  identical (mean difference 1.5/255). Images now get a one-month browser cache.
- **Structure:** the two unreferenced static prototypes (`dashboard/`, `logbook-demo/`) moved to `docs/prototypes/`.
  Stale role comments updated. The Revision 8 notes that sat above this file's title are now in order below.
- **Tests:** 6 new checks (section components, no stray database dumps, config sample). Not run in this environment: PHP was
  not available, so edited files were only checked for balanced brackets and tags; run `php tests/run.php` before deploying.

## Revision 8 (addendum): officer roles and Add Student
- **Add student:** the *Duty day* field is removed from the add/edit form. Existing students keep their stored duty day; new students are saved without one.
- **Officer roles:** the role list is now President, Internal Vice President, External Vice President and Secretary (Director, Assistant Director and Managers I – VIII are gone). Existing Director / Assistant Director accounts are converted to President / Internal Vice President automatically; Manager accounts stay listed, flagged "old role", until an administrator edits them and picks a new role. President and Internal VP can send announcements (as Director/Assistant Director could).

## Unreleased

### Changed
- New visual design: light content area with a navy sidebar and blue accents (all colours are tokens in `assets/css/style.css`, section 1).
- Sidebar brand, tagline and quote, top bar (account menu with Change Password / Logout), dashboard hero with photo, circular stat icons, announcements panel and quick actions.
- `APP_SHORT_NAME` is now "Student Organizations".

## Revision 8: search without an Apply button, queries out of pages
- **UX:** on filter bars that have no Apply button (Students, Attendance, Reports, Audit Logs, Corrections) the search box now
  also submits itself about 0.6 s after typing stops and keeps its focus after the page reloads; Enter still works, and without
  JavaScript nothing changes. (`form[data-live-search]` in `app.js`; set automatically by `filter_bar()` when `apply` is null.)
- **Structure:** the last SQL left inside pages moved to the domain layer: `student_login_states()` (Students list) and
  `student_pending_corrections_count()` (student dashboard). No page in `admin/`, `student/` or `reports/` talks to the database now.
- **Tests:** 175 checks (live-search flag). The live-search script was exercised in headless Chromium (debounce, focus kept, no
  focus jump when a dropdown submits the form). Still not run: `tests/integration.php` (needs MySQL).

## Revision 7: filter bars and tidy-up (no behaviour change beyond the filter bars)
- **UI: simpler filter bars (your request).** Students, Attendance, Reports (all four) and Audit Logs no longer show the sort
  dropdowns, the course/table dropdowns, the date boxes (Audit), Apply or Reset filters. Selects and dates apply as you change them,
  the search box applies on Enter, and column headers still sort. A course, table, date range or sort already in the URL is kept
  when you filter. Corrections also lost Apply and Reset; only Announcement History keeps its full filter bar.
- **Removed the Incomplete Attendance report** (page, tab, CSV/PDF export, its search query and sort list, and the dashboard "Review" link). Incomplete records are still flagged on the Attendance list, student profile, student dashboard and the dashboard's "Needs attention" panel.
- **Reusable component:** `filter_bar($action, $controls, $options)` now takes a named options array (`active`, `hidden`, `extra`,
  `apply`, `reset`) instead of six positional arguments; `apply => null` / `reset => null` leave a button out. New `sort_hidden()`
  keeps the current sort across a filter submit; `student_filter_controls()` has a `$withCourse` flag.
- **Cleanup:** `report_tabs()` lost an unused argument and a no-op ternary; the session check reads four columns instead of `SELECT *`.
- **Hygiene:** `config/config.sample.php` is back in the project (Revision 6 restored it, but it was missing from the zip received);
  the zip no longer contains `config/config.local.php`.
- **Tests:** 166 -> 174 checks (filter bar options, `sort_hidden`, course-less student filters).
- Not run: anything that needs MySQL (`tests/integration.php`); run it on a throw-away database.

## Revision 6: hardening and tidy-up (no behaviour change)
- **Fix:** the **Print** button on the Account Recovery page did nothing because it used an inline `onclick`, which the site's Content-Security-Policy blocks. It now uses the shared `data-print` hook.
- **UI fix: required marker.** The red `*` sat on its own line under the label of every required field (the label is a CSS grid). Labels now go through one helper, `field_label_text()`, including the four hand-written ones.
- **UI fix: Show / Now buttons.** The "Show" password button and the "Now" time button were positioned against the whole label, so a hint under the input (e.g. "At least 8 characters.") pushed them out of the field. `app.js` now wraps the input in `.input-wrap` and the buttons are centred on the input itself.
- **UI: sign-in, recovery and reset footers** are separate lines with a divider, and links look like links.
- **Security:** the Content-Security-Policy now states `script-src 'self'` and `object-src 'none'` explicitly. The last inline style attributes (other than progress-bar widths) moved into the stylesheet (`.recovery-codes`, `.input-upper`).
- **Performance:** the CSV student import prepares its INSERT statements once instead of once per row.
- **Consistency:** `students_duty_day_counts()` reads through `db_all()` like the other readers.
- **Project hygiene:** `config/config.sample.php` restored (README and the setup error refer to it); README no longer points at migration/seed SQL files that are not in the project (the app upgrades the schema itself); security checklist added; `.gitignore` also excludes database exports.
- **Tests:** `tests/run.php` now fails if any page or partial contains an inline event handler, which the Content-Security-Policy would silently block.

## Administrator account recovery
- New admin page **Account Recovery** (`admin/recovery.php`): generates 8 single-use recovery codes (current password required; shown once; only SHA-256 hashes stored; a new set replaces the old one).
- New public page `recover-admin.php`, linked from the sign-in page: username + unused recovery code + new password resets the administrator password. Failures share one message and are delayed slightly. Signed-in sessions of that account end because the password changed.
- New table `admin_recovery_codes` (created automatically, or run `database/migrate_admin_recovery.sql`). Every step is written to the audit log (codes are never logged).

## Members position, email removed
- **Members** added to the student positions.
- The student **email** field is removed from the form, profile, validation and CSV import/template. CSVs that still have an `email` column import fine (the column is ignored). The old `students.email` column is left in existing databases, unused; new installs no longer create it.

## Bus Manager replaced by Secretary
- The Bus Manager officer role is now **Secretary** (`secretary`), and "Bus Manager" is no longer a student position (Secretary was already one).
- Existing Bus Manager accounts are converted automatically on first load, or run `database/migrate_bus_manager_to_secretary.sql`. The seed account username is now `secretary` (same password as before).
- Students already saved with the Bus Manager position keep it and stay editable.

## Unreleased: refactor (no behaviour change)
- **Performance:** the dashboard and reports now aggregate attendance per student once and join afterwards
  (`students_with_totals()`), and the dashboard, analytics and header reuse results instead of repeating queries.
  3.5-4.5x faster on the heavy pages with 344,000 attendance rows; outputs verified identical (352 result sets on two databases).
  Student list paging and the composer's audience sizes moved to single SQL queries; the schema check on first sign-in is one query.
- **Structure:** `app/ui/` (rendering helpers) split from `app/core/` (infrastructure); `attendance`, `reports` split by responsibility;
  `bootstrap.php` loads three grouped lists instead of 26 `require` lines.
- **Reusable pieces:** `handle_post()` (CSRF + dispatch + failure reporting) replaces the same skeleton in eight pages;
  `filter_bar()` replaces nine hand-written filter forms; `action_menu()`; shared `reset_link_handler()`/`student_lifecycle_handlers()`; `sort_rows()`.
- **Long functions split:** `student_import_parse` (102 lines -> four functions), `report_export_build` (three builders), `attendance_save`.
- **UI/UX:** row actions tuck destructive buttons behind "More"; filters fold behind a "Filters" button on phones;
  duty-day tabs use two columns on phones; Apply/Reset sat together (Revision 7 makes them optional); one wording for "Reset filters".
- **Tooling:** `tests/seed-large.php`, `tests/benchmark.php`; unit tests 133 -> 163.

## Unreleased: A–H improvements
- **New tables** (auto-applied, see `database/migrate_improvements.sql`): `announcements`, `announcement_recipients` (read receipts),
  `attendance_changes`, `attendance_corrections`, `password_resets`, and `users.is_active`.
- **Announcements:** priority, pinning, expiry, edit/cancel, history page, read receipts, urgent confirmation, recipient inbox.
- **Attendance:** officers can no longer replace an existing record; duplicate warning; no future dates; afternoon cannot start before the morning ends;
  change history with reason; correction requests; "days present" now counts days with a time-in (not empty rows).
- **Students:** CSV import with preview, deactivate/reactivate, field-level errors, pagination, profile page.
- **Reports:** PDF export, hours-not-completed and incomplete-attendance reports, charts. `reports/export.php` serves every export; `export-csv.php` still works.
- **Accounts:** deactivation (signs the user out), one-time password-reset links, role-change confirmation.
- **UI:** breadcrumbs, mobile menu, stacked mobile tables, required markers, accessible status indicators, scrollable sidebar on short screens.
- `config/config.sample.php` added (the README always referred to it).

- **Announcements for the Director and Assistant Director.** They now have an Announcements page in their sidebar (same form and
  audiences as the administrator; subject to duty hours like the rest of their access). Sending is audited under their name.
- **Fix: adding an officer account failed on older databases.** The `users.role` column is now upgraded automatically to include
  every officer role (Director … Manager I – VIII), so `migrate_manager_roles.sql` no longer has to be run by hand. Accounts that were already saved with a blank role now
  appear in Officer Accounts (marked "No role") so they can be edited and fixed.
- **Code-quality pass (no feature changes).**
  - Every signed-in user, not only officers, is now signed out when an administrator deletes the account, moves it to a
    different kind of role, or resets its password (`session_is_current()` replaces `officer_session_is_current()`).
  - The yearly-hours milestone check now sums minutes in SQL (`attendance_year_minutes()`) instead of loading a student's
    whole attendance history on every save.
  - The unread-notification count is queried once per request (the header and the page body shared it).
  - Shared helpers replace duplicated code: `paginate()`, `sql_placeholders()`, `db_is_duplicate_key()`,
    `attendance_input_from_post()`; `app_config_error()` replaces a `$GLOBALS` flag; the icon set moved to `app/core/icons.php`.
  - The logo colours and the login heading now come from CSS tokens / `APP_SHORT_NAME` instead of being hard-coded.
- **UI/UX.** "Now" button on attendance time fields; success and info messages can be dismissed; the "(optional)" hint no
  longer wraps onto its own line; the last stat card no longer sits half-width on phones; shorter search placeholder so it
  is not cut off on phones; smoother button hover transitions.

- **Officer accounts can be edited and deleted.** Edit the username, role or password from Officer Accounts;
  delete a login you no longer need. Recorded attendance is kept. Changes are audited, the officer is notified of a
  password reset, and open officer sessions end when the account is deleted, loses the officer role or gets a new
  password (`officer_session_is_current()` in `app/core/auth.php`).
- **Notifications.** New `notifications` table, `app/domain/notifications.php`, the `notifications.php` page and a
  bell with an unread badge (refreshed by `notifications-count.php`). Automatic notifications for attendance
  recorded/updated/deleted, officer activity (to administrators), the yearly-hours milestone and password changes.
  Administrators get an **Announcements** page (`admin/announcements.php`) to message a group. Existing databases
  get the table automatically; `database/migrate_notifications.sql` does it by hand.
- Officer accounts can now be created for **Manager I – VIII** (roles `manager_1` … `manager_8`), with the same
  restricted, duty-hours-only access as the other officer roles. Existing databases need
  `database/migrate_manager_roles.sql` once.

## Revision 5: review and clean-up
**Security**
- The release archive contained `config/config.local.php` with live database credentials. It is no longer
  shipped; `config/config.sample.php` replaces it. **Rotate that database password** (it was distributed in an archive) and keep your own `config.local.php` on the server.

**Bug fixes**
- Printing a report produced a blank page (light text on a white background). The print stylesheet now
  switches to a dark-on-light palette, hides the sidebar, banners and dialogs, and keeps the progress
  and hours colours.
- Staff accounts (Director, Assistant Director, Bus Manager) that opened the student dashboard URL got a
  404 page; they are now sent to their own landing page.
- Staff signing in outside duty hours were told "Invalid username or password". They now see
  "This account can sign in only during duty hours (8:00 AM – 5:00 PM)", shown only after the password
  was verified so it does not reveal which usernames exist.
- The database connection now uses the same time zone as PHP, so audit-log times, the date filters and
  "recent activity" agree on hosts whose MySQL runs in UTC.
- Audit-log dates are shown as "Oct 5, 2026, 2:30 PM" instead of the raw database value.
- Missing `config.sample.php` (referenced by the README and the setup error message) added.

**Code quality**
- New `db_one()` and `db_value()`; about a dozen prepare/execute/fetch blocks in `app/domain/` now use
  the `db_*` helpers.
- `url($path, $query)` builds query strings safely; the hand-written `'?x=' . urlencode(...)` links are gone.
- New `plural()`, `table_start()/table_end()` and `hero()`; the duplicated hero markup (admin and student
  dashboards) and the repeated table wrapper (five places) now live in one function each.
- `sort_th()` accepts `null` so the attendance table no longer repeats a ternary per column.
- The dashboard's "recent activity" uses a dedicated `audit_recent()` query instead of running the audit
  search (with its COUNT query) and discarding all but four rows.
- `login_user()` returns the error message (or `null`), and `require_student()` / `home_url()` use
  clearer logic.
- Added `tests/run.php` (about 60 checks, no database needed).

**UI / CSS**
- The stylesheet is rewritten as one coherent file. The old one was two layers (a light theme and a
  dark theme) where later rules silently overrode earlier ones, with unused rules and about 40
  hard-coded colours. Every colour is now a token in one place. No visual change on screen (verified
  page by page against the previous version).
- Contrast of secondary text slightly increased; `theme-color` and `color-scheme` meta tags match the
  dark theme.

## Earlier revisions

### Revision 3: code quality, UI/UX, performance, structure
**Bug fixes**
- The admin student page (`admin/student-view.php`) showed `0h 0m completed this year` next to a remaining/percent figure that still counted every year. It now uses the same yearly calculation as the student dashboard (`attendance_year_progress()`).
- The error page's "Go back" link used a `javascript:` URL, which the Content-Security-Policy blocks. It is now a normal link (previous page on this site, otherwise the start page).
- Roles are shown as readable labels (Assistant Director, Bus Manager) instead of `Assistant_director`.
- Staff opening `attendance.php?edit=ID` no longer see a misleading "record could not be found" message.
- Added the missing `config/config.sample.php` (the README and an earlier changelog entry referred to it).

**Structure**
- `core/security.php` was split by responsibility: `request.php` (input, redirects, `run_action`), `session.php` (session, flash, remembered input), `security.php` (headers, escaping, CSRF).
- Database upgrades moved from `database.php` to `schema.php`; the audit helper and the audit-log query moved out of `auth.php` and `admin/audit-logs.php` into `domain/audit.php`.
- Form and list helpers moved from `components.php` to `forms.php`; `components.php` now holds display components only.
- Constants instead of string literals: `ROLE_*`, `STAFF_ROLES`, `ROLE_LABELS`, `DUTY_DAYS` (was `YEAR_LEVELS`; the database column keeps its name), `STUDENT_STATUSES`.

**Less duplication**
- `run_action()` replaces three copies of the same try/catch/flash block; `get_choice()` replaces repeated `in_array` validation.
- `toolbar_select()` and `sort_controls()` replace the hand-written `<select>` markup in four filter toolbars.
- `student_filters_from_request()`, `student_label()`, `student_subtitle()`, `attendance_year_progress()`, `change_password()`, `session_end()` and the `duty-day-tabs` partial each replace logic that existed in two or more places.
- `students_search()` takes a filters array instead of positional arguments.

**UI/UX**
- Audit logs are paginated (50 per page, previous/next and numbered links, filters and sort preserved). Before, only the newest 300 entries could ever be seen.
- Stylesheet: duplicate rules merged, repeated colours replaced by the existing tokens, the unused `.cols-3` rule removed, pagination styles added. No other visual change.

**Performance**
- Audit-log dropdowns no longer scan the whole table (`DISTINCT` on indexed columns); `idx_audit_action` and `idx_audit_table` are added automatically on existing installs and included in `logbook.sql`.
- The audit page reads one page of rows plus a count instead of up to 300 rows with JSON payloads.

### Revision: yearly hours and prepared statements
- **Required hours are per year.** The 100 hours now count over one calendar year instead of one month.
  - Monthly Report: new *This Month* and *Year to Date* columns; Remaining and Progress use Year to Date (1 January to the end of the selected month).
  - CSV export: matching columns (Hours This Month, Hours Year to Date, Remaining Hours, Year Progress).
  - Student pages (admin student view and student dashboard): Completed, Remaining and the progress bar count the current year only.
- **Every SQL statement is now a prepared statement.** Added `db_run($sql, $params)` in `app/core/database.php` and replaced the remaining `db()->query()` calls with it. Fixed values such as `'Active'` and `'admin'` are bound as parameters. `ORDER BY` columns stay on a fixed allow-list because identifiers cannot be bound.

Functionality, URLs and the database schema are unchanged. Everything below is internal quality,
security, performance or UI/UX work.

### Second rework (UI/UX, structure, motion)
- Reusable view helpers: `field_input()`, `field_select()`, `delete_form()`, `empty_row()` replace repeated markup in the student form, student list, attendance table, audit log and report pages.
- Motion system: page and card entrance, stat-card lift, button press, animated progress bars, modal open/close, count-up stat numbers, spinner on submit buttons, login background drift. Everything respects `prefers-reduced-motion`.
- Login: show/hide password toggle. Added an inline TC favicon.
- Security headers: Content-Security-Policy and Permissions-Policy.
- Performance: gzip and long-lived caching for versioned CSS/JS (`.htaccess`).
- Added the missing `config/config.sample.php` referenced by the README.

### Security
- **Database credentials removed from source.** Settings now live in `config/config.local.php`
  (git-ignored, web-blocked). **Rotate the old database password** — it was in the original files.
- Removed `ADMIN_LOGIN.txt` (it sat in the web root and was publicly downloadable).
- Session stores only id/username/role/student_id — no longer the password hash.
- Warning banner while the default admin password is still in use.
- Login form is CSRF-protected; login timing no longer reveals whether a username exists.
- Raw SQL errors are no longer shown to users; they are logged and replaced by friendly messages.
- `.htaccess` protection for `app/`, `config/`, `database/`, and for `.sql`/`.md` files.
- Security headers (X-Frame-Options, nosniff, Referrer-Policy); signed-in pages are not cached.
- CSV export neutralises spreadsheet formulas and adds a UTF-8 BOM (accented names open correctly in Excel).

### Bugs fixed
- Unauthenticated visits to `admin/*` redirected to a non-existent `admin/index.php` (404).
- Creating a student with a duplicate username left a half-saved student; saves are now transactional.
- Deleting a student left an orphaned, broken login; the login is now deleted with the student.
- Searching a full name ("Juan Cruz") failed for students without a middle name.
- The students search box dropped the selected year filter; "All Students" count ignored non-standard year levels.
- Editing attendance for an inactive student could silently modify another student's record.
- Server-side validation added (required fields, lengths, email, dates, password length when editing).
- Student-view and similar pages showed raw `HH:MM:SS` and blank " - " for empty sessions.

### Code quality & structure
- The duration helper was copy-pasted 5 times under different names; now one `domain/duration.php`.
- Minified one-line pages split into readable logic + templates; SQL moved to `app/domain/`.
- Layout, sidebar, flash messages, tables, stat cards, progress bars and forms are now shared components.
- `export-csv.php` no longer fakes a `$_GET` flag and includes another page.
- Inline `onclick`/`onsubmit` handlers replaced by `data-*` attributes; JS rewritten with focus management.

### Performance
- Dashboard "total logged" is computed in SQL instead of loading every attendance row into PHP.
- Dashboard counts consolidated into one query; schema upgrade checks run once per session, not on every request.
- Google Fonts loaded with `<link>` + preconnect instead of a render-blocking CSS `@import`.
- Assets are cache-busted by file modification time.

### UI/UX
- Add/Edit student moved from the bottom of the page into a dialog; attendance create/edit forms share one component.
- Forms keep what you typed when validation fails.
- Empty states, colour-coded status badges, 12-hour times, report totals row and progress bars.
- Focus rings, skip link, dialog focus trap, proper table captions/ARIA, reduced-motion and safe-area support.
- Date filter submits on change; "Today" shortcut; delete confirmations name the record.
- Sorting (click column headers) and filters (duty day, course, status, search) on Monthly Report, CSV export, Students, Attendance and Audit Logs (user, action, table, date range).
- Completed hours shown in green, remaining hours in orange (green when finished); progress bar fills green.

### Revision 4: TechHub dark UI
- Dark theme across all pages; icon sidebar with club logo and tagline, top bar with student search and user chip.
- Admin dashboard: hero banner, five-card stat row, today attendance table, Today / Recent Activity / Quick Actions panels. Student dashboard gets the same hero and stat row.
- New icons and brand_logo() in components.php; nav_items() now returns an icon as the third entry.

### Officer Accounts
- New admin page `admin/officers.php` (domain logic in `app/domain/officers.php`) to create Director, Assistant Director and Bus Manager logins. Added helpers `db_all()`, `format_datetime()`, `field_password()` and an `officers` icon.
