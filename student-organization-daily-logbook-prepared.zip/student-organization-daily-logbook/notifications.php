<?php
require __DIR__ . '/app/bootstrap.php';
require_login();

$userId  = (int) user()['id'];
$pageUrl = url('notifications.php');

/* Opening a notification marks it as read, then goes to the page it points at. */
if (!is_post() && ($openId = (int) get_str('open')) > 0) {
    $opened = notification_find($openId, $userId);
    if ($opened !== null) {
        notification_mark_read($openId, $userId);
        redirect(notification_href($opened) ?? $pageUrl);
    }
    redirect($pageUrl);
}

$unreadOnly = get_str('filter') === 'unread';

/* ---- Handle form posts (then redirect back to the same filter and page) ---- */
if (is_post()) {
    check_csrf();
    $action = post_str('action');
    $id     = (int) post_str('id');
    $page   = (int) post_str('page');
    $back   = url('notifications.php', [
        'filter' => post_str('filter') === 'unread' ? 'unread' : '',
        'page'   => $page > 1 ? $page : '',
    ]);

    $outcome = run_action('notification ' . $action, static function () use ($action, $id, $userId): void {
        switch ($action) {
            case 'read':
                notification_mark_read($id, $userId);
                break;
            case 'delete':
                notification_delete($id, $userId);
                break;
            case 'read_all':
                $count = notifications_mark_all_read($userId);
                flash('success', $count > 0 ? plural($count, 'notification') . ' marked as read.' : 'You have no unread notifications.');
                break;
            case 'clear_read':
                $count = notifications_clear_read($userId);
                flash('success', $count > 0 ? plural($count, 'read notification') . ' deleted.' : 'There are no read notifications to delete.');
                break;
            default:
                throw new ValidationException('Unknown notification action.');
        }
    });
    redirect($outcome === ACTION_OK ? $back : $pageUrl);
}

$result  = notifications_for_user($userId, $unreadOnly, (int) get_str('page'));
$unread  = notifications_unread_count($userId);
$hidden  = static fn(): string => '<input type="hidden" name="filter" value="' . ($unreadOnly ? 'unread' : '') . '">'
    . '<input type="hidden" name="page" value="' . (int) $result['page'] . '">';

render_header('Notifications', 'notifications');
page_head('Notifications', $unread > 0 ? 'You have ' . plural($unread, 'unread notification') . '.' : "You're all caught up.");
?>
<section class="card">
    <div class="toolbar no-print notif-toolbar">
        <nav class="notif-filter" aria-label="Filter notifications">
            <a class="notif-filter-link<?= $unreadOnly ? '' : ' active' ?>" href="<?= e($pageUrl) ?>"<?= $unreadOnly ? '' : ' aria-current="page"' ?>>All</a>
            <a class="notif-filter-link<?= $unreadOnly ? ' active' : '' ?>" href="<?= e(url('notifications.php', ['filter' => 'unread'])) ?>"<?= $unreadOnly ? ' aria-current="page"' : '' ?>>Unread<?= $unread > 0 ? ' (' . $unread . ')' : '' ?></a>
        </nav>
        <span class="notif-toolbar-actions">
            <form method="post" action="<?= e($pageUrl) ?>">
                <?= csrf_field() ?><?= $hidden() ?>
                <input type="hidden" name="action" value="read_all">
                <button class="btn secondary btn-sm" type="submit"<?= $unread > 0 ? '' : ' disabled' ?>>Mark all as read</button>
            </form>
            <form method="post" action="<?= e($pageUrl) ?>" data-confirm="Delete all notifications you have already read?">
                <?= csrf_field() ?><?= $hidden() ?>
                <input type="hidden" name="action" value="clear_read">
                <button class="btn secondary btn-sm" type="submit">Clear read</button>
            </form>
        </span>
    </div>

    <?php if (!$result['rows']): ?>
        <p class="notif-empty"><?= $unreadOnly ? 'No unread notifications.' : 'No notifications yet. Updates about your attendance and announcements will appear here.' ?></p>
    <?php else: ?>
        <ul class="notif-list">
            <?php foreach ($result['rows'] as $n):
                [$typeLabel, $typeTone] = NOTIFICATION_TYPES[$n['type']] ?? [ucfirst((string) $n['type']), 'neutral'];
                $unreadItem = (int) $n['is_read'] === 0;
                $href       = notification_href($n); ?>
                <li class="notif-item<?= $unreadItem ? ' is-unread' : '' ?>">
                    <span class="notif-dot" aria-hidden="true"></span>
                    <div class="notif-body">
                        <div class="notif-meta">
                            <span class="badge <?= e($typeTone) ?>"><?= e($typeLabel) ?></span>
                            <time datetime="<?= e(date('c', (int) strtotime((string) $n['created_at']))) ?>" title="<?= e(format_datetime((string) $n['created_at'])) ?>"><?= e(notification_age((string) $n['created_at'])) ?></time>
                            <?php if ($unreadItem): ?><span class="sr-only">Unread</span><?php endif; ?>
                        </div>
                        <h2 class="notif-title">
                            <?php if ($href !== null): ?>
                                <a href="<?= e(url('notifications.php', ['open' => $n['id']])) ?>"><?= e($n['title']) ?></a>
                            <?php else: ?>
                                <?= e($n['title']) ?>
                            <?php endif; ?>
                        </h2>
                        <?php if ((string) $n['message'] !== ''): ?><p class="notif-text"><?= e($n['message']) ?></p><?php endif; ?>
                    </div>
                    <div class="notif-actions no-print">
                        <?php if ($unreadItem): ?>
                            <form method="post" action="<?= e($pageUrl) ?>">
                                <?= csrf_field() ?><?= $hidden() ?>
                                <input type="hidden" name="action" value="read">
                                <input type="hidden" name="id" value="<?= (int) $n['id'] ?>">
                                <button class="btn secondary btn-sm" type="submit">Mark read</button>
                            </form>
                        <?php endif; ?>
                        <?= delete_form($pageUrl, (int) $n['id'], 'Delete this notification?', ['filter' => $unreadOnly ? 'unread' : '', 'page' => $result['page']]) ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <?= pagination($result['page'], $result['pages'], $pageUrl, $unreadOnly ? ['filter' => 'unread'] : []) ?>
    <?php endif; ?>
</section>
<?php render_footer();
