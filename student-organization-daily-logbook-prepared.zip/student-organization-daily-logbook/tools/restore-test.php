<?php
/**
 * Restore a backup into a SEPARATE, EMPTY test database and compare row counts. Never touches production.
 *
 *   php tools/restore-test.php path/to/logbook_YYYYMMDD_HHMMSS_xxxxxxxx.sql  test_database_name
 *
 * Uses the db_host / db_user / db_pass from config/config.local.php; the test database must already exist and its name
 * must differ from the production db_name.
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$_SERVER['SCRIPT_FILENAME'] = dirname(__DIR__) . '/index.php';
$_SERVER['REQUEST_METHOD']  = 'GET';
require dirname(__DIR__) . '/app/bootstrap.php';

[$script, $file, $testDb] = $argv + [null, null, null];
if (!$file || !$testDb) {
    fwrite(STDERR, "Usage: php tools/restore-test.php <backup.sql> <test_database_name>\n");
    exit(2);
}
if ($testDb === db_setting('name')) {
    fwrite(STDERR, "Refusing: '{$testDb}' is the production database.\n");
    exit(2);
}
$check = backup_verify_file($file);
echo ($check['ok'] ? 'Verify: OK' : 'Verify: FAILED') . " - {$check['message']}\n";
if (!$check['ok']) {
    exit(1);
}

$pdo = new PDO('mysql:host=' . db_setting('host') . ';dbname=' . $testDb . ';charset=utf8mb4', db_setting('user'), db_setting('pass'), [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
$n = backup_execute_file($pdo, $file);
echo "Executed {$n} statements into {$testDb}.\n";

$rows = 0;
foreach (backup_tables($pdo) as $table) {
    $c = (int) $pdo->query('SELECT COUNT(*) FROM `' . str_replace('`', '``', $table) . '`')->fetchColumn();
    echo str_pad($table, 32) . $c . "\n";
    $rows += $c;
}
echo "Total rows restored: {$rows}; backup declared: {$check['rows']}\n";
echo $rows === $check['rows'] ? "RESULT: PASS\n" : "RESULT: MISMATCH\n";
exit($rows === $check['rows'] ? 0 : 1);
