<?php
require __DIR__ . '/app/bootstrap.php';

session_end();
redirect(url('index.php'));
