<?php
require __DIR__ . '/app/bootstrap.php';
require_login();

$userId  = (int) user()['id'];
$pageUrl = url('my-announcements.php');

/* One announcement: only recipients can open it, and opening it records THEIR read receipt (never anyone else's). */
if (($openId = (int) get_str('id')) > 0) {
    $item = announcement_find_for_user($openId, $userId);
    if ($item === null) {
        render_error_page(404, 'Announcement not found', 'This announcement does not exist, was cancelled, or was not addressed to you.');
    }
    announcement_mark_read($openId, $userId);
    $state = announcement_status($item);
    render_header($item['title'], 'inbox');
    page_head('Announcement', 'Published ' . format_datetime((string) $item['published_at']) . ($item['author'] ? ' by ' . $item['author'] : ''), [
        ['label' => '← All announcements', 'href' => $pageUrl],
    ], [['Announcements', $pageUrl], [mb_strimwidth($item['title'], 0, 40, '…'), null]]);
    ?>
    <article class="card announcement-card priority-<?= e($item['priority']) ?>">
        <div class="notif-meta">
            <?= announcement_priority_badge($item['priority']) ?>
            <?php if ($item['is_pinned']): ?><span class="badge info"><?= icon('pin') ?>Pinned</span><?php endif; ?>
            <?php if ($state === 'expired'): ?><span class="badge neutral">Expired</span><?php endif; ?>
            <?php if ($item['expires_at'] !== null && $state === 'active'): ?><span class="small">Valid until <?= e(format_date(substr((string) $item['expires_at'], 0, 10))) ?></span><?php endif; ?>
        </div>
        <h2><?= e($item['title']) ?></h2>
        <div class="announcement-body"><?= nl2br(e($item['message'])) ?></div>
    </article>
    <?php
    render_footer();
    exit;
}

$tab    = get_choice('tab', ['current', 'archive'], 'current');
$term   = get_str('q');
$result = announcements_for_user($userId, $tab, $term, (int) get_str('page'));
$query  = clean_query(['tab' => $tab === 'archive' ? 'archive' : '', 'q' => $term]);
$unread = announcements_unread_summary($userId)['unread'];

render_header('Announcements', 'inbox');
page_head('Announcements', $unread > 0 ? 'You have ' . plural($unread, 'unread announcement') . '.' : 'You are up to date.', [], [['Announcements', null]]);
?>
<section class="card">
    <div class="toolbar no-print notif-toolbar">
        <nav class="notif-filter" aria-label="Announcement list">
            <a class="notif-filter-link<?= $tab === 'current' ? ' active' : '' ?>" href="<?= e(url('my-announcements.php')) ?>"<?= $tab === 'current' ? ' aria-current="page"' : '' ?>>Current</a>
            <a class="notif-filter-link<?= $tab === 'archive' ? ' active' : '' ?>" href="<?= e(url('my-announcements.php', ['tab' => 'archive'])) ?>"<?= $tab === 'archive' ? ' aria-current="page"' : '' ?>>Archive (expired)</a>
        </nav>
        <form method="get" action="<?= e($pageUrl) ?>" class="inline-search" role="search">
            <?php if ($tab === 'archive'): ?><input type="hidden" name="tab" value="archive"><?php endif; ?>
            <input type="search" name="q" value="<?= e($term) ?>" placeholder="Search announcements" aria-label="Search announcements">
            <button class="btn secondary btn-sm" type="submit">Search</button>
            <?php if ($term !== ''): ?><a class="btn secondary btn-sm" href="<?= e(url('my-announcements.php', $tab === 'archive' ? ['tab' => 'archive'] : [])) ?>">Reset</a><?php endif; ?>
        </form>
    </div>

    <?php if (!$result['rows']): ?>
        <?= $term !== ''
            ? empty_state('No announcements match your search', 'Try different words or reset the search.', '', 'search')
            : empty_state($tab === 'archive' ? 'Nothing in the archive' : 'No announcements right now', $tab === 'archive' ? 'Expired announcements will be kept here.' : 'New announcements from the administrators will appear here.', '', 'send') ?>
    <?php else: ?>
        <ul class="notif-list announcement-list">
            <?php foreach ($result['rows'] as $a):
                $isUnread = $a['read_at'] === null;
                $snippet  = mb_strlen($a['message']) > 160 ? mb_substr($a['message'], 0, 157) . '…' : $a['message']; ?>
                <li class="notif-item priority-<?= e($a['priority']) ?><?= $isUnread ? ' is-unread' : '' ?>">
                    <span class="notif-dot" aria-hidden="true"></span>
                    <div class="notif-body">
                        <div class="notif-meta">
                            <?= announcement_priority_badge($a['priority']) ?>
                            <?php if ($a['is_pinned']): ?><span class="badge info"><?= icon('pin') ?>Pinned</span><?php endif; ?>
                            <?= $isUnread ? '<span class="badge warning">New</span>' : '<span class="badge neutral">' . icon('check') . 'Read</span>' ?>
                            <time datetime="<?= e(date('c', (int) strtotime((string) $a['published_at']))) ?>"><?= e(notification_age((string) $a['published_at'])) ?></time>
                        </div>
                        <h3 class="notif-title"><a href="<?= e(url('my-announcements.php', ['id' => (int) $a['id']])) ?>"><?= e($a['title']) ?></a></h3>
                        <p class="notif-text"><?= e($snippet) ?></p>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <?= pagination($result['page'], $result['pages'], $pageUrl, $query) ?>
    <?php endif; ?>
</section>
<?php render_footer();
